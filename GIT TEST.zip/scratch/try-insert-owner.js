const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = 'https://cyjzbkdxhlzeqfmamdau.supabase.co';
const supabaseKey = 'sb_publishable__qLGRXfnfzbVqQZJippZVQ_K8lkNqkR';

const supabase = createClient(supabaseUrl, supabaseKey);

async function tryInsert() {
  console.log('--- Testing direct client-side insert into theater_owners ---');
  
  // Try inserting a dummy row with a random UUID
  const dummyUserId = '00000000-0000-0000-0000-000000000000';
  const demoTheatreId = 'dddd58fe-82c1-45fc-aadf-79613cbdb122'; // Demo cinema

  const { data, error } = await supabase
    .from('theater_owners')
    .insert({
      user_id: dummyUserId,
      theatre_id: demoTheatreId,
      role: 'owner'
    })
    .select();

  if (error) {
    console.error('Insert failed:', error.message);
  } else {
    console.log('Insert succeeded! Row created:', data);
    
    // Clean up the dummy row
    await supabase
      .from('theater_owners')
      .delete()
      .eq('user_id', dummyUserId);
  }
}

tryInsert();
