const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = 'https://cyjzbkdxhlzeqfmamdau.supabase.co';
const supabaseKey = 'sb_publishable__qLGRXfnfzbVqQZJippZVQ_K8lkNqkR';

const supabase = createClient(supabaseUrl, supabaseKey);

async function listOwners() {
  console.log('--- Querying theater_owners Table ---');
  const { data: owners, error } = await supabase
    .from('theater_owners')
    .select(`
      id,
      user_id,
      theatre_id,
      role
    `);

  if (error) {
    console.error('Error fetching theater owners:', error.message);
  } else {
    console.log(`Found ${owners?.length || 0} theater owner mappings:`);
    owners?.forEach(o => {
      console.log(`Mapping ID: ${o.id}, User Auth ID: ${o.user_id}, Theatre ID: ${o.theatre_id}, Role: ${o.role}`);
    });
  }
}

listOwners();
