const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = 'https://cyjzbkdxhlzeqfmamdau.supabase.co';
const supabaseKey = 'sb_publishable__qLGRXfnfzbVqQZJippZVQ_K8lkNqkR';

const supabase = createClient(supabaseUrl, supabaseKey);

async function checkData() {
  console.log('--- Checking Shows in DB ---');
  const { data: shows, error: showsError } = await supabase
    .from('shows')
    .select(`
      id,
      start_time,
      price,
      movie_id,
      screen_id
    `)
    .limit(10);
  
  if (showsError) {
    console.error('Error fetching shows:', showsError.message);
  } else {
    console.log(`Found ${shows?.length || 0} shows:`);
    shows?.forEach(s => {
      console.log(`Show ID: ${s.id}, Movie ID: ${s.movie_id}, Start Time: ${s.start_time}, Screen ID: ${s.screen_id}`);
    });
  }

  console.log('\n--- Checking Event Shows in DB ---');
  const { data: eventShows, error: eventShowsError } = await supabase
    .from('event_shows')
    .select(`
      id,
      start_time,
      price,
      event_id,
      screen_id
    `)
    .limit(10);

  if (eventShowsError) {
    console.error('Error fetching event shows:', eventShowsError.message);
  } else {
    console.log(`Found ${eventShows?.length || 0} event shows:`);
    eventShows?.forEach(es => {
      console.log(`Event Show ID: ${es.id}, Event ID: ${es.event_id}, Start Time: ${es.start_time}, Screen ID: ${es.screen_id}`);
    });
  }

  console.log('\n--- Checking Theatres in DB ---');
  const { data: theatres, error: theatresError } = await supabase
    .from('theatres')
    .select('id, name, location')
    .limit(10);
  
  if (theatresError) {
    console.error('Error fetching theatres:', theatresError.message);
  } else {
    console.log(`Found ${theatres?.length || 0} theatres:`);
    theatres?.forEach(t => {
      console.log(`Theatre ID: ${t.id}, Name: ${t.name}`);
    });
  }
}

checkData();
