const { createClient } = require('@supabase/supabase-js');

const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

async function runHerdTest() {
    console.log('Fetching a valid show and available seat...');
    
    // Find an active show
    const { data: shows, error: showErr } = await supabase
        .from('shows')
        .select('id, screen_id')
        .limit(1);
        
    if (showErr || !shows || shows.length === 0) {
        console.error('No shows found:', showErr);
        return;
    }
    
    const showId = shows[0].id;
    const screenId = shows[0].screen_id;
    
    // Find an available seat
    const { data: seats, error: seatErr } = await supabase
        .from('seats')
        .select('id, row, col')
        .eq('screen_id', screenId)
        .limit(1);
        
    if (seatErr || !seats || seats.length === 0) {
        console.error('No seats found:', seatErr);
        return;
    }
    
    const seatId = seats[0].id;
    console.log(`Found Show: ${showId}`);
    console.log(`Found Seat: ${seats[0].row}${seats[0].col} (${seatId})`);
    
    // Make sure the seat is unlocked/unbooked first
    await supabase.from('bookings').delete().eq('show_id', showId).eq('seat_id', seatId);

    const HERD_SIZE = 1000;
    console.log(`\n🚀 Launching THUNDERING HERD test with ${HERD_SIZE} concurrent users...`);
    console.log(`(We cap at 1,000 locally to avoid triggering Cloudflare DDoS protection, but the DB lock mechanism handles 1,000,000 the exact same way)`);

    const start = Date.now();
    
    // Create promises for simultaneous execution
    const requests = Array.from({ length: HERD_SIZE }).map((_, i) => {
        return supabase.rpc('lock_seat', {
            p_show_id: showId,
            p_seat_id: seatId,
            p_session_id: `hacker_session_${i}`
        });
    });

    // Fire them all at once
    const results = await Promise.all(requests);
    const duration = Date.now() - start;

    const successes = results.filter(r => r.data && r.data[0] && r.data[0].success === true);
    const failures = results.filter(r => r.error || (r.data && r.data[0] && r.data[0].success === false));
    
    console.log(`\n⏱️  Test completed in ${duration}ms`);
    console.log(`\n📊 RESULTS:`);
    console.log(`✅ Successes: ${successes.length} (Should be exactly 1)`);
    console.log(`❌ Failures: ${failures.length} (Should be ${HERD_SIZE - 1})`);
    
    // Analyze failures
    const errorTypes = {};
    failures.forEach(f => {
        const msg = f.error ? f.error.message : (f.data[0] ? f.data[0].message : 'Unknown error');
        errorTypes[msg] = (errorTypes[msg] || 0) + 1;
    });
    
    console.log(`\n🔍 Failure Reasons:`);
    for (const [msg, count] of Object.entries(errorTypes)) {
        console.log(`- "${msg}": ${count} times`);
    }
    
    if (successes.length === 1) {
        console.log('\n🏆 THUNDERING HERD DEFEATED: Database transaction locking flawlessly prevented double booking!');
    } else if (successes.length > 1) {
        console.log('\n⚠️ WARNING: DOUBLE BOOKING OCCURRED!');
    } else {
        console.log('\n⚠️ WARNING: NO ONE GOT THE SEAT!');
    }
}

runHerdTest();
