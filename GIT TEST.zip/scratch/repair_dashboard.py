import sys

with open('public/assets/js/owner-dashboard.js', 'r', encoding='utf-8') as f:
    lines = f.readlines()

# Delete lines 315 to 510 (0-indexed: 314 to 509)
# Actually, let's verify before deleting
if 'async function selectShow(showId, showType = \'movie\') {' in lines[314] and 'async function selectShow(showId, showType = \'movie\') {' in lines[509]:
    del lines[314:509]
    print("Deleted duplicate lines.")
else:
    print("Warning: Lines did not match expected structure.")
    print("Line 315:", lines[314].strip())
    print("Line 510:", lines[509].strip())

# Append the customer list modal functions
append_code = """
// ==========================================
// Customer List Modal Logic
// ==========================================

let currentCustomerData = [];

window.openCustomerListModal = async function() {
    if (!currentShowId) return;
    
    const modal = document.getElementById('customer-list-modal');
    const tbody = document.getElementById('customer-list-body');
    const loading = document.getElementById('customer-list-loading');
    const empty = document.getElementById('customer-list-empty');
    
    if (modal) modal.classList.remove('hidden');
    
    tbody.innerHTML = '';
    loading.classList.remove('hidden');
    empty.classList.add('hidden');
    
    try {
        const client = JayShow.getSupabaseClient();
        const user = JayShow.getCurrentUser();
        if (!user) throw new Error('Not logged in');

        const { data, error } = await client.rpc('get_customer_bookings_for_show', {
            p_show_id: currentShowId,
            p_type: currentShowType || 'movie',
            p_user_id: user.id
        });

        if (error) throw error;

        currentCustomerData = data || [];
        loading.classList.add('hidden');

        if (currentCustomerData.length === 0) {
            empty.classList.remove('hidden');
            return;
        }

        tbody.innerHTML = currentCustomerData.map(booking => {
            const seatLabel = `${booking.seat_row}${booking.seat_col}`;
            const dateStr = new Date(booking.created_at).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' });
            return `
                <tr style="border-bottom: 1px solid rgba(255,255,255,0.05); transition: background 0.2s;">
                    <td style="padding: 1rem; font-weight: 600; color: var(--primary);">${JayShow.escapeHtml(seatLabel)}</td>
                    <td style="padding: 1rem;">${JayShow.escapeHtml(booking.guest_name || 'Anonymous')}</td>
                    <td style="padding: 1rem; color: var(--text-secondary);">${JayShow.escapeHtml(booking.guest_email || 'N/A')}</td>
                    <td style="padding: 1rem; color: var(--text-secondary);">${JayShow.escapeHtml(booking.guest_phone || 'N/A')}</td>
                    <td style="padding: 1rem;">₹${booking.price}</td>
                    <td style="padding: 1rem; color: var(--text-secondary); font-size: 0.8rem;">${dateStr}</td>
                </tr>
            `;
        }).join('');

    } catch (err) {
        console.error('Error fetching customer list:', err);
        loading.classList.add('hidden');
        tbody.innerHTML = `<tr><td colspan="6" style="padding: 2rem; text-align: center; color: var(--danger);">Error loading data: ${err.message}</td></tr>`;
    }
};

window.closeCustomerListModal = function() {
    const modal = document.getElementById('customer-list-modal');
    if (modal) modal.classList.add('hidden');
};

window.downloadCustomerCSV = function() {
    if (!currentCustomerData || currentCustomerData.length === 0) {
        JayShow.showToast('No customer data to download', 'error');
        return;
    }

    const headers = ['Seat', 'Name', 'Email', 'Phone', 'Price', 'Booking Date'];
    const rows = currentCustomerData.map(b => [
        `${b.seat_row}${b.seat_col}`,
        b.guest_name || 'Anonymous',
        b.guest_email || 'N/A',
        b.guest_phone || 'N/A',
        b.price,
        new Date(b.created_at).toLocaleString()
    ]);

    const csvContent = [
        headers.join(','),
        ...rows.map(r => r.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
    ].join('\\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `customers_show_${currentShowId}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
};
"""

lines.append(append_code)

with open('public/assets/js/owner-dashboard.js', 'w', encoding='utf-8') as f:
    f.writelines(lines)
