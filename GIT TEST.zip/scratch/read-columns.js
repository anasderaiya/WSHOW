const fs = require('fs');
const path = require('path');

const schemaPath = path.join(__dirname, '..', 'supabase', 'unified_schema.sql');

try {
  const content = fs.readFileSync(schemaPath, 'utf8');
  
  // Find table definition for theater_owners
  const table = 'theater_owners';
  const tableRegex = new RegExp(`create\\s+table\\s+(?:if\\s+not\\s+exists\\s+)?(?:public\\.)?["\`]?${table}["\`]?\\s*\\(([^;]+)\\)`, 'i');
  const tableMatch = content.match(tableRegex);
  
  if (tableMatch) {
    console.log(`--- Columns for "${table}" ---`);
    console.log(tableMatch[1].trim());
  } else {
    console.log(`Could not find definition for ${table}`);
  }

} catch (err) {
  console.error('Error:', err.message);
}
