const http = require('http');
const https = require('https');

// Keep-alive agents to prevent local socket exhaustion
// This is the CRITICAL part for sending 1,000,000 requests without hitting OS socket limits
const httpAgent = new http.Agent({ keepAlive: true, maxSockets: 50 });
const httpsAgent = new https.Agent({ keepAlive: true, maxSockets: 50 });

const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });
const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_ANON_KEY;

// --- CONFIGURATION ---
const TOTAL_REQUESTS = 1000000;
const CONCURRENCY_LIMIT = 50; 
// Replace these with actual UUIDs from your database!
const TARGET_SHOW_ID = '600277da-c3c0-48ce-ae26-d52aa6eaa805'; 
const TARGET_SEAT_ID = '21946b02-8895-473a-815e-40163f2d1d13';

async function sendLockRequest(index) {
    const url = `${SUPABASE_URL}/rest/v1/rpc/lock_seat`;
    const payload = {
        p_show_id: TARGET_SHOW_ID,
        p_seat_id: TARGET_SEAT_ID,
        p_user_id: null,
        p_session_id: `herd_test_${index}`
    };

    // Node 18+ global fetch
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'apikey': SUPABASE_KEY,
                'Authorization': `Bearer ${SUPABASE_KEY}`
            },
            body: JSON.stringify(payload),
            // Pass the agent so fetch reuses the 50 sockets instead of creating 1M sockets
            dispatcher: new (require('undici').Agent)({
                connections: CONCURRENCY_LIMIT
            })
        });
        
        const data = await response.json().catch(() => null);
        let success = false;
        if (response.status === 200 && Array.isArray(data) && data.length > 0 && data[0].success === true) {
            success = true;
        }
        return { status: response.status, data, success };
    } catch (err) {
        return { status: 500, data: null, success: false };
    }
}

async function runThunderingHerd() {
    console.log(`Starting thundering herd test with ${TOTAL_REQUESTS} requests...`);
    console.log(`Concurrency limited to ${CONCURRENCY_LIMIT} to prevent socket exhaustion.`);
    
    let active = 0;
    let completed = 0;
    let successes = 0; // 200 OK (locked successfully)
    let failures = 0;  // 400+ (already locked or rate limited)
    let rateLimited = 0; // 429

    const startTime = Date.now();

    // The runner loop
    for (let i = 0; i < TOTAL_REQUESTS; i++) {
        // Wait if we've hit our concurrency limit
        while (active >= CONCURRENCY_LIMIT) {
            await new Promise(r => setTimeout(r, 5));
        }

        active++;
        sendLockRequest(i).then(result => {
            active--;
            completed++;
            
            if (result.status === 429) rateLimited++;
            else if (result.success) successes++;
            else failures++;

            if (completed % 1000 === 0) {
                const elapsed = (Date.now() - startTime) / 1000;
                const rps = Math.round(completed / elapsed);
                console.log(`[Progress] ${completed}/${TOTAL_REQUESTS} | ${rps} req/s | Success: ${successes} | Failed: ${failures} | RateLimit: ${rateLimited}`);
            }
        });
    }

    // Wait for remaining requests to finish
    while (active > 0) {
        await new Promise(r => setTimeout(r, 100));
    }

    const totalElapsed = (Date.now() - startTime) / 1000;
    console.log('\n--- TEST COMPLETE ---');
    console.log(`Total Time: ${totalElapsed.toFixed(2)} seconds`);
    console.log(`Average Speed: ${Math.round(TOTAL_REQUESTS / totalElapsed)} req/s`);
    console.log(`Locks Acquired (Successes): ${successes}`);
    console.log(`Locks Rejected (Already Locked): ${failures - rateLimited}`);
    console.log(`Rate Limited by Supabase (429): ${rateLimited}`);
    
    if (successes > 1) {
        console.error('⚠️ RACE CONDITION DETECTED: More than 1 request successfully locked the same seat!');
    } else if (successes === 1) {
        console.log('✅ PASS: Only 1 request successfully locked the seat (Idempotency/Concurrency safe).');
    } else {
        console.log('⚠️ WARNING: 0 successes. The seat was probably already locked before the test started.');
    }
}

// Run the test
if (TARGET_SHOW_ID === 'REPLACE_ME_WITH_SHOW_UUID') {
    console.error('Please edit this script and set TARGET_SHOW_ID and TARGET_SEAT_ID before running.');
    process.exit(1);
}

runThunderingHerd();
