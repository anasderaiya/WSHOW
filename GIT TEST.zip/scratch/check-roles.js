const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = 'https://cyjzbkdxhlzeqfmamdau.supabase.co';
const supabaseKey = 'sb_publishable__qLGRXfnfzbVqQZJippZVQ_K8lkNqkR';

const supabase = createClient(supabaseUrl, supabaseKey);

async function checkUsers() {
  console.log('--- Checking Custom User Profiles & Roles in DB ---');
  
  // 1. Check if there is a profiles or roles table
  const { data: tables, error: tablesError } = await supabase
    .from('profiles')
    .select('*')
    .limit(5);

  if (tablesError) {
    console.log('Profiles table not found or failed:', tablesError.message);
  } else {
    console.log('Profiles found:', tables);
  }

  // 2. Check for theatre_users or staff
  const { data: staff, error: staffError } = await supabase
    .from('theatre_users')
    .select('*')
    .limit(5);

  if (staffError) {
    // try different name
    const { data: staff2, error: staffError2 } = await supabase
      .from('staff')
      .select('*')
      .limit(5);
    
    if (staffError2) {
      console.log('theatre_users or staff table not found:', staffError2.message);
    } else {
      console.log('staff found:', staff2);
    }
  } else {
    console.log('theatre_users found:', staff);
  }

  // 3. Let's list all database table names by inspecting a public view or table
  // Since we have supabase CLI, or unified_schema.sql, let's look at unified_schema.sql!
}

checkUsers();
