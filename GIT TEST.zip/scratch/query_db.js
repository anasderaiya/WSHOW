const https = require('https');

const HOST = 'cyjzbkdxhlzeqfmamdau.supabase.co';
const KEY = 'sb_publishable__qLGRXfnfzbVqQZJippZVQ_K8lkNqkR';

function apiCall(path, method = 'GET', body = null) {
  return new Promise((resolve) => {
    const headers = {
      'apikey': KEY,
      'Authorization': `Bearer ${KEY}`,
      'Content-Type': 'application/json',
    };
    if (body) headers['Content-Length'] = Buffer.byteLength(body);
    
    const req = https.request({ hostname: HOST, path, method, headers }, res => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => resolve({ status: res.statusCode, body: d }));
    });
    req.on('error', e => resolve({ status: 0, body: e.message }));
    if (body) req.write(body);
    req.end();
  });
}

async function main() {
  console.log('--- GETTING THEATRES ---');
  const theatres = await apiCall('/rest/v1/theatres?select=*');
  console.log('Theatres:', theatres.status, JSON.stringify(JSON.parse(theatres.body), null, 2));

  console.log('\n--- GETTING THEATER OWNERS ---');
  const owners = await apiCall('/rest/v1/theater_owners?select=*');
  console.log('Owners:', owners.status, JSON.stringify(JSON.parse(owners.body), null, 2));
}

main();
