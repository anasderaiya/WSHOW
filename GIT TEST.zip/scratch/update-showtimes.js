const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = 'https://cyjzbkdxhlzeqfmamdau.supabase.co';
const supabaseKey = 'sb_publishable__qLGRXfnfzbVqQZJippZVQ_K8lkNqkR';

const supabase = createClient(supabaseUrl, supabaseKey);

async function updateShowtimes() {
  console.log('--- Shifting Showtimes to Today and Tomorrow ---');
  
  const today = new Date();
  today.setHours(20, 0, 0, 0); // 8:00 PM Today
  const todayISO = today.toISOString();

  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  tomorrow.setHours(21, 30, 0, 0); // 9:30 PM Tomorrow
  const tomorrowISO = tomorrow.toISOString();

  console.log(`Setting Show 1 to: ${todayISO}`);
  console.log(`Setting Show 2 to: ${tomorrowISO}`);

  // Update Show 1
  const { data: update1, error: error1 } = await supabase
    .from('shows')
    .update({ start_time: todayISO })
    .eq('id', '600277da-c3c0-48ce-ae26-d52aa6eaa805')
    .select();

  if (error1) {
    console.error('Error updating Show 1:', error1.message);
  } else {
    console.log('Show 1 updated successfully!');
  }

  // Update Show 2
  const { data: update2, error: error2 } = await supabase
    .from('shows')
    .update({ start_time: tomorrowISO })
    .eq('id', 'b590dd55-005c-474c-85f2-2897410d94a4')
    .select();

  if (error2) {
    console.error('Error updating Show 2:', error2.message);
  } else {
    console.log('Show 2 updated successfully!');
  }
}

updateShowtimes();
