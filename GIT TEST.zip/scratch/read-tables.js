const fs = require('fs');
const path = require('path');

const schemaPath = path.join(__dirname, '..', 'supabase', 'unified_schema.sql');

try {
  const content = fs.readFileSync(schemaPath, 'utf8');
  console.log(`Schema file read successfully. Size: ${content.length} bytes.`);

  // Find all CREATE TABLE statements, ignoring IF NOT EXISTS
  const createTableRegex = /create\s+table\s+(?:if\s+not\s+exists\s+)?([a-zA-Z0-9_."`]+)/gi;
  let match;
  const tables = [];
  
  while ((match = createTableRegex.exec(content)) !== null) {
    // clean up quotes or schema prefix
    let tableName = match[1].replace(/["`]/g, '');
    if (tableName.includes('.')) {
      tableName = tableName.split('.')[1];
    }
    tables.push(tableName);
  }

  console.log(`Found ${tables.length} tables in schema file:`);
  console.log(JSON.stringify(tables, null, 2));

  // Let's print out snippets of tables related to users or roles
  const userRelated = tables.filter(t => t.toLowerCase().includes('user') || t.toLowerCase().includes('role') || t.toLowerCase().includes('staff') || t.toLowerCase().includes('admin') || t.toLowerCase().includes('theat') || t.toLowerCase().includes('owner') || t.toLowerCase().includes('profile'));
  console.log('\nUser-related tables:', userRelated);

  // Let's print out the exact column names of the tables by searching inside the SQL
  tables.forEach(table => {
    const tableRegex = new RegExp(`create\\s+table\\s+(?:if\\s+not\\s+exists\\s+)?(?:public\\.)?["\`]?${table}["\`]?\\s*\\(([^)]+)\\)`, 'i');
    const tableMatch = content.match(tableRegex);
    if (tableMatch) {
      console.log(`\nColumns for table "${table}":`);
      const cols = tableMatch[1].trim().split('\n').map(l => l.trim()).filter(l => l && !l.startsWith('--') && !l.startsWith('constraint') && !l.startsWith('primary key') && !l.startsWith('foreign key') && !l.startsWith('unique'));
      cols.slice(0, 10).forEach(c => console.log(`  ${c}`));
    }
  });

} catch (err) {
  console.error('Error reading schema file:', err.message);
}
