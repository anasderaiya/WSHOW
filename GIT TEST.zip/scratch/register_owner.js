const { createClient } = require('@supabase/supabase-js');

const SUPABASE_URL = 'https://cyjzbkdxhlzeqfmamdau.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable__qLGRXfnfzbVqQZJippZVQ_K8lkNqkR';

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

async function main() {
  // 1. Sign in as Admin
  const { data, error } = await supabase.auth.signInWithPassword({
    email: 'admin@quickmyticket.com',
    password: 'Admin@1234'
  });

  if (error) {
    console.error('Login error:', error);
    return;
  }

  console.log('Admin logged in! User ID:', data.user.id);

  // 2. Try to insert ourselves (Admin) as owner of Demo cinema (dddd58fe-82c1-45fc-aadf-79613cbdb122)
  console.log('Assigning Admin to Demo Cinema...');
  const { data: insertData1, error: insertErr1 } = await supabase
    .from('theater_owners')
    .insert({
      user_id: data.user.id,
      theatre_id: 'dddd58fe-82c1-45fc-aadf-79613cbdb122',
      role: 'owner'
    })
    .select();

  console.log('Assignment 1 result:', insertData1, insertErr1);

  // 3. Try to insert ourselves (Admin) as owner of designme cinema (629cc8cb-05e5-4d9e-a39f-26479abf4155)
  console.log('Assigning Admin to DesignMe Cinema...');
  const { data: insertData2, error: insertErr2 } = await supabase
    .from('theater_owners')
    .insert({
      user_id: data.user.id,
      theatre_id: '629cc8cb-05e5-4d9e-a39f-26479abf4155',
      role: 'owner'
    })
    .select();

  console.log('Assignment 2 result:', insertData2, insertErr2);

  // 4. Verify roles
  const { data: isOwner } = await supabase.rpc('is_theater_owner', { p_user_id: data.user.id });
  console.log('is_theater_owner after:', isOwner);
}

main();
