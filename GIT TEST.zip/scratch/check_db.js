const { createClient } = require('@supabase/supabase-js');

// Read env variables
const supabaseUrl = 'https://cyjzbkdxhlzeqfmamdau.supabase.co';
const supabaseKey = 'sb_publishable__qLGRXfnfzbVqQZJippZVQ_K8lkNqkR';

const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: { persistSession: false }
});

async function main() {
  console.log('=== CHECKING SUPABASE DATA ===\n');

  // 1. Fetch theatres
  const { data: theatres, error: tErr } = await supabase.from('theatres').select('*');
  if (tErr) {
    console.error('Error fetching theatres:', tErr);
  } else {
    console.log('--- Theatres in Database ---');
    console.log(theatres.map(t => ({ id: t.id, name: t.name, location: t.location })));
  }

  // 2. Fetch theater owners
  const { data: owners, error: oErr } = await supabase.from('theater_owners').select('*');
  if (oErr) {
    console.error('Error fetching owners:', oErr);
  } else {
    console.log('\n--- Theater Owners in Database ---');
    console.log(owners);
  }

  // 3. Find user anashderaiya@gmail.com
  // Since we cannot read auth.users table easily without Service Key, we can check by searching theater_owners mapping
  console.log('\n--- Checking if there are any owners linked ---');
  if (owners && owners.length > 0) {
    console.log(`Found ${owners.length} theater owner records.`);
  } else {
    console.log('No records in theater_owners table!');
  }
}

main();
