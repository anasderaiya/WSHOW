const { createClient } = require('@supabase/supabase-js');

const SUPABASE_URL = 'https://cyjzbkdxhlzeqfmamdau.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable__qLGRXfnfzbVqQZJippZVQ_K8lkNqkR';

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

async function main() {
  const { data, error } = await supabase.auth.signInWithPassword({
    email: 'admin@quickmyticket.com',
    password: 'Admin@1234'
  });

  if (error) {
    console.error('Login error:', error);
    return;
  }

  console.log('Login success!');
  console.log('User app_metadata:', data.user.app_metadata);
  console.log('User user_metadata:', data.user.user_metadata);
  console.log('User id:', data.user.id);

  // Check if this user is a theater owner or admin
  const { data: isOwner, error: rpcErr } = await supabase.rpc('is_theater_owner', { p_user_id: data.user.id });
  console.log('is_theater_owner (RPC):', isOwner, rpcErr);

  // Check roles
  const { data: roleData, error: roleErr } = await supabase.rpc('get_user_role', { p_user_id: data.user.id });
  console.log('get_user_role (RPC):', roleData, roleErr);
}

main();
