
-- ============================================
-- Quick My Ticket - Allow Test Confirmations
-- Migration 027
-- ============================================

-- Grant UPDATE permission to allow frontend testing of the booking flow
GRANT UPDATE ON public.bookings TO anon;
GRANT UPDATE ON public.bookings TO authenticated;

-- Add a policy that allows ANYONE to confirm a booking IF:
-- 1. The booking is currently 'locked'
-- 2. they are setting the status to 'confirmed'
-- 3. The payment_id starts with 'TEST_'
-- This allows developers to test the full flow without a backend/edge function.

DROP POLICY IF EXISTS "Allow test confirmations" ON public.bookings;
CREATE POLICY "Allow test confirmations" ON public.bookings
    FOR UPDATE
    USING (status = 'locked')
    WITH CHECK (
        status = 'confirmed' AND 
        payment_id LIKE 'TEST_%' AND
        confirmed_at IS NOT NULL
    );


-- Migration 028: Add razorpay_order_id for order creation idempotency
-- =====================================================================
-- When create-order is called, the Razorpay order ID is stored on
-- the booking rows. On retry, the Edge Function checks for an existing
-- order before creating a new one, preventing duplicate charges.

ALTER TABLE bookings
    ADD COLUMN IF NOT EXISTS razorpay_order_id text;

-- Index for fast lookup during idempotency check
CREATE INDEX IF NOT EXISTS idx_bookings_razorpay_order_id
    ON bookings (razorpay_order_id)
    WHERE razorpay_order_id IS NOT NULL;

COMMENT ON COLUMN bookings.razorpay_order_id IS 'Razorpay order ID stored at order creation for idempotency on retry';


-- Migration 029: Remove test confirmation backdoor
-- =====================================================================
-- MUST run before going live. This reverses the permissions granted in
-- migration 027 that allowed unauthenticated test confirmations.

REVOKE UPDATE ON public.bookings FROM anon;
REVOKE UPDATE ON public.bookings FROM authenticated;

DROP POLICY IF EXISTS "Allow test confirmations" ON public.bookings;


-- Migration 030: Fix get_admin_owner_revenue_breakdown return type
-- =================================================================
-- The SUM() aggregate over a bigint column (COUNT) returns numeric,
-- which conflicted with the function signature expecting a bigint.
-- We cast the final sum back to bigint.

CREATE OR REPLACE FUNCTION get_admin_owner_revenue_breakdown(p_start_date DATE DEFAULT NULL, p_end_date DATE DEFAULT NULL)
RETURNS TABLE(
    owner_id UUID,
    owner_email TEXT,
    owner_name TEXT,
    theatre_names TEXT,
    revenue NUMERIC,
    booking_count BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    IF NOT ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;

    RETURN QUERY
    WITH owner_theatres AS (
        SELECT 
            to_owner.user_id,
            t.id as theatre_id,
            t.name as theatre_name,
            oa.email as user_email,
            oa.full_name as user_name
        FROM theater_owners to_owner
        JOIN theatres t ON t.id = to_owner.theatre_id
        LEFT JOIN owner_applications oa ON oa.user_id = to_owner.user_id AND oa.status = 'approved'
    ),
    movie_bookings AS (
        SELECT 
            s.theatre_id,
            COUNT(b.id) as booking_count,
            SUM(COALESCE(seats.price, sh.price, 0)) as revenue
        FROM bookings b
        JOIN shows sh ON sh.id = b.show_id
        JOIN screens s ON s.id = sh.screen_id
        LEFT JOIN seats ON seats.id = b.seat_id
        WHERE b.status = 'confirmed' 
            AND (p_start_date IS NULL OR b.created_at >= p_start_date)
            AND (p_end_date IS NULL OR b.created_at < (p_end_date + INTERVAL '1 day'))
        GROUP BY s.theatre_id
    ),
    event_bookings AS (
        SELECT 
            s.theatre_id,
            COUNT(b.id) as booking_count,
            SUM(COALESCE(seats.price, es.price, 0)) as revenue
        FROM bookings b
        JOIN event_shows es ON es.id = b.event_show_id
        JOIN screens s ON s.id = es.screen_id
        LEFT JOIN seats ON seats.id = b.seat_id
        WHERE b.status = 'confirmed' 
            AND (p_start_date IS NULL OR b.created_at >= p_start_date)
            AND (p_end_date IS NULL OR b.created_at < (p_end_date + INTERVAL '1 day'))
        GROUP BY s.theatre_id
    )
    SELECT 
        ot.user_id as owner_id,
        MAX(ot.user_email) as owner_email,
        MAX(ot.user_name) as owner_name,
        STRING_AGG(DISTINCT ot.theatre_name, ', ') as theatre_names,
        COALESCE(SUM(mb.revenue), 0) + COALESCE(SUM(eb.revenue), 0) as revenue,
        (COALESCE(SUM(mb.booking_count), 0) + COALESCE(SUM(eb.booking_count), 0))::BIGINT as booking_count
    FROM owner_theatres ot
    LEFT JOIN movie_bookings mb ON mb.theatre_id = ot.theatre_id
    LEFT JOIN event_bookings eb ON eb.theatre_id = ot.theatre_id
    GROUP BY ot.user_id
    ORDER BY revenue DESC;
END;
$$;

GRANT EXECUTE ON FUNCTION get_admin_owner_revenue_breakdown(DATE, DATE) TO authenticated;


-- ============================================
-- Quick My Ticket — Automatic Expired Lock Cleanup
-- ============================================
-- Sets up a pg_cron job that runs every minute to release seats
-- that have been in "locked" status for more than 5 minutes
-- without a completed payment.
--
-- Prerequisites:
--   The pg_cron extension must be enabled in your Supabase project.
--   (Dashboard → Database → Extensions → pg_cron → Enable)
-- ============================================

-- 1. pg_cron must be enabled in Supabase Dashboard -> Database -> Extensions
-- We skip auto-creation here because Supabase manages extensions centrally.

-- 2. Create the cleanup function (SECURITY DEFINER so it can write to bookings)
CREATE OR REPLACE FUNCTION release_expired_locks()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_count INTEGER;
BEGIN
    UPDATE bookings
    SET status   = 'expired',
        locked_at = NULL
    WHERE status = 'locked'
      AND locked_at < NOW() - INTERVAL '5 minutes';

    GET DIAGNOSTICS v_count = ROW_COUNT;

    IF v_count > 0 THEN
        RAISE LOG '[QMT] Released % expired seat lock(s)', v_count;
    END IF;
END;
$$;

-- 3. Schedule the job to run every minute
--    cron.schedule returns the job id; we use an idempotent wrapper
--    so re-running this migration is safe.
DO $$
BEGIN
    -- Remove any previous version of this job first
    PERFORM cron.unschedule(jobid)
    FROM cron.job
    WHERE jobname = 'release-expired-locks';

    -- Schedule the new job
    PERFORM cron.schedule(
        'release-expired-locks',    -- job name (idempotent key)
        '* * * * *',                -- every minute
        'SELECT release_expired_locks();'
    );

    RAISE LOG '[QMT] pg_cron job "release-expired-locks" scheduled (every minute)';
EXCEPTION WHEN OTHERS THEN
    RAISE LOG '[QMT] pg_cron not available - skipping cron job setup. Enable pg_cron in Supabase Dashboard -> Database -> Extensions.';
END;
$$;


-- ============================================
-- Quick My Ticket — Rate Limit Seat Locking
-- ============================================
-- Prevents a single user/session from holding more than 10
-- active (locked) seats per show. This stops abuse where
-- someone rapidly locks and abandons seats via the API.
-- ============================================

-- 1. Update lock_seat to enforce per-show rate limit
CREATE OR REPLACE FUNCTION lock_seat(
    p_show_id UUID, 
    p_seat_id UUID, 
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    booking_id UUID, 
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking_id UUID;
    v_existing RECORD;
    v_screen_id UUID;
    v_seat_exists BOOLEAN;
    v_reusable_booking UUID;
    v_lock_timeout_minutes INTEGER := 5;
    v_active_locks INTEGER;
    v_max_locks INTEGER := 10;
BEGIN
    -- Validate that the show exists and get screen_id
    SELECT screen_id INTO v_screen_id 
    FROM shows 
    WHERE id = p_show_id;
    
    IF v_screen_id IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Show not found'::TEXT;
        RETURN;
    END IF;
    
    -- Validate that the seat exists and belongs to the show's screen
    SELECT EXISTS(
        SELECT 1 FROM seats 
        WHERE id = p_seat_id AND screen_id = v_screen_id
    ) INTO v_seat_exists;
    
    IF NOT v_seat_exists THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat not found for this show'::TEXT;
        RETURN;
    END IF;

    -- *** RATE LIMIT CHECK ***
    -- Count how many seats this user/session currently has locked for THIS show
    SELECT COUNT(*) INTO v_active_locks
    FROM bookings
    WHERE show_id = p_show_id
      AND status = 'locked'
      AND locked_at >= NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL
      AND (
          (p_user_id IS NOT NULL AND user_id = p_user_id)
          OR
          (p_session_id IS NOT NULL AND session_id = p_session_id)
      );

    IF v_active_locks >= v_max_locks THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 
            ('You cannot lock more than ' || v_max_locks || ' seats per show')::TEXT;
        RETURN;
    END IF;
    
    -- Auto-expire stale locks on this specific seat
    UPDATE bookings 
    SET status = 'expired', locked_at = NULL
    WHERE show_id = p_show_id 
      AND seat_id = p_seat_id 
      AND status = 'locked'
      AND locked_at < NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL;
    
    -- Try to acquire a lock on existing active booking
    BEGIN
        SELECT * INTO v_existing
        FROM bookings 
        WHERE show_id = p_show_id 
          AND seat_id = p_seat_id 
          AND status IN ('locked', 'confirmed')
        FOR UPDATE NOWAIT;
    EXCEPTION
        WHEN lock_not_available THEN
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is currently being processed by another user, please try again'::TEXT;
            RETURN;
    END;
    
    -- Check if seat is already taken
    IF FOUND THEN
        IF (v_existing.user_id IS NOT NULL AND v_existing.user_id = p_user_id AND v_existing.status = 'locked') OR 
           (v_existing.session_id IS NOT NULL AND v_existing.session_id = p_session_id AND v_existing.status = 'locked') THEN
            -- Refresh the lock timestamp
            UPDATE bookings 
            SET locked_at = NOW() 
            WHERE id = v_existing.id;
            
            RETURN QUERY SELECT v_existing.id, TRUE, 'Lock refreshed'::TEXT;
            RETURN;
        ELSE
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is already locked or booked'::TEXT;
            RETURN;
        END IF;
    END IF;
    
    -- Look for a reusable cancelled/expired booking for this seat
    SELECT id INTO v_reusable_booking
    FROM bookings
    WHERE show_id = p_show_id
      AND seat_id = p_seat_id
      AND status IN ('cancelled', 'expired')
    ORDER BY created_at DESC
    LIMIT 1
    FOR UPDATE;
    
    IF v_reusable_booking IS NOT NULL THEN
        UPDATE bookings 
        SET status = 'locked',
            user_id = p_user_id,
            session_id = p_session_id,
            locked_at = NOW(),
            payment_id = NULL,
            confirmed_at = NULL
        WHERE id = v_reusable_booking
        RETURNING id INTO v_booking_id;
        
        RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
        RETURN;
    END IF;
    
    -- Insert new booking with lock
    INSERT INTO bookings (show_id, seat_id, user_id, session_id, status, locked_at)
    VALUES (p_show_id, p_seat_id, p_user_id, p_session_id, 'locked', NOW())
    RETURNING id INTO v_booking_id;
    
    RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
    
EXCEPTION
    WHEN unique_violation THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat was just locked by another user'::TEXT;
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, ('Error: ' || SQLERRM)::TEXT;
END;
$$;

GRANT EXECUTE ON FUNCTION lock_seat(UUID, UUID, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION lock_seat(UUID, UUID, UUID, TEXT) TO anon;


-- 2. Update lock_event_seat with the same rate limit
CREATE OR REPLACE FUNCTION lock_event_seat(
    p_event_show_id UUID, 
    p_seat_id UUID, 
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    booking_id UUID, 
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking_id UUID;
    v_existing RECORD;
    v_screen_id UUID;
    v_seat_exists BOOLEAN;
    v_reusable_booking UUID;
    v_lock_timeout_minutes INTEGER := 5;
    v_active_locks INTEGER;
    v_max_locks INTEGER := 10;
BEGIN
    SELECT screen_id INTO v_screen_id 
    FROM event_shows 
    WHERE id = p_event_show_id;
    
    IF v_screen_id IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Event show not found'::TEXT;
        RETURN;
    END IF;
    
    SELECT EXISTS(
        SELECT 1 FROM seats 
        WHERE id = p_seat_id AND screen_id = v_screen_id
    ) INTO v_seat_exists;
    
    IF NOT v_seat_exists THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat not found for this event'::TEXT;
        RETURN;
    END IF;

    -- *** RATE LIMIT CHECK ***
    SELECT COUNT(*) INTO v_active_locks
    FROM bookings
    WHERE event_show_id = p_event_show_id
      AND status = 'locked'
      AND locked_at >= NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL
      AND (
          (p_user_id IS NOT NULL AND user_id = p_user_id)
          OR
          (p_session_id IS NOT NULL AND session_id = p_session_id)
      );

    IF v_active_locks >= v_max_locks THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 
            ('You cannot lock more than ' || v_max_locks || ' seats per show')::TEXT;
        RETURN;
    END IF;

    UPDATE bookings 
    SET status = 'expired', locked_at = NULL
    WHERE event_show_id = p_event_show_id 
      AND seat_id = p_seat_id 
      AND status = 'locked'
      AND locked_at < NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL;
    
    BEGIN
        SELECT * INTO v_existing
        FROM bookings 
        WHERE event_show_id = p_event_show_id 
          AND seat_id = p_seat_id 
          AND status IN ('locked', 'confirmed')
        FOR UPDATE NOWAIT;
    EXCEPTION
        WHEN lock_not_available THEN
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is being processed by another user'::TEXT;
            RETURN;
    END;
    
    IF FOUND THEN
        IF (v_existing.user_id IS NOT NULL AND v_existing.user_id = p_user_id AND v_existing.status = 'locked') OR 
           (v_existing.session_id IS NOT NULL AND v_existing.session_id = p_session_id AND v_existing.status = 'locked') THEN
            UPDATE bookings 
            SET locked_at = NOW() 
            WHERE id = v_existing.id;
            
            RETURN QUERY SELECT v_existing.id, TRUE, 'Lock refreshed'::TEXT;
            RETURN;
        ELSE
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is already locked or booked'::TEXT;
            RETURN;
        END IF;
    END IF;

    SELECT id INTO v_reusable_booking
    FROM bookings
    WHERE event_show_id = p_event_show_id
      AND seat_id = p_seat_id
      AND status IN ('cancelled', 'expired')
    ORDER BY created_at DESC
    LIMIT 1
    FOR UPDATE;
    
    IF v_reusable_booking IS NOT NULL THEN
        UPDATE bookings 
        SET status = 'locked',
            user_id = p_user_id,
            session_id = p_session_id,
            locked_at = NOW(),
            payment_id = NULL,
            confirmed_at = NULL
        WHERE id = v_reusable_booking
        RETURNING id INTO v_booking_id;
        
        RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
        RETURN;
    END IF;
    
    INSERT INTO bookings (event_show_id, seat_id, user_id, session_id, status, locked_at)
    VALUES (p_event_show_id, p_seat_id, p_user_id, p_session_id, 'locked', NOW())
    RETURNING id INTO v_booking_id;
    
    RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
    
EXCEPTION
    WHEN unique_violation THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat was just locked by another user'::TEXT;
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, ('Error: ' || SQLERRM)::TEXT;
END;
$$;

GRANT EXECUTE ON FUNCTION lock_event_seat(UUID, UUID, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION lock_event_seat(UUID, UUID, UUID, TEXT) TO anon;


-- ============================================
-- Fix Ambiguous release_expired_locks Function
-- ============================================
-- The previous migration (031) created a version of release_expired_locks()
-- with no arguments. This conflicts with the original version created in
-- migration 001 which had an optional parameter `p_lock_timeout_minutes INTEGER DEFAULT 5`.
-- Since both can be called with zero arguments, Postgres throws an ambiguity error.
-- We drop the void version and update the pg_cron job to explicitly cast/call
-- the correct version.

-- 1. Drop the conflicting void function (without dropping the one with arguments)
DROP FUNCTION IF EXISTS release_expired_locks();

-- 2. Redefine the parameterized function to ensure it clears locked_at = NULL
CREATE OR REPLACE FUNCTION release_expired_locks(
    p_lock_timeout_minutes INTEGER DEFAULT 5
)
RETURNS TABLE(
    released_count INTEGER,
    released_ids UUID[]
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_released_ids UUID[];
    v_count INTEGER;
BEGIN
    WITH expired AS (
        UPDATE bookings 
        SET status = 'expired', 
            locked_at = NULL
        WHERE status = 'locked' 
          AND locked_at < NOW() - (p_lock_timeout_minutes || ' minutes')::INTERVAL
        RETURNING id
    )
    SELECT array_agg(id), COUNT(*)::INTEGER 
    INTO v_released_ids, v_count
    FROM expired;
    
    RETURN QUERY SELECT COALESCE(v_count, 0), COALESCE(v_released_ids, ARRAY[]::UUID[]);
END;
$$;

-- Only allow service role to execute (for cron/edge function)
REVOKE ALL ON FUNCTION release_expired_locks(INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION release_expired_locks(INTEGER) TO service_role;

-- 3. Ensure the cron job is using the proper parameterized one
DO $$
BEGIN
    -- Remove the old job
    PERFORM cron.unschedule('release-expired-locks');

    -- Re-schedule explicitly passing the default 5 to avoid any potential ambiguity
    PERFORM cron.schedule(
        'release-expired-locks',
        '* * * * *',
        'SELECT release_expired_locks(5);'
    );

    RAISE LOG '[QMT] pg_cron job "release-expired-locks" fixed and rescheduled';
EXCEPTION WHEN OTHERS THEN
    RAISE LOG '[QMT] pg_cron not available - skipping cron job update. Enable pg_cron in Supabase Dashboard -> Database -> Extensions.';
END;
$$;


-- Theater branding & white-label configuration
CREATE TABLE IF NOT EXISTS theater_branding (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  theater_id          UUID UNIQUE NOT NULL REFERENCES theatres(id) ON DELETE CASCADE,
  
  -- Identity
  display_name        TEXT NOT NULL,
  tagline             TEXT,
  logo_url            TEXT,
  favicon_url         TEXT,
  
  -- Colors (hex values)
  primary_color       TEXT NOT NULL DEFAULT '#e50914',
  accent_color        TEXT NOT NULL DEFAULT '#ffffff',
  background_color    TEXT NOT NULL DEFAULT '#141414',
  card_color          TEXT NOT NULL DEFAULT '#1a1a1a',
  text_color          TEXT NOT NULL DEFAULT '#ffffff',
  
  -- Domain
  subdomain           TEXT UNIQUE,            -- 'angelcineworld' → angelcineworld.quickmytickets.com
  custom_domain       TEXT UNIQUE,            -- 'tickets.angelcineworld.com'
  
  -- Contact
  whatsapp_number     TEXT,
  support_email       TEXT,
  
  -- Social
  instagram_url       TEXT,
  facebook_url        TEXT,
  
  -- Config
  active              BOOLEAN DEFAULT true,
  show_powered_by     BOOLEAN DEFAULT true,   -- 'Powered by Quick My Ticket' footer badge
  
  created_at          TIMESTAMPTZ DEFAULT NOW(),
  updated_at          TIMESTAMPTZ DEFAULT NOW()
);

-- RLS: Only the theater owner and admins can read/write their branding
ALTER TABLE theater_branding ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Theater owner can manage own branding"
ON theater_branding
FOR ALL
USING (
  theater_id IN (
    SELECT t.id FROM theatres t
    JOIN theater_owners to2 ON t.id = to2.theatre_id
    WHERE to2.user_id = auth.uid()
  )
)
WITH CHECK (
  theater_id IN (
    SELECT t.id FROM theatres t
    JOIN theater_owners to2 ON t.id = to2.theatre_id
    WHERE to2.user_id = auth.uid()
  )
);

CREATE POLICY "Admins can manage all branding"
ON theater_branding
FOR ALL
USING (
  (auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true
);

CREATE POLICY "Public can read active branding"
ON theater_branding
FOR SELECT
USING (active = true);

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_theater_branding_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER theater_branding_updated_at
  BEFORE UPDATE ON theater_branding
  FOR EACH ROW EXECUTE FUNCTION update_theater_branding_timestamp();

-- Index for fast domain lookups
CREATE INDEX idx_theater_branding_subdomain ON theater_branding(subdomain);
CREATE INDEX idx_theater_branding_custom_domain ON theater_branding(custom_domain);
CREATE INDEX idx_theater_branding_theater_id ON theater_branding(theater_id);


-- Create storage bucket for theater branding assets
INSERT INTO storage.buckets (id, name, public)
VALUES ('branding', 'branding', true)
ON CONFLICT (id) DO NOTHING;

-- Public read access on branding bucket
CREATE POLICY "Public read branding assets"
ON storage.objects FOR SELECT
USING (bucket_id = 'branding');

-- Theater owners can upload to their own folder
CREATE POLICY "Theater owners can upload branding"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'branding'
  AND (storage.foldername(name))[2] IN (
    SELECT t.id::text FROM theatres t
    JOIN theater_owners to2 ON t.id = to2.theatre_id
    WHERE to2.user_id = auth.uid()
  )
);

CREATE POLICY "Theater owners can update branding"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'branding'
  AND (storage.foldername(name))[2] IN (
    SELECT t.id::text FROM theatres t
    JOIN theater_owners to2 ON t.id = to2.theatre_id
    WHERE to2.user_id = auth.uid()
  )
);


