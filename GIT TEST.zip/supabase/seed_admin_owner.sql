-- ============================================================
-- ADMIN OWNER SEED SCRIPT
-- Quick My Ticket — Supabase SQL Editor
-- ============================================================
-- Purpose: Assign admin@quickmyticket.com as the 'owner' role
--          for ALL theatres in the database.
--
-- Steps:
--   1. Paste this entire script into the Supabase SQL Editor
--   2. Click "Run"
--   3. Login with: admin@quickmyticket.com / Admin@1234
-- ============================================================

-- Step 1: Find the admin user UUID from auth.users
-- NOTE: The account must ALREADY exist. If not, create it first
-- at http://localhost:3001/login using the "Sign Up" tab.

DO $$
DECLARE
  v_admin_id UUID;
  v_theatre RECORD;
  v_count INT := 0;
BEGIN
  -- Resolve the admin user's UUID from their email
  SELECT id INTO v_admin_id
  FROM auth.users
  WHERE email = 'admin@quickmyticket.com'
  LIMIT 1;

  IF v_admin_id IS NULL THEN
    RAISE NOTICE '❌ User admin@quickmyticket.com not found in auth.users.';
    RAISE NOTICE '   Please sign up first at /login, then run this script again.';
    RETURN;
  END IF;

  RAISE NOTICE '✅ Found admin user: %', v_admin_id;

  -- Step 2: Assign as owner of EVERY theatre in the system
  FOR v_theatre IN SELECT id, name FROM theatres LOOP
    INSERT INTO theater_owners (user_id, theatre_id, role)
    VALUES (v_admin_id, v_theatre.id, 'owner')
    ON CONFLICT (user_id, theatre_id) DO UPDATE
      SET role = 'owner', updated_at = NOW();

    v_count := v_count + 1;
    RAISE NOTICE '  ✓ Assigned owner role for theatre: % (%)', v_theatre.name, v_theatre.id;
  END LOOP;

  -- Step 3: Mark user as admin in app metadata (enables bypass checks)
  UPDATE auth.users
  SET raw_app_meta_data = raw_app_meta_data || '{"is_admin": true}'::jsonb,
      raw_user_meta_data = raw_user_meta_data || '{"full_name": "Super Admin"}'::jsonb,
      email_confirmed_at = COALESCE(email_confirmed_at, NOW())
  WHERE id = v_admin_id;

  RAISE NOTICE '';
  RAISE NOTICE '🎉 DONE! admin@quickmyticket.com is now owner of % theatre(s).', v_count;
  RAISE NOTICE '   Login at: http://localhost:3001/login';
  RAISE NOTICE '   Email:    admin@quickmyticket.com';
  RAISE NOTICE '   Password: Admin@1234';

EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE '❌ Error: %', SQLERRM;
END;
$$;


-- ============================================================
-- VERIFICATION QUERY — Run separately to confirm
-- ============================================================
-- Uncomment and run after the above to verify:
/*
SELECT
  au.email,
  t.name AS theatre_name,
  to_owner.role,
  to_owner.created_at
FROM theater_owners to_owner
JOIN auth.users au ON au.id = to_owner.user_id
JOIN theatres t ON t.id = to_owner.theatre_id
WHERE au.email = 'admin@quickmyticket.com';
*/
