-- ==========================================
-- Quick My Ticket - Unified Supabase Schema
-- Generated for fresh deployment
-- ==========================================

-- ==========================================
-- Migration: 000_baseline.sql
-- ==========================================

-- ============================================
-- Quick My Ticket Baseline Schema
-- ============================================
-- Reconstructed from frontend queries to provide the foundational tables.
-- These tables were originally created manually via the Supabase UI.

-- 1. Theatres
CREATE TABLE IF NOT EXISTS theatres (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    location TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE theatres ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public theatres are viewable by everyone" ON theatres FOR SELECT USING (true);
CREATE POLICY "Admins can insert theatres" ON theatres FOR INSERT WITH CHECK (true);
CREATE POLICY "Admins can update theatres" ON theatres FOR UPDATE USING (true);
CREATE POLICY "Admins can delete theatres" ON theatres FOR DELETE USING (true);

-- 2. Screens
CREATE TABLE IF NOT EXISTS screens (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    theatre_id UUID REFERENCES theatres(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    seat_layout JSONB,
    total_seats INTEGER,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE screens ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public screens are viewable by everyone" ON screens FOR SELECT USING (true);
CREATE POLICY "Admins can insert screens" ON screens FOR INSERT WITH CHECK (true);
CREATE POLICY "Admins can update screens" ON screens FOR UPDATE USING (true);
CREATE POLICY "Admins can delete screens" ON screens FOR DELETE USING (true);

-- 3. Movies
CREATE TABLE IF NOT EXISTS movies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    description TEXT,
    poster_url TEXT,
    duration_minutes INTEGER,
    genre TEXT,
    rating TEXT,
    release_date DATE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE movies ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public movies are viewable by everyone" ON movies FOR SELECT USING (true);
CREATE POLICY "Admins can insert movies" ON movies FOR INSERT WITH CHECK (true);
CREATE POLICY "Admins can update movies" ON movies FOR UPDATE USING (true);
CREATE POLICY "Admins can delete movies" ON movies FOR DELETE USING (true);

-- 4. Shows
CREATE TABLE IF NOT EXISTS shows (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    movie_id UUID REFERENCES movies(id) ON DELETE CASCADE,
    screen_id UUID REFERENCES screens(id) ON DELETE CASCADE,
    start_time TIMESTAMPTZ NOT NULL,
    price DECIMAL DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE shows ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public shows are viewable by everyone" ON shows FOR SELECT USING (true);
CREATE POLICY "Admins can insert shows" ON shows FOR INSERT WITH CHECK (true);
CREATE POLICY "Admins can update shows" ON shows FOR UPDATE USING (true);
CREATE POLICY "Admins can delete shows" ON shows FOR DELETE USING (true);

-- 5. Seats
CREATE TABLE IF NOT EXISTS seats (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    screen_id UUID REFERENCES screens(id) ON DELETE CASCADE,
    row TEXT NOT NULL,
    col INTEGER NOT NULL,
    tier TEXT,
    price DECIMAL DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE seats ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public seats are viewable by everyone" ON seats FOR SELECT USING (true);
CREATE POLICY "Admins can insert seats" ON seats FOR INSERT WITH CHECK (true);
CREATE POLICY "Admins can update seats" ON seats FOR UPDATE USING (true);
CREATE POLICY "Admins can delete seats" ON seats FOR DELETE USING (true);

-- 6. Bookings
CREATE TABLE IF NOT EXISTS bookings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    show_id UUID REFERENCES shows(id) ON DELETE CASCADE,
    seat_id UUID REFERENCES seats(id) ON DELETE CASCADE,
    user_id UUID, -- References auth.users(id) inherently 
    session_id TEXT,
    status TEXT DEFAULT 'locked' CHECK (status IN ('locked', 'confirmed', 'cancelled', 'expired')),
    locked_at TIMESTAMPTZ,
    confirmed_at TIMESTAMPTZ,
    payment_id TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own bookings" ON bookings FOR SELECT USING (true); -- Relaxed for baseline, restricted in functions
CREATE POLICY "Users can insert bookings" ON bookings FOR INSERT WITH CHECK (true);
CREATE POLICY "Users can update own bookings" ON bookings FOR UPDATE USING (true);
CREATE POLICY "Users can delete own bookings" ON bookings FOR DELETE USING (true);


-- ==========================================
-- Migration: 001_scalability_improvements.sql
-- ==========================================

-- ============================================
-- Quick My Ticket Scalability Improvements
-- ============================================
-- This migration adds:
-- 1. Atomic seat locking function (prevents race conditions)
-- 2. Lock expiry mechanism (releases abandoned locks)
-- 3. Performance indexes
-- 4. Seat availability view (optimized queries)
-- 5. Server-side price calculation function

-- ============================================
-- 1. ATOMIC SEAT LOCKING FUNCTION
-- ============================================
-- This function uses row-level locking to prevent race conditions
-- when multiple users try to lock the same seat simultaneously.

CREATE OR REPLACE FUNCTION lock_seat(
    p_show_id UUID, 
    p_seat_id UUID, 
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    booking_id UUID, 
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER  -- Runs with function owner's permissions
AS $$
DECLARE
    v_booking_id UUID;
    v_existing RECORD;
    v_screen_id UUID;
    v_seat_exists BOOLEAN;
BEGIN
    -- Validate that the show exists and get screen_id
    SELECT screen_id INTO v_screen_id 
    FROM shows 
    WHERE id = p_show_id;
    
    IF v_screen_id IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Show not found'::TEXT;
        RETURN;
    END IF;
    
    -- Validate that the seat exists and belongs to the show's screen
    SELECT EXISTS(
        SELECT 1 FROM seats 
        WHERE id = p_seat_id AND screen_id = v_screen_id
    ) INTO v_seat_exists;
    
    IF NOT v_seat_exists THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat not found for this show'::TEXT;
        RETURN;
    END IF;
    
    -- Try to acquire a lock on existing booking (if any)
    -- SKIP LOCKED ensures we don't wait for other transactions
    SELECT * INTO v_existing
    FROM bookings 
    WHERE show_id = p_show_id 
      AND seat_id = p_seat_id 
      AND status IN ('locked', 'confirmed')
    FOR UPDATE SKIP LOCKED;
    
    -- Check if seat is already taken
    IF FOUND THEN
        -- Check if it's the same user's existing lock
        IF ((v_existing.user_id IS NOT NULL AND v_existing.user_id = p_user_id) OR
            (v_existing.user_id IS NULL AND v_existing.session_id = p_session_id)) AND v_existing.status = 'locked' THEN
            -- Refresh the lock timestamp
            UPDATE bookings 
            SET locked_at = NOW() 
            WHERE id = v_existing.id;
            
            RETURN QUERY SELECT v_existing.id, TRUE, 'Lock refreshed'::TEXT;
            RETURN;
        ELSE
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is already locked or booked'::TEXT;
            RETURN;
        END IF;
    END IF;
    
    -- Insert new booking with lock
    INSERT INTO bookings (show_id, seat_id, user_id, session_id, status, locked_at)
    VALUES (p_show_id, p_seat_id, p_user_id, p_session_id, 'locked', NOW())
    RETURNING id INTO v_booking_id;
    
    RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
    
EXCEPTION
    WHEN unique_violation THEN
        -- Race condition: another transaction inserted first
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat was just locked by another user'::TEXT;
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, ('Error: ' || SQLERRM)::TEXT;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION lock_seat(UUID, UUID, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION lock_seat(UUID, UUID, UUID, TEXT) TO anon;


-- ============================================
-- 2. LOCK EXPIRY FUNCTION
-- ============================================
-- This function releases locks that have been held for too long.
-- Should be called periodically via a cron job or Edge Function.

CREATE OR REPLACE FUNCTION release_expired_locks(
    p_lock_timeout_minutes INTEGER DEFAULT 5
)
RETURNS TABLE(
    released_count INTEGER,
    released_ids UUID[]
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_released_ids UUID[];
    v_count INTEGER;
BEGIN
    -- Update expired locks to 'expired' status
    WITH expired AS (
        UPDATE bookings 
        SET status = 'expired'
        WHERE status = 'locked' 
          AND locked_at < NOW() - (p_lock_timeout_minutes || ' minutes')::INTERVAL
        RETURNING id
    )
    SELECT array_agg(id), COUNT(*)::INTEGER 
    INTO v_released_ids, v_count
    FROM expired;
    
    RETURN QUERY SELECT COALESCE(v_count, 0), COALESCE(v_released_ids, ARRAY[]::UUID[]);
END;
$$;

-- Only allow service role to execute (for cron/edge function)
REVOKE ALL ON FUNCTION release_expired_locks(INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION release_expired_locks(INTEGER) TO service_role;


-- ============================================
-- 3. SERVER-SIDE PRICE CALCULATION
-- ============================================
-- Calculates the total price for a set of bookings.
-- Used by Edge Functions to verify payment amounts.

CREATE OR REPLACE FUNCTION calculate_booking_total(
    p_booking_ids UUID[],
    p_tax_rate DECIMAL DEFAULT 0.18
)
RETURNS TABLE(
    subtotal DECIMAL,
    tax DECIMAL,
    total DECIMAL,
    seat_count INTEGER
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_subtotal DECIMAL;
    v_seat_count INTEGER;
BEGIN
    -- Calculate subtotal from seats or show prices
    SELECT 
        COALESCE(SUM(COALESCE(s.price, sh.price, 0)), 0),
        COUNT(*)::INTEGER
    INTO v_subtotal, v_seat_count
    FROM bookings b
    JOIN seats s ON s.id = b.seat_id
    JOIN shows sh ON sh.id = b.show_id
    WHERE b.id = ANY(p_booking_ids)
      AND b.status = 'locked';  -- Only count locked bookings
    
    RETURN QUERY SELECT 
        v_subtotal,
        ROUND(v_subtotal * p_tax_rate, 2),
        ROUND(v_subtotal * (1 + p_tax_rate), 2),
        v_seat_count;
END;
$$;

GRANT EXECUTE ON FUNCTION calculate_booking_total(UUID[], DECIMAL) TO authenticated;
GRANT EXECUTE ON FUNCTION calculate_booking_total(UUID[], DECIMAL) TO service_role;


-- ============================================
-- 4. PERFORMANCE INDEXES
-- ============================================
-- These indexes optimize common queries in the application.

-- Index for finding bookings by show and status (seat availability)
CREATE INDEX IF NOT EXISTS idx_bookings_show_status 
ON bookings(show_id, status) 
WHERE status IN ('locked', 'confirmed');

-- Index for finding bookings by seat and show (locking check)
CREATE INDEX IF NOT EXISTS idx_bookings_seat_show 
ON bookings(seat_id, show_id);

-- Index for user's bookings
CREATE INDEX IF NOT EXISTS idx_bookings_user_status 
ON bookings(user_id, status);

-- Index for expired locks cleanup
CREATE INDEX IF NOT EXISTS idx_bookings_locked_at 
ON bookings(locked_at) 
WHERE status = 'locked';

-- Index for shows by movie (movie details page)
CREATE INDEX IF NOT EXISTS idx_shows_movie_date 
ON shows(movie_id, start_time);

-- Index for seats by screen (seat grid loading)
CREATE INDEX IF NOT EXISTS idx_seats_screen_position 
ON seats(screen_id, row, col);


-- ============================================
-- 5. SEAT AVAILABILITY VIEW
-- ============================================
-- This view provides an optimized way to fetch seat states.

CREATE OR REPLACE VIEW seat_availability AS
SELECT 
    s.id AS seat_id,
    s.screen_id,
    s.row,
    s.col,
    s.tier,
    s.price AS seat_price,
    sh.id AS show_id,
    sh.price AS show_price,
    COALESCE(s.price, sh.price, 0) AS effective_price,
    CASE 
        WHEN b.status = 'confirmed' THEN 'booked'
        WHEN b.status = 'locked' THEN 'locked'
        ELSE 'available'
    END AS availability_status,
    b.user_id AS locked_by,
    b.id AS booking_id,
    b.locked_at
FROM seats s
CROSS JOIN shows sh
LEFT JOIN LATERAL (
    SELECT * FROM bookings 
    WHERE seat_id = s.id 
      AND show_id = sh.id 
      AND status IN ('locked', 'confirmed')
    LIMIT 1
) b ON TRUE
WHERE s.screen_id = sh.screen_id;

-- Grant select on the view
GRANT SELECT ON seat_availability TO authenticated;
GRANT SELECT ON seat_availability TO anon;


-- ============================================
-- 6. UNLOCK SEAT FUNCTION
-- ============================================
-- Safely unlocks a seat (user can only unlock their own locks)

CREATE OR REPLACE FUNCTION unlock_seat(
    p_booking_id UUID,
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking RECORD;
BEGIN
    -- Get the booking
    SELECT * INTO v_booking
    FROM bookings
    WHERE id = p_booking_id
    FOR UPDATE;
    
    IF NOT FOUND THEN
        RETURN QUERY SELECT FALSE, 'Booking not found'::TEXT;
        RETURN;
    END IF;
    
    -- Verify ownership
    IF (v_booking.user_id IS NOT NULL AND v_booking.user_id != p_user_id) OR
       (v_booking.user_id IS NULL AND v_booking.session_id != p_session_id) THEN
        RETURN QUERY SELECT FALSE, 'Not authorized to unlock this booking'::TEXT;
        RETURN;
    END IF;
    
    -- Can only unlock 'locked' status
    IF v_booking.status != 'locked' THEN
        RETURN QUERY SELECT FALSE, ('Cannot unlock booking with status: ' || v_booking.status)::TEXT;
        RETURN;
    END IF;
    
    -- Update to cancelled
    UPDATE bookings 
    SET status = 'cancelled', locked_at = NULL
    WHERE id = p_booking_id;
    
    RETURN QUERY SELECT TRUE, 'Seat unlocked successfully'::TEXT;
END;
$$;

GRANT EXECUTE ON FUNCTION unlock_seat(UUID, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION unlock_seat(UUID, UUID, TEXT) TO anon;


-- ============================================
-- 7. CONFIRM BOOKING FUNCTION (for Edge Function)
-- ============================================
-- Confirms bookings after successful payment verification.
-- Only callable by service_role (Edge Functions).

CREATE OR REPLACE FUNCTION confirm_bookings(
    p_booking_ids UUID[],
    p_payment_id TEXT
)
RETURNS TABLE(
    confirmed_count INTEGER,
    total_amount DECIMAL
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_count INTEGER;
    v_total DECIMAL;
BEGIN
    -- Calculate total before confirming
    SELECT total INTO v_total
    FROM calculate_booking_total(p_booking_ids);
    
    -- Confirm all bookings
    WITH confirmed AS (
        UPDATE bookings 
        SET status = 'confirmed',
            payment_id = p_payment_id,
            confirmed_at = NOW()
        WHERE id = ANY(p_booking_ids)
          AND status = 'locked'
        RETURNING id
    )
    SELECT COUNT(*)::INTEGER INTO v_count FROM confirmed;
    
    RETURN QUERY SELECT v_count, COALESCE(v_total, 0);
END;
$$;

REVOKE ALL ON FUNCTION confirm_bookings(UUID[], TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION confirm_bookings(UUID[], TEXT) TO service_role;


-- ============================================
-- 8. OPTIONAL: Add status check constraint
-- ============================================
-- Ensure only valid statuses are used

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'bookings_status_check'
    ) THEN
        ALTER TABLE bookings 
        ADD CONSTRAINT bookings_status_check 
        CHECK (status IN ('locked', 'confirmed', 'cancelled', 'expired'));
    END IF;
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;


-- ============================================
-- 9. LOCK TIMEOUT SETTING (optional)
-- ============================================
-- Store the lock timeout in a settings table or as a constant

-- Create a simple settings table if needed
CREATE TABLE IF NOT EXISTS app_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    description TEXT,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Insert default lock timeout (5 minutes)
INSERT INTO app_settings (key, value, description)
VALUES ('lock_timeout_minutes', '5', 'How long a seat lock remains valid before expiring')
ON CONFLICT (key) DO NOTHING;

GRANT SELECT ON app_settings TO authenticated;
GRANT SELECT ON app_settings TO anon;


-- ==========================================
-- Migration: 002_theater_owner_system.sql
-- ==========================================

-- ============================================
-- Quick My Ticket Theater Owner System
-- ============================================
-- This migration adds:
-- 1. Theater owners table (links users to theatres)
-- 2. Updated RLS policies for multi-tenant access
-- 3. Owner-specific views and functions
-- 4. Dashboard statistics functions

-- ============================================
-- 1. THEATER OWNERS TABLE
-- ============================================
-- Links users to theatres they own/manage

CREATE TABLE IF NOT EXISTS theater_owners (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    theatre_id UUID NOT NULL REFERENCES theatres(id) ON DELETE CASCADE,
    role TEXT DEFAULT 'owner' CHECK (role IN ('owner', 'manager', 'staff')),
    permissions JSONB DEFAULT '{"can_edit_shows": true, "can_view_revenue": true, "can_manage_staff": false}'::JSONB,
    invited_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, theatre_id)
);

-- Create index for quick lookups
CREATE INDEX IF NOT EXISTS idx_theater_owners_user ON theater_owners(user_id);
CREATE INDEX IF NOT EXISTS idx_theater_owners_theatre ON theater_owners(theatre_id);

-- Enable RLS
ALTER TABLE theater_owners ENABLE ROW LEVEL SECURITY;

-- ============================================
-- 2. RLS POLICIES FOR THEATER OWNERS TABLE
-- ============================================

-- Super admins can manage all theater owners
CREATE POLICY "Admin full access theater_owners" ON theater_owners 
FOR ALL USING (
    (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);

-- Theater owners can read their own assignments
CREATE POLICY "Owners read own assignments" ON theater_owners 
FOR SELECT USING (
    auth.uid() = user_id
);

-- Theater owners with 'owner' role can invite managers/staff to their theatres
CREATE POLICY "Owners can add staff" ON theater_owners 
FOR INSERT WITH CHECK (
    EXISTS (
        SELECT 1 FROM theater_owners existing
        WHERE existing.theatre_id = theater_owners.theatre_id
        AND existing.user_id = auth.uid()
        AND existing.role = 'owner'
    )
    AND theater_owners.role IN ('manager', 'staff')
);


-- ============================================
-- 3. UPDATE THEATRES RLS FOR OWNER ACCESS
-- ============================================

-- Drop existing admin-only policy if exists (safely)
DO $$
BEGIN
    DROP POLICY IF EXISTS "Admin write" ON theatres;
    DROP POLICY IF EXISTS "Admin full access" ON theatres;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- Allow theater owners to manage their theatres
CREATE POLICY "Owner manage theatres" ON theatres 
FOR UPDATE USING (
    EXISTS (
        SELECT 1 FROM theater_owners 
        WHERE theatre_id = theatres.id 
        AND user_id = auth.uid()
        AND role IN ('owner', 'manager')
    )
);

-- Admins can do everything on theatres
CREATE POLICY "Admin manage theatres" ON theatres 
FOR ALL USING (
    (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);


-- ============================================
-- 4. UPDATE SCREENS RLS FOR OWNER ACCESS
-- ============================================

DO $$
BEGIN
    DROP POLICY IF EXISTS "Admin write" ON screens;
    DROP POLICY IF EXISTS "Admin full access" ON screens;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- Allow theater owners to manage screens in their theatres
CREATE POLICY "Owner manage screens" ON screens 
FOR ALL USING (
    EXISTS (
        SELECT 1 FROM theater_owners 
        WHERE theatre_id = screens.theatre_id 
        AND user_id = auth.uid()
        AND role IN ('owner', 'manager')
    )
);

-- Admins can do everything on screens
CREATE POLICY "Admin manage screens" ON screens 
FOR ALL USING (
    (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);


-- ============================================
-- 5. UPDATE SHOWS RLS FOR OWNER ACCESS
-- ============================================

DO $$
BEGIN
    DROP POLICY IF EXISTS "Admin write" ON shows;
    DROP POLICY IF EXISTS "Admin full access" ON shows;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- Allow theater owners to manage shows on their screens
CREATE POLICY "Owner manage shows" ON shows 
FOR ALL USING (
    EXISTS (
        SELECT 1 FROM theater_owners to_owner
        JOIN screens s ON s.theatre_id = to_owner.theatre_id
        WHERE s.id = shows.screen_id
        AND to_owner.user_id = auth.uid()
        AND to_owner.role IN ('owner', 'manager')
    )
);

-- Admins can do everything on shows
CREATE POLICY "Admin manage shows" ON shows 
FOR ALL USING (
    (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);


-- ============================================
-- 6. OWNER DASHBOARD FUNCTIONS
-- ============================================

-- Function to get theatres owned by a user
CREATE OR REPLACE FUNCTION get_owned_theatres(p_user_id UUID)
RETURNS TABLE(
    theatre_id UUID,
    theatre_name TEXT,
    location TEXT,
    role TEXT,
    screen_count BIGINT,
    total_seats BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        t.id AS theatre_id,
        t.name AS theatre_name,
        t.location,
        to_owner.role,
        COUNT(DISTINCT s.id) AS screen_count,
        COUNT(DISTINCT seats.id) AS total_seats
    FROM theater_owners to_owner
    JOIN theatres t ON t.id = to_owner.theatre_id
    LEFT JOIN screens s ON s.theatre_id = t.id
    LEFT JOIN seats ON seats.screen_id = s.id
    WHERE to_owner.user_id = p_user_id
    GROUP BY t.id, t.name, t.location, to_owner.role
    ORDER BY t.name;
END;
$$;

GRANT EXECUTE ON FUNCTION get_owned_theatres(UUID) TO authenticated;


-- Function to get dashboard statistics for a theater owner
CREATE OR REPLACE FUNCTION get_owner_dashboard_stats(p_user_id UUID)
RETURNS TABLE(
    total_theatres BIGINT,
    total_screens BIGINT,
    total_seats BIGINT,
    today_bookings BIGINT,
    today_revenue DECIMAL,
    currently_locked BIGINT,
    today_confirmed BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_theatre_ids UUID[];
    v_today DATE := CURRENT_DATE;
BEGIN
    -- Get all theatre IDs owned by this user
    SELECT ARRAY_AGG(theatre_id) INTO v_theatre_ids
    FROM theater_owners
    WHERE user_id = p_user_id;
    
    -- If user owns no theatres, return zeros
    IF v_theatre_ids IS NULL THEN
        RETURN QUERY SELECT 0::BIGINT, 0::BIGINT, 0::BIGINT, 0::BIGINT, 0::DECIMAL, 0::BIGINT, 0::BIGINT;
        RETURN;
    END IF;
    
    RETURN QUERY
    WITH owned_screens AS (
        SELECT s.id AS screen_id
        FROM screens s
        WHERE s.theatre_id = ANY(v_theatre_ids)
    ),
    owned_shows AS (
        SELECT sh.id AS show_id, sh.price
        FROM shows sh
        JOIN owned_screens os ON os.screen_id = sh.screen_id
    ),
    owned_bookings AS (
        SELECT b.*
        FROM bookings b
        JOIN owned_shows osh ON osh.show_id = b.show_id
    )
    SELECT
        (SELECT COUNT(*) FROM unnest(v_theatre_ids))::BIGINT AS total_theatres,
        (SELECT COUNT(*) FROM owned_screens)::BIGINT AS total_screens,
        (SELECT COUNT(*) FROM seats WHERE screen_id IN (SELECT screen_id FROM owned_screens))::BIGINT AS total_seats,
        (SELECT COUNT(*) FROM owned_bookings WHERE DATE(created_at) = v_today)::BIGINT AS today_bookings,
        COALESCE((
            SELECT SUM(COALESCE(seats.price, osh.price, 0))
            FROM owned_bookings ob
            JOIN owned_shows osh ON osh.show_id = ob.show_id
            JOIN seats ON seats.id = ob.seat_id
            WHERE ob.status = 'confirmed' AND DATE(ob.confirmed_at) = v_today
        ), 0)::DECIMAL AS today_revenue,
        (SELECT COUNT(*) FROM owned_bookings WHERE status = 'locked')::BIGINT AS currently_locked,
        (SELECT COUNT(*) FROM owned_bookings WHERE status = 'confirmed' AND DATE(confirmed_at) = v_today)::BIGINT AS today_confirmed;
END;
$$;

GRANT EXECUTE ON FUNCTION get_owner_dashboard_stats(UUID) TO authenticated;


-- Function to get shows for a theatre with booking counts
CREATE OR REPLACE FUNCTION get_owner_shows(
    p_user_id UUID,
    p_theatre_id UUID DEFAULT NULL,
    p_date DATE DEFAULT CURRENT_DATE
)
RETURNS TABLE(
    show_id UUID,
    movie_title TEXT,
    screen_name TEXT,
    theatre_name TEXT,
    start_time TIMESTAMPTZ,
    end_time TIMESTAMPTZ,
    base_price DECIMAL,
    total_seats BIGINT,
    booked_seats BIGINT,
    locked_seats BIGINT,
    available_seats BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        sh.id AS show_id,
        m.title AS movie_title,
        sc.name AS screen_name,
        t.name AS theatre_name,
        sh.start_time,
        sh.end_time,
        sh.price AS base_price,
        COUNT(DISTINCT seats.id) AS total_seats,
        COUNT(DISTINCT CASE WHEN b.status = 'confirmed' THEN b.id END) AS booked_seats,
        COUNT(DISTINCT CASE WHEN b.status = 'locked' THEN b.id END) AS locked_seats,
        COUNT(DISTINCT seats.id) - COUNT(DISTINCT CASE WHEN b.status IN ('confirmed', 'locked') THEN b.id END) AS available_seats
    FROM shows sh
    JOIN movies m ON m.id = sh.movie_id
    JOIN screens sc ON sc.id = sh.screen_id
    JOIN theatres t ON t.id = sc.theatre_id
    JOIN theater_owners to_owner ON to_owner.theatre_id = t.id
    LEFT JOIN seats ON seats.screen_id = sc.id
    LEFT JOIN bookings b ON b.show_id = sh.id AND b.seat_id = seats.id AND b.status IN ('confirmed', 'locked')
    WHERE to_owner.user_id = p_user_id
      AND (p_theatre_id IS NULL OR t.id = p_theatre_id)
      AND DATE(sh.start_time) = p_date
    GROUP BY sh.id, m.title, sc.name, t.name, sh.start_time, sh.end_time, sh.price
    ORDER BY sh.start_time;
END;
$$;

GRANT EXECUTE ON FUNCTION get_owner_shows(UUID, UUID, DATE) TO authenticated;


-- Function to check if user is a theater owner
CREATE OR REPLACE FUNCTION is_theater_owner(p_user_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM theater_owners WHERE user_id = p_user_id
    );
END;
$$;

GRANT EXECUTE ON FUNCTION is_theater_owner(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION is_theater_owner(UUID) TO anon;


-- ============================================
-- 7. ADD OWNER FLAG TO USER METADATA CHECK
-- ============================================

-- View to easily check user roles
CREATE OR REPLACE VIEW user_roles AS
SELECT 
    au.id AS user_id,
    au.email,
    COALESCE((au.raw_user_meta_data ->> 'is_admin')::boolean, false) AS is_admin,
    EXISTS (SELECT 1 FROM theater_owners WHERE user_id = au.id) AS is_theater_owner,
    (SELECT ARRAY_AGG(theatre_id) FROM theater_owners WHERE user_id = au.id) AS owned_theatre_ids
FROM auth.users au;

-- Note: This view uses auth.users which requires careful RLS handling
-- For security, we provide a function instead

CREATE OR REPLACE FUNCTION get_user_role(p_user_id UUID)
RETURNS TABLE(
    is_admin BOOLEAN,
    is_theater_owner BOOLEAN,
    owned_theatre_count BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        COALESCE((au.raw_user_meta_data ->> 'is_admin')::boolean, false) AS is_admin,
        EXISTS (SELECT 1 FROM theater_owners WHERE user_id = p_user_id) AS is_theater_owner,
        (SELECT COUNT(*) FROM theater_owners WHERE user_id = p_user_id) AS owned_theatre_count
    FROM auth.users au
    WHERE au.id = p_user_id;
END;
$$;

GRANT EXECUTE ON FUNCTION get_user_role(UUID) TO authenticated;


-- ============================================
-- 8. TRIGGER TO UPDATE updated_at
-- ============================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS update_theater_owners_updated_at ON theater_owners;
CREATE TRIGGER update_theater_owners_updated_at
    BEFORE UPDATE ON theater_owners
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();


-- ============================================
-- 9. GRANT SELECT ON theater_owners FOR OWNERSHIP CHECK
-- ============================================

GRANT SELECT ON theater_owners TO authenticated;


-- ============================================
-- 10. SAMPLE DATA (Optional - for testing)
-- ============================================
-- Uncomment to add sample theater owner assignments
-- This assumes you have existing theatres and users

/*
-- Example: Assign a user as theater owner
INSERT INTO theater_owners (user_id, theatre_id, role)
SELECT 
    'USER_UUID_HERE',
    id,
    'owner'
FROM theatres
WHERE name = 'Your Theatre Name'
ON CONFLICT DO NOTHING;
*/

-- ============================================
-- MIGRATION COMPLETE
-- ============================================
-- Next steps:
-- 1. Run this migration in Supabase SQL Editor
-- 2. Assign theater owners via admin panel or direct SQL
-- 3. Theater owners can now access owner-dashboard.html


-- ==========================================
-- Migration: 003_owner_registration_system.sql
-- ==========================================

-- ============================================
-- Quick My Ticket - Owner Registration & Approval System
-- Migration 003
-- ============================================

-- Table for pending owner applications
CREATE TABLE IF NOT EXISTS owner_applications (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    full_name TEXT NOT NULL,
    phone TEXT,
    theatre_name TEXT NOT NULL,
    theatre_location TEXT NOT NULL,
    business_license TEXT, -- Optional license number
    message TEXT, -- Why they want to partner
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
    admin_notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    reviewed_at TIMESTAMP WITH TIME ZONE,
    reviewed_by UUID REFERENCES auth.users(id)
);

-- Enable RLS
ALTER TABLE owner_applications ENABLE ROW LEVEL SECURITY;

-- Users can view their own applications
CREATE POLICY "Users can view own applications" ON owner_applications
    FOR SELECT USING (auth.uid() = user_id);

-- Users can insert their own application
CREATE POLICY "Users can create applications" ON owner_applications
    FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Admins can view all applications
CREATE POLICY "Admins can view all applications" ON owner_applications
    FOR SELECT USING (
        (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
    );

-- Admins can update applications (approve/reject)
CREATE POLICY "Admins can update applications" ON owner_applications
    FOR UPDATE USING (
        (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
    );

-- ============================================
-- Functions for Owner Application System
-- ============================================

-- Submit owner application
CREATE OR REPLACE FUNCTION submit_owner_application(
    p_full_name TEXT,
    p_phone TEXT,
    p_theatre_name TEXT,
    p_theatre_location TEXT,
    p_business_license TEXT DEFAULT NULL,
    p_message TEXT DEFAULT NULL
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_email TEXT;
    v_existing_app UUID;
    v_result JSON;
BEGIN
    -- Get user email
    SELECT email INTO v_email FROM auth.users WHERE id = v_user_id;
    
    IF v_email IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'User not authenticated');
    END IF;
    
    -- Check if user already has a pending or approved application
    SELECT id INTO v_existing_app 
    FROM owner_applications 
    WHERE user_id = v_user_id AND status IN ('pending', 'approved')
    LIMIT 1;
    
    IF v_existing_app IS NOT NULL THEN
        RETURN json_build_object('success', false, 'error', 'You already have a pending or approved application');
    END IF;
    
    -- Check if user is already an owner
    IF EXISTS (SELECT 1 FROM theater_owners WHERE user_id = v_user_id) THEN
        RETURN json_build_object('success', false, 'error', 'You are already a registered theater owner');
    END IF;
    
    -- Insert application
    INSERT INTO owner_applications (
        user_id, email, full_name, phone, 
        theatre_name, theatre_location, business_license, message
    ) VALUES (
        v_user_id, v_email, p_full_name, p_phone,
        p_theatre_name, p_theatre_location, p_business_license, p_message
    );
    
    RETURN json_build_object('success', true, 'message', 'Application submitted successfully');
END;
$$;

GRANT EXECUTE ON FUNCTION submit_owner_application(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated;

-- Get pending applications (for admin)
CREATE OR REPLACE FUNCTION get_pending_applications()
RETURNS TABLE(
    id UUID,
    user_id UUID,
    email TEXT,
    full_name TEXT,
    phone TEXT,
    theatre_name TEXT,
    theatre_location TEXT,
    business_license TEXT,
    message TEXT,
    status TEXT,
    created_at TIMESTAMP WITH TIME ZONE
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Check if caller is admin
    IF NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;
    
    RETURN QUERY
    SELECT 
        oa.id, oa.user_id, oa.email, oa.full_name, oa.phone,
        oa.theatre_name, oa.theatre_location, oa.business_license,
        oa.message, oa.status, oa.created_at
    FROM owner_applications oa
    WHERE oa.status = 'pending'
    ORDER BY oa.created_at DESC;
END;
$$;

GRANT EXECUTE ON FUNCTION get_pending_applications() TO authenticated;

-- Approve owner application (admin only)
CREATE OR REPLACE FUNCTION approve_owner_application(
    p_application_id UUID,
    p_admin_notes TEXT DEFAULT NULL
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_admin_id UUID := auth.uid();
    v_app RECORD;
    v_theatre_id UUID;
BEGIN
    -- Check if caller is admin
    IF NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RETURN json_build_object('success', false, 'error', 'Access denied: Admin only');
    END IF;
    
    -- Get application
    SELECT * INTO v_app FROM owner_applications WHERE id = p_application_id;
    
    IF v_app IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Application not found');
    END IF;
    
    IF v_app.status != 'pending' THEN
        RETURN json_build_object('success', false, 'error', 'Application already processed');
    END IF;
    
    -- Create the theatre
    INSERT INTO theatres (name, location)
    VALUES (v_app.theatre_name, v_app.theatre_location)
    RETURNING id INTO v_theatre_id;
    
    -- Add user as theater owner
    INSERT INTO theater_owners (user_id, theatre_id, role)
    VALUES (v_app.user_id, v_theatre_id, 'owner');
    
    -- Update application status
    UPDATE owner_applications
    SET status = 'approved',
        reviewed_at = NOW(),
        reviewed_by = v_admin_id,
        admin_notes = p_admin_notes
    WHERE id = p_application_id;
    
    RETURN json_build_object(
        'success', true, 
        'message', 'Application approved',
        'theatre_id', v_theatre_id
    );
END;
$$;

GRANT EXECUTE ON FUNCTION approve_owner_application(UUID, TEXT) TO authenticated;

-- Reject owner application (admin only)
CREATE OR REPLACE FUNCTION reject_owner_application(
    p_application_id UUID,
    p_admin_notes TEXT DEFAULT NULL
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_admin_id UUID := auth.uid();
BEGIN
    -- Check if caller is admin
    IF NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RETURN json_build_object('success', false, 'error', 'Access denied: Admin only');
    END IF;
    
    -- Check if application exists and is pending
    IF NOT EXISTS (SELECT 1 FROM owner_applications WHERE id = p_application_id AND status = 'pending') THEN
        RETURN json_build_object('success', false, 'error', 'Application not found or already processed');
    END IF;
    
    -- Update application status
    UPDATE owner_applications
    SET status = 'rejected',
        reviewed_at = NOW(),
        reviewed_by = v_admin_id,
        admin_notes = p_admin_notes
    WHERE id = p_application_id;
    
    RETURN json_build_object('success', true, 'message', 'Application rejected');
END;
$$;

GRANT EXECUTE ON FUNCTION reject_owner_application(UUID, TEXT) TO authenticated;

-- Check application status (for users)
CREATE OR REPLACE FUNCTION get_my_application_status()
RETURNS TABLE(
    id UUID,
    status TEXT,
    created_at TIMESTAMP WITH TIME ZONE,
    reviewed_at TIMESTAMP WITH TIME ZONE,
    admin_notes TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        oa.id, oa.status, oa.created_at, oa.reviewed_at, oa.admin_notes
    FROM owner_applications oa
    WHERE oa.user_id = auth.uid()
    ORDER BY oa.created_at DESC
    LIMIT 1;
END;
$$;

GRANT EXECUTE ON FUNCTION get_my_application_status() TO authenticated;


-- ==========================================
-- Migration: 004_custom_seat_layouts.sql
-- ==========================================

-- ============================================
-- Quick My Ticket - Custom Seat Layout System
-- Migration 004
-- ============================================

-- Add seat_layout column to screens table
-- This stores the custom layout as JSON
ALTER TABLE screens ADD COLUMN IF NOT EXISTS seat_layout JSONB;

-- The seat_layout JSON structure:
-- {
--   "rows": [
--     {
--       "label": "A",           -- Row label
--       "seats": [
--         { "id": 1, "type": "regular", "price": 200 },
--         { "id": 2, "type": "regular", "price": 200 },
--         null,                  -- null = gap/aisle
--         { "id": 3, "type": "premium", "price": 300 },
--         ...
--       ]
--     },
--     ...
--   ],
--   "metadata": {
--     "totalSeats": 100,
--     "rowCount": 10,
--     "maxSeatsPerRow": 15
--   }
-- }

-- Function to update seat layout (for owners)
CREATE OR REPLACE FUNCTION update_screen_layout(
    p_screen_id UUID,
    p_seat_layout JSONB
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_theatre_id UUID;
    v_is_owner BOOLEAN;
BEGIN
    -- Get the theatre for this screen
    SELECT theatre_id INTO v_theatre_id
    FROM screens
    WHERE id = p_screen_id;
    
    IF v_theatre_id IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Screen not found');
    END IF;
    
    -- Check if user owns this theatre
    SELECT EXISTS(
        SELECT 1 FROM theater_owners
        WHERE user_id = v_user_id AND theatre_id = v_theatre_id
    ) INTO v_is_owner;
    
    -- Also allow admins
    IF NOT v_is_owner AND NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RETURN json_build_object('success', false, 'error', 'Access denied');
    END IF;
    
    -- Sync seats table.
    -- To avoid FK issues and layout/seat mismatches, only allow this if no active
    -- bookings exist, and check before changing screens.seat_layout.
    IF EXISTS (
        SELECT 1 FROM bookings b
        JOIN shows s ON b.show_id = s.id
        WHERE s.screen_id = p_screen_id AND b.status IN ('confirmed', 'locked')
    ) THEN
        RETURN json_build_object('success', false, 'error', 'Cannot update layout: Active bookings exist for this screen');
    END IF;

    -- Update the screen record after validation so failed saves leave it unchanged.
    UPDATE screens
    SET
        seat_layout = p_seat_layout,
        rows = COALESCE((p_seat_layout->'metadata'->>'rowCount')::integer, rows),
        seats_per_row = COALESCE((p_seat_layout->'metadata'->>'maxSeatsPerRow')::integer, seats_per_row)
    WHERE id = p_screen_id;

    -- Delete old seats
    DELETE FROM seats WHERE screen_id = p_screen_id;

    -- Insert new seats from JSON
    -- Expecting structure: { "rows": [ { "label": "A", "seats": [ { "id": 1, "type": "regular", "price": 200 }, null, ... ] } ] }
    INSERT INTO seats (screen_id, row, col, tier, price)
    SELECT 
        p_screen_id,
        r->>'label',
        (s->>'id')::integer,
        s->>'type',
        (s->>'price')::integer
    FROM jsonb_array_elements(p_seat_layout->'rows') AS r
    CROSS JOIN jsonb_array_elements(r->'seats') AS s
    WHERE s IS NOT NULL AND s != 'null'::jsonb;

    RETURN json_build_object('success', true, 'message', 'Layout updated and seats synced');
END;
$$;

GRANT EXECUTE ON FUNCTION update_screen_layout(UUID, JSONB) TO authenticated;

-- Function to get screen layout
CREATE OR REPLACE FUNCTION get_screen_layout(p_screen_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_layout JSONB;
    v_rows INTEGER;
    v_seats_per_row INTEGER;
BEGIN
    SELECT seat_layout, rows, seats_per_row
    INTO v_layout, v_rows, v_seats_per_row
    FROM screens
    WHERE id = p_screen_id;
    
    -- If custom layout exists, return it
    IF v_layout IS NOT NULL THEN
        RETURN v_layout;
    END IF;
    
    -- Otherwise, generate default layout from rows/seats_per_row
    RETURN generate_default_layout(v_rows, v_seats_per_row);
END;
$$;

GRANT EXECUTE ON FUNCTION get_screen_layout(UUID) TO anon, authenticated;

-- Helper function to generate default seat layout
CREATE OR REPLACE FUNCTION generate_default_layout(
    p_rows INTEGER,
    p_seats_per_row INTEGER
)
RETURNS JSONB
LANGUAGE plpgsql
AS $$
DECLARE
    v_layout JSONB := '{"rows": [], "metadata": {}}';
    v_rows JSONB := '[]';
    v_row JSONB;
    v_seats JSONB;
    v_seat JSONB;
    i INTEGER;
    j INTEGER;
    v_row_label TEXT;
    v_seat_type TEXT;
    v_price INTEGER;
BEGIN
    FOR i IN 1..COALESCE(p_rows, 10) LOOP
        -- Generate row label (A, B, C, ...)
        v_row_label := CHR(64 + i);
        
        -- Determine seat type based on row position
        IF i <= 2 THEN
            v_seat_type := 'regular';
            v_price := 200;
        ELSIF i <= COALESCE(p_rows, 10) - 2 THEN
            v_seat_type := 'premium';
            v_price := 300;
        ELSE
            v_seat_type := 'vip';
            v_price := 500;
        END IF;
        
        v_seats := '[]';
        FOR j IN 1..COALESCE(p_seats_per_row, 12) LOOP
            v_seat := json_build_object(
                'id', j,
                'type', v_seat_type,
                'price', v_price
            )::jsonb;
            v_seats := v_seats || v_seat;
        END LOOP;
        
        v_row := json_build_object(
            'label', v_row_label,
            'seats', v_seats
        )::jsonb;
        
        v_rows := v_rows || v_row;
    END LOOP;
    
    v_layout := json_build_object(
        'rows', v_rows,
        'metadata', json_build_object(
            'totalSeats', COALESCE(p_rows, 10) * COALESCE(p_seats_per_row, 12),
            'rowCount', COALESCE(p_rows, 10),
            'maxSeatsPerRow', COALESCE(p_seats_per_row, 12)
        )
    )::jsonb;
    
    RETURN v_layout;
END;
$$;


-- ==========================================
-- Migration: 005_fix_seat_release.sql
-- ==========================================

-- ============================================
-- Quick My Ticket - Fix Seat Release Issue
-- ============================================
-- This migration fixes the seat release mechanism:
-- 1. Updates lock_seat to reuse cancelled/expired bookings instead of creating new ones
-- 2. Adds a manual cleanup function that can be called from client-side
-- 3. Adds a unique partial index to prevent duplicate active bookings

-- ============================================
-- 1. ADD UNIQUE PARTIAL INDEX
-- ============================================
-- Ensures only one active booking (locked/confirmed) per seat per show
CREATE UNIQUE INDEX IF NOT EXISTS idx_bookings_active_unique 
ON bookings(show_id, seat_id) 
WHERE status IN ('locked', 'confirmed');

-- ============================================
-- 2. IMPROVED LOCK_SEAT FUNCTION
-- ============================================
-- Key fix: Instead of always INSERTing, this version will:
-- 1. First check for any cancelled/expired booking for this seat and REUSE it
-- 2. Only create a new booking if none exists

CREATE OR REPLACE FUNCTION lock_seat(
    p_show_id UUID, 
    p_seat_id UUID, 
    p_user_id UUID
)
RETURNS TABLE(
    booking_id UUID, 
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking_id UUID;
    v_existing RECORD;
    v_screen_id UUID;
    v_seat_exists BOOLEAN;
    v_reusable_booking UUID;
BEGIN
    -- Validate that the show exists and get screen_id
    SELECT screen_id INTO v_screen_id 
    FROM shows 
    WHERE id = p_show_id;
    
    IF v_screen_id IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Show not found'::TEXT;
        RETURN;
    END IF;
    
    -- Validate that the seat exists and belongs to the show's screen
    SELECT EXISTS(
        SELECT 1 FROM seats 
        WHERE id = p_seat_id AND screen_id = v_screen_id
    ) INTO v_seat_exists;
    
    IF NOT v_seat_exists THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat not found for this show'::TEXT;
        RETURN;
    END IF;
    
    -- Try to acquire a lock on existing active booking (if any)
    SELECT * INTO v_existing
    FROM bookings 
    WHERE show_id = p_show_id 
      AND seat_id = p_seat_id 
      AND status IN ('locked', 'confirmed')
    FOR UPDATE SKIP LOCKED;
    
    -- Check if seat is already taken
    IF FOUND THEN
        -- Check if it's the same user's existing lock
        IF v_existing.user_id = p_user_id AND v_existing.status = 'locked' THEN
            -- Refresh the lock timestamp
            UPDATE bookings 
            SET locked_at = NOW() 
            WHERE id = v_existing.id;
            
            RETURN QUERY SELECT v_existing.id, TRUE, 'Lock refreshed'::TEXT;
            RETURN;
        ELSE
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is already locked or booked'::TEXT;
            RETURN;
        END IF;
    END IF;
    
    -- Look for a reusable cancelled/expired booking for this seat
    SELECT id INTO v_reusable_booking
    FROM bookings
    WHERE show_id = p_show_id
      AND seat_id = p_seat_id
      AND status IN ('cancelled', 'expired')
    ORDER BY created_at DESC
    LIMIT 1
    FOR UPDATE;
    
    IF v_reusable_booking IS NOT NULL THEN
        -- Reuse existing booking record
        UPDATE bookings 
        SET status = 'locked',
            user_id = p_user_id,
            locked_at = NOW(),
            payment_id = NULL,
            confirmed_at = NULL
        WHERE id = v_reusable_booking
        RETURNING id INTO v_booking_id;
        
        RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully (reused)'::TEXT;
        RETURN;
    END IF;
    
    -- Insert new booking with lock
    INSERT INTO bookings (show_id, seat_id, user_id, status, locked_at)
    VALUES (p_show_id, p_seat_id, p_user_id, 'locked', NOW())
    RETURNING id INTO v_booking_id;
    
    RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
    
EXCEPTION
    WHEN unique_violation THEN
        -- Race condition: another transaction inserted first
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat was just locked by another user'::TEXT;
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, ('Error: ' || SQLERRM)::TEXT;
END;
$$;

-- ============================================
-- 3. CLIENT-CALLABLE CLEANUP FUNCTION
-- ============================================
-- This function can be called by authenticated users to release their own expired locks
-- It's a lighter version that doesn't require service_role

CREATE OR REPLACE FUNCTION cleanup_my_expired_locks(
    p_timeout_minutes INTEGER DEFAULT 5
)
RETURNS TABLE(
    cleaned_count INTEGER
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id UUID;
    v_count INTEGER;
BEGIN
    -- Get current user
    v_user_id := auth.uid();
    
    IF v_user_id IS NULL THEN
        RETURN QUERY SELECT 0;
        RETURN;
    END IF;
    
    -- Release user's own expired locks
    WITH expired AS (
        UPDATE bookings 
        SET status = 'expired'
        WHERE user_id = v_user_id
          AND status = 'locked' 
          AND locked_at < NOW() - (p_timeout_minutes || ' minutes')::INTERVAL
        RETURNING id
    )
    SELECT COUNT(*)::INTEGER INTO v_count FROM expired;
    
    RETURN QUERY SELECT COALESCE(v_count, 0);
END;
$$;

GRANT EXECUTE ON FUNCTION cleanup_my_expired_locks(INTEGER) TO authenticated;

-- ============================================
-- 4. FORCE RELEASE FUNCTION (for stuck seats)
-- ============================================
-- Releases ALL locks older than a specified time (service role only)
-- Call this manually if seats are stuck

CREATE OR REPLACE FUNCTION force_release_all_expired_locks(
    p_timeout_minutes INTEGER DEFAULT 5
)
RETURNS TABLE(
    released_count INTEGER,
    released_ids UUID[]
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_released_ids UUID[];
    v_count INTEGER;
BEGIN
    -- Force release ALL expired locks regardless of user
    WITH expired AS (
        UPDATE bookings 
        SET status = 'expired',
            locked_at = NULL
        WHERE status = 'locked' 
          AND locked_at < NOW() - (p_timeout_minutes || ' minutes')::INTERVAL
        RETURNING id
    )
    SELECT array_agg(id), COUNT(*)::INTEGER 
    INTO v_released_ids, v_count
    FROM expired;
    
    RETURN QUERY SELECT COALESCE(v_count, 0), COALESCE(v_released_ids, ARRAY[]::UUID[]);
END;
$$;

-- Allow both service_role AND authenticated users to call this (for emergency use)
GRANT EXECUTE ON FUNCTION force_release_all_expired_locks(INTEGER) TO authenticated;
GRANT EXECUTE ON FUNCTION force_release_all_expired_locks(INTEGER) TO service_role;

-- ============================================
-- 5. FIX STATUS CONSTRAINT AND CLEANUP
-- ============================================
-- First, ensure 'expired' is a valid status, then clean up stuck bookings

-- Drop the old constraint if it exists and recreate with 'expired'
DO $$
BEGIN
    -- Drop existing constraint if it exists
    IF EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'bookings_status_check'
    ) THEN
        ALTER TABLE bookings DROP CONSTRAINT bookings_status_check;
    END IF;
    
    -- Add constraint with 'expired' included
    ALTER TABLE bookings 
    ADD CONSTRAINT bookings_status_check 
    CHECK (status IN ('locked', 'confirmed', 'cancelled', 'expired'));
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;

-- Now run immediate cleanup to release all currently stuck locks
DO $$
DECLARE
    v_count INTEGER;
BEGIN
    -- Release all locks older than 10 minutes (likely stuck)
    UPDATE bookings 
    SET status = 'expired', locked_at = NULL
    WHERE status = 'locked' 
      AND locked_at < NOW() - INTERVAL '10 minutes';
    
    GET DIAGNOSTICS v_count = ROW_COUNT;
    RAISE NOTICE 'Released % stuck locks', v_count;
END $$;


-- ==========================================
-- Migration: 006_fix_seat_locking_race_condition.sql
-- ==========================================

-- ============================================
-- Quick My Ticket - Fix Seat Locking Race Condition
-- ============================================
-- This migration fixes two critical issues:
-- 1. Race condition where multiple users can lock the same seat simultaneously
-- 2. Expired locks (older than 5 minutes) still showing as "locked" in UI
--
-- Key changes:
-- - Uses FOR UPDATE NOWAIT instead of SKIP LOCKED (fails immediately if row is locked)
-- - Auto-expires stale locks within the lock_seat function
-- - Updates seat_availability view to filter expired locks

-- ============================================
-- 1. IMPROVED LOCK_SEAT FUNCTION
-- ============================================
-- Fixes:
-- - FOR UPDATE NOWAIT: Fails immediately if another transaction has the row
-- - Auto-expires locks older than 5 minutes before checking
-- - Handles lock_not_available exception gracefully

CREATE OR REPLACE FUNCTION lock_seat(
    p_show_id UUID, 
    p_seat_id UUID, 
    p_user_id UUID
)
RETURNS TABLE(
    booking_id UUID, 
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking_id UUID;
    v_existing RECORD;
    v_screen_id UUID;
    v_seat_exists BOOLEAN;
    v_reusable_booking UUID;
    v_lock_timeout_minutes INTEGER := 5;
BEGIN
    -- Validate that the show exists and get screen_id
    SELECT screen_id INTO v_screen_id 
    FROM shows 
    WHERE id = p_show_id;
    
    IF v_screen_id IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Show not found'::TEXT;
        RETURN;
    END IF;
    
    -- Validate that the seat exists and belongs to the show's screen
    SELECT EXISTS(
        SELECT 1 FROM seats 
        WHERE id = p_seat_id AND screen_id = v_screen_id
    ) INTO v_seat_exists;
    
    IF NOT v_seat_exists THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat not found for this show'::TEXT;
        RETURN;
    END IF;
    
    -- STEP 1: Auto-expire stale locks on this specific seat FIRST
    -- This ensures expired locks don't block new bookings
    UPDATE bookings 
    SET status = 'expired', locked_at = NULL
    WHERE show_id = p_show_id 
      AND seat_id = p_seat_id 
      AND status = 'locked'
      AND locked_at < NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL;
    
    -- STEP 2: Try to acquire a lock on existing active booking
    -- Use NOWAIT to fail immediately if another transaction has the row locked
    -- This prevents race conditions where two users try to lock simultaneously
    BEGIN
        SELECT * INTO v_existing
        FROM bookings 
        WHERE show_id = p_show_id 
          AND seat_id = p_seat_id 
          AND status IN ('locked', 'confirmed')
        FOR UPDATE NOWAIT;
    EXCEPTION
        WHEN lock_not_available THEN
            -- Another transaction is currently modifying this row
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is currently being processed by another user, please try again'::TEXT;
            RETURN;
    END;
    
    -- Check if seat is already taken
    IF FOUND THEN
        -- Check if it's the same user's existing lock
        IF v_existing.user_id = p_user_id AND v_existing.status = 'locked' THEN
            -- Refresh the lock timestamp
            UPDATE bookings 
            SET locked_at = NOW() 
            WHERE id = v_existing.id;
            
            RETURN QUERY SELECT v_existing.id, TRUE, 'Lock refreshed'::TEXT;
            RETURN;
        ELSE
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is already locked or booked'::TEXT;
            RETURN;
        END IF;
    END IF;
    
    -- STEP 3: Look for a reusable cancelled/expired booking for this seat
    SELECT id INTO v_reusable_booking
    FROM bookings
    WHERE show_id = p_show_id
      AND seat_id = p_seat_id
      AND status IN ('cancelled', 'expired')
    ORDER BY created_at DESC
    LIMIT 1
    FOR UPDATE;
    
    IF v_reusable_booking IS NOT NULL THEN
        -- Reuse existing booking record
        UPDATE bookings 
        SET status = 'locked',
            user_id = p_user_id,
            locked_at = NOW(),
            payment_id = NULL,
            confirmed_at = NULL
        WHERE id = v_reusable_booking
        RETURNING id INTO v_booking_id;
        
        RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
        RETURN;
    END IF;
    
    -- STEP 4: Insert new booking with lock
    INSERT INTO bookings (show_id, seat_id, user_id, status, locked_at)
    VALUES (p_show_id, p_seat_id, p_user_id, 'locked', NOW())
    RETURNING id INTO v_booking_id;
    
    RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
    
EXCEPTION
    WHEN unique_violation THEN
        -- Race condition: another transaction inserted first (caught by unique index)
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat was just locked by another user'::TEXT;
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, ('Error: ' || SQLERRM)::TEXT;
END;
$$;

-- ============================================
-- 2. UPDATED SEAT_AVAILABILITY VIEW
-- ============================================
-- Now filters out expired locks (older than 5 minutes)
-- Expired locks show as "available" instead of "locked"

CREATE OR REPLACE VIEW seat_availability AS
SELECT 
    s.id AS seat_id,
    s.screen_id,
    s.row,
    s.col,
    s.tier,
    s.price AS seat_price,
    sh.id AS show_id,
    sh.price AS show_price,
    COALESCE(s.price, sh.price, 0) AS effective_price,
    CASE 
        WHEN b.status = 'confirmed' THEN 'booked'
        WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 'locked'
        ELSE 'available'
    END AS availability_status,
    b.user_id AS locked_by,
    b.id AS booking_id,
    b.locked_at
FROM seats s
CROSS JOIN shows sh
LEFT JOIN LATERAL (
    SELECT * FROM bookings 
    WHERE seat_id = s.id 
      AND show_id = sh.id 
      AND (
          status = 'confirmed' 
          OR (status = 'locked' AND locked_at >= NOW() - INTERVAL '5 minutes')
      )
    ORDER BY 
        CASE WHEN status = 'confirmed' THEN 0 ELSE 1 END,
        locked_at DESC
    LIMIT 1
) b ON TRUE
WHERE s.screen_id = sh.screen_id;

-- Re-grant permissions on the view (required after CREATE OR REPLACE)
GRANT SELECT ON seat_availability TO authenticated;
GRANT SELECT ON seat_availability TO anon;

-- ============================================
-- 3. IMMEDIATE CLEANUP OF ALL EXPIRED LOCKS
-- ============================================
-- Release all currently expired locks to make those seats available immediately

DO $$
DECLARE
    v_count INTEGER;
BEGIN
    UPDATE bookings 
    SET status = 'expired', locked_at = NULL
    WHERE status = 'locked' 
      AND locked_at < NOW() - INTERVAL '5 minutes';
    
    GET DIAGNOSTICS v_count = ROW_COUNT;
    RAISE NOTICE 'Released % expired locks', v_count;
END $$;


-- ==========================================
-- Migration: 007_extend_lock_function.sql
-- ==========================================

-- ============================================
-- Quick My Ticket - Extend Lock Function
-- ============================================
-- This migration adds a function to extend seat locks
-- Used by the heartbeat/ping feature to keep locks alive
-- while the user is actively on the booking page.

-- ============================================
-- 1. EXTEND LOCKS FUNCTION
-- ============================================
-- Extends the lock duration for a user's active bookings
-- Only extends if the lock hasn't already expired

CREATE OR REPLACE FUNCTION extend_locks(
    p_booking_ids UUID[],
    p_user_id UUID
)
RETURNS TABLE(
    extended_count INTEGER,
    success BOOLEAN,
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_count INTEGER := 0;
    v_lock_timeout_minutes INTEGER := 5;
BEGIN
    -- Update locked_at timestamp for all valid bookings
    -- Only extend locks that:
    -- 1. Belong to the requesting user
    -- 2. Are still in 'locked' status
    -- 3. Haven't expired yet (locked_at within timeout period)
    UPDATE bookings
    SET locked_at = NOW()
    WHERE id = ANY(p_booking_ids)
      AND user_id = p_user_id
      AND status = 'locked'
      AND locked_at >= NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL;
    
    GET DIAGNOSTICS v_count = ROW_COUNT;
    
    IF v_count > 0 THEN
        RETURN QUERY SELECT v_count, TRUE, format('Extended %s lock(s)', v_count)::TEXT;
    ELSE
        RETURN QUERY SELECT 0, FALSE, 'No active locks to extend'::TEXT;
    END IF;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION extend_locks(UUID[], UUID) TO authenticated;

-- ============================================
-- 2. REFRESH SINGLE LOCK FUNCTION (for individual seat refresh)
-- ============================================
-- Refreshes a single booking's lock if it's still valid

CREATE OR REPLACE FUNCTION refresh_lock(
    p_booking_id UUID,
    p_user_id UUID
)
RETURNS TABLE(
    success BOOLEAN,
    new_locked_at TIMESTAMPTZ,
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_lock_timeout_minutes INTEGER := 5;
    v_new_time TIMESTAMPTZ;
BEGIN
    UPDATE bookings
    SET locked_at = NOW()
    WHERE id = p_booking_id
      AND user_id = p_user_id
      AND status = 'locked'
      AND locked_at >= NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL
    RETURNING locked_at INTO v_new_time;
    
    IF v_new_time IS NOT NULL THEN
        RETURN QUERY SELECT TRUE, v_new_time, 'Lock refreshed'::TEXT;
    ELSE
        RETURN QUERY SELECT FALSE, NULL::TIMESTAMPTZ, 'Lock expired or not found'::TEXT;
    END IF;
END;
$$;

-- Grant execute permission
GRANT EXECUTE ON FUNCTION refresh_lock(UUID, UUID) TO authenticated;


-- ==========================================
-- Migration: 008_add_theatre_for_owners.sql
-- ==========================================

-- ============================================
-- QuickIt - Add Theatre for Existing Owners
-- Migration 008
-- ============================================
-- Run this in Supabase SQL Editor to allow
-- existing theater owners to add more theatres

-- Allow existing theater owners to create new theatres
CREATE OR REPLACE FUNCTION add_theatre_for_owner(
    p_name TEXT,
    p_location TEXT,
    p_address TEXT DEFAULT NULL,
    p_phone TEXT DEFAULT NULL,
    p_email TEXT DEFAULT NULL
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_theatre_id UUID;
    v_is_owner BOOLEAN;
BEGIN
    -- Check if user is already a theater owner
    SELECT EXISTS(
        SELECT 1 FROM theater_owners WHERE user_id = v_user_id
    ) INTO v_is_owner;
    
    IF NOT v_is_owner THEN
        RETURN json_build_object('success', false, 'error', 'You must be an existing theater owner to add theatres');
    END IF;
    
    -- Create the theatre
    INSERT INTO theatres (name, location, address, phone, email)
    VALUES (p_name, p_location, p_address, p_phone, p_email)
    RETURNING id INTO v_theatre_id;
    
    -- Link owner to the new theatre
    INSERT INTO theater_owners (user_id, theatre_id, role)
    VALUES (v_user_id, v_theatre_id, 'owner');
    
    RETURN json_build_object(
        'success', true, 
        'message', 'Theatre added successfully',
        'theatre_id', v_theatre_id
    );
END;
$$;

GRANT EXECUTE ON FUNCTION add_theatre_for_owner(TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated;

-- Add missing columns to theatres if they don't exist
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'theatres' AND column_name = 'address') THEN
        ALTER TABLE theatres ADD COLUMN address TEXT;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'theatres' AND column_name = 'phone') THEN
        ALTER TABLE theatres ADD COLUMN phone TEXT;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'theatres' AND column_name = 'email') THEN
        ALTER TABLE theatres ADD COLUMN email TEXT;
    END IF;
END $$;


-- ==========================================
-- Migration: 009_events_system.sql
-- ==========================================

-- ============================================
-- Quick My Ticket Events System
-- ============================================
-- This migration adds:
-- 1. Events table for concerts, sports, comedy shows, etc.
-- 2. Event shows table linking events to venues
-- 3. Modified bookings support for events
-- 4. Event availability view
-- 5. RLS policies for events

-- ============================================
-- 1. EVENTS TABLE
-- ============================================

CREATE TABLE IF NOT EXISTS events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    description TEXT,
    category TEXT NOT NULL DEFAULT 'concert',
    poster_url TEXT,
    banner_url TEXT,
    organizer TEXT,
    venue_name TEXT,
    city TEXT,
    tags TEXT[] DEFAULT '{}',
    is_featured BOOLEAN DEFAULT FALSE,
    status TEXT DEFAULT 'upcoming' CHECK (status IN ('upcoming', 'ongoing', 'completed', 'cancelled')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Add indexes
CREATE INDEX IF NOT EXISTS idx_events_category ON events(category);
CREATE INDEX IF NOT EXISTS idx_events_status ON events(status);
CREATE INDEX IF NOT EXISTS idx_events_featured ON events(is_featured) WHERE is_featured = TRUE;
CREATE INDEX IF NOT EXISTS idx_events_city ON events(city);

-- ============================================
-- 2. EVENT SHOWS TABLE
-- ============================================
-- Links events to venues/screens for seat booking

CREATE TABLE IF NOT EXISTS event_shows (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    event_id UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    screen_id UUID REFERENCES screens(id) ON DELETE SET NULL,
    start_time TIMESTAMPTZ NOT NULL,
    end_time TIMESTAMPTZ,
    price DECIMAL(10,2) DEFAULT 0,
    status TEXT DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'ongoing', 'completed', 'cancelled')),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Add indexes
CREATE INDEX IF NOT EXISTS idx_event_shows_event ON event_shows(event_id);
CREATE INDEX IF NOT EXISTS idx_event_shows_screen ON event_shows(screen_id);
CREATE INDEX IF NOT EXISTS idx_event_shows_start ON event_shows(start_time);

-- ============================================
-- 3. MODIFY BOOKINGS TABLE
-- ============================================
-- Add event_show_id column for event bookings

ALTER TABLE bookings 
ADD COLUMN IF NOT EXISTS event_show_id UUID REFERENCES event_shows(id) ON DELETE CASCADE;

-- Update constraint: either show_id OR event_show_id must be set
-- Note: We allow both to be NULL temporarily during migration
CREATE INDEX IF NOT EXISTS idx_bookings_event_show ON bookings(event_show_id) 
WHERE event_show_id IS NOT NULL;

-- ============================================
-- 4. EVENT SEAT LOCKING FUNCTION
-- ============================================

CREATE OR REPLACE FUNCTION lock_event_seat(
    p_event_show_id UUID, 
    p_seat_id UUID, 
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    booking_id UUID, 
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking_id UUID;
    v_existing RECORD;
    v_screen_id UUID;
    v_seat_exists BOOLEAN;
BEGIN
    -- Validate that the event show exists and get screen_id
    SELECT screen_id INTO v_screen_id 
    FROM event_shows 
    WHERE id = p_event_show_id;
    
    IF v_screen_id IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Event show not found'::TEXT;
        RETURN;
    END IF;
    
    -- Validate that the seat exists and belongs to the event's screen
    SELECT EXISTS(
        SELECT 1 FROM seats 
        WHERE id = p_seat_id AND screen_id = v_screen_id
    ) INTO v_seat_exists;
    
    IF NOT v_seat_exists THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat not found for this event'::TEXT;
        RETURN;
    END IF;
    
    -- Try to acquire a lock on existing booking (if any)
    SELECT * INTO v_existing
    FROM bookings 
    WHERE event_show_id = p_event_show_id 
      AND seat_id = p_seat_id 
      AND status IN ('locked', 'confirmed')
    FOR UPDATE NOWAIT;
    
    -- Check if seat is already taken
    IF FOUND THEN
        IF ((v_existing.user_id IS NOT NULL AND v_existing.user_id = p_user_id) OR
            (v_existing.user_id IS NULL AND v_existing.session_id = p_session_id)) AND v_existing.status = 'locked' THEN
            UPDATE bookings 
            SET locked_at = NOW() 
            WHERE id = v_existing.id;
            
            RETURN QUERY SELECT v_existing.id, TRUE, 'Lock refreshed'::TEXT;
            RETURN;
        ELSIF v_existing.status = 'locked' AND v_existing.locked_at < NOW() - INTERVAL '5 minutes' THEN
            -- Steal the lock! Expire the old one.
            UPDATE bookings SET status = 'expired' WHERE id = v_existing.id;
        ELSE
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is already locked or booked'::TEXT;
            RETURN;
        END IF;
    END IF;
    
    -- Insert new booking with lock
    INSERT INTO bookings (event_show_id, seat_id, user_id, session_id, status, locked_at)
    VALUES (p_event_show_id, p_seat_id, p_user_id, p_session_id, 'locked', NOW())
    RETURNING id INTO v_booking_id;
    
    RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
    
EXCEPTION
    WHEN lock_not_available THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is being processed by another user'::TEXT;
    WHEN unique_violation THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat was just locked by another user'::TEXT;
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, ('Error: ' || SQLERRM)::TEXT;
END;
$$;

GRANT EXECUTE ON FUNCTION lock_event_seat(UUID, UUID, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION lock_event_seat(UUID, UUID, UUID, TEXT) TO anon;

-- ============================================
-- 5. EVENT SEAT AVAILABILITY VIEW
-- ============================================

CREATE OR REPLACE VIEW event_seat_availability AS
SELECT 
    es.id AS event_show_id,
    es.event_id,
    e.title AS event_title,
    s.id AS seat_id,
    s.screen_id,
    s.row,
    s.col,
    s.tier,
    COALESCE(s.price, es.price) AS effective_price,
    b.id AS booking_id,
    b.user_id AS locked_by,
    b.locked_at,
    CASE 
        WHEN b.status = 'confirmed' THEN 'booked'
        WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 'locked'
        ELSE 'available'
    END AS availability_status
FROM event_shows es
JOIN events e ON e.id = es.event_id
JOIN seats s ON s.screen_id = es.screen_id
LEFT JOIN bookings b ON b.seat_id = s.id 
    AND b.event_show_id = es.id 
    AND b.status IN ('locked', 'confirmed');

-- ============================================
-- 6. RLS POLICIES FOR EVENTS
-- ============================================

ALTER TABLE events ENABLE ROW LEVEL SECURITY;
ALTER TABLE event_shows ENABLE ROW LEVEL SECURITY;

-- Events: everyone can read
CREATE POLICY "Events are viewable by everyone"
ON events FOR SELECT
TO anon, authenticated
USING (true);

-- Events: only authenticated users can insert (for now)
CREATE POLICY "Authenticated users can create events"
ON events FOR INSERT
TO authenticated
WITH CHECK (true);

-- Event shows: everyone can read
CREATE POLICY "Event shows are viewable by everyone"
ON event_shows FOR SELECT
TO anon, authenticated
USING (true);

-- Event shows: authenticated users can create
CREATE POLICY "Authenticated users can create event shows"
ON event_shows FOR INSERT
TO authenticated
WITH CHECK (true);

-- ============================================
-- 7. SAMPLE DATA FOR TESTING
-- ============================================

INSERT INTO events (id, title, description, category, poster_url, organizer, venue_name, city, tags, is_featured, status)
VALUES 
    ('e0000001-0001-0001-0001-000000000001', 'Arijit Singh Live', 'Experience the magic of Arijit Singh live in concert. An evening of soulful melodies and unforgettable music.', 'concert', 'https://image.tmdb.org/t/p/w500/aymjrprSz3kNjMHzDNlBp9kSVIw.jpg', 'BookMyShow Live', 'Jawaharlal Nehru Stadium', 'Mumbai', ARRAY['music', 'bollywood', 'live'], TRUE, 'upcoming'),
    ('e0000002-0002-0002-0002-000000000002', 'IPL 2026: MI vs CSK', 'The biggest rivalry in cricket! Watch Mumbai Indians take on Chennai Super Kings.', 'sports', 'https://image.tmdb.org/t/p/w500/dMPxdcMhs0VZlbgjNmKvAdzfyWe.jpg', 'BCCI', 'Wankhede Stadium', 'Mumbai', ARRAY['cricket', 'ipl', 'sports'], TRUE, 'upcoming'),
    ('e0000003-0003-0003-0003-000000000003', 'Zakir Khan Stand-Up Comedy', 'Join Zakir Khan for a night of laughter and relatable comedy about life, love, and everything in between.', 'comedy', 'https://image.tmdb.org/t/p/w500/9gk7adHYeDvHkCSEqAvQNLV5Ber.jpg', 'ZK Entertainment', 'NCPA', 'Mumbai', ARRAY['comedy', 'standup', 'hindi'], FALSE, 'upcoming'),
    ('e0000004-0004-0004-0004-000000000004', 'Sunburn Music Festival', 'Indias biggest electronic dance music festival featuring world-renowned DJs.', 'festival', 'https://image.tmdb.org/t/p/w500/5P1i4ydN5XWk8h3WnBB9JjMzMJA.jpg', 'Sunburn', 'Vagator Beach', 'Goa', ARRAY['edm', 'festival', 'music', 'party'], TRUE, 'upcoming'),
    ('e0000005-0005-0005-0005-000000000005', 'India vs Australia Test', 'Day 1 of the historic India vs Australia test match at the iconic Eden Gardens.', 'sports', 'https://image.tmdb.org/t/p/w500/udDclJoHjfjb8Ekgsd4FDteOkCU.jpg', 'BCCI', 'Eden Gardens', 'Kolkata', ARRAY['cricket', 'test', 'india'], FALSE, 'upcoming')
ON CONFLICT (id) DO NOTHING;

-- ============================================
-- 8. GRANT PERMISSIONS
-- ============================================

GRANT SELECT ON events TO anon, authenticated;
GRANT SELECT ON event_shows TO anon, authenticated;
GRANT SELECT ON event_seat_availability TO anon, authenticated;
GRANT INSERT, UPDATE ON events TO authenticated;
GRANT INSERT, UPDATE ON event_shows TO authenticated;


-- ==========================================
-- Migration: 010_guest_booking_system.sql
-- ==========================================

-- ============================================
-- Quick My Ticket - Guest Booking System
-- ============================================
-- This migration adds:
-- 1. Support for guest bookings in the bookings table
-- 2. Modified seat locking RPCs to support session IDs
-- 3. Modified confirm bookings RPC to handle guest details

-- 1. Update table schema
ALTER TABLE public.bookings ALTER COLUMN user_id DROP NOT NULL;
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS session_id TEXT;
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS guest_name TEXT;
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS guest_email TEXT;
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS guest_phone TEXT;

-- 2. Update lock_seat function to support session_id
CREATE OR REPLACE FUNCTION lock_seat(
    p_show_id UUID, 
    p_seat_id UUID, 
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    booking_id UUID, 
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking_id UUID;
    v_existing RECORD;
    v_screen_id UUID;
    v_seat_exists BOOLEAN;
    v_reusable_booking UUID;
    v_lock_timeout_minutes INTEGER := 5;
BEGIN
    SELECT screen_id INTO v_screen_id 
    FROM shows 
    WHERE id = p_show_id;
    
    IF v_screen_id IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Show not found'::TEXT;
        RETURN;
    END IF;
    
    SELECT EXISTS(
        SELECT 1 FROM seats 
        WHERE id = p_seat_id AND screen_id = v_screen_id
    ) INTO v_seat_exists;
    
    IF NOT v_seat_exists THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat not found for this show'::TEXT;
        RETURN;
    END IF;
    
    UPDATE bookings 
    SET status = 'expired', locked_at = NULL
    WHERE show_id = p_show_id 
      AND seat_id = p_seat_id 
      AND status = 'locked'
      AND locked_at < NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL;
    
    BEGIN
        SELECT * INTO v_existing
        FROM bookings 
        WHERE show_id = p_show_id 
          AND seat_id = p_seat_id 
          AND status IN ('locked', 'confirmed')
        FOR UPDATE NOWAIT;
    EXCEPTION
        WHEN lock_not_available THEN
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is currently being processed by another user, please try again'::TEXT;
            RETURN;
    END;
    
    IF FOUND THEN
        IF (v_existing.user_id IS NOT NULL AND v_existing.user_id = p_user_id AND v_existing.status = 'locked') OR 
           (v_existing.session_id IS NOT NULL AND v_existing.session_id = p_session_id AND v_existing.status = 'locked') THEN
            UPDATE bookings 
            SET locked_at = NOW() 
            WHERE id = v_existing.id;
            
            RETURN QUERY SELECT v_existing.id, TRUE, 'Lock refreshed'::TEXT;
            RETURN;
        ELSE
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is already locked or booked'::TEXT;
            RETURN;
        END IF;
    END IF;
    
    SELECT id INTO v_reusable_booking
    FROM bookings
    WHERE show_id = p_show_id
      AND seat_id = p_seat_id
      AND status IN ('cancelled', 'expired')
    ORDER BY created_at DESC
    LIMIT 1
    FOR UPDATE;
    
    IF v_reusable_booking IS NOT NULL THEN
        UPDATE bookings 
        SET status = 'locked',
            user_id = p_user_id,
            session_id = p_session_id,
            locked_at = NOW(),
            payment_id = NULL,
            confirmed_at = NULL
        WHERE id = v_reusable_booking
        RETURNING id INTO v_booking_id;
        
        RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
        RETURN;
    END IF;
    
    INSERT INTO bookings (show_id, seat_id, user_id, session_id, status, locked_at)
    VALUES (p_show_id, p_seat_id, p_user_id, p_session_id, 'locked', NOW())
    RETURNING id INTO v_booking_id;
    
    RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
    
EXCEPTION
    WHEN unique_violation THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat was just locked by another user'::TEXT;
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, ('Error: ' || SQLERRM)::TEXT;
END;
$$;

GRANT EXECUTE ON FUNCTION lock_seat(UUID, UUID, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION lock_seat(UUID, UUID, UUID, TEXT) TO anon;

-- 3. Update lock_event_seat function
CREATE OR REPLACE FUNCTION lock_event_seat(
    p_event_show_id UUID, 
    p_seat_id UUID, 
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    booking_id UUID, 
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking_id UUID;
    v_existing RECORD;
    v_screen_id UUID;
    v_seat_exists BOOLEAN;
    v_reusable_booking UUID;
    v_lock_timeout_minutes INTEGER := 5;
BEGIN
    SELECT screen_id INTO v_screen_id 
    FROM event_shows 
    WHERE id = p_event_show_id;
    
    IF v_screen_id IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Event show not found'::TEXT;
        RETURN;
    END IF;
    
    SELECT EXISTS(
        SELECT 1 FROM seats 
        WHERE id = p_seat_id AND screen_id = v_screen_id
    ) INTO v_seat_exists;
    
    IF NOT v_seat_exists THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat not found for this event'::TEXT;
        RETURN;
    END IF;

    UPDATE bookings 
    SET status = 'expired', locked_at = NULL
    WHERE event_show_id = p_event_show_id 
      AND seat_id = p_seat_id 
      AND status = 'locked'
      AND locked_at < NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL;
    
    BEGIN
        SELECT * INTO v_existing
        FROM bookings 
        WHERE event_show_id = p_event_show_id 
          AND seat_id = p_seat_id 
          AND status IN ('locked', 'confirmed')
        FOR UPDATE NOWAIT;
    EXCEPTION
        WHEN lock_not_available THEN
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is being processed by another user'::TEXT;
            RETURN;
    END;
    
    IF FOUND THEN
        IF (v_existing.user_id IS NOT NULL AND v_existing.user_id = p_user_id AND v_existing.status = 'locked') OR 
           (v_existing.session_id IS NOT NULL AND v_existing.session_id = p_session_id AND v_existing.status = 'locked') THEN
            UPDATE bookings 
            SET locked_at = NOW() 
            WHERE id = v_existing.id;
            
            RETURN QUERY SELECT v_existing.id, TRUE, 'Lock refreshed'::TEXT;
            RETURN;
        ELSE
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is already locked or booked'::TEXT;
            RETURN;
        END IF;
    END IF;

    SELECT id INTO v_reusable_booking
    FROM bookings
    WHERE event_show_id = p_event_show_id
      AND seat_id = p_seat_id
      AND status IN ('cancelled', 'expired')
    ORDER BY created_at DESC
    LIMIT 1
    FOR UPDATE;
    
    IF v_reusable_booking IS NOT NULL THEN
        UPDATE bookings 
        SET status = 'locked',
            user_id = p_user_id,
            session_id = p_session_id,
            locked_at = NOW(),
            payment_id = NULL,
            confirmed_at = NULL
        WHERE id = v_reusable_booking
        RETURNING id INTO v_booking_id;
        
        RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
        RETURN;
    END IF;
    
    INSERT INTO bookings (event_show_id, seat_id, user_id, session_id, status, locked_at)
    VALUES (p_event_show_id, p_seat_id, p_user_id, p_session_id, 'locked', NOW())
    RETURNING id INTO v_booking_id;
    
    RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
    
EXCEPTION
    WHEN unique_violation THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat was just locked by another user'::TEXT;
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, ('Error: ' || SQLERRM)::TEXT;
END;
$$;

GRANT EXECUTE ON FUNCTION lock_event_seat(UUID, UUID, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION lock_event_seat(UUID, UUID, UUID, TEXT) TO anon;

-- 4. Update unlock_seat function
CREATE OR REPLACE FUNCTION unlock_seat(
    p_booking_id UUID,
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking RECORD;
BEGIN
    SELECT * INTO v_booking
    FROM bookings
    WHERE id = p_booking_id
    FOR UPDATE;
    
    IF NOT FOUND THEN
        RETURN QUERY SELECT FALSE, 'Booking not found'::TEXT;
        RETURN;
    END IF;
    
    IF (v_booking.user_id IS NOT NULL AND v_booking.user_id = p_user_id) OR
       (v_booking.session_id IS NOT NULL AND v_booking.session_id = p_session_id) THEN
        -- Ownership verified
    ELSE
        RETURN QUERY SELECT FALSE, 'Not authorized to unlock this booking'::TEXT;
        RETURN;
    END IF;
    
    IF v_booking.status != 'locked' THEN
        RETURN QUERY SELECT FALSE, ('Cannot unlock booking with status: ' || v_booking.status)::TEXT;
        RETURN;
    END IF;
    
    UPDATE bookings 
    SET status = 'cancelled', locked_at = NULL
    WHERE id = p_booking_id;
    
    RETURN QUERY SELECT TRUE, 'Seat unlocked successfully'::TEXT;
END;
$$;

GRANT EXECUTE ON FUNCTION unlock_seat(UUID, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION unlock_seat(UUID, UUID, TEXT) TO anon;

-- 5. Update confirm_bookings to accept guest details
CREATE OR REPLACE FUNCTION confirm_bookings(
    p_booking_ids UUID[],
    p_payment_id TEXT,
    p_guest_name TEXT DEFAULT NULL,
    p_guest_email TEXT DEFAULT NULL,
    p_guest_phone TEXT DEFAULT NULL
)
RETURNS TABLE(
    confirmed_count INTEGER,
    total_amount DECIMAL
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_count INTEGER;
    v_total DECIMAL;
BEGIN
    SELECT total INTO v_total
    FROM calculate_booking_total(p_booking_ids);
    
    WITH confirmed AS (
        UPDATE bookings 
        SET status = 'confirmed',
            payment_id = p_payment_id,
            confirmed_at = NOW(),
            guest_name = COALESCE(bookings.guest_name, p_guest_name),
            guest_email = COALESCE(bookings.guest_email, p_guest_email),
            guest_phone = COALESCE(bookings.guest_phone, p_guest_phone)
        WHERE id = ANY(p_booking_ids)
          AND status = 'locked'
        RETURNING id
    )
    SELECT COUNT(*)::INTEGER INTO v_count FROM confirmed;
    
    RETURN QUERY SELECT v_count, COALESCE(v_total, 0);
END;
$$;

REVOKE ALL ON FUNCTION confirm_bookings(UUID[], TEXT, TEXT, TEXT, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION confirm_bookings(UUID[], TEXT, TEXT, TEXT, TEXT) TO service_role;


-- ==========================================
-- Migration: 011_fix_guest_lock_release.sql
-- ==========================================

-- ============================================
-- Quick My Ticket - Fix Guest Lock Release
-- ============================================
-- This migration:
-- 1. Updates extend_locks to support guest sessions
-- 2. Adds a pg_cron job to auto-release expired locks every minute
-- 3. Adds a direct SQL function for force-releasing all expired locks

-- 1. Update extend_locks to support session_id (guest heartbeat)
CREATE OR REPLACE FUNCTION extend_locks(
    p_booking_ids UUID[],
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    extended_count INTEGER,
    success BOOLEAN,
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_count INTEGER := 0;
    v_lock_timeout_minutes INTEGER := 5;
BEGIN
    -- Extend locks matching either user_id or session_id
    UPDATE bookings
    SET locked_at = NOW()
    WHERE id = ANY(p_booking_ids)
      AND status = 'locked'
      AND locked_at >= NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL
      AND (
          (p_user_id IS NOT NULL AND user_id = p_user_id) OR
          (p_session_id IS NOT NULL AND session_id = p_session_id)
      );
    
    GET DIAGNOSTICS v_count = ROW_COUNT;
    
    IF v_count > 0 THEN
        RETURN QUERY SELECT v_count, TRUE, format('Extended %s lock(s)', v_count)::TEXT;
    ELSE
        RETURN QUERY SELECT 0, FALSE, 'No active locks to extend'::TEXT;
    END IF;
END;
$$;

-- Grant to both authenticated and anon (guests)
GRANT EXECUTE ON FUNCTION extend_locks(UUID[], UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION extend_locks(UUID[], UUID, TEXT) TO anon;

-- 2. Auto-release expired locks directly in SQL (no Edge Function needed)
-- This runs as a simple function that pg_cron can call directly
CREATE OR REPLACE FUNCTION auto_release_expired_locks()
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_count INTEGER;
BEGIN
    UPDATE bookings
    SET status = 'expired', locked_at = NULL
    WHERE status = 'locked'
      AND locked_at < NOW() - INTERVAL '5 minutes';
    
    GET DIAGNOSTICS v_count = ROW_COUNT;
    
    IF v_count > 0 THEN
        RAISE LOG 'JayShow: Auto-released % expired seat locks', v_count;
    END IF;
    
    RETURN v_count;
END;
$$;

-- 3. Schedule the auto-release job via pg_cron (optional)
-- NOTE: pg_cron must be enabled in Supabase Dashboard -> Database -> Extensions
-- If pg_cron is not enabled, this block is skipped gracefully.
DO $$
BEGIN
    PERFORM cron.schedule(
        'release-expired-locks',
        '* * * * *',
        'SELECT auto_release_expired_locks()'
    );
    RAISE LOG '[QMT] pg_cron job "release-expired-locks" scheduled (every minute)';
EXCEPTION WHEN OTHERS THEN
    RAISE LOG '[QMT] pg_cron not available — skipping cron job setup. Enable pg_cron in Supabase Dashboard -> Database -> Extensions and re-run this block manually.';
END;
$$;


-- ==========================================
-- Migration: 012_fix_events_rls.sql
-- ==========================================

-- ============================================
-- Fix: Events RLS Policies
-- ============================================
-- Adds missing UPDATE and DELETE policies for administrators on events and event_shows.

-- 1. Events Update/Delete for Admins
CREATE POLICY "Admins can update events" 
ON events FOR UPDATE 
TO authenticated
USING ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true)
WITH CHECK ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true);

CREATE POLICY "Admins can delete events" 
ON events FOR DELETE 
TO authenticated
USING ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true);

-- 2. Event Shows Update/Delete for Admins
CREATE POLICY "Admins can update event shows" 
ON event_shows FOR UPDATE 
TO authenticated
USING ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true)
WITH CHECK ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true);

CREATE POLICY "Admins can delete event shows" 
ON event_shows FOR DELETE 
TO authenticated
USING ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true);

-- 3. Ensure theater owners can also manage event shows if they own the theatre
-- Only if the event show is at their screen
CREATE POLICY "Owners can update event shows" 
ON event_shows FOR UPDATE 
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM theater_owners to_owner
        JOIN screens s ON s.theatre_id = to_owner.theatre_id
        WHERE s.id = event_shows.screen_id
        AND to_owner.user_id = auth.uid()
        AND to_owner.role IN ('owner', 'manager')
    )
);

CREATE POLICY "Owners can delete event shows" 
ON event_shows FOR DELETE 
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM theater_owners to_owner
        JOIN screens s ON s.theatre_id = to_owner.theatre_id
        WHERE s.id = event_shows.screen_id
        AND to_owner.user_id = auth.uid()
        AND to_owner.role IN ('owner', 'manager')
    )
);


-- ==========================================
-- Migration: 013_booking_system_hardening.sql
-- ==========================================

-- ============================================
-- Quick My Ticket - Final Booking System Hardening
-- ============================================
-- This migration:
-- 1. Adds partial unique indexes to prevent double bookings
-- 2. Updates confirm_bookings to support user identification
-- 3. Optimizes booking queries

-- 1. ADD PARTIAL UNIQUE INDEXES (Critical for Concurrency)
-- These ensure that for any given show/seat, there can be AT MOST ONE active booking
-- (either 'locked' or 'confirmed'). Expired/Cancelled bookings are ignored.

-- For Movie Shows
CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_active_movie_booking 
ON public.bookings (show_id, seat_id) 
WHERE status IN ('locked', 'confirmed') AND show_id IS NOT NULL;

-- For Event Shows
CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_active_event_booking 
ON public.bookings (event_show_id, seat_id) 
WHERE status IN ('locked', 'confirmed') AND event_show_id IS NOT NULL;


-- 2. UPDATE confirm_bookings 
-- Adds support for updating the user_id if a guest logs in during the flow
CREATE OR REPLACE FUNCTION confirm_bookings(
    p_booking_ids UUID[],
    p_payment_id TEXT,
    p_guest_name TEXT DEFAULT NULL,
    p_guest_email TEXT DEFAULT NULL,
    p_guest_phone TEXT DEFAULT NULL,
    p_user_id UUID DEFAULT NULL
)
RETURNS TABLE(
    confirmed_count INTEGER,
    total_amount DECIMAL
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_count INTEGER;
    v_total DECIMAL;
BEGIN
    -- Calculate total for the specific requested IDs
    SELECT total INTO v_total
    FROM calculate_booking_total(p_booking_ids);
    
    WITH confirmed AS (
        UPDATE bookings 
        SET status = 'confirmed',
            payment_id = p_payment_id,
            confirmed_at = NOW(),
            -- Only update guest details if not already present
            guest_name = COALESCE(bookings.guest_name, p_guest_name),
            guest_email = COALESCE(bookings.guest_email, p_guest_email),
            guest_phone = COALESCE(bookings.guest_phone, p_guest_phone),
            -- Link to user if provided (e.g., guest logged in before checkout)
            user_id = COALESCE(bookings.user_id, p_user_id)
        WHERE id = ANY(p_booking_ids)
          AND status = 'locked'
        RETURNING id
    )
    SELECT COUNT(*)::INTEGER INTO v_count FROM confirmed;
    
    RETURN QUERY SELECT v_count, COALESCE(v_total, 0);
END;
$$;


-- 3. PERMISSION RE-GRANT
REVOKE ALL ON FUNCTION confirm_bookings(UUID[], TEXT, TEXT, TEXT, TEXT, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION confirm_bookings(UUID[], TEXT, TEXT, TEXT, TEXT, UUID) TO service_role;


-- 4. HOUSEKEEPING: REFRESH VIEWS
-- Ensure the seat_availability view is fully optimized with the new indexes
ANALYZE bookings;


-- ==========================================
-- Migration: 014_fix_event_booking_calculation.sql
-- ==========================================

-- ============================================
-- Quick My Ticket - Fix Event Booking Price Calculation
-- Migration 014
-- ============================================

-- Safely replace calculate_booking_total to support both movie shows and event shows
-- Previously, it used an INNER JOIN on shows, which filtered out event_shows
-- and caused the 'create-order' edge function to fail during payment.

CREATE OR REPLACE FUNCTION calculate_booking_total(
    p_booking_ids UUID[],
    p_tax_rate DECIMAL DEFAULT 0.18
)
RETURNS TABLE(
    subtotal DECIMAL,
    tax DECIMAL,
    total DECIMAL,
    seat_count INTEGER
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_subtotal DECIMAL;
    v_seat_count INTEGER;
BEGIN
    -- Calculate subtotal from seats, movie shows, or event shows
    SELECT 
        COALESCE(SUM(COALESCE(s.price, sh.price, es.price, 0)), 0),
        COUNT(*)::INTEGER
    INTO v_subtotal, v_seat_count
    FROM bookings b
    JOIN seats s ON s.id = b.seat_id
    LEFT JOIN shows sh ON sh.id = b.show_id
    LEFT JOIN event_shows es ON es.id = b.event_show_id
    WHERE b.id = ANY(p_booking_ids)
      AND b.status = 'locked';  -- Only count locked bookings
    
    RETURN QUERY SELECT 
        v_subtotal,
        ROUND(v_subtotal * p_tax_rate, 2),
        v_subtotal + ROUND(v_subtotal * p_tax_rate, 2),
        v_seat_count;
END;
$$;

GRANT EXECUTE ON FUNCTION calculate_booking_total(UUID[], DECIMAL) TO authenticated;
GRANT EXECUTE ON FUNCTION calculate_booking_total(UUID[], DECIMAL) TO anon;
GRANT EXECUTE ON FUNCTION calculate_booking_total(UUID[], DECIMAL) TO service_role;


-- ==========================================
-- Migration: 015_add_guest_session_to_views.sql
-- ==========================================

-- Migration: Update views to expose guest session IDs
-- Allows frontend to recover guest locks upon page reload and prevents "phantom locked" seats

-- Drop the views first to avoid Postgres column matching rule conflicts (ERROR: 42P16)
DROP VIEW IF EXISTS seat_availability CASCADE;
DROP VIEW IF EXISTS event_seat_availability CASCADE;

-- Recreate seat_availability view to include session_id
CREATE OR REPLACE VIEW seat_availability AS
SELECT 
    s.id AS seat_id,
    s.screen_id,
    s.row,
    s.col,
    s.tier,
    s.price AS seat_price,
    sh.id AS show_id,
    sh.price AS show_price,
    COALESCE(s.price, sh.price, 0) AS effective_price,
    CASE 
        WHEN b.status = 'confirmed' THEN 'booked'
        WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 'locked'
        ELSE 'available'
    END AS availability_status,
    b.user_id AS locked_by,
    b.id AS booking_id,
    b.locked_at,
    b.session_id AS locked_by_session -- newly added column safely at the end
FROM seats s
CROSS JOIN shows sh
LEFT JOIN LATERAL (
    SELECT * FROM bookings 
    WHERE seat_id = s.id 
      AND show_id = sh.id 
      AND (
          status = 'confirmed' 
          OR (status = 'locked' AND locked_at >= NOW() - INTERVAL '5 minutes')
      )
    ORDER BY locked_at DESC
    LIMIT 1
) b ON true
WHERE s.screen_id = sh.screen_id;

-- Recreate event_seat_availability view to include session_id
CREATE OR REPLACE VIEW event_seat_availability AS
SELECT 
    es.id AS event_show_id,
    es.event_id,
    e.title AS event_title,
    s.id AS seat_id,
    s.screen_id,
    s.row,
    s.col,
    s.tier,
    COALESCE(s.price, es.price) AS effective_price,
    b.id AS booking_id,
    b.user_id AS locked_by,
    b.locked_at,
    CASE 
        WHEN b.status = 'confirmed' THEN 'booked'
        WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 'locked'
        ELSE 'available'
    END AS availability_status,
    b.session_id AS locked_by_session -- newly added column safely at the end
FROM event_shows es
JOIN events e ON e.id = es.event_id
JOIN seats s ON s.screen_id = es.screen_id
LEFT JOIN LATERAL (
    SELECT * FROM bookings
    WHERE seat_id = s.id
      AND event_show_id = es.id
      AND (
          status = 'confirmed'
          OR (status = 'locked' AND locked_at >= NOW() - INTERVAL '5 minutes')
      )
    ORDER BY
        CASE WHEN status = 'confirmed' THEN 0 ELSE 1 END,
        locked_at DESC
    LIMIT 1
) b ON true;


-- ==========================================
-- Migration: 016_owner_dashboard_events.sql
-- ==========================================

-- Migration: Upgrade Owner Dashboard to support events
-- Replaces old RPC functions to unify shows and event_shows datasets

DROP FUNCTION IF EXISTS get_owner_shows(UUID, UUID, DATE);
DROP FUNCTION IF EXISTS get_owner_dashboard_stats(UUID);

CREATE OR REPLACE FUNCTION get_owner_dashboard_stats(p_user_id UUID)
RETURNS TABLE(
    total_theatres BIGINT,
    total_screens BIGINT,
    total_seats BIGINT,
    today_bookings BIGINT,
    today_revenue DECIMAL,
    currently_locked BIGINT,
    today_confirmed BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_theatre_ids UUID[];
    v_today DATE := CURRENT_DATE;
BEGIN
    SELECT ARRAY_AGG(theatre_id) INTO v_theatre_ids
    FROM theater_owners
    WHERE user_id = p_user_id;
    
    IF v_theatre_ids IS NULL THEN
        RETURN QUERY SELECT 0::BIGINT, 0::BIGINT, 0::BIGINT, 0::BIGINT, 0::DECIMAL, 0::BIGINT, 0::BIGINT;
        RETURN;
    END IF;
    
    RETURN QUERY
    WITH owned_screens AS (
        SELECT s.id AS screen_id
        FROM screens s
        WHERE s.theatre_id = ANY(v_theatre_ids)
    ),
    owned_shows AS (
        SELECT sh.id AS show_id, sh.price
        FROM shows sh
        JOIN owned_screens os ON os.screen_id = sh.screen_id
    ),
    owned_event_shows AS (
        SELECT es.id AS event_show_id, es.price
        FROM event_shows es
        JOIN owned_screens os ON os.screen_id = es.screen_id
    ),
    owned_bookings AS (
        SELECT b.*
        FROM bookings b
        WHERE (b.show_id IN (SELECT show_id FROM owned_shows)) OR (b.event_show_id IN (SELECT event_show_id FROM owned_event_shows))
    )
    SELECT
        (SELECT COUNT(*) FROM unnest(v_theatre_ids))::BIGINT AS total_theatres,
        (SELECT COUNT(*) FROM owned_screens)::BIGINT AS total_screens,
        (SELECT COUNT(*) FROM seats WHERE screen_id IN (SELECT screen_id FROM owned_screens))::BIGINT AS total_seats,
        (SELECT COUNT(*) FROM owned_bookings WHERE DATE(created_at) = v_today)::BIGINT AS today_bookings,
        COALESCE((
            SELECT SUM(
                COALESCE(
                    seats.price, 
                    (SELECT price FROM shows WHERE id = b.show_id), 
                    (SELECT price FROM event_shows WHERE id = b.event_show_id), 
                    0
                )
            )
            FROM owned_bookings b
            LEFT JOIN seats ON seats.id = b.seat_id
            WHERE DATE(b.created_at) = v_today AND b.status = 'confirmed'
        ), 0)::DECIMAL AS today_revenue,
        (SELECT COUNT(*) FROM owned_bookings WHERE status = 'locked' AND locked_at >= NOW() - INTERVAL '5 minutes')::BIGINT AS currently_locked,
        (SELECT COUNT(*) FROM owned_bookings WHERE DATE(created_at) = v_today AND status = 'confirmed')::BIGINT AS today_confirmed;
END;
$$;


CREATE OR REPLACE FUNCTION get_owner_shows(
    p_user_id UUID,
    p_theatre_id UUID DEFAULT NULL,
    p_date DATE DEFAULT CURRENT_DATE
)
RETURNS TABLE(
    id UUID,             
    type TEXT,
    title TEXT,          
    screen_name TEXT,
    theatre_name TEXT,
    start_time TIMESTAMPTZ,
    end_time TIMESTAMPTZ,
    base_price DECIMAL,
    total_seats BIGINT,
    booked_seats BIGINT,
    locked_seats BIGINT,
    available_seats BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    WITH all_unified_shows AS (
        SELECT 
            sh.id,
            'movie' AS type,
            m.title,
            sc.name AS screen_name,
            t.name AS theatre_name,
            sh.start_time,
            sh.end_time,
            sh.price AS base_price,
            sc.id AS screen_id,
            t.id AS theatre_id
        FROM shows sh
        JOIN movies m ON m.id = sh.movie_id
        JOIN screens sc ON sc.id = sh.screen_id
        JOIN theatres t ON t.id = sc.theatre_id
        
        UNION ALL
        
        SELECT 
            es.id,
            'event' AS type,
            e.title,
            sc.name AS screen_name,
            t.name AS theatre_name,
            es.start_time,
            es.end_time,
            es.price AS base_price,
            sc.id AS screen_id,
            t.id AS theatre_id
        FROM event_shows es
        JOIN events e ON e.id = es.event_id
        JOIN screens sc ON sc.id = es.screen_id
        JOIN theatres t ON t.id = sc.theatre_id
    )
    SELECT 
        u.id,
        u.type,
        u.title,
        u.screen_name,
        u.theatre_name,
        u.start_time,
        u.end_time,
        u.base_price,
        COUNT(DISTINCT seats.id) AS total_seats,
        COUNT(DISTINCT CASE WHEN b.status = 'confirmed' THEN b.id END) AS booked_seats,
        COUNT(DISTINCT CASE WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN b.id END) AS locked_seats,
        COUNT(DISTINCT seats.id) - COUNT(DISTINCT CASE WHEN b.status = 'confirmed' OR (b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes') THEN b.id END) AS available_seats
    FROM all_unified_shows u
    JOIN theater_owners to_owner ON to_owner.theatre_id = u.theatre_id
    LEFT JOIN seats ON seats.screen_id = u.screen_id
    LEFT JOIN bookings b ON ( (b.show_id = u.id AND u.type = 'movie') OR (b.event_show_id = u.id AND u.type = 'event') ) AND b.seat_id = seats.id AND b.status IN ('confirmed', 'locked')
    WHERE to_owner.user_id = p_user_id
        AND (p_theatre_id IS NULL OR u.theatre_id = p_theatre_id)
        AND DATE(u.start_time) = p_date
    GROUP BY u.id, u.type, u.title, u.screen_name, u.theatre_name, u.start_time, u.end_time, u.base_price
    ORDER BY u.start_time;
END;
$$;

GRANT EXECUTE ON FUNCTION get_owner_shows(UUID, UUID, DATE) TO authenticated;
GRANT EXECUTE ON FUNCTION get_owner_dashboard_stats(UUID) TO authenticated;


-- ==========================================
-- Migration: 017_admin_financials.sql
-- ==========================================

-- Migration: Admin Financials & Owner Revenue Breakdown (STABILIZED)
-- Fixes grouping ambiguities and performance bottlenecks

-- Platform Wide Stats
CREATE OR REPLACE FUNCTION get_admin_dashboard_stats()
RETURNS TABLE(
    total_revenue NUMERIC,
    total_bookings BIGINT,
    total_theatres BIGINT,
    total_owners BIGINT,
    today_revenue NUMERIC,
    today_bookings BIGINT,
    active_locks BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Only admins
    IF NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;

    RETURN QUERY
    WITH revenue_calc AS (
        -- Combine all booking sources for a unified calc
        SELECT 
            b.id,
            b.status,
            b.created_at,
            b.locked_at,
            COALESCE(
                seats.price, 
                sh.price, 
                es.price, 
                0
            ) as seat_price
        FROM bookings b
        LEFT JOIN seats ON seats.id = b.seat_id
        LEFT JOIN shows sh ON sh.id = b.show_id
        LEFT JOIN event_shows es ON es.id = b.event_show_id
    )
    SELECT
        COALESCE(SUM(seat_price) FILTER (WHERE status = 'confirmed'), 0)::NUMERIC,
        COUNT(*) FILTER (WHERE status = 'confirmed')::BIGINT,
        (SELECT COUNT(*) FROM theatres)::BIGINT,
        (SELECT COUNT(DISTINCT user_id) FROM theater_owners)::BIGINT,
        COALESCE(SUM(seat_price) FILTER (WHERE status = 'confirmed' AND DATE(created_at) = CURRENT_DATE), 0)::NUMERIC,
        COUNT(*) FILTER (WHERE status = 'confirmed' AND DATE(created_at) = CURRENT_DATE)::BIGINT,
        COUNT(*) FILTER (WHERE status = 'locked' AND locked_at >= NOW() - INTERVAL '10 minutes')::BIGINT
    FROM revenue_calc;
END;
$$;

-- Owner Revenue Breakdown
CREATE OR REPLACE FUNCTION get_admin_owner_revenue_breakdown(p_start_date DATE DEFAULT NULL, p_end_date DATE DEFAULT NULL)
RETURNS TABLE(
    owner_id UUID,
    owner_email TEXT,
    owner_name TEXT,
    theatre_names TEXT,
    revenue NUMERIC,
    booking_count BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Only admins
    IF NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;

    RETURN QUERY
    WITH owner_theatres AS (
        SELECT 
            to_owner.user_id,
            t.id as theatre_id,
            t.name as theatre_name,
            oa.email as user_email,
            oa.full_name as user_name
        FROM theater_owners to_owner
        JOIN theatres t ON t.id = to_owner.theatre_id
        LEFT JOIN owner_applications oa ON oa.user_id = to_owner.user_id AND oa.status = 'approved'
    ),
    all_owner_bookings AS (
        -- Select all confirmed bookings associated with owner theatres
        SELECT 
            ot.user_id,
            ot.user_email,
            ot.user_name,
            ot.theatre_name,
            b.id as booking_id,
            COALESCE(seats.price, sh.price, es.price, 0) as booking_price
        FROM bookings b
        LEFT JOIN shows sh ON sh.id = b.show_id
        LEFT JOIN event_shows es ON es.id = b.event_show_id
        JOIN screens s ON s.id = COALESCE(sh.screen_id, es.screen_id)
        JOIN owner_theatres ot ON ot.theatre_id = s.theatre_id
        LEFT JOIN seats ON seats.id = b.seat_id
        WHERE b.status = 'confirmed'
          AND (p_start_date IS NULL OR DATE(b.created_at) >= p_start_date)
          AND (p_end_date IS NULL OR DATE(b.created_at) <= p_end_date)
    )
    SELECT 
        user_id as owner_id,
        COALESCE(user_email, 'N/A') as owner_email,
        COALESCE(user_name, 'Unknown Owner') as owner_name,
        string_agg(DISTINCT theatre_name, ', ') as theatre_names,
        SUM(booking_price)::NUMERIC as revenue,
        COUNT(DISTINCT booking_id)::BIGINT as booking_count
    FROM all_owner_bookings
    GROUP BY user_id, user_email, user_name
    ORDER BY revenue DESC;
END;
$$;

GRANT EXECUTE ON FUNCTION get_admin_dashboard_stats() TO authenticated;
GRANT EXECUTE ON FUNCTION get_admin_owner_revenue_breakdown(DATE, DATE) TO authenticated;


-- ==========================================
-- Migration: 018_production_hardening.sql
-- ==========================================

-- Migration: Production Hardening
-- Adds structural auditing and performance optimizations

-- 1. Create Transaction Logs Table for Financial Auditing
CREATE TABLE IF NOT EXISTS transaction_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
    user_id UUID, -- NULL for guest
    session_id TEXT, -- For guest tracking
    payment_provider TEXT DEFAULT 'internal',
    provider_transaction_id TEXT,
    amount NUMERIC(10, 2) NOT NULL,
    currency TEXT DEFAULT 'INR',
    status TEXT DEFAULT 'success' CHECK (status IN ('success', 'refunded', 'failed', 'pending')),
    metadata JSONB DEFAULT '{}'::JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS on transaction_logs
ALTER TABLE transaction_logs ENABLE ROW LEVEL SECURITY;

-- Policies for transaction_logs
CREATE POLICY "Admins full access trans_logs" ON transaction_logs 
    FOR ALL USING ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true);

CREATE POLICY "Users view own trans_logs" ON transaction_logs 
    FOR SELECT USING (auth.uid() = user_id OR session_id = (SELECT session_id FROM bookings WHERE id = booking_id));

-- 2. Audit Trail Trigger
-- Automatically logs when a booking is confirmed
CREATE OR REPLACE FUNCTION audit_confirmed_booking()
RETURNS TRIGGER AS $$
DECLARE
    v_amount NUMERIC;
BEGIN
    IF (NEW.status = 'confirmed' AND (OLD.status IS NULL OR OLD.status != 'confirmed')) THEN
        -- Get the amount for this booking
        SELECT COALESCE(seats.price, sh.price, es.price, 0) INTO v_amount
        FROM bookings b
        LEFT JOIN seats ON seats.id = b.seat_id
        LEFT JOIN shows sh ON sh.id = b.show_id
        LEFT JOIN event_shows es ON es.id = b.event_show_id
        WHERE b.id = NEW.id;

        INSERT INTO transaction_logs (
            booking_id, 
            user_id, 
            session_id, 
            payment_provider, 
            provider_transaction_id, 
            amount,
            metadata
        ) VALUES (
            NEW.id,
            NEW.user_id,
            NEW.session_id,
            'internal', -- Update this when real provider is added
            NEW.payment_id,
            COALESCE(v_amount, 0),
            jsonb_build_object('source', 'auto_audit_trigger', 'timestamp', NOW())
        );
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER trg_audit_booking_confirmation
AFTER UPDATE ON bookings
FOR EACH ROW
EXECUTE FUNCTION audit_confirmed_booking();

-- 3. High-Performance Indexing Strategy
-- Composite indexes for financial reporting and real-time dashboard performance

-- Optimization for: get_admin_dashboard_stats & get_owner_dashboard_stats
CREATE INDEX IF NOT EXISTS idx_bookings_financial_stat 
ON bookings (status, created_at) 
INCLUDE (show_id, event_show_id);

-- Optimization for: get_admin_owner_revenue_breakdown
CREATE INDEX IF NOT EXISTS idx_bookings_owner_reporting 
ON bookings (show_id, event_show_id) 
WHERE status = 'confirmed';

-- Optimization for: Seat Availability Views
CREATE INDEX IF NOT EXISTS idx_bookings_availability_lookup 
ON bookings (show_id, seat_id, status) 
WHERE status IN ('locked', 'confirmed');

CREATE INDEX IF NOT EXISTS idx_bookings_availability_event_lookup 
ON bookings (event_show_id, seat_id, status) 
WHERE status IN ('locked', 'confirmed');

-- Optimization for: Dashboard card counts
CREATE INDEX IF NOT EXISTS idx_bookings_realtime_badge 
ON bookings (show_id, status) 
WHERE status = 'confirmed';

CREATE INDEX IF NOT EXISTS idx_bookings_realtime_event_badge 
ON bookings (event_show_id, status) 
WHERE status = 'confirmed';

-- Optimization for: Show lookup performance
CREATE INDEX IF NOT EXISTS idx_shows_screen_time 
ON shows (screen_id, start_time);

CREATE INDEX IF NOT EXISTS idx_event_shows_screen_time 
ON event_shows (screen_id, start_time);

-- 4. Admin Security Hardening
-- Ensure RPCs are strictly restricted
GRANT SELECT ON transaction_logs TO authenticated;
GRANT SELECT ON transaction_logs TO anon; -- Allow guest to potentially view their own receipt


-- ==========================================
-- Migration: 019_fix_seat_layout_editor_save.sql
-- ==========================================

-- ============================================
-- Quick My Ticket - Fix Seat Layout Editor Save
-- Migration 019
-- ============================================

CREATE OR REPLACE FUNCTION update_screen_layout(
    p_screen_id UUID,
    p_seat_layout JSONB
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_theatre_id UUID;
    v_is_owner BOOLEAN;
BEGIN
    IF p_seat_layout IS NULL
       OR jsonb_typeof(p_seat_layout->'rows') IS DISTINCT FROM 'array' THEN
        RETURN json_build_object('success', false, 'error', 'Invalid seat layout');
    END IF;

    SELECT theatre_id INTO v_theatre_id
    FROM screens
    WHERE id = p_screen_id;

    IF v_theatre_id IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Screen not found');
    END IF;

    SELECT EXISTS(
        SELECT 1 FROM theater_owners
        WHERE user_id = v_user_id AND theatre_id = v_theatre_id
    ) INTO v_is_owner;

    IF NOT v_is_owner AND NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RETURN json_build_object('success', false, 'error', 'Access denied');
    END IF;

    IF EXISTS (
        SELECT 1 FROM bookings b
        JOIN shows s ON b.show_id = s.id
        WHERE s.screen_id = p_screen_id AND b.status IN ('confirmed', 'locked')

        UNION ALL

        SELECT 1 FROM bookings b
        JOIN event_shows es ON b.event_show_id = es.id
        WHERE es.screen_id = p_screen_id AND b.status IN ('confirmed', 'locked')
    ) THEN
        RETURN json_build_object('success', false, 'error', 'Cannot update layout: Active bookings exist for this screen');
    END IF;

    UPDATE screens
    SET
        seat_layout = p_seat_layout,
        rows = COALESCE((p_seat_layout->'metadata'->>'rowCount')::integer, rows),
        seats_per_row = COALESCE((p_seat_layout->'metadata'->>'maxSeatsPerRow')::integer, seats_per_row)
    WHERE id = p_screen_id;

    DELETE FROM seats WHERE screen_id = p_screen_id;

    INSERT INTO seats (screen_id, row, col, tier, price)
    SELECT
        p_screen_id,
        r->>'label',
        (s->>'id')::integer,
        s->>'type',
        (s->>'price')::integer
    FROM jsonb_array_elements(p_seat_layout->'rows') AS r
    CROSS JOIN jsonb_array_elements(r->'seats') AS s
    WHERE s IS NOT NULL AND s != 'null'::jsonb;

    RETURN json_build_object('success', true, 'message', 'Layout updated and seats synced');
END;
$$;

GRANT EXECUTE ON FUNCTION update_screen_layout(UUID, JSONB) TO authenticated;


-- ==========================================
-- Migration: 020_fix_seat_availability_screen_scope.sql
-- ==========================================

-- ============================================
-- Quick My Ticket - Fix Seat Availability Screen Scope
-- Migration 020
-- ============================================
-- Migration 015 accidentally allowed movie seat availability to cross join
-- seats from every screen into every show. That made booking pages render
-- repeated seat numbers from unrelated screens.

CREATE OR REPLACE VIEW seat_availability AS
SELECT
    s.id AS seat_id,
    s.screen_id,
    s.row,
    s.col,
    s.tier,
    s.price AS seat_price,
    sh.id AS show_id,
    sh.price AS show_price,
    COALESCE(s.price, sh.price, 0) AS effective_price,
    CASE
        WHEN b.status = 'confirmed' THEN 'booked'
        WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 'locked'
        ELSE 'available'
    END AS availability_status,
    b.user_id AS locked_by,
    b.id AS booking_id,
    b.locked_at,
    b.session_id AS locked_by_session
FROM shows sh
JOIN seats s ON s.screen_id = sh.screen_id
LEFT JOIN LATERAL (
    SELECT *
    FROM bookings
    WHERE seat_id = s.id
      AND show_id = sh.id
      AND (
          status = 'confirmed'
          OR (status = 'locked' AND locked_at >= NOW() - INTERVAL '5 minutes')
      )
    ORDER BY
        CASE WHEN status = 'confirmed' THEN 0 ELSE 1 END,
        locked_at DESC
    LIMIT 1
) b ON true;

CREATE OR REPLACE VIEW event_seat_availability AS
SELECT
    es.id AS event_show_id,
    es.event_id,
    e.title AS event_title,
    s.id AS seat_id,
    s.screen_id,
    s.row,
    s.col,
    s.tier,
    COALESCE(s.price, es.price) AS effective_price,
    b.id AS booking_id,
    b.user_id AS locked_by,
    b.locked_at,
    CASE
        WHEN b.status = 'confirmed' THEN 'booked'
        WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 'locked'
        ELSE 'available'
    END AS availability_status,
    b.session_id AS locked_by_session
FROM event_shows es
JOIN events e ON e.id = es.event_id
JOIN seats s ON s.screen_id = es.screen_id
LEFT JOIN LATERAL (
    SELECT *
    FROM bookings
    WHERE seat_id = s.id
      AND event_show_id = es.id
      AND (
          status = 'confirmed'
          OR (status = 'locked' AND locked_at >= NOW() - INTERVAL '5 minutes')
      )
    ORDER BY
        CASE WHEN status = 'confirmed' THEN 0 ELSE 1 END,
        locked_at DESC
    LIMIT 1
) b ON true;

GRANT SELECT ON seat_availability TO authenticated;
GRANT SELECT ON seat_availability TO anon;
GRANT SELECT ON event_seat_availability TO authenticated;
GRANT SELECT ON event_seat_availability TO anon;


-- ==========================================
-- Migration: 021_repair_unconfigured_duplicate_screens.sql
-- ==========================================

-- ============================================
-- Quick My Ticket - Repair Shows on Unconfigured Duplicate Screens
-- Migration 021
-- ============================================
-- Some theatres have duplicate screen names where one screen has a saved layout
-- and seats, while the duplicate has neither. Shows attached to the empty
-- duplicate cannot render or book seats. This moves unbooked shows/event shows
-- from empty duplicates to the configured screen with the same theatre + name.

WITH screen_seat_counts AS (
    SELECT
        s.id,
        s.theatre_id,
        s.name,
        s.seat_layout,
        COUNT(seats.id) AS seat_count
    FROM screens s
    LEFT JOIN seats ON seats.screen_id = s.id
    GROUP BY s.id, s.theatre_id, s.name, s.seat_layout
),
empty_screens AS (
    SELECT *
    FROM screen_seat_counts
    WHERE seat_layout IS NULL
      AND seat_count = 0
),
configured_screens AS (
    SELECT *
    FROM screen_seat_counts
    WHERE seat_layout IS NOT NULL
      AND seat_count > 0
),
screen_replacements AS (
    SELECT DISTINCT ON (empty_screens.id)
        empty_screens.id AS empty_screen_id,
        configured_screens.id AS configured_screen_id
    FROM empty_screens
    JOIN configured_screens
      ON configured_screens.theatre_id = empty_screens.theatre_id
     AND configured_screens.name = empty_screens.name
    ORDER BY
        empty_screens.id,
        configured_screens.seat_count DESC,
        configured_screens.id
)
UPDATE shows
SET screen_id = screen_replacements.configured_screen_id
FROM screen_replacements
WHERE shows.screen_id = screen_replacements.empty_screen_id
  AND NOT EXISTS (
      SELECT 1
      FROM bookings b
      WHERE b.show_id = shows.id
        AND b.status IN ('confirmed', 'locked')
  );

WITH screen_seat_counts AS (
    SELECT
        s.id,
        s.theatre_id,
        s.name,
        s.seat_layout,
        COUNT(seats.id) AS seat_count
    FROM screens s
    LEFT JOIN seats ON seats.screen_id = s.id
    GROUP BY s.id, s.theatre_id, s.name, s.seat_layout
),
empty_screens AS (
    SELECT *
    FROM screen_seat_counts
    WHERE seat_layout IS NULL
      AND seat_count = 0
),
configured_screens AS (
    SELECT *
    FROM screen_seat_counts
    WHERE seat_layout IS NOT NULL
      AND seat_count > 0
),
screen_replacements AS (
    SELECT DISTINCT ON (empty_screens.id)
        empty_screens.id AS empty_screen_id,
        configured_screens.id AS configured_screen_id
    FROM empty_screens
    JOIN configured_screens
      ON configured_screens.theatre_id = empty_screens.theatre_id
     AND configured_screens.name = empty_screens.name
    ORDER BY
        empty_screens.id,
        configured_screens.seat_count DESC,
        configured_screens.id
)
UPDATE event_shows
SET screen_id = screen_replacements.configured_screen_id
FROM screen_replacements
WHERE event_shows.screen_id = screen_replacements.empty_screen_id
  AND NOT EXISTS (
      SELECT 1
      FROM bookings b
      WHERE b.event_show_id = event_shows.id
        AND b.status IN ('confirmed', 'locked')
  );


-- ==========================================
-- Migration: 022_fix_update_screen_layout_columns.sql
-- ==========================================

-- ============================================
-- Quick My Ticket - Fix all Seat Layout RPCs
-- Migration 022 (FINAL FIX)
-- ============================================

-- First, drop existing functions to ensure we are starting fresh
DROP FUNCTION IF EXISTS update_screen_layout(UUID, JSONB);
DROP FUNCTION IF EXISTS get_screen_layout(UUID);

-- 1. Fix update_screen_layout
CREATE OR REPLACE FUNCTION update_screen_layout(
    p_screen_id UUID,
    p_seat_layout JSONB
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_theatre_id UUID;
    v_is_owner BOOLEAN;
BEGIN
    -- Validation
    IF p_seat_layout IS NULL 
       OR jsonb_typeof(p_seat_layout->'rows') IS DISTINCT FROM 'array' THEN
        RETURN json_build_object('success', false, 'error', 'Invalid seat layout');
    END IF;

    -- Find theatre and check permissions
    SELECT theatre_id INTO v_theatre_id
    FROM screens
    WHERE id = p_screen_id;

    IF v_theatre_id IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Screen not found');
    END IF;

    SELECT EXISTS(
        SELECT 1 FROM theater_owners
        WHERE user_id = v_user_id AND theatre_id = v_theatre_id
    ) INTO v_is_owner;

    IF NOT v_is_owner AND NOT (COALESCE((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean, false) = true) THEN
        RETURN json_build_object('success', false, 'error', 'Access denied');
    END IF;

    -- Check for active bookings
    IF EXISTS (
        SELECT 1 FROM bookings b
        JOIN shows s ON b.show_id = s.id
        WHERE s.screen_id = p_screen_id AND b.status IN ('confirmed', 'locked')
        
        UNION ALL
        
        SELECT 1 FROM bookings b
        JOIN event_shows es ON b.event_show_id = es.id
        WHERE es.screen_id = p_screen_id AND b.status IN ('confirmed', 'locked')
    ) THEN
        RETURN json_build_object('success', false, 'error', 'Cannot update layout: Active bookings exist for this screen');
    END IF;

    -- Update screen (using verified columns: seat_layout, total_seats)
    UPDATE screens
    SET 
        seat_layout = p_seat_layout,
        total_seats = COALESCE((p_seat_layout->'metadata'->>'totalSeats')::integer, total_seats)
    WHERE id = p_screen_id;

    -- Sync seats table
    DELETE FROM seats WHERE screen_id = p_screen_id;

    INSERT INTO seats (screen_id, row, col, tier, price)
    SELECT 
        p_screen_id,
        r->>'label',
        (s->>'id')::integer,
        s->>'type',
        (s->>'price')::integer
    FROM jsonb_array_elements(p_seat_layout->'rows') AS r
    CROSS JOIN jsonb_array_elements(r->'seats') AS s
    WHERE s IS NOT NULL AND s != 'null'::jsonb;

    RETURN json_build_object('success', true, 'message', 'Layout updated and seats synced');
END;
$$;

-- 2. Fix get_screen_layout
CREATE OR REPLACE FUNCTION get_screen_layout(p_screen_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_layout JSONB;
BEGIN
    -- Only select columns that actually exist!
    SELECT seat_layout
    INTO v_layout
    FROM screens
    WHERE id = p_screen_id;
    
    -- If custom layout exists, return it
    IF v_layout IS NOT NULL THEN
        RETURN v_layout;
    END IF;
    
    -- If no layout, return a simple 10x12 default
    RETURN generate_default_layout(10, 12);
END;
$$;

GRANT EXECUTE ON FUNCTION update_screen_layout(UUID, JSONB) TO authenticated;
GRANT EXECUTE ON FUNCTION get_screen_layout(UUID) TO anon, authenticated;


-- ==========================================
-- Migration: 023_restrict_calculate_booking_total.sql
-- ==========================================

-- ============================================
-- Quick My Ticket - Restrict calculate_booking_total
-- Migration 023
-- ============================================
-- SECURITY: calculate_booking_total touches pricing and runs as
-- SECURITY DEFINER. It should only be callable by service_role
-- (Edge Functions), never directly by authenticated or anon users.

REVOKE ALL ON FUNCTION calculate_booking_total(UUID[], DECIMAL) FROM PUBLIC;
REVOKE ALL ON FUNCTION calculate_booking_total(UUID[], DECIMAL) FROM authenticated;
REVOKE ALL ON FUNCTION calculate_booking_total(UUID[], DECIMAL) FROM anon;
GRANT EXECUTE ON FUNCTION calculate_booking_total(UUID[], DECIMAL) TO service_role;


-- ==========================================
-- Migration: 024_dashboard_performance_indexes.sql
-- ==========================================

-- Migration: Dashboard Performance Optimization
-- Adds critical foreign key indexes and rewrites RPCs for sub-second execution

-- 1. Create missing foreign key indexes to eliminate sequential scans
CREATE INDEX IF NOT EXISTS idx_bookings_show_id ON bookings(show_id);
CREATE INDEX IF NOT EXISTS idx_bookings_event_show_id ON bookings(event_show_id);

-- Add Composite Power Indexes targeting exactly the WHERE clauses used in stats
CREATE INDEX IF NOT EXISTS idx_bookings_perf_confirmed 
ON bookings (status, created_at) 
WHERE status = 'confirmed';

CREATE INDEX IF NOT EXISTS idx_bookings_perf_locked 
ON bookings (status, locked_at) 
WHERE status = 'locked';

-- 2. Rewrite get_owner_dashboard_stats to avoid CTEs, OR clauses, and DATE() functions
CREATE OR REPLACE FUNCTION get_owner_dashboard_stats(p_user_id UUID)
RETURNS TABLE(
    total_theatres BIGINT,
    total_screens BIGINT,
    total_seats BIGINT,
    today_bookings BIGINT,
    today_revenue DECIMAL,
    currently_locked BIGINT,
    today_confirmed BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_theatre_ids UUID[];
    v_today DATE := CURRENT_DATE;
BEGIN
    SELECT ARRAY_AGG(theatre_id) INTO v_theatre_ids
    FROM theater_owners
    WHERE user_id = p_user_id;
    
    IF v_theatre_ids IS NULL THEN
        RETURN QUERY SELECT 0::BIGINT, 0::BIGINT, 0::BIGINT, 0::BIGINT, 0::DECIMAL, 0::BIGINT, 0::BIGINT;
        RETURN;
    END IF;

    RETURN QUERY
    WITH screen_data AS (
        SELECT s.id as screen_id, 
               (SELECT COUNT(*) FROM seats WHERE screen_id = s.id) as seat_count
        FROM screens s
        WHERE s.theatre_id = ANY(v_theatre_ids)
    ),
    movie_stats AS (
        SELECT 
            SUM(CASE WHEN b.created_at >= v_today AND b.created_at < (v_today + interval '1 day') THEN 1 ELSE 0 END) AS today_bookings,
            SUM(CASE WHEN b.created_at >= v_today AND b.created_at < (v_today + interval '1 day') AND b.status = 'confirmed' THEN COALESCE(seats.price, sh.price, 0) ELSE 0 END) AS today_revenue,
            SUM(CASE WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 1 ELSE 0 END) AS currently_locked,
            SUM(CASE WHEN b.created_at >= v_today AND b.created_at < (v_today + interval '1 day') AND b.status = 'confirmed' THEN 1 ELSE 0 END) AS today_confirmed
        FROM shows sh
        JOIN screen_data sd ON sd.screen_id = sh.screen_id
        JOIN bookings b ON b.show_id = sh.id
        LEFT JOIN seats ON seats.id = b.seat_id
    ),
    event_stats AS (
        SELECT 
            SUM(CASE WHEN b.created_at >= v_today AND b.created_at < (v_today + interval '1 day') THEN 1 ELSE 0 END) AS today_bookings,
            SUM(CASE WHEN b.created_at >= v_today AND b.created_at < (v_today + interval '1 day') AND b.status = 'confirmed' THEN COALESCE(seats.price, es.price, 0) ELSE 0 END) AS today_revenue,
            SUM(CASE WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 1 ELSE 0 END) AS currently_locked,
            SUM(CASE WHEN b.created_at >= v_today AND b.created_at < (v_today + interval '1 day') AND b.status = 'confirmed' THEN 1 ELSE 0 END) AS today_confirmed
        FROM event_shows es
        JOIN screen_data sd ON sd.screen_id = es.screen_id
        JOIN bookings b ON b.event_show_id = es.id
        LEFT JOIN seats ON seats.id = b.seat_id
    )
    SELECT
        (SELECT COUNT(*) FROM unnest(v_theatre_ids))::BIGINT AS total_theatres,
        (SELECT COUNT(*) FROM screen_data)::BIGINT AS total_screens,
        (SELECT COALESCE(SUM(seat_count), 0) FROM screen_data)::BIGINT AS total_seats,
        (COALESCE((SELECT today_bookings FROM movie_stats), 0) + COALESCE((SELECT today_bookings FROM event_stats), 0))::BIGINT AS today_bookings,
        (COALESCE((SELECT today_revenue FROM movie_stats), 0) + COALESCE((SELECT today_revenue FROM event_stats), 0))::DECIMAL AS today_revenue,
        (COALESCE((SELECT currently_locked FROM movie_stats), 0) + COALESCE((SELECT currently_locked FROM event_stats), 0))::BIGINT AS currently_locked,
        (COALESCE((SELECT today_confirmed FROM movie_stats), 0) + COALESCE((SELECT today_confirmed FROM event_stats), 0))::BIGINT AS today_confirmed;
END;
$$;

-- 3. Rewrite get_admin_dashboard_stats
CREATE OR REPLACE FUNCTION get_admin_dashboard_stats()
RETURNS TABLE(
    total_revenue NUMERIC,
    total_bookings BIGINT,
    total_theatres BIGINT,
    total_owners BIGINT,
    today_revenue NUMERIC,
    today_bookings BIGINT,
    active_locks BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Only admins
    IF NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;

    RETURN QUERY
    WITH movie_stats AS (
        SELECT
            SUM(COALESCE(seats.price, sh.price, 0)) FILTER (WHERE b.status = 'confirmed') AS total_revenue,
            COUNT(*) FILTER (WHERE b.status = 'confirmed') AS total_bookings,
            SUM(COALESCE(seats.price, sh.price, 0)) FILTER (WHERE b.status = 'confirmed' AND b.created_at >= CURRENT_DATE AND b.created_at < (CURRENT_DATE + interval '1 day')) AS today_revenue,
            COUNT(*) FILTER (WHERE b.status = 'confirmed' AND b.created_at >= CURRENT_DATE AND b.created_at < (CURRENT_DATE + interval '1 day')) AS today_bookings,
            COUNT(*) FILTER (WHERE b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '10 minutes') AS active_locks
        FROM bookings b
        JOIN shows sh ON sh.id = b.show_id
        LEFT JOIN seats ON seats.id = b.seat_id
    ),
    event_stats AS (
        SELECT
            SUM(COALESCE(seats.price, es.price, 0)) FILTER (WHERE b.status = 'confirmed') AS total_revenue,
            COUNT(*) FILTER (WHERE b.status = 'confirmed') AS total_bookings,
            SUM(COALESCE(seats.price, es.price, 0)) FILTER (WHERE b.status = 'confirmed' AND b.created_at >= CURRENT_DATE AND b.created_at < (CURRENT_DATE + interval '1 day')) AS today_revenue,
            COUNT(*) FILTER (WHERE b.status = 'confirmed' AND b.created_at >= CURRENT_DATE AND b.created_at < (CURRENT_DATE + interval '1 day')) AS today_bookings,
            COUNT(*) FILTER (WHERE b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '10 minutes') AS active_locks
        FROM bookings b
        JOIN event_shows es ON es.id = b.event_show_id
        LEFT JOIN seats ON seats.id = b.seat_id
    )
    SELECT
        (COALESCE((SELECT total_revenue FROM movie_stats), 0) + COALESCE((SELECT total_revenue FROM event_stats), 0))::NUMERIC,
        (COALESCE((SELECT total_bookings FROM movie_stats), 0) + COALESCE((SELECT total_bookings FROM event_stats), 0))::BIGINT,
        (SELECT COUNT(*) FROM theatres)::BIGINT,
        (SELECT COUNT(DISTINCT user_id) FROM theater_owners)::BIGINT,
        (COALESCE((SELECT today_revenue FROM movie_stats), 0) + COALESCE((SELECT today_revenue FROM event_stats), 0))::NUMERIC,
        (COALESCE((SELECT today_bookings FROM movie_stats), 0) + COALESCE((SELECT today_bookings FROM event_stats), 0))::BIGINT,
        (COALESCE((SELECT active_locks FROM movie_stats), 0) + COALESCE((SELECT active_locks FROM event_stats), 0))::BIGINT;
END;
$$;

-- 4. Rewrite get_admin_owner_revenue_breakdown
CREATE OR REPLACE FUNCTION get_admin_owner_revenue_breakdown(p_start_date DATE DEFAULT NULL, p_end_date DATE DEFAULT NULL)
RETURNS TABLE(
    owner_id UUID,
    owner_email TEXT,
    owner_name TEXT,
    theatre_names TEXT,
    revenue NUMERIC,
    booking_count BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Only admins
    IF NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;

    RETURN QUERY
    WITH owner_theatres AS (
        SELECT 
            to_owner.user_id,
            t.id as theatre_id,
            t.name as theatre_name,
            oa.email as user_email,
            oa.full_name as user_name
        FROM theater_owners to_owner
        JOIN theatres t ON t.id = to_owner.theatre_id
        LEFT JOIN owner_applications oa ON oa.user_id = to_owner.user_id AND oa.status = 'approved'
    ),
    movie_bookings AS (
        SELECT 
            s.theatre_id,
            COUNT(b.id) as booking_count,
            SUM(COALESCE(seats.price, sh.price, 0)) as revenue
        FROM bookings b
        JOIN shows sh ON sh.id = b.show_id
        JOIN screens s ON s.id = sh.screen_id
        LEFT JOIN seats ON seats.id = b.seat_id
        WHERE b.status = 'confirmed' 
            AND (p_start_date IS NULL OR b.created_at >= p_start_date)
            AND (p_end_date IS NULL OR b.created_at < (p_end_date + INTERVAL '1 day'))
        GROUP BY s.theatre_id
    ),
    event_bookings AS (
        SELECT 
            s.theatre_id,
            COUNT(b.id) as booking_count,
            SUM(COALESCE(seats.price, es.price, 0)) as revenue
        FROM bookings b
        JOIN event_shows es ON es.id = b.event_show_id
        JOIN screens s ON s.id = es.screen_id
        LEFT JOIN seats ON seats.id = b.seat_id
        WHERE b.status = 'confirmed' 
            AND (p_start_date IS NULL OR b.created_at >= p_start_date)
            AND (p_end_date IS NULL OR b.created_at < (p_end_date + INTERVAL '1 day'))
        GROUP BY s.theatre_id
    )
    SELECT 
        ot.user_id as owner_id,
        MAX(ot.user_email) as owner_email,
        MAX(ot.user_name) as owner_name,
        STRING_AGG(DISTINCT ot.theatre_name, ', ') as theatre_names,
        COALESCE(SUM(mb.revenue), 0) + COALESCE(SUM(eb.revenue), 0) as revenue,
        COALESCE(SUM(mb.booking_count), 0) + COALESCE(SUM(eb.booking_count), 0) as booking_count
    FROM owner_theatres ot
    LEFT JOIN movie_bookings mb ON mb.theatre_id = ot.theatre_id
    LEFT JOIN event_bookings eb ON eb.theatre_id = ot.theatre_id
    GROUP BY ot.user_id
    ORDER BY revenue DESC;
END;
$$;

-- 5. Optimize get_owner_shows
DROP FUNCTION IF EXISTS get_owner_shows(UUID, UUID, DATE);

CREATE OR REPLACE FUNCTION get_owner_shows(
    p_user_id UUID,
    p_theatre_id UUID DEFAULT NULL,
    p_date DATE DEFAULT CURRENT_DATE
)
RETURNS TABLE(
    id UUID,             
    type TEXT,
    title TEXT,          
    screen_name TEXT,
    theatre_name TEXT,
    start_time TIMESTAMPTZ,
    end_time TIMESTAMPTZ,
    base_price DECIMAL,
    total_seats BIGINT,
    booked_seats BIGINT,
    locked_seats BIGINT,
    available_seats BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    WITH owner_theatres AS (
        SELECT theatre_id 
        FROM theater_owners 
        WHERE user_id = p_user_id 
          AND (p_theatre_id IS NULL OR theatre_id = p_theatre_id)
    ),
    filtered_movies AS (
        SELECT 
            sh.id,
            'movie' AS type,
            m.title,
            sc.name AS screen_name,
            t.name AS theatre_name,
            sh.start_time,
            sh.end_time,
            sh.price AS base_price,
            sc.id AS screen_id,
            t.id AS theatre_id
        FROM shows sh
        JOIN movies m ON m.id = sh.movie_id
        JOIN screens sc ON sc.id = sh.screen_id
        JOIN theatres t ON t.id = sc.theatre_id
        WHERE sc.theatre_id IN (SELECT theatre_id FROM owner_theatres)
          AND sh.start_time >= p_date AND sh.start_time < (p_date + interval '1 day')
    ),
    filtered_events AS (
        SELECT 
            es.id,
            'event' AS type,
            e.title,
            sc.name AS screen_name,
            t.name AS theatre_name,
            es.start_time,
            es.end_time,
            es.price AS base_price,
            sc.id AS screen_id,
            t.id AS theatre_id
        FROM event_shows es
        JOIN events e ON e.id = es.event_id
        JOIN screens sc ON sc.id = es.screen_id
        JOIN theatres t ON t.id = sc.theatre_id
        WHERE sc.theatre_id IN (SELECT theatre_id FROM owner_theatres)
          AND es.start_time >= p_date AND es.start_time < (p_date + interval '1 day')
    ),
    all_unified_shows AS (
        SELECT * FROM filtered_movies
        UNION ALL
        SELECT * FROM filtered_events
    )
    SELECT 
        u.id,
        u.type,
        u.title,
        u.screen_name,
        u.theatre_name,
        u.start_time,
        u.end_time,
        u.base_price,
        (SELECT COUNT(*) FROM seats WHERE screen_id = u.screen_id)::BIGINT AS total_seats,
        (SELECT COUNT(*) FROM bookings b WHERE (b.show_id = u.id OR b.event_show_id = u.id) AND b.status = 'confirmed')::BIGINT AS booked_seats,
        (SELECT COUNT(*) FROM bookings b WHERE (b.show_id = u.id OR b.event_show_id = u.id) AND b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes')::BIGINT AS locked_seats,
        ((SELECT COUNT(*) FROM seats WHERE screen_id = u.screen_id) - 
         (SELECT COUNT(*) FROM bookings b WHERE (b.show_id = u.id OR b.event_show_id = u.id) AND b.status IN ('confirmed', 'locked') AND (b.status = 'confirmed' OR (b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes'))))::BIGINT AS available_seats
    FROM all_unified_shows u
    ORDER BY u.start_time;
END;
$$;


-- ==========================================
-- Migration: 025_security_hardening.sql
-- ==========================================


-- ============================================
-- Quick My Ticket - Security Hardening
-- Migration 025
-- ============================================

-- 1. ENABLE RLS ON REMAINING TABLES
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.seats ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.movies ENABLE ROW LEVEL SECURITY;

-- 2. BOOKINGS POLICIES
DROP POLICY IF EXISTS "Users view own bookings" ON public.bookings;
CREATE POLICY "Users view own bookings" ON public.bookings
    FOR SELECT USING (
        auth.uid() = user_id OR 
        (user_id IS NULL AND session_id IS NOT NULL)
    );

DROP POLICY IF EXISTS "Admins full access bookings" ON public.bookings;
CREATE POLICY "Admins full access bookings" ON public.bookings
    FOR ALL USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

DROP POLICY IF EXISTS "Owners view bookings for their shows" ON public.bookings;
CREATE POLICY "Owners view bookings for their shows" ON public.bookings
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM theater_owners to_
            JOIN shows s ON s.id = bookings.show_id
            WHERE to_.user_id = auth.uid() AND to_.theatre_id = (SELECT theatre_id FROM screens WHERE id = s.screen_id)
        ) OR
        EXISTS (
            SELECT 1 FROM theater_owners to_
            JOIN event_shows es ON es.id = bookings.event_show_id
            WHERE to_.user_id = auth.uid() AND to_.theatre_id = (SELECT theatre_id FROM screens WHERE id = es.screen_id)
        )
    );

-- Block direct INSERT/UPDATE/DELETE for non-admins
DROP POLICY IF EXISTS "No direct inserts for non-admins" ON public.bookings;
CREATE POLICY "No direct inserts for non-admins" ON public.bookings
    FOR INSERT WITH CHECK ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

DROP POLICY IF EXISTS "No direct updates for non-admins" ON public.bookings;
CREATE POLICY "No direct updates for non-admins" ON public.bookings
    FOR UPDATE USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true)
    WITH CHECK ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

DROP POLICY IF EXISTS "No direct deletes for non-admins" ON public.bookings;
CREATE POLICY "No direct deletes for non-admins" ON public.bookings
    FOR DELETE USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);


-- 3. SEATS POLICIES
DROP POLICY IF EXISTS "Seats are viewable by everyone" ON public.seats;
CREATE POLICY "Seats are viewable by everyone" ON public.seats
    FOR SELECT USING (true);

DROP POLICY IF EXISTS "Admins can manage seats" ON public.seats;
CREATE POLICY "Admins can manage seats" ON public.seats
    FOR ALL USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);


-- 4. MOVIES POLICIES
DROP POLICY IF EXISTS "Movies are viewable by everyone" ON public.movies;
CREATE POLICY "Movies are viewable by everyone" ON public.movies
    FOR SELECT USING (true);

DROP POLICY IF EXISTS "Admins can manage movies" ON public.movies;
CREATE POLICY "Admins can manage movies" ON public.movies
    FOR ALL USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);


-- 5. PERMISSION REFINEMENT
REVOKE ALL ON public.bookings FROM anon;
GRANT SELECT ON public.bookings TO anon;
GRANT SELECT ON public.bookings TO authenticated;


-- ==========================================
-- Migration: 026_fix_privilege_escalation.sql
-- ==========================================

-- ============================================
-- Quick My Ticket - CRITICAL SECURITY FIX
-- Migration 026: Close Privilege Escalation
-- ============================================
-- PROBLEM: All admin checks use auth.jwt()->'user_metadata' which
-- any authenticated user can self-modify via supabase.auth.updateUser().
-- FIX: Switch every check to auth.jwt()->'app_metadata' which can
-- only be set server-side (service_role or Supabase Dashboard).
-- ============================================

-- =============================================
-- PART 1: RLS POLICIES (DROP + RECREATE)
-- =============================================

-- 1A. theater_owners
DROP POLICY IF EXISTS "Admin full access theater_owners" ON theater_owners;
CREATE POLICY "Admin full access theater_owners" ON theater_owners 
FOR ALL USING (
    (auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true
);

-- 1B. theatres
DROP POLICY IF EXISTS "Admin manage theatres" ON theatres;
CREATE POLICY "Admin manage theatres" ON theatres 
FOR ALL USING (
    (auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true
);

-- 1C. screens
DROP POLICY IF EXISTS "Admin manage screens" ON screens;
CREATE POLICY "Admin manage screens" ON screens 
FOR ALL USING (
    (auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true
);

-- 1D. shows
DROP POLICY IF EXISTS "Admin manage shows" ON shows;
CREATE POLICY "Admin manage shows" ON shows 
FOR ALL USING (
    (auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true
);

-- 1E. owner_applications
DROP POLICY IF EXISTS "Admins can view all applications" ON owner_applications;
CREATE POLICY "Admins can view all applications" ON owner_applications
    FOR SELECT USING (
        (auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true
    );

DROP POLICY IF EXISTS "Admins can update applications" ON owner_applications;
CREATE POLICY "Admins can update applications" ON owner_applications
    FOR UPDATE USING (
        (auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true
    );

-- 1F. events
DROP POLICY IF EXISTS "Admins can update events" ON events;
CREATE POLICY "Admins can update events" 
ON events FOR UPDATE 
TO authenticated
USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true)
WITH CHECK ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

DROP POLICY IF EXISTS "Admins can delete events" ON events;
CREATE POLICY "Admins can delete events" 
ON events FOR DELETE 
TO authenticated
USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

-- 1G. event_shows
DROP POLICY IF EXISTS "Admins can update event shows" ON event_shows;
CREATE POLICY "Admins can update event shows" 
ON event_shows FOR UPDATE 
TO authenticated
USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true)
WITH CHECK ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

DROP POLICY IF EXISTS "Admins can delete event shows" ON event_shows;
CREATE POLICY "Admins can delete event shows" 
ON event_shows FOR DELETE 
TO authenticated
USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

-- 1H. transaction_logs
DROP POLICY IF EXISTS "Admins full access trans_logs" ON transaction_logs;
CREATE POLICY "Admins full access trans_logs" ON transaction_logs 
    FOR ALL USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

-- 1I. bookings (already fixed in 025 but ensure consistency)
DROP POLICY IF EXISTS "Admins full access bookings" ON public.bookings;
CREATE POLICY "Admins full access bookings" ON public.bookings
    FOR ALL USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

-- 1J. seats
DROP POLICY IF EXISTS "Admins can manage seats" ON public.seats;
CREATE POLICY "Admins can manage seats" ON public.seats
    FOR ALL USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

-- 1K. movies
DROP POLICY IF EXISTS "Admins can manage movies" ON public.movies;
CREATE POLICY "Admins can manage movies" ON public.movies
    FOR ALL USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);


-- =============================================
-- PART 2: SECURITY DEFINER FUNCTIONS
-- =============================================

-- 2A. get_pending_applications
CREATE OR REPLACE FUNCTION get_pending_applications()
RETURNS TABLE(
    id UUID,
    user_id UUID,
    email TEXT,
    full_name TEXT,
    phone TEXT,
    theatre_name TEXT,
    theatre_location TEXT,
    business_license TEXT,
    message TEXT,
    status TEXT,
    created_at TIMESTAMP WITH TIME ZONE
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    IF NOT ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;
    
    RETURN QUERY
    SELECT 
        oa.id, oa.user_id, oa.email, oa.full_name, oa.phone,
        oa.theatre_name, oa.theatre_location, oa.business_license,
        oa.message, oa.status, oa.created_at
    FROM owner_applications oa
    WHERE oa.status = 'pending'
    ORDER BY oa.created_at DESC;
END;
$$;

-- 2B. approve_owner_application
CREATE OR REPLACE FUNCTION approve_owner_application(
    p_application_id UUID,
    p_admin_notes TEXT DEFAULT NULL
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_admin_id UUID := auth.uid();
    v_app RECORD;
    v_theatre_id UUID;
BEGIN
    IF NOT ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true) THEN
        RETURN json_build_object('success', false, 'error', 'Access denied: Admin only');
    END IF;
    
    SELECT * INTO v_app FROM owner_applications WHERE id = p_application_id;
    
    IF v_app IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Application not found');
    END IF;
    
    IF v_app.status != 'pending' THEN
        RETURN json_build_object('success', false, 'error', 'Application already processed');
    END IF;
    
    INSERT INTO theatres (name, location)
    VALUES (v_app.theatre_name, v_app.theatre_location)
    RETURNING id INTO v_theatre_id;
    
    INSERT INTO theater_owners (user_id, theatre_id, role)
    VALUES (v_app.user_id, v_theatre_id, 'owner');
    
    UPDATE owner_applications
    SET status = 'approved',
        reviewed_at = NOW(),
        reviewed_by = v_admin_id,
        admin_notes = p_admin_notes
    WHERE id = p_application_id;
    
    RETURN json_build_object(
        'success', true, 
        'message', 'Application approved',
        'theatre_id', v_theatre_id
    );
END;
$$;

-- 2C. reject_owner_application
CREATE OR REPLACE FUNCTION reject_owner_application(
    p_application_id UUID,
    p_admin_notes TEXT DEFAULT NULL
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_admin_id UUID := auth.uid();
BEGIN
    IF NOT ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true) THEN
        RETURN json_build_object('success', false, 'error', 'Access denied: Admin only');
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM owner_applications WHERE id = p_application_id AND status = 'pending') THEN
        RETURN json_build_object('success', false, 'error', 'Application not found or already processed');
    END IF;
    
    UPDATE owner_applications
    SET status = 'rejected',
        reviewed_at = NOW(),
        reviewed_by = v_admin_id,
        admin_notes = p_admin_notes
    WHERE id = p_application_id;
    
    RETURN json_build_object('success', true, 'message', 'Application rejected');
END;
$$;

-- 2D. update_screen_layout
CREATE OR REPLACE FUNCTION update_screen_layout(
    p_screen_id UUID,
    p_seat_layout JSONB
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_theatre_id UUID;
    v_is_owner BOOLEAN;
BEGIN
    IF p_seat_layout IS NULL 
       OR jsonb_typeof(p_seat_layout->'rows') IS DISTINCT FROM 'array' THEN
        RETURN json_build_object('success', false, 'error', 'Invalid seat layout');
    END IF;

    SELECT theatre_id INTO v_theatre_id
    FROM screens
    WHERE id = p_screen_id;

    IF v_theatre_id IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Screen not found');
    END IF;

    SELECT EXISTS(
        SELECT 1 FROM theater_owners
        WHERE user_id = v_user_id AND theatre_id = v_theatre_id
    ) INTO v_is_owner;

    IF NOT v_is_owner AND NOT (COALESCE((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean, false) = true) THEN
        RETURN json_build_object('success', false, 'error', 'Access denied');
    END IF;

    IF EXISTS (
        SELECT 1 FROM bookings b
        JOIN shows s ON b.show_id = s.id
        WHERE s.screen_id = p_screen_id AND b.status IN ('confirmed', 'locked')
        
        UNION ALL
        
        SELECT 1 FROM bookings b
        JOIN event_shows es ON b.event_show_id = es.id
        WHERE es.screen_id = p_screen_id AND b.status IN ('confirmed', 'locked')
    ) THEN
        RETURN json_build_object('success', false, 'error', 'Cannot update layout: Active bookings exist for this screen');
    END IF;

    UPDATE screens
    SET 
        seat_layout = p_seat_layout,
        total_seats = COALESCE((p_seat_layout->'metadata'->>'totalSeats')::integer, total_seats)
    WHERE id = p_screen_id;

    DELETE FROM seats WHERE screen_id = p_screen_id;

    INSERT INTO seats (screen_id, row, col, tier, price)
    SELECT 
        p_screen_id,
        r->>'label',
        (s->>'id')::integer,
        s->>'type',
        (s->>'price')::integer
    FROM jsonb_array_elements(p_seat_layout->'rows') AS r
    CROSS JOIN jsonb_array_elements(r->'seats') AS s
    WHERE s IS NOT NULL AND s != 'null'::jsonb;

    RETURN json_build_object('success', true, 'message', 'Layout updated and seats synced');
END;
$$;

-- 2E. get_admin_dashboard_stats
CREATE OR REPLACE FUNCTION get_admin_dashboard_stats()
RETURNS TABLE(
    total_revenue NUMERIC,
    total_bookings BIGINT,
    total_theatres BIGINT,
    total_owners BIGINT,
    today_revenue NUMERIC,
    today_bookings BIGINT,
    active_locks BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    IF NOT ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;

    RETURN QUERY
    WITH movie_stats AS (
        SELECT
            SUM(COALESCE(seats.price, sh.price, 0)) FILTER (WHERE b.status = 'confirmed') AS total_revenue,
            COUNT(*) FILTER (WHERE b.status = 'confirmed') AS total_bookings,
            SUM(COALESCE(seats.price, sh.price, 0)) FILTER (WHERE b.status = 'confirmed' AND b.created_at >= CURRENT_DATE AND b.created_at < (CURRENT_DATE + interval '1 day')) AS today_revenue,
            COUNT(*) FILTER (WHERE b.status = 'confirmed' AND b.created_at >= CURRENT_DATE AND b.created_at < (CURRENT_DATE + interval '1 day')) AS today_bookings,
            COUNT(*) FILTER (WHERE b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '10 minutes') AS active_locks
        FROM bookings b
        JOIN shows sh ON sh.id = b.show_id
        LEFT JOIN seats ON seats.id = b.seat_id
    ),
    event_stats AS (
        SELECT
            SUM(COALESCE(seats.price, es.price, 0)) FILTER (WHERE b.status = 'confirmed') AS total_revenue,
            COUNT(*) FILTER (WHERE b.status = 'confirmed') AS total_bookings,
            SUM(COALESCE(seats.price, es.price, 0)) FILTER (WHERE b.status = 'confirmed' AND b.created_at >= CURRENT_DATE AND b.created_at < (CURRENT_DATE + interval '1 day')) AS today_revenue,
            COUNT(*) FILTER (WHERE b.status = 'confirmed' AND b.created_at >= CURRENT_DATE AND b.created_at < (CURRENT_DATE + interval '1 day')) AS today_bookings,
            COUNT(*) FILTER (WHERE b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '10 minutes') AS active_locks
        FROM bookings b
        JOIN event_shows es ON es.id = b.event_show_id
        LEFT JOIN seats ON seats.id = b.seat_id
    )
    SELECT
        (COALESCE((SELECT total_revenue FROM movie_stats), 0) + COALESCE((SELECT total_revenue FROM event_stats), 0))::NUMERIC,
        (COALESCE((SELECT total_bookings FROM movie_stats), 0) + COALESCE((SELECT total_bookings FROM event_stats), 0))::BIGINT,
        (SELECT COUNT(*) FROM theatres)::BIGINT,
        (SELECT COUNT(DISTINCT user_id) FROM theater_owners)::BIGINT,
        (COALESCE((SELECT today_revenue FROM movie_stats), 0) + COALESCE((SELECT today_revenue FROM event_stats), 0))::NUMERIC,
        (COALESCE((SELECT today_bookings FROM movie_stats), 0) + COALESCE((SELECT today_bookings FROM event_stats), 0))::BIGINT,
        (COALESCE((SELECT active_locks FROM movie_stats), 0) + COALESCE((SELECT active_locks FROM event_stats), 0))::BIGINT;
END;
$$;

-- 2F. get_admin_owner_revenue_breakdown
CREATE OR REPLACE FUNCTION get_admin_owner_revenue_breakdown(p_start_date DATE DEFAULT NULL, p_end_date DATE DEFAULT NULL)
RETURNS TABLE(
    owner_id UUID,
    owner_email TEXT,
    owner_name TEXT,
    theatre_names TEXT,
    revenue NUMERIC,
    booking_count BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    IF NOT ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;

    RETURN QUERY
    WITH owner_theatres AS (
        SELECT 
            to_owner.user_id,
            t.id as theatre_id,
            t.name as theatre_name,
            oa.email as user_email,
            oa.full_name as user_name
        FROM theater_owners to_owner
        JOIN theatres t ON t.id = to_owner.theatre_id
        LEFT JOIN owner_applications oa ON oa.user_id = to_owner.user_id AND oa.status = 'approved'
    ),
    movie_bookings AS (
        SELECT 
            s.theatre_id,
            COUNT(b.id) as booking_count,
            SUM(COALESCE(seats.price, sh.price, 0)) as revenue
        FROM bookings b
        JOIN shows sh ON sh.id = b.show_id
        JOIN screens s ON s.id = sh.screen_id
        LEFT JOIN seats ON seats.id = b.seat_id
        WHERE b.status = 'confirmed' 
            AND (p_start_date IS NULL OR b.created_at >= p_start_date)
            AND (p_end_date IS NULL OR b.created_at < (p_end_date + INTERVAL '1 day'))
        GROUP BY s.theatre_id
    ),
    event_bookings AS (
        SELECT 
            s.theatre_id,
            COUNT(b.id) as booking_count,
            SUM(COALESCE(seats.price, es.price, 0)) as revenue
        FROM bookings b
        JOIN event_shows es ON es.id = b.event_show_id
        JOIN screens s ON s.id = es.screen_id
        LEFT JOIN seats ON seats.id = b.seat_id
        WHERE b.status = 'confirmed' 
            AND (p_start_date IS NULL OR b.created_at >= p_start_date)
            AND (p_end_date IS NULL OR b.created_at < (p_end_date + INTERVAL '1 day'))
        GROUP BY s.theatre_id
    )
    SELECT 
        ot.user_id as owner_id,
        MAX(ot.user_email) as owner_email,
        MAX(ot.user_name) as owner_name,
        STRING_AGG(DISTINCT ot.theatre_name, ', ') as theatre_names,
        COALESCE(SUM(mb.revenue), 0) + COALESCE(SUM(eb.revenue), 0) as revenue,
        COALESCE(SUM(mb.booking_count), 0) + COALESCE(SUM(eb.booking_count), 0) as booking_count
    FROM owner_theatres ot
    LEFT JOIN movie_bookings mb ON mb.theatre_id = ot.theatre_id
    LEFT JOIN event_bookings eb ON eb.theatre_id = ot.theatre_id
    GROUP BY ot.user_id
    ORDER BY revenue DESC;
END;
$$;

-- 2G. get_user_role (also reads from raw_user_meta_data — switch to raw_app_meta_data)
CREATE OR REPLACE FUNCTION get_user_role(p_user_id UUID)
RETURNS TABLE(
    is_admin BOOLEAN,
    is_theater_owner BOOLEAN,
    owned_theatre_count BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        COALESCE((au.raw_app_meta_data ->> 'is_admin')::boolean, false) AS is_admin,
        EXISTS (SELECT 1 FROM theater_owners WHERE user_id = p_user_id) AS is_theater_owner,
        (SELECT COUNT(*) FROM theater_owners WHERE user_id = p_user_id) AS owned_theatre_count
    FROM auth.users au
    WHERE au.id = p_user_id;
END;
$$;

-- 2H. user_roles view
CREATE OR REPLACE VIEW user_roles AS
SELECT 
    au.id AS user_id,
    au.email,
    COALESCE((au.raw_app_meta_data ->> 'is_admin')::boolean, false) AS is_admin,
    EXISTS (SELECT 1 FROM theater_owners WHERE user_id = au.id) AS is_theater_owner,
    (SELECT ARRAY_AGG(theatre_id) FROM theater_owners WHERE user_id = au.id) AS owned_theatre_ids
FROM auth.users au;


-- =============================================
-- PART 3: IMPORTANT — MIGRATE EXISTING ADMIN FLAG
-- =============================================
-- If you have existing admins with is_admin in user_metadata,
-- you MUST copy the flag to app_metadata via the Supabase Dashboard
-- or by running this with the service_role key:
--
-- UPDATE auth.users 
-- SET raw_app_meta_data = raw_app_meta_data || '{"is_admin": true}'::jsonb
-- WHERE raw_user_meta_data ->> 'is_admin' = 'true';
--
-- After verifying admins still work, clean up user_metadata:
-- UPDATE auth.users 
-- SET raw_user_meta_data = raw_user_meta_data - 'is_admin'
-- WHERE raw_user_meta_data ? 'is_admin';


-- ==========================================
-- Migration: 027_allow_test_confirmations.sql
-- ==========================================


-- ============================================
-- Quick My Ticket - Allow Test Confirmations
-- Migration 027
-- ============================================

-- Grant UPDATE permission to allow frontend testing of the booking flow
GRANT UPDATE ON public.bookings TO anon;
GRANT UPDATE ON public.bookings TO authenticated;

-- Add a policy that allows ANYONE to confirm a booking IF:
-- 1. The booking is currently 'locked'
-- 2. they are setting the status to 'confirmed'
-- 3. The payment_id starts with 'TEST_'
-- This allows developers to test the full flow without a backend/edge function.

DROP POLICY IF EXISTS "Allow test confirmations" ON public.bookings;
CREATE POLICY "Allow test confirmations" ON public.bookings
    FOR UPDATE
    USING (status = 'locked')
    WITH CHECK (
        status = 'confirmed' AND 
        payment_id LIKE 'TEST_%' AND
        confirmed_at IS NOT NULL
    );


-- ==========================================
-- Migration: 028_order_idempotency.sql
-- ==========================================

-- Migration 028: Add razorpay_order_id for order creation idempotency
-- =====================================================================
-- When create-order is called, the Razorpay order ID is stored on
-- the booking rows. On retry, the Edge Function checks for an existing
-- order before creating a new one, preventing duplicate charges.

ALTER TABLE bookings
    ADD COLUMN IF NOT EXISTS razorpay_order_id text;

-- Index for fast lookup during idempotency check
CREATE INDEX IF NOT EXISTS idx_bookings_razorpay_order_id
    ON bookings (razorpay_order_id)
    WHERE razorpay_order_id IS NOT NULL;

COMMENT ON COLUMN bookings.razorpay_order_id IS 'Razorpay order ID stored at order creation for idempotency on retry';


-- ==========================================
-- Migration: 029_remove_test_backdoor.sql
-- ==========================================

-- Migration 029: Remove test confirmation backdoor
-- =====================================================================
-- MUST run before going live. This reverses the permissions granted in
-- migration 027 that allowed unauthenticated test confirmations.

REVOKE UPDATE ON public.bookings FROM anon;
REVOKE UPDATE ON public.bookings FROM authenticated;

DROP POLICY IF EXISTS "Allow test confirmations" ON public.bookings;


-- ==========================================
-- Migration: 030_fix_admin_revenue_breakdown_type.sql
-- ==========================================

-- Migration 030: Fix get_admin_owner_revenue_breakdown return type
-- =================================================================
-- The SUM() aggregate over a bigint column (COUNT) returns numeric,
-- which conflicted with the function signature expecting a bigint.
-- We cast the final sum back to bigint.

CREATE OR REPLACE FUNCTION get_admin_owner_revenue_breakdown(p_start_date DATE DEFAULT NULL, p_end_date DATE DEFAULT NULL)
RETURNS TABLE(
    owner_id UUID,
    owner_email TEXT,
    owner_name TEXT,
    theatre_names TEXT,
    revenue NUMERIC,
    booking_count BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    IF NOT ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;

    RETURN QUERY
    WITH owner_theatres AS (
        SELECT 
            to_owner.user_id,
            t.id as theatre_id,
            t.name as theatre_name,
            oa.email as user_email,
            oa.full_name as user_name
        FROM theater_owners to_owner
        JOIN theatres t ON t.id = to_owner.theatre_id
        LEFT JOIN owner_applications oa ON oa.user_id = to_owner.user_id AND oa.status = 'approved'
    ),
    movie_bookings AS (
        SELECT 
            s.theatre_id,
            COUNT(b.id) as booking_count,
            SUM(COALESCE(seats.price, sh.price, 0)) as revenue
        FROM bookings b
        JOIN shows sh ON sh.id = b.show_id
        JOIN screens s ON s.id = sh.screen_id
        LEFT JOIN seats ON seats.id = b.seat_id
        WHERE b.status = 'confirmed' 
            AND (p_start_date IS NULL OR b.created_at >= p_start_date)
            AND (p_end_date IS NULL OR b.created_at < (p_end_date + INTERVAL '1 day'))
        GROUP BY s.theatre_id
    ),
    event_bookings AS (
        SELECT 
            s.theatre_id,
            COUNT(b.id) as booking_count,
            SUM(COALESCE(seats.price, es.price, 0)) as revenue
        FROM bookings b
        JOIN event_shows es ON es.id = b.event_show_id
        JOIN screens s ON s.id = es.screen_id
        LEFT JOIN seats ON seats.id = b.seat_id
        WHERE b.status = 'confirmed' 
            AND (p_start_date IS NULL OR b.created_at >= p_start_date)
            AND (p_end_date IS NULL OR b.created_at < (p_end_date + INTERVAL '1 day'))
        GROUP BY s.theatre_id
    )
    SELECT 
        ot.user_id as owner_id,
        MAX(ot.user_email) as owner_email,
        MAX(ot.user_name) as owner_name,
        STRING_AGG(DISTINCT ot.theatre_name, ', ') as theatre_names,
        COALESCE(SUM(mb.revenue), 0) + COALESCE(SUM(eb.revenue), 0) as revenue,
        (COALESCE(SUM(mb.booking_count), 0) + COALESCE(SUM(eb.booking_count), 0))::BIGINT as booking_count
    FROM owner_theatres ot
    LEFT JOIN movie_bookings mb ON mb.theatre_id = ot.theatre_id
    LEFT JOIN event_bookings eb ON eb.theatre_id = ot.theatre_id
    GROUP BY ot.user_id
    ORDER BY revenue DESC;
END;
$$;

GRANT EXECUTE ON FUNCTION get_admin_owner_revenue_breakdown(DATE, DATE) TO authenticated;


-- ==========================================
-- Migration: 031_setup_locks_cron.sql
-- ==========================================

-- ============================================
-- Quick My Ticket — Automatic Expired Lock Cleanup
-- ============================================
-- Sets up a pg_cron job that runs every minute to release seats
-- that have been in "locked" status for more than 5 minutes
-- without a completed payment.
--
-- Prerequisites:
--   The pg_cron extension must be enabled in your Supabase project.
--   (Dashboard → Database → Extensions → pg_cron → Enable)
-- ============================================

-- 1. pg_cron must be enabled in Supabase Dashboard -> Database -> Extensions
-- We skip auto-creation here because Supabase manages extensions centrally.

-- 2. Create the cleanup function (SECURITY DEFINER so it can write to bookings)
CREATE OR REPLACE FUNCTION release_expired_locks()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_count INTEGER;
BEGIN
    UPDATE bookings
    SET status   = 'expired',
        locked_at = NULL
    WHERE status = 'locked'
      AND locked_at < NOW() - INTERVAL '5 minutes';

    GET DIAGNOSTICS v_count = ROW_COUNT;

    IF v_count > 0 THEN
        RAISE LOG '[QMT] Released % expired seat lock(s)', v_count;
    END IF;
END;
$$;

-- 3. Schedule the job to run every minute
--    cron.schedule returns the job id; we use an idempotent wrapper
--    so re-running this migration is safe.
DO $$
BEGIN
    -- Remove any previous version of this job first
    PERFORM cron.unschedule(jobid)
    FROM cron.job
    WHERE jobname = 'release-expired-locks';

    -- Schedule the new job
    PERFORM cron.schedule(
        'release-expired-locks',    -- job name (idempotent key)
        '* * * * *',                -- every minute
        'SELECT release_expired_locks();'
    );

    RAISE LOG '[QMT] pg_cron job "release-expired-locks" scheduled (every minute)';
EXCEPTION WHEN OTHERS THEN
    RAISE LOG '[QMT] pg_cron not available - skipping cron job setup. Enable pg_cron in Supabase Dashboard -> Database -> Extensions.';
END;
$$;


-- ==========================================
-- Migration: 032_rate_limit_lock_seat.sql
-- ==========================================

-- ============================================
-- Quick My Ticket — Rate Limit Seat Locking
-- ============================================
-- Prevents a single user/session from holding more than 10
-- active (locked) seats per show. This stops abuse where
-- someone rapidly locks and abandons seats via the API.
-- ============================================

-- 1. Update lock_seat to enforce per-show rate limit
CREATE OR REPLACE FUNCTION lock_seat(
    p_show_id UUID, 
    p_seat_id UUID, 
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    booking_id UUID, 
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking_id UUID;
    v_existing RECORD;
    v_screen_id UUID;
    v_seat_exists BOOLEAN;
    v_reusable_booking UUID;
    v_lock_timeout_minutes INTEGER := 5;
    v_active_locks INTEGER;
    v_max_locks INTEGER := 10;
BEGIN
    -- Validate that the show exists and get screen_id
    SELECT screen_id INTO v_screen_id 
    FROM shows 
    WHERE id = p_show_id;
    
    IF v_screen_id IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Show not found'::TEXT;
        RETURN;
    END IF;
    
    -- Validate that the seat exists and belongs to the show's screen
    SELECT EXISTS(
        SELECT 1 FROM seats 
        WHERE id = p_seat_id AND screen_id = v_screen_id
    ) INTO v_seat_exists;
    
    IF NOT v_seat_exists THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat not found for this show'::TEXT;
        RETURN;
    END IF;

    -- *** RATE LIMIT CHECK ***
    -- Count how many seats this user/session currently has locked for THIS show
    SELECT COUNT(*) INTO v_active_locks
    FROM bookings
    WHERE show_id = p_show_id
      AND status = 'locked'
      AND locked_at >= NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL
      AND (
          (p_user_id IS NOT NULL AND user_id = p_user_id)
          OR
          (p_session_id IS NOT NULL AND session_id = p_session_id)
      );

    IF v_active_locks >= v_max_locks THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 
            ('You cannot lock more than ' || v_max_locks || ' seats per show')::TEXT;
        RETURN;
    END IF;
    
    -- Auto-expire stale locks on this specific seat
    UPDATE bookings 
    SET status = 'expired', locked_at = NULL
    WHERE show_id = p_show_id 
      AND seat_id = p_seat_id 
      AND status = 'locked'
      AND locked_at < NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL;
    
    -- Try to acquire a lock on existing active booking
    BEGIN
        SELECT * INTO v_existing
        FROM bookings 
        WHERE show_id = p_show_id 
          AND seat_id = p_seat_id 
          AND status IN ('locked', 'confirmed')
        FOR UPDATE NOWAIT;
    EXCEPTION
        WHEN lock_not_available THEN
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is currently being processed by another user, please try again'::TEXT;
            RETURN;
    END;
    
    -- Check if seat is already taken
    IF FOUND THEN
        IF (v_existing.user_id IS NOT NULL AND v_existing.user_id = p_user_id AND v_existing.status = 'locked') OR 
           (v_existing.session_id IS NOT NULL AND v_existing.session_id = p_session_id AND v_existing.status = 'locked') THEN
            -- Refresh the lock timestamp
            UPDATE bookings 
            SET locked_at = NOW() 
            WHERE id = v_existing.id;
            
            RETURN QUERY SELECT v_existing.id, TRUE, 'Lock refreshed'::TEXT;
            RETURN;
        ELSE
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is already locked or booked'::TEXT;
            RETURN;
        END IF;
    END IF;
    
    -- Look for a reusable cancelled/expired booking for this seat
    SELECT id INTO v_reusable_booking
    FROM bookings
    WHERE show_id = p_show_id
      AND seat_id = p_seat_id
      AND status IN ('cancelled', 'expired')
    ORDER BY created_at DESC
    LIMIT 1
    FOR UPDATE;
    
    IF v_reusable_booking IS NOT NULL THEN
        UPDATE bookings 
        SET status = 'locked',
            user_id = p_user_id,
            session_id = p_session_id,
            locked_at = NOW(),
            payment_id = NULL,
            confirmed_at = NULL
        WHERE id = v_reusable_booking
        RETURNING id INTO v_booking_id;
        
        RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
        RETURN;
    END IF;
    
    -- Insert new booking with lock
    INSERT INTO bookings (show_id, seat_id, user_id, session_id, status, locked_at)
    VALUES (p_show_id, p_seat_id, p_user_id, p_session_id, 'locked', NOW())
    RETURNING id INTO v_booking_id;
    
    RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
    
EXCEPTION
    WHEN unique_violation THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat was just locked by another user'::TEXT;
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, ('Error: ' || SQLERRM)::TEXT;
END;
$$;

GRANT EXECUTE ON FUNCTION lock_seat(UUID, UUID, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION lock_seat(UUID, UUID, UUID, TEXT) TO anon;


-- 2. Update lock_event_seat with the same rate limit
CREATE OR REPLACE FUNCTION lock_event_seat(
    p_event_show_id UUID, 
    p_seat_id UUID, 
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    booking_id UUID, 
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking_id UUID;
    v_existing RECORD;
    v_screen_id UUID;
    v_seat_exists BOOLEAN;
    v_reusable_booking UUID;
    v_lock_timeout_minutes INTEGER := 5;
    v_active_locks INTEGER;
    v_max_locks INTEGER := 10;
BEGIN
    SELECT screen_id INTO v_screen_id 
    FROM event_shows 
    WHERE id = p_event_show_id;
    
    IF v_screen_id IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Event show not found'::TEXT;
        RETURN;
    END IF;
    
    SELECT EXISTS(
        SELECT 1 FROM seats 
        WHERE id = p_seat_id AND screen_id = v_screen_id
    ) INTO v_seat_exists;
    
    IF NOT v_seat_exists THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat not found for this event'::TEXT;
        RETURN;
    END IF;

    -- *** RATE LIMIT CHECK ***
    SELECT COUNT(*) INTO v_active_locks
    FROM bookings
    WHERE event_show_id = p_event_show_id
      AND status = 'locked'
      AND locked_at >= NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL
      AND (
          (p_user_id IS NOT NULL AND user_id = p_user_id)
          OR
          (p_session_id IS NOT NULL AND session_id = p_session_id)
      );

    IF v_active_locks >= v_max_locks THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 
            ('You cannot lock more than ' || v_max_locks || ' seats per show')::TEXT;
        RETURN;
    END IF;

    UPDATE bookings 
    SET status = 'expired', locked_at = NULL
    WHERE event_show_id = p_event_show_id 
      AND seat_id = p_seat_id 
      AND status = 'locked'
      AND locked_at < NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL;
    
    BEGIN
        SELECT * INTO v_existing
        FROM bookings 
        WHERE event_show_id = p_event_show_id 
          AND seat_id = p_seat_id 
          AND status IN ('locked', 'confirmed')
        FOR UPDATE NOWAIT;
    EXCEPTION
        WHEN lock_not_available THEN
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is being processed by another user'::TEXT;
            RETURN;
    END;
    
    IF FOUND THEN
        IF (v_existing.user_id IS NOT NULL AND v_existing.user_id = p_user_id AND v_existing.status = 'locked') OR 
           (v_existing.session_id IS NOT NULL AND v_existing.session_id = p_session_id AND v_existing.status = 'locked') THEN
            UPDATE bookings 
            SET locked_at = NOW() 
            WHERE id = v_existing.id;
            
            RETURN QUERY SELECT v_existing.id, TRUE, 'Lock refreshed'::TEXT;
            RETURN;
        ELSE
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is already locked or booked'::TEXT;
            RETURN;
        END IF;
    END IF;

    SELECT id INTO v_reusable_booking
    FROM bookings
    WHERE event_show_id = p_event_show_id
      AND seat_id = p_seat_id
      AND status IN ('cancelled', 'expired')
    ORDER BY created_at DESC
    LIMIT 1
    FOR UPDATE;
    
    IF v_reusable_booking IS NOT NULL THEN
        UPDATE bookings 
        SET status = 'locked',
            user_id = p_user_id,
            session_id = p_session_id,
            locked_at = NOW(),
            payment_id = NULL,
            confirmed_at = NULL
        WHERE id = v_reusable_booking
        RETURNING id INTO v_booking_id;
        
        RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
        RETURN;
    END IF;
    
    INSERT INTO bookings (event_show_id, seat_id, user_id, session_id, status, locked_at)
    VALUES (p_event_show_id, p_seat_id, p_user_id, p_session_id, 'locked', NOW())
    RETURNING id INTO v_booking_id;
    
    RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
    
EXCEPTION
    WHEN unique_violation THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat was just locked by another user'::TEXT;
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, ('Error: ' || SQLERRM)::TEXT;
END;
$$;

GRANT EXECUTE ON FUNCTION lock_event_seat(UUID, UUID, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION lock_event_seat(UUID, UUID, UUID, TEXT) TO anon;


-- ==========================================
-- Migration: 033_fix_release_expired_locks_ambiguity.sql
-- ==========================================

-- ============================================
-- Fix Ambiguous release_expired_locks Function
-- ============================================
-- The previous migration (031) created a version of release_expired_locks()
-- with no arguments. This conflicts with the original version created in
-- migration 001 which had an optional parameter `p_lock_timeout_minutes INTEGER DEFAULT 5`.
-- Since both can be called with zero arguments, Postgres throws an ambiguity error.
-- We drop the void version and update the pg_cron job to explicitly cast/call
-- the correct version.

-- 1. Drop the conflicting void function (without dropping the one with arguments)
DROP FUNCTION IF EXISTS release_expired_locks();

-- 2. Redefine the parameterized function to ensure it clears locked_at = NULL
CREATE OR REPLACE FUNCTION release_expired_locks(
    p_lock_timeout_minutes INTEGER DEFAULT 5
)
RETURNS TABLE(
    released_count INTEGER,
    released_ids UUID[]
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_released_ids UUID[];
    v_count INTEGER;
BEGIN
    WITH expired AS (
        UPDATE bookings 
        SET status = 'expired', 
            locked_at = NULL
        WHERE status = 'locked' 
          AND locked_at < NOW() - (p_lock_timeout_minutes || ' minutes')::INTERVAL
        RETURNING id
    )
    SELECT array_agg(id), COUNT(*)::INTEGER 
    INTO v_released_ids, v_count
    FROM expired;
    
    RETURN QUERY SELECT COALESCE(v_count, 0), COALESCE(v_released_ids, ARRAY[]::UUID[]);
END;
$$;

-- Only allow service role to execute (for cron/edge function)
REVOKE ALL ON FUNCTION release_expired_locks(INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION release_expired_locks(INTEGER) TO service_role;

-- 3. Ensure the cron job is using the proper parameterized one
DO $$
BEGIN
    -- Remove the old job
    PERFORM cron.unschedule('release-expired-locks');

    -- Re-schedule explicitly passing the default 5 to avoid any potential ambiguity
    PERFORM cron.schedule(
        'release-expired-locks',
        '* * * * *',
        'SELECT release_expired_locks(5);'
    );

    RAISE LOG '[QMT] pg_cron job "release-expired-locks" fixed and rescheduled';
EXCEPTION WHEN OTHERS THEN
    RAISE LOG '[QMT] pg_cron not available - skipping cron job update. Enable pg_cron in Supabase Dashboard -> Database -> Extensions.';
END;
$$;


-- ==========================================
-- Migration: 034_theater_branding.sql
-- ==========================================

-- Theater branding & white-label configuration
CREATE TABLE IF NOT EXISTS theater_branding (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  theater_id          UUID UNIQUE NOT NULL REFERENCES theatres(id) ON DELETE CASCADE,
  
  -- Identity
  display_name        TEXT NOT NULL,
  tagline             TEXT,
  logo_url            TEXT,
  favicon_url         TEXT,
  
  -- Colors (hex values)
  primary_color       TEXT NOT NULL DEFAULT '#e50914',
  accent_color        TEXT NOT NULL DEFAULT '#ffffff',
  background_color    TEXT NOT NULL DEFAULT '#141414',
  card_color          TEXT NOT NULL DEFAULT '#1a1a1a',
  text_color          TEXT NOT NULL DEFAULT '#ffffff',
  
  -- Domain
  subdomain           TEXT UNIQUE,            -- 'angelcineworld' → angelcineworld.quickmytickets.com
  custom_domain       TEXT UNIQUE,            -- 'tickets.angelcineworld.com'
  
  -- Contact
  whatsapp_number     TEXT,
  support_email       TEXT,
  
  -- Social
  instagram_url       TEXT,
  facebook_url        TEXT,
  
  -- Config
  active              BOOLEAN DEFAULT true,
  show_powered_by     BOOLEAN DEFAULT true,   -- 'Powered by Quick My Ticket' footer badge
  
  created_at          TIMESTAMPTZ DEFAULT NOW(),
  updated_at          TIMESTAMPTZ DEFAULT NOW()
);

-- RLS: Only the theater owner and admins can read/write their branding
ALTER TABLE theater_branding ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Theater owner can manage own branding"
ON theater_branding
FOR ALL
USING (
  theater_id IN (
    SELECT t.id FROM theatres t
    JOIN theater_owners to2 ON t.id = to2.theatre_id
    WHERE to2.user_id = auth.uid()
  )
)
WITH CHECK (
  theater_id IN (
    SELECT t.id FROM theatres t
    JOIN theater_owners to2 ON t.id = to2.theatre_id
    WHERE to2.user_id = auth.uid()
  )
);

CREATE POLICY "Admins can manage all branding"
ON theater_branding
FOR ALL
USING (
  (auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true
);

CREATE POLICY "Public can read active branding"
ON theater_branding
FOR SELECT
USING (active = true);

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_theater_branding_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER theater_branding_updated_at
  BEFORE UPDATE ON theater_branding
  FOR EACH ROW EXECUTE FUNCTION update_theater_branding_timestamp();

-- Index for fast domain lookups
CREATE INDEX idx_theater_branding_subdomain ON theater_branding(subdomain);
CREATE INDEX idx_theater_branding_custom_domain ON theater_branding(custom_domain);
CREATE INDEX idx_theater_branding_theater_id ON theater_branding(theater_id);


-- ==========================================
-- Migration: 035_branding_storage.sql
-- ==========================================

-- Create storage bucket for theater branding assets
INSERT INTO storage.buckets (id, name, public)
VALUES ('branding', 'branding', true)
ON CONFLICT (id) DO NOTHING;

-- Public read access on branding bucket
CREATE POLICY "Public read branding assets"
ON storage.objects FOR SELECT
USING (bucket_id = 'branding');

-- Theater owners can upload to their own folder
CREATE POLICY "Theater owners can upload branding"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'branding'
  AND (storage.foldername(name))[2] IN (
    SELECT t.id::text FROM theatres t
    JOIN theater_owners to2 ON t.id = to2.theatre_id
    WHERE to2.user_id = auth.uid()
  )
);

CREATE POLICY "Theater owners can update branding"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'branding'
  AND (storage.foldername(name))[2] IN (
    SELECT t.id::text FROM theatres t
    JOIN theater_owners to2 ON t.id = to2.theatre_id
    WHERE to2.user_id = auth.uid()
  )
);


