/**
 * Quick My Ticket - Razorpay Webhook Edge Function
 * ==================================================
 * 
 * Handles Razorpay webhook events for payment confirmation backup.
 * This ensures bookings are confirmed even if the client closes the browser.
 * 
 * SECURITY:
 * ---------
 * - This is a server-to-server endpoint (Razorpay → Supabase).
 * - NO CORS headers — browsers must never call this.
 * - Signature verification is MANDATORY; if the secret is missing the
 *   function returns 500 immediately (fail-closed).
 * 
 * SETUP:
 * ------
 * 1. Deploy: supabase functions deploy razorpay-webhook
 * 2. Set secret: supabase secrets set RAZORPAY_WEBHOOK_SECRET=xxx
 *    - URL: https://<YOUR_PROJECT_ID>.supabase.co/functions/v1/razorpay-webhook
 *    - Events: payment.captured, payment.failed
 *    - Copy the webhook secret to Supabase
 */

import { serve } from 'https://deno.land/std@0.220.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.0';
import { createHmac } from 'node:crypto';

serve(async (req) => {
    // No CORS preflight — this is a server-to-server webhook endpoint.
    // Reject anything that isn't a POST.
    if (req.method !== 'POST') {
        return new Response(
            JSON.stringify({ error: 'Method not allowed' }),
            { status: 405, headers: { 'Content-Type': 'application/json' } }
        );
    }

    try {
        const body = await req.text();
        const signature = req.headers.get('x-razorpay-signature');
        const webhookSecret = Deno.env.get('RAZORPAY_WEBHOOK_SECRET');

        // SECURITY: fail-closed — if the secret is not configured, refuse all requests.
        if (!webhookSecret) {
            console.error('RAZORPAY_WEBHOOK_SECRET is not set — refusing request');
            return new Response(
                JSON.stringify({ error: 'Webhook secret not configured' }),
                { status: 500, headers: { 'Content-Type': 'application/json' } }
            );
        }

        // SECURITY: reject requests without a signature header.
        if (!signature) {
            console.error('Missing x-razorpay-signature header');
            return new Response(
                JSON.stringify({ error: 'Missing signature' }),
                { status: 401, headers: { 'Content-Type': 'application/json' } }
            );
        }

        // Verify webhook signature
        const expectedSignature = createHmac('sha256', webhookSecret)
            .update(body)
            .digest('hex');

        if (expectedSignature !== signature) {
            console.error('Invalid webhook signature');
            return new Response(
                JSON.stringify({ error: 'Invalid signature' }),
                { status: 401, headers: { 'Content-Type': 'application/json' } }
            );
        }

        const event = JSON.parse(body);
        console.log('Webhook event:', event.event);

        // Create Supabase client with service role
        const supabase = createClient(
            Deno.env.get('SUPABASE_URL')!,
            Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
        );

        // Handle different event types
        switch (event.event) {
            case 'payment.captured': {
                const payment = event.payload.payment.entity;
                const orderId = payment.order_id;
                const paymentId = payment.id;

                console.log(`Payment captured: ${paymentId} for order ${orderId}`);

                // Bug 2 fix: Look up bookings by razorpay_order_id from DB
                // instead of parsing notes (which silently truncate at 256 chars).
                const { data: orderBookings } = await supabase
                    .from('bookings')
                    .select('id, status')
                    .eq('razorpay_order_id', orderId);

                const bookingIds = (orderBookings || []).map((b: any) => b.id);
                console.log(`Booking IDs (from DB): ${bookingIds.join(', ')}`);

                if (bookingIds.length === 0) {
                    console.log(`No bookings found for order ${orderId}`);
                    break;
                }

                // Bug 5 fix: Idempotency guard — if all bookings are already
                // confirmed, return 200 so Razorpay stops retrying.
                const alreadyDone = (orderBookings || []).every((b: any) => b.status === 'confirmed');
                if (alreadyDone) {
                    console.log(`Webhook duplicate: ${paymentId} already processed — skipping`);
                    break;
                }

                // Confirm bookings using the hardened function
                const { error } = await supabase.rpc('confirm_bookings', {
                    p_booking_ids: bookingIds,
                    p_payment_id: paymentId,
                    p_user_id: payment.notes?.user_id || null
                });

                if (error) {
                    console.error('Error confirming bookings via webhook:', error);
                } else {
                    console.log(`Successfully confirmed ${bookingIds.length} bookings via webhook`);
                }
                break;
            }

            case 'payment.failed': {
                const payment = event.payload.payment.entity;
                const failedOrderId = payment.order_id;

                console.log(`Payment failed: ${payment.id} for order ${failedOrderId}`);

                // Bug 2 fix: Look up bookings by razorpay_order_id from DB
                const { data: failedBookings } = await supabase
                    .from('bookings')
                    .select('id')
                    .eq('razorpay_order_id', failedOrderId);

                const failedBookingIds = (failedBookings || []).map((b: any) => b.id);

                if (failedBookingIds.length > 0) {
                    // Update locked seats to 'cancelled' status (instead of deleting)
                    const { error } = await supabase
                        .from('bookings')
                        .update({ status: 'cancelled', locked_at: null })
                        .in('id', failedBookingIds)
                        .eq('status', 'locked');

                    if (error) {
                        console.error('Error releasing seats:', error);
                    } else {
                        console.log(`Marked ${failedBookingIds.length} seats as cancelled after failed payment`);
                    }
                }
                break;
            }

            case 'order.paid': {
                console.log('Order paid event received');
                break;
            }

            default:
                console.log(`Unhandled event type: ${event.event}`);
        }

        return new Response(
            JSON.stringify({ received: true }),
            { status: 200, headers: { 'Content-Type': 'application/json' } }
        );

    } catch (error) {
        console.error('Webhook error:', error);
        return new Response(
            JSON.stringify({ error: error.message }),
            { status: 500, headers: { 'Content-Type': 'application/json' } }
        );
    }
});
