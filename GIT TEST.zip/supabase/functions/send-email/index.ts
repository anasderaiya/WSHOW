import { serve } from 'https://deno.land/std@0.220.0/http/server.ts';
import nodemailer from 'npm:nodemailer@6.9.7';

const corsHeaders = {
    'Access-Control-Allow-Origin': 'https://quickmytickets.com',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
    // Handle CORS preflight
    if (req.method === 'OPTIONS') {
        return new Response('ok', { headers: corsHeaders });
    }

    // AUTH GUARD: This function is internal-only (invoked by verify-payment).
    // Reject requests that don't carry the service role key.
    const authHeader = req.headers.get('Authorization');
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    if (!serviceRoleKey || authHeader !== `Bearer ${serviceRoleKey}`) {
        return new Response(
            JSON.stringify({ error: 'Unauthorized — internal function only' }),
            { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
    }

    try {
        const { to, subject, html } = await req.json();

        if (!to || !subject || !html) {
            return new Response(
                JSON.stringify({ error: 'Missing required fields: to, subject, html' }),
                { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
            );
        }

        // Initialize Nodemailer transporter with AWS SES SMTP credentials
        const transporter = nodemailer.createTransport({
            host: Deno.env.get('SMTP_HOST'),
            port: parseInt(Deno.env.get('SMTP_PORT') || '587'),
            secure: Deno.env.get('SMTP_PORT') === '465', // secure is true for port 465, false for others
            auth: {
                user: Deno.env.get('SMTP_USER'),
                pass: Deno.env.get('SMTP_PASS'),
            },
        });

        const mailOptions = {
            from: Deno.env.get('SMTP_SENDER_EMAIL'), // Must be verified in AWS SES
            to: to,
            subject: subject,
            html: html,
        };

        const info = await transporter.sendMail(mailOptions);
        console.log('Email sent successfully: %s', info.messageId);

        return new Response(
            JSON.stringify({ success: true, messageId: info.messageId }),
            { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );

    } catch (error: any) {
        console.error('Error sending email:', error);
        return new Response(
            JSON.stringify({ error: 'Failed to send email', details: error.message }),
            { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
    }
});
