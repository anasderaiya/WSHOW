export const getCorsHeaders = (origin: string | null) => {
  const allowedOrigin = Deno.env.get('ALLOWED_ORIGIN') || 'https://quickmytickets.com';
  
  let allowed = allowedOrigin;
  
  if (origin) {
    const isLocal = /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin);
    const isVercelSubdomain = /^https:\/\/qmt-[a-z0-9-]+\.vercel\.app$/.test(origin);
    const isMainDomain = origin === allowedOrigin;
    
    // Check additional allowed origins from environment variable
    const additionalOrigins = Deno.env.get('ADDITIONAL_ALLOWED_ORIGINS')?.split(',') || [];
    const isAdditional = additionalOrigins.includes(origin);
    
    if (isLocal || isVercelSubdomain || isMainDomain || isAdditional) {
      allowed = origin;
    }
  }
  
  return {
    'Access-Control-Allow-Origin': allowed,
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
  };
};
