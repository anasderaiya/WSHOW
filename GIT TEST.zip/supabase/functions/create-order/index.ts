
import { serve } from 'https://deno.land/std@0.220.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.0';
import { getCorsHeaders } from '../_shared/cors.ts';

serve(async (req) => {
    const origin = req.headers.get('Origin');
    const corsHeaders = getCorsHeaders(origin);

    // Handle CORS preflight
    if (req.method === 'OPTIONS') {
        return new Response('ok', { headers: corsHeaders });
    }

    try {
        const { receipt, booking_ids, session_id } = await req.json();

        if (!booking_ids || !Array.isArray(booking_ids) || booking_ids.length === 0) {
            return new Response(
                JSON.stringify({ error: 'booking_ids array is required' }),
                { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
            );
        }

        // Create Supabase client
        const supabase = createClient(
            Deno.env.get('SUPABASE_URL')!,
            Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
        );

        // Get auth token from request
        const authHeader = req.headers.get('Authorization');
        const token = authHeader?.replace('Bearer ', '');

        // Verify user if token provided
        let userId = null;
        if (token && token.length > 100) {
            try {
                const { data: { user }, error: userError } = await supabase.auth.getUser(token);
                if (!userError && user) userId = user.id;
            } catch { /* skip */ }
        }

        // Calculate total amount SERVER-SIDE
        const { data: priceData, error: priceError } = await supabase.rpc('calculate_booking_total', {
            p_booking_ids: booking_ids,
            p_tax_rate: 0.18
        });

        if (priceError || !priceData || priceData.length === 0) {
            return new Response(
                JSON.stringify({ error: 'Failed to calculate booking total' }),
                { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
            );
        }

        const { total, seat_count } = priceData[0];
        const amountInPaise = Math.round(total * 100);

        // Razorpay order creation logic...
        const RAZORPAY_KEY_ID = Deno.env.get('RAZORPAY_KEY_ID');
        const RAZORPAY_KEY_SECRET = Deno.env.get('RAZORPAY_KEY_SECRET');

        if (!RAZORPAY_KEY_ID || !RAZORPAY_KEY_SECRET) {
            return new Response(
                JSON.stringify({ error: 'Payment gateway not configured' }),
                { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
            );
        }

        // Build a deterministic receipt from sorted booking IDs.
        // If the client retries the same set of bookings, the receipt
        // will be identical, letting us detect duplicate order creation.
        const sortedIds = [...booking_ids].sort();
        const deterministicReceipt = receipt || `QMT-${sortedIds.join('-').slice(0, 40)}`;

        // Idempotency: check if an order was already created for these bookings.
        // We store the Razorpay order ID in the bookings table when an order is
        // created, so if any of these bookings already has a razorpay_order_id,
        // return the existing order instead of creating a new one.
        const { data: existingBookings } = await supabase
            .from('bookings')
            .select('razorpay_order_id')
            .in('id', booking_ids)
            .not('razorpay_order_id', 'is', null)
            .limit(1);

        if (existingBookings && existingBookings.length > 0 && existingBookings[0].razorpay_order_id) {
            // Fetch the existing order from Razorpay
            const existingOrderId = existingBookings[0].razorpay_order_id;
            const existingOrderResp = await fetch(`https://api.razorpay.com/v1/orders/${existingOrderId}`, {
                headers: {
                    'Authorization': 'Basic ' + btoa(`${RAZORPAY_KEY_ID}:${RAZORPAY_KEY_SECRET}`)
                }
            });
            if (existingOrderResp.ok) {
                const existingOrder = await existingOrderResp.json();
                // Only reuse if the order is still in 'created' or 'attempted' status
                if (existingOrder.status === 'created' || existingOrder.status === 'attempted') {
                    return new Response(
                        JSON.stringify({ ...existingOrder, calculated_total: total, seat_count, reused: true }),
                        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
                    );
                }
            }
        }

        // Bug 4 fix: Fetch the theater's Razorpay Account ID for Route transfers.
        // Try movie show first, then fall back to event show.
        let razorpayAccountId = null;
        const { data: movieBooking } = await supabase
            .from('bookings')
            .select(`
                shows!inner(
                    screens!inner(
                        theatres!inner(
                            razorpay_account_id
                        )
                    )
                )
            `)
            .in('id', booking_ids)
            .not('show_id', 'is', null)
            .limit(1)
            .maybeSingle();

        if (movieBooking?.shows?.screens?.theatres?.razorpay_account_id) {
            razorpayAccountId = movieBooking.shows.screens.theatres.razorpay_account_id;
        } else {
            // Fall back to event show
            const { data: eventBooking } = await supabase
                .from('bookings')
                .select(`
                    event_shows!inner(
                        screens!inner(
                            theatres!inner(
                                razorpay_account_id
                            )
                        )
                    )
                `)
                .in('id', booking_ids)
                .not('event_show_id', 'is', null)
                .limit(1)
                .maybeSingle();

            razorpayAccountId = eventBooking?.event_shows?.screens?.theatres?.razorpay_account_id ?? null;
        }

        // Bug 3 fix: Read platform fee from platform_settings instead of hardcoding.
        // Uses the same convenience_fee setting that calculate_booking_total uses
        // for the customer-facing fee — one setting, one source of truth.
        let platformFeePaise = Math.round(amountInPaise * 0.10); // fallback: 10%
        const { data: feeConfig } = await supabase
            .from('platform_settings')
            .select('value')
            .eq('key', 'convenience_fee')
            .single();

        if (feeConfig?.value) {
            const feeSetting = feeConfig.value;
            if (feeSetting.type === 'fixed' && typeof feeSetting.amount === 'number') {
                // Fixed fee per seat (e.g., ₹20 × seat_count), convert to paise
                platformFeePaise = Math.round(feeSetting.amount * seat_count * 100);
            } else if ((feeSetting.type === 'percent' || feeSetting.type === 'percentage') && typeof feeSetting.amount === 'number') {
                platformFeePaise = Math.round(amountInPaise * feeSetting.amount / 100);
            }
        }
        
        const orderPayload: any = {
            amount: amountInPaise,
            currency: 'INR',
            receipt: deterministicReceipt,
            notes: {
                booking_ids: booking_ids.join(','),
                seat_count: seat_count.toString(),
                user_id: userId || ''
            }
        };

        if (razorpayAccountId) {
            const transferAmountPaise = amountInPaise - platformFeePaise;
            
            orderPayload.transfers = [
                {
                    account: razorpayAccountId,
                    amount: transferAmountPaise,
                    currency: 'INR',
                    notes: {
                        description: 'Ticket sales transfer'
                    },
                    on_hold: 0 // Keep funds immediately available to vendor
                }
            ];
        }

        const razorpayResponse = await fetch('https://api.razorpay.com/v1/orders', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Basic ' + btoa(`${RAZORPAY_KEY_ID}:${RAZORPAY_KEY_SECRET}`)
            },
            body: JSON.stringify(orderPayload)
        });

        if (!razorpayResponse.ok) {
            return new Response(
                JSON.stringify({ error: 'Failed to create payment order' }),
                { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
            );
        }

        const order = await razorpayResponse.json();

        // Store the Razorpay order ID on the bookings for idempotency on retry
        await supabase
            .from('bookings')
            .update({ razorpay_order_id: order.id })
            .in('id', booking_ids);

        return new Response(
            JSON.stringify({ ...order, calculated_total: total, seat_count }),
            { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );

    } catch (error) {
        return new Response(
            JSON.stringify({ error: error.message }),
            { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
    }
});
