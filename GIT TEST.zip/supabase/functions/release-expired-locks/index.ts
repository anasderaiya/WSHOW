/**
 * Quick My Ticket - Release Expired Locks Edge Function
 * ======================================================
 * 
 * This function releases seat locks that have been held for too long.
 * It should be called on a schedule (e.g., every minute) via:
 * - Supabase cron (pg_cron extension)
 * - External cron service (e.g., cron-job.org, GitHub Actions)
 * - Vercel cron
 * 
 * DEPLOYMENT:
 * -----------
 * supabase functions deploy release-expired-locks
 * 
 * CRON SETUP (Option 1 - Supabase Dashboard):
 * -------------------------------------------
 * 1. Go to Database → Extensions → Enable pg_cron
 * 2. Run this SQL:
 *    SELECT cron.schedule(
 *      'release-expired-locks',
 *      '* * * * *',  -- Every minute
 *      $$SELECT net.http_post(
 *        url := 'https://YOUR_PROJECT_REF.supabase.co/functions/v1/release-expired-locks',
 *        headers := '{"Authorization": "Bearer YOUR_SERVICE_ROLE_KEY"}'::jsonb
 *      )$$
 *    );
 * 
 * CRON SETUP (Option 2 - External):
 * ---------------------------------
 * Set up a cron job to POST to:
 * https://YOUR_PROJECT_REF.supabase.co/functions/v1/release-expired-locks
 * with Authorization: Bearer YOUR_SERVICE_ROLE_KEY header
 */

import { serve } from 'https://deno.land/std@0.220.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.0';

serve(async (req) => {
    // This is a server-to-server cron endpoint. No CORS needed.
    // Reject non-POST methods.
    if (req.method !== 'POST') {
        return new Response(
            JSON.stringify({ error: 'Method not allowed' }),
            { status: 405, headers: { 'Content-Type': 'application/json' } }
        );
    }

    // AUTH GUARD: Only accept requests with the service role key.
    const authHeader = req.headers.get('Authorization');
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    if (!serviceRoleKey || authHeader !== `Bearer ${serviceRoleKey}`) {
        return new Response(
            JSON.stringify({ error: 'Unauthorized' }),
            { status: 401, headers: { 'Content-Type': 'application/json' } }
        );
    }

    try {
        // Create Supabase client with service role key
        const supabase = createClient(
            Deno.env.get('SUPABASE_URL')!,
            Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
        );

        // Get lock timeout from settings (default 5 minutes)
        let lockTimeout = 5;
        const { data: settings } = await supabase
            .from('app_settings')
            .select('value')
            .eq('key', 'lock_timeout_minutes')
            .single();

        if (settings?.value) {
            lockTimeout = parseInt(settings.value, 10) || 5;
        }

        // Call the release_expired_locks function
        const { data, error } = await supabase.rpc('release_expired_locks', {
            p_lock_timeout_minutes: lockTimeout
        });

        if (error) {
            console.error('Error releasing expired locks:', error);
            return new Response(
                JSON.stringify({
                    success: false,
                    error: error.message
                }),
                {
                    status: 500,
                    headers: { 'Content-Type': 'application/json' }
                }
            );
        }

        const result = data?.[0] || { released_count: 0, released_ids: [] };

        console.log(`Released ${result.released_count} expired locks`);

        return new Response(
            JSON.stringify({
                success: true,
                released_count: result.released_count,
                released_ids: result.released_ids,
                lock_timeout_minutes: lockTimeout,
                timestamp: new Date().toISOString()
            }),
            {
                status: 200,
                headers: { 'Content-Type': 'application/json' }
            }
        );

    } catch (error) {
        console.error('Unexpected error:', error);
        return new Response(
            JSON.stringify({
                success: false,
                error: error.message
            }),
            {
                status: 500,
                headers: { 'Content-Type': 'application/json' }
            }
        );
    }
});
