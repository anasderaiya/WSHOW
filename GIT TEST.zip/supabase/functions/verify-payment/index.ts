/**
 * Quick My Ticket - Verify Payment Edge Function
 * ================================================
 * 
 * Verifies Razorpay payment signature and confirms bookings.
 * 
 * DEPLOYMENT:
 * -----------
 * supabase functions deploy verify-payment
 * supabase secrets set RAZORPAY_KEY_SECRET=xxx
 */

import { serve } from 'https://deno.land/std@0.220.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.0';
import { createHmac } from 'node:crypto';
import { getCorsHeaders } from '../_shared/cors.ts';

serve(async (req) => {
    const origin = req.headers.get('Origin');
    const corsHeaders = getCorsHeaders(origin);
    
    // Handle CORS preflight
    if (req.method === 'OPTIONS') {
        return new Response('ok', { headers: corsHeaders });
    }

    try {
        const {
            razorpay_order_id,
            razorpay_payment_id,
            razorpay_signature,
            booking_ids,
            guest_name,
            guest_email,
            guest_phone
        } = await req.json();

        // Validate required fields
        if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
            return new Response(
                JSON.stringify({ error: 'Missing required payment fields' }),
                { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
            );
        }

        if (!booking_ids || !Array.isArray(booking_ids) || booking_ids.length === 0) {
            return new Response(
                JSON.stringify({ error: 'booking_ids array is required' }),
                { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
            );
        }

        // Verify Razorpay signature
        const secret = Deno.env.get('RAZORPAY_KEY_SECRET');

        if (!secret) {
            return new Response(
                JSON.stringify({ error: 'Payment verification not configured' }),
                { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
            );
        }

        const body = razorpay_order_id + '|' + razorpay_payment_id;
        const expectedSignature = createHmac('sha256', secret)
            .update(body)
            .digest('hex');

        if (expectedSignature !== razorpay_signature) {
            console.error('Invalid signature', {
                expected: expectedSignature,
                received: razorpay_signature
            });
            return new Response(
                JSON.stringify({ error: 'Invalid payment signature' }),
                { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
            );
        }

        // Create Supabase client with service role
        const supabase = createClient(
            Deno.env.get('SUPABASE_URL')!,
            Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
        );

        // Try to get user ID if authenticated
        let userId = null;
        const authHeader = req.headers.get('Authorization');
        if (authHeader && authHeader !== 'Bearer ') {
            const token = authHeader.replace('Bearer ', '');
            const { data: { user } } = await supabase.auth.getUser(token);
            if (user?.id) {
                userId = user.id;
            }
        }

        // Confirm bookings using database function
        const { data, error } = await supabase.rpc('confirm_bookings', {
            p_booking_ids: booking_ids,
            p_payment_id: razorpay_payment_id,
            p_guest_name: guest_name || null,
            p_guest_email: guest_email || null,
            p_guest_phone: guest_phone || null,
            p_user_id: userId
        });

        if (error) {
            console.error('Error confirming bookings:', error);
            return new Response(
                JSON.stringify({
                    error: 'Failed to confirm bookings',
                    details: error.message
                }),
                { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
            );
        }

        const result = data?.[0] || { confirmed_count: 0, total_amount: 0 };

        console.log(`Confirmed ${result.confirmed_count} bookings for payment ${razorpay_payment_id}`);

        // Fetch the generated ticket tokens for these bookings
        let tokens: string[] = [];
        if (result.confirmed_count > 0) {
            const { data: tokenData, error: tokenError } = await supabase
                .from('bookings')
                .select('ticket_token')
                .in('id', booking_ids)
                .not('ticket_token', 'is', null);
                
            if (!tokenError && tokenData) {
                tokens = tokenData.map((b: any) => b.ticket_token);
            } else if (tokenError) {
                console.error('Failed to fetch ticket tokens:', tokenError);
            }
        }

        // Try to get email to send confirmation email
        try {
            let userEmail = guest_email;
            
            // Reuse the userId from the auth check above (lines 87-95)
            // instead of calling getUser() a second time.
            if (userId && !userEmail) {
                const { data: { user } } = await supabase.auth.admin.getUserById(userId);
                if (user?.email) {
                    userEmail = user.email;
                }
            }

            if (userEmail) {
                const emailHtml = `
                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden;">
                        <div style="background-color: #d4af37; padding: 20px; text-align: center;">
                            <h1 style="color: white; margin: 0;">Quick My Ticket — Booking Confirmed!</h1>
                        </div>
                        <div style="padding: 20px;">
                            <p style="font-size: 16px; color: #333;">Hello,</p>
                            <p style="font-size: 16px; color: #333;">Your payment was successful and your tickets are now confirmed.</p>
                            <div style="background-color: #f9f9f9; padding: 15px; border-radius: 4px; border-left: 4px solid #d4af37; margin: 20px 0;">
                                <p style="margin: 5px 0;"><strong>No. of Tickets:</strong> ${result.confirmed_count}</p>
                                <p style="margin: 5px 0;"><strong>Order ID:</strong> ${razorpay_order_id}</p>
                                <p style="margin: 5px 0;"><strong>Payment ID:</strong> ${razorpay_payment_id}</p>
                            </div>
                            <p style="font-size: 16px; color: #333;">You can view your full ticket details in the Quick My Ticket app under 'My Bookings', or check your tickets directly from the payment success page.</p>
                            <p style="font-size: 16px; color: #333;">Thank you for choosing Quick My Ticket!</p>
                        </div>
                        <div style="background-color: #f5f5f5; padding: 15px; text-align: center; font-size: 12px; color: #888;">
                            <p style="margin: 0;">This is an automated message. Please do not reply to this email.</p>
                        </div>
                    </div>
                `;

                // Invoke send-email function
                const { error: invokeError } = await supabase.functions.invoke('send-email', {
                    body: {
                        to: userEmail,
                        subject: 'Your Quick My Ticket Booking is Confirmed!',
                        html: emailHtml
                    }
                });

                if (invokeError) {
                    console.error('Error invoking send-email function:', invokeError);
                } else {
                    console.log(`Confirmation email sent to ${userEmail}`);
                }
            }
        } catch (emailError) {
            console.error('Failed to send confirmation email. Continuing anyway:', emailError);
        }

        return new Response(
            JSON.stringify({
                success: true,
                verified: true,
                payment_id: razorpay_payment_id,
                order_id: razorpay_order_id,
                confirmed_count: result.confirmed_count,
                total_amount: result.total_amount,
                tokens: tokens
            }),
            {
                status: 200,
                headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            }
        );

    } catch (error: any) {
        console.error('Unexpected error:', error);
        return new Response(
            JSON.stringify({ error: error.message }),
            { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
    }
});
