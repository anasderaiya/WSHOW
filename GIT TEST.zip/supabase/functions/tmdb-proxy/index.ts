import { serve } from 'https://deno.land/std@0.220.0/http/server.ts';
import { getCorsHeaders } from '../_shared/cors.ts';

const ALLOWED_ENDPOINTS: Record<string, (params: URLSearchParams) => string> = {
  'trending':  () => 'trending/movie/week',
  'search':    (p) => `search/movie?query=${encodeURIComponent(p.get('query') || '')}`,
  'details':   (p) => `movie/${p.get('id') || ''}`,
  'credits':   (p) => `movie/${p.get('id') || ''}/credits`,
  'videos':    (p) => `movie/${p.get('id') || ''}/videos`,
};

serve(async (req) => {
  const origin = req.headers.get('Origin');
  const corsHeaders = getCorsHeaders(origin);

  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  if (req.method !== 'GET') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }

  try {
    const TMDB_API_KEY = Deno.env.get('TMDB_API_KEY');
    if (!TMDB_API_KEY) {
      return new Response(JSON.stringify({ error: 'TMDB API key not configured' }), {
        status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const url = new URL(req.url);
    const endpoint = url.searchParams.get('endpoint') || 'trending';

    const endpointBuilder = ALLOWED_ENDPOINTS[endpoint];
    if (!endpointBuilder) {
      return new Response(JSON.stringify({
        error: `Invalid endpoint. Allowed: ${Object.keys(ALLOWED_ENDPOINTS).join(', ')}`
      }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' }});
    }

    const tmdbPath = endpointBuilder(url.searchParams);

    // Validate movie ID is numeric to prevent path injection
    if (endpoint === 'details' || endpoint === 'credits' || endpoint === 'videos') {
      const id = url.searchParams.get('id');
      if (!id || !/^\d+$/.test(id)) {
        return new Response(JSON.stringify({ error: 'Invalid movie id' }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
    }

    // Preserve any extra TMDB params (page, language etc)
    const tmdbParams = new URLSearchParams();
    tmdbParams.set('api_key', TMDB_API_KEY);
    ['page', 'language', 'region'].forEach(p => {
      if (url.searchParams.get(p)) tmdbParams.set(p, url.searchParams.get(p)!);
    });

    const separator = tmdbPath.includes('?') ? '&' : '?';
    const tmdbUrl = `https://api.themoviedb.org/3/${tmdbPath}${separator}${tmdbParams}`;

    const tmdbResponse = await fetch(tmdbUrl);
    const data = await tmdbResponse.json();

    if (!tmdbResponse.ok) {
      return new Response(JSON.stringify({ error: 'TMDB error', details: data }), {
        status: tmdbResponse.status,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    return new Response(JSON.stringify(data), {
      status: 200,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json',
        'Cache-Control': endpoint === 'trending' ? 'public, max-age=3600' : 'public, max-age=86400',
      }
    });

  } catch (err) {
    console.error('tmdb-proxy error:', err);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
