-- ============================================
-- Quick My Ticket Events System
-- ============================================
-- This migration adds:
-- 1. Events table for concerts, sports, comedy shows, etc.
-- 2. Event shows table linking events to venues
-- 3. Modified bookings support for events
-- 4. Event availability view
-- 5. RLS policies for events

-- ============================================
-- 1. EVENTS TABLE
-- ============================================

CREATE TABLE IF NOT EXISTS events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    description TEXT,
    category TEXT NOT NULL DEFAULT 'concert',
    poster_url TEXT,
    banner_url TEXT,
    organizer TEXT,
    venue_name TEXT,
    city TEXT,
    tags TEXT[] DEFAULT '{}',
    is_featured BOOLEAN DEFAULT FALSE,
    status TEXT DEFAULT 'upcoming' CHECK (status IN ('upcoming', 'ongoing', 'completed', 'cancelled')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Add indexes
CREATE INDEX IF NOT EXISTS idx_events_category ON events(category);
CREATE INDEX IF NOT EXISTS idx_events_status ON events(status);
CREATE INDEX IF NOT EXISTS idx_events_featured ON events(is_featured) WHERE is_featured = TRUE;
CREATE INDEX IF NOT EXISTS idx_events_city ON events(city);

-- ============================================
-- 2. EVENT SHOWS TABLE
-- ============================================
-- Links events to venues/screens for seat booking

CREATE TABLE IF NOT EXISTS event_shows (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    event_id UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    screen_id UUID REFERENCES screens(id) ON DELETE SET NULL,
    start_time TIMESTAMPTZ NOT NULL,
    end_time TIMESTAMPTZ,
    price DECIMAL(10,2) DEFAULT 0,
    status TEXT DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'ongoing', 'completed', 'cancelled')),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Add indexes
CREATE INDEX IF NOT EXISTS idx_event_shows_event ON event_shows(event_id);
CREATE INDEX IF NOT EXISTS idx_event_shows_screen ON event_shows(screen_id);
CREATE INDEX IF NOT EXISTS idx_event_shows_start ON event_shows(start_time);

-- ============================================
-- 3. MODIFY BOOKINGS TABLE
-- ============================================
-- Add event_show_id column for event bookings

ALTER TABLE bookings 
ADD COLUMN IF NOT EXISTS event_show_id UUID REFERENCES event_shows(id) ON DELETE CASCADE;

-- Update constraint: either show_id OR event_show_id must be set
-- Note: We allow both to be NULL temporarily during migration
CREATE INDEX IF NOT EXISTS idx_bookings_event_show ON bookings(event_show_id) 
WHERE event_show_id IS NOT NULL;

-- ============================================
-- 4. EVENT SEAT LOCKING FUNCTION
-- ============================================

CREATE OR REPLACE FUNCTION lock_event_seat(
    p_event_show_id UUID, 
    p_seat_id UUID, 
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    booking_id UUID, 
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking_id UUID;
    v_existing RECORD;
    v_screen_id UUID;
    v_seat_exists BOOLEAN;
BEGIN
    -- Validate that the event show exists and get screen_id
    SELECT screen_id INTO v_screen_id 
    FROM event_shows 
    WHERE id = p_event_show_id;
    
    IF v_screen_id IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Event show not found'::TEXT;
        RETURN;
    END IF;
    
    -- Validate that the seat exists and belongs to the event's screen
    SELECT EXISTS(
        SELECT 1 FROM seats 
        WHERE id = p_seat_id AND screen_id = v_screen_id
    ) INTO v_seat_exists;
    
    IF NOT v_seat_exists THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat not found for this event'::TEXT;
        RETURN;
    END IF;
    
    -- Try to acquire a lock on existing booking (if any)
    SELECT * INTO v_existing
    FROM bookings 
    WHERE event_show_id = p_event_show_id 
      AND seat_id = p_seat_id 
      AND status IN ('locked', 'confirmed')
    FOR UPDATE NOWAIT;
    
    -- Check if seat is already taken
    IF FOUND THEN
        IF ((v_existing.user_id IS NOT NULL AND v_existing.user_id = p_user_id) OR
            (v_existing.user_id IS NULL AND v_existing.session_id = p_session_id)) AND v_existing.status = 'locked' THEN
            UPDATE bookings 
            SET locked_at = NOW() 
            WHERE id = v_existing.id;
            
            RETURN QUERY SELECT v_existing.id, TRUE, 'Lock refreshed'::TEXT;
            RETURN;
        ELSIF v_existing.status = 'locked' AND v_existing.locked_at < NOW() - INTERVAL '5 minutes' THEN
            -- Steal the lock! Expire the old one.
            UPDATE bookings SET status = 'expired' WHERE id = v_existing.id;
        ELSE
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is already locked or booked'::TEXT;
            RETURN;
        END IF;
    END IF;
    
    -- Insert new booking with lock
    INSERT INTO bookings (event_show_id, seat_id, user_id, session_id, status, locked_at)
    VALUES (p_event_show_id, p_seat_id, p_user_id, p_session_id, 'locked', NOW())
    RETURNING id INTO v_booking_id;
    
    RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
    
EXCEPTION
    WHEN lock_not_available THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is being processed by another user'::TEXT;
    WHEN unique_violation THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat was just locked by another user'::TEXT;
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, ('Error: ' || SQLERRM)::TEXT;
END;
$$;

GRANT EXECUTE ON FUNCTION lock_event_seat(UUID, UUID, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION lock_event_seat(UUID, UUID, UUID, TEXT) TO anon;

-- ============================================
-- 5. EVENT SEAT AVAILABILITY VIEW
-- ============================================

CREATE OR REPLACE VIEW event_seat_availability AS
SELECT 
    es.id AS event_show_id,
    es.event_id,
    e.title AS event_title,
    s.id AS seat_id,
    s.screen_id,
    s.row,
    s.col,
    s.tier,
    COALESCE(s.price, es.price) AS effective_price,
    b.id AS booking_id,
    b.user_id AS locked_by,
    b.locked_at,
    CASE 
        WHEN b.status = 'confirmed' THEN 'booked'
        WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 'locked'
        ELSE 'available'
    END AS availability_status
FROM event_shows es
JOIN events e ON e.id = es.event_id
JOIN seats s ON s.screen_id = es.screen_id
LEFT JOIN bookings b ON b.seat_id = s.id 
    AND b.event_show_id = es.id 
    AND b.status IN ('locked', 'confirmed');

-- ============================================
-- 6. RLS POLICIES FOR EVENTS
-- ============================================

ALTER TABLE events ENABLE ROW LEVEL SECURITY;
ALTER TABLE event_shows ENABLE ROW LEVEL SECURITY;

-- Events: everyone can read
CREATE POLICY "Events are viewable by everyone"
ON events FOR SELECT
TO anon, authenticated
USING (true);

-- Events: only authenticated users can insert (for now)
CREATE POLICY "Authenticated users can create events"
ON events FOR INSERT
TO authenticated
WITH CHECK (true);

-- Event shows: everyone can read
CREATE POLICY "Event shows are viewable by everyone"
ON event_shows FOR SELECT
TO anon, authenticated
USING (true);

-- Event shows: authenticated users can create
CREATE POLICY "Authenticated users can create event shows"
ON event_shows FOR INSERT
TO authenticated
WITH CHECK (true);

-- ============================================
-- 7. SAMPLE DATA FOR TESTING
-- ============================================

INSERT INTO events (id, title, description, category, poster_url, organizer, venue_name, city, tags, is_featured, status)
VALUES 
    ('e0000001-0001-0001-0001-000000000001', 'Arijit Singh Live', 'Experience the magic of Arijit Singh live in concert. An evening of soulful melodies and unforgettable music.', 'concert', 'https://image.tmdb.org/t/p/w500/aymjrprSz3kNjMHzDNlBp9kSVIw.jpg', 'BookMyShow Live', 'Jawaharlal Nehru Stadium', 'Mumbai', ARRAY['music', 'bollywood', 'live'], TRUE, 'upcoming'),
    ('e0000002-0002-0002-0002-000000000002', 'IPL 2026: MI vs CSK', 'The biggest rivalry in cricket! Watch Mumbai Indians take on Chennai Super Kings.', 'sports', 'https://image.tmdb.org/t/p/w500/dMPxdcMhs0VZlbgjNmKvAdzfyWe.jpg', 'BCCI', 'Wankhede Stadium', 'Mumbai', ARRAY['cricket', 'ipl', 'sports'], TRUE, 'upcoming'),
    ('e0000003-0003-0003-0003-000000000003', 'Zakir Khan Stand-Up Comedy', 'Join Zakir Khan for a night of laughter and relatable comedy about life, love, and everything in between.', 'comedy', 'https://image.tmdb.org/t/p/w500/9gk7adHYeDvHkCSEqAvQNLV5Ber.jpg', 'ZK Entertainment', 'NCPA', 'Mumbai', ARRAY['comedy', 'standup', 'hindi'], FALSE, 'upcoming'),
    ('e0000004-0004-0004-0004-000000000004', 'Sunburn Music Festival', 'Indias biggest electronic dance music festival featuring world-renowned DJs.', 'festival', 'https://image.tmdb.org/t/p/w500/5P1i4ydN5XWk8h3WnBB9JjMzMJA.jpg', 'Sunburn', 'Vagator Beach', 'Goa', ARRAY['edm', 'festival', 'music', 'party'], TRUE, 'upcoming'),
    ('e0000005-0005-0005-0005-000000000005', 'India vs Australia Test', 'Day 1 of the historic India vs Australia test match at the iconic Eden Gardens.', 'sports', 'https://image.tmdb.org/t/p/w500/udDclJoHjfjb8Ekgsd4FDteOkCU.jpg', 'BCCI', 'Eden Gardens', 'Kolkata', ARRAY['cricket', 'test', 'india'], FALSE, 'upcoming')
ON CONFLICT (id) DO NOTHING;

-- ============================================
-- 8. GRANT PERMISSIONS
-- ============================================

GRANT SELECT ON events TO anon, authenticated;
GRANT SELECT ON event_shows TO anon, authenticated;
GRANT SELECT ON event_seat_availability TO anon, authenticated;
GRANT INSERT, UPDATE ON events TO authenticated;
GRANT INSERT, UPDATE ON event_shows TO authenticated;


-- ============================================
-- Quick My Ticket - Guest Booking System
-- ============================================
-- This migration adds:
-- 1. Support for guest bookings in the bookings table
-- 2. Modified seat locking RPCs to support session IDs
-- 3. Modified confirm bookings RPC to handle guest details

-- 1. Update table schema
ALTER TABLE public.bookings ALTER COLUMN user_id DROP NOT NULL;
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS session_id TEXT;
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS guest_name TEXT;
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS guest_email TEXT;
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS guest_phone TEXT;

-- 2. Update lock_seat function to support session_id
CREATE OR REPLACE FUNCTION lock_seat(
    p_show_id UUID, 
    p_seat_id UUID, 
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    booking_id UUID, 
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking_id UUID;
    v_existing RECORD;
    v_screen_id UUID;
    v_seat_exists BOOLEAN;
    v_reusable_booking UUID;
    v_lock_timeout_minutes INTEGER := 5;
BEGIN
    SELECT screen_id INTO v_screen_id 
    FROM shows 
    WHERE id = p_show_id;
    
    IF v_screen_id IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Show not found'::TEXT;
        RETURN;
    END IF;
    
    SELECT EXISTS(
        SELECT 1 FROM seats 
        WHERE id = p_seat_id AND screen_id = v_screen_id
    ) INTO v_seat_exists;
    
    IF NOT v_seat_exists THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat not found for this show'::TEXT;
        RETURN;
    END IF;
    
    UPDATE bookings 
    SET status = 'expired', locked_at = NULL
    WHERE show_id = p_show_id 
      AND seat_id = p_seat_id 
      AND status = 'locked'
      AND locked_at < NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL;
    
    BEGIN
        SELECT * INTO v_existing
        FROM bookings 
        WHERE show_id = p_show_id 
          AND seat_id = p_seat_id 
          AND status IN ('locked', 'confirmed')
        FOR UPDATE NOWAIT;
    EXCEPTION
        WHEN lock_not_available THEN
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is currently being processed by another user, please try again'::TEXT;
            RETURN;
    END;
    
    IF FOUND THEN
        IF (v_existing.user_id IS NOT NULL AND v_existing.user_id = p_user_id AND v_existing.status = 'locked') OR 
           (v_existing.session_id IS NOT NULL AND v_existing.session_id = p_session_id AND v_existing.status = 'locked') THEN
            UPDATE bookings 
            SET locked_at = NOW() 
            WHERE id = v_existing.id;
            
            RETURN QUERY SELECT v_existing.id, TRUE, 'Lock refreshed'::TEXT;
            RETURN;
        ELSE
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is already locked or booked'::TEXT;
            RETURN;
        END IF;
    END IF;
    
    SELECT id INTO v_reusable_booking
    FROM bookings
    WHERE show_id = p_show_id
      AND seat_id = p_seat_id
      AND status IN ('cancelled', 'expired')
    ORDER BY created_at DESC
    LIMIT 1
    FOR UPDATE;
    
    IF v_reusable_booking IS NOT NULL THEN
        UPDATE bookings 
        SET status = 'locked',
            user_id = p_user_id,
            session_id = p_session_id,
            locked_at = NOW(),
            payment_id = NULL,
            confirmed_at = NULL
        WHERE id = v_reusable_booking
        RETURNING id INTO v_booking_id;
        
        RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
        RETURN;
    END IF;
    
    INSERT INTO bookings (show_id, seat_id, user_id, session_id, status, locked_at)
    VALUES (p_show_id, p_seat_id, p_user_id, p_session_id, 'locked', NOW())
    RETURNING id INTO v_booking_id;
    
    RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
    
EXCEPTION
    WHEN unique_violation THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat was just locked by another user'::TEXT;
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, ('Error: ' || SQLERRM)::TEXT;
END;
$$;

GRANT EXECUTE ON FUNCTION lock_seat(UUID, UUID, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION lock_seat(UUID, UUID, UUID, TEXT) TO anon;

-- 3. Update lock_event_seat function
CREATE OR REPLACE FUNCTION lock_event_seat(
    p_event_show_id UUID, 
    p_seat_id UUID, 
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    booking_id UUID, 
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking_id UUID;
    v_existing RECORD;
    v_screen_id UUID;
    v_seat_exists BOOLEAN;
    v_reusable_booking UUID;
    v_lock_timeout_minutes INTEGER := 5;
BEGIN
    SELECT screen_id INTO v_screen_id 
    FROM event_shows 
    WHERE id = p_event_show_id;
    
    IF v_screen_id IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Event show not found'::TEXT;
        RETURN;
    END IF;
    
    SELECT EXISTS(
        SELECT 1 FROM seats 
        WHERE id = p_seat_id AND screen_id = v_screen_id
    ) INTO v_seat_exists;
    
    IF NOT v_seat_exists THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat not found for this event'::TEXT;
        RETURN;
    END IF;

    UPDATE bookings 
    SET status = 'expired', locked_at = NULL
    WHERE event_show_id = p_event_show_id 
      AND seat_id = p_seat_id 
      AND status = 'locked'
      AND locked_at < NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL;
    
    BEGIN
        SELECT * INTO v_existing
        FROM bookings 
        WHERE event_show_id = p_event_show_id 
          AND seat_id = p_seat_id 
          AND status IN ('locked', 'confirmed')
        FOR UPDATE NOWAIT;
    EXCEPTION
        WHEN lock_not_available THEN
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is being processed by another user'::TEXT;
            RETURN;
    END;
    
    IF FOUND THEN
        IF (v_existing.user_id IS NOT NULL AND v_existing.user_id = p_user_id AND v_existing.status = 'locked') OR 
           (v_existing.session_id IS NOT NULL AND v_existing.session_id = p_session_id AND v_existing.status = 'locked') THEN
            UPDATE bookings 
            SET locked_at = NOW() 
            WHERE id = v_existing.id;
            
            RETURN QUERY SELECT v_existing.id, TRUE, 'Lock refreshed'::TEXT;
            RETURN;
        ELSE
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is already locked or booked'::TEXT;
            RETURN;
        END IF;
    END IF;

    SELECT id INTO v_reusable_booking
    FROM bookings
    WHERE event_show_id = p_event_show_id
      AND seat_id = p_seat_id
      AND status IN ('cancelled', 'expired')
    ORDER BY created_at DESC
    LIMIT 1
    FOR UPDATE;
    
    IF v_reusable_booking IS NOT NULL THEN
        UPDATE bookings 
        SET status = 'locked',
            user_id = p_user_id,
            session_id = p_session_id,
            locked_at = NOW(),
            payment_id = NULL,
            confirmed_at = NULL
        WHERE id = v_reusable_booking
        RETURNING id INTO v_booking_id;
        
        RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
        RETURN;
    END IF;
    
    INSERT INTO bookings (event_show_id, seat_id, user_id, session_id, status, locked_at)
    VALUES (p_event_show_id, p_seat_id, p_user_id, p_session_id, 'locked', NOW())
    RETURNING id INTO v_booking_id;
    
    RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
    
EXCEPTION
    WHEN unique_violation THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat was just locked by another user'::TEXT;
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, ('Error: ' || SQLERRM)::TEXT;
END;
$$;

GRANT EXECUTE ON FUNCTION lock_event_seat(UUID, UUID, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION lock_event_seat(UUID, UUID, UUID, TEXT) TO anon;

-- 4. Update unlock_seat function
CREATE OR REPLACE FUNCTION unlock_seat(
    p_booking_id UUID,
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking RECORD;
BEGIN
    SELECT * INTO v_booking
    FROM bookings
    WHERE id = p_booking_id
    FOR UPDATE;
    
    IF NOT FOUND THEN
        RETURN QUERY SELECT FALSE, 'Booking not found'::TEXT;
        RETURN;
    END IF;
    
    IF (v_booking.user_id IS NOT NULL AND v_booking.user_id = p_user_id) OR
       (v_booking.session_id IS NOT NULL AND v_booking.session_id = p_session_id) THEN
        -- Ownership verified
    ELSE
        RETURN QUERY SELECT FALSE, 'Not authorized to unlock this booking'::TEXT;
        RETURN;
    END IF;
    
    IF v_booking.status != 'locked' THEN
        RETURN QUERY SELECT FALSE, ('Cannot unlock booking with status: ' || v_booking.status)::TEXT;
        RETURN;
    END IF;
    
    UPDATE bookings 
    SET status = 'cancelled', locked_at = NULL
    WHERE id = p_booking_id;
    
    RETURN QUERY SELECT TRUE, 'Seat unlocked successfully'::TEXT;
END;
$$;

GRANT EXECUTE ON FUNCTION unlock_seat(UUID, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION unlock_seat(UUID, UUID, TEXT) TO anon;

-- 5. Update confirm_bookings to accept guest details
CREATE OR REPLACE FUNCTION confirm_bookings(
    p_booking_ids UUID[],
    p_payment_id TEXT,
    p_guest_name TEXT DEFAULT NULL,
    p_guest_email TEXT DEFAULT NULL,
    p_guest_phone TEXT DEFAULT NULL
)
RETURNS TABLE(
    confirmed_count INTEGER,
    total_amount DECIMAL
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_count INTEGER;
    v_total DECIMAL;
BEGIN
    SELECT total INTO v_total
    FROM calculate_booking_total(p_booking_ids);
    
    WITH confirmed AS (
        UPDATE bookings 
        SET status = 'confirmed',
            payment_id = p_payment_id,
            confirmed_at = NOW(),
            guest_name = COALESCE(bookings.guest_name, p_guest_name),
            guest_email = COALESCE(bookings.guest_email, p_guest_email),
            guest_phone = COALESCE(bookings.guest_phone, p_guest_phone)
        WHERE id = ANY(p_booking_ids)
          AND status = 'locked'
        RETURNING id
    )
    SELECT COUNT(*)::INTEGER INTO v_count FROM confirmed;
    
    RETURN QUERY SELECT v_count, COALESCE(v_total, 0);
END;
$$;

REVOKE ALL ON FUNCTION confirm_bookings(UUID[], TEXT, TEXT, TEXT, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION confirm_bookings(UUID[], TEXT, TEXT, TEXT, TEXT) TO service_role;


-- ============================================
-- Quick My Ticket - Fix Guest Lock Release
-- ============================================
-- This migration:
-- 1. Updates extend_locks to support guest sessions
-- 2. Adds a pg_cron job to auto-release expired locks every minute
-- 3. Adds a direct SQL function for force-releasing all expired locks

-- 1. Update extend_locks to support session_id (guest heartbeat)
CREATE OR REPLACE FUNCTION extend_locks(
    p_booking_ids UUID[],
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    extended_count INTEGER,
    success BOOLEAN,
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_count INTEGER := 0;
    v_lock_timeout_minutes INTEGER := 5;
BEGIN
    -- Extend locks matching either user_id or session_id
    UPDATE bookings
    SET locked_at = NOW()
    WHERE id = ANY(p_booking_ids)
      AND status = 'locked'
      AND locked_at >= NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL
      AND (
          (p_user_id IS NOT NULL AND user_id = p_user_id) OR
          (p_session_id IS NOT NULL AND session_id = p_session_id)
      );
    
    GET DIAGNOSTICS v_count = ROW_COUNT;
    
    IF v_count > 0 THEN
        RETURN QUERY SELECT v_count, TRUE, format('Extended %s lock(s)', v_count)::TEXT;
    ELSE
        RETURN QUERY SELECT 0, FALSE, 'No active locks to extend'::TEXT;
    END IF;
END;
$$;

-- Grant to both authenticated and anon (guests)
GRANT EXECUTE ON FUNCTION extend_locks(UUID[], UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION extend_locks(UUID[], UUID, TEXT) TO anon;

-- 2. Auto-release expired locks directly in SQL (no Edge Function needed)
-- This runs as a simple function that pg_cron can call directly
CREATE OR REPLACE FUNCTION auto_release_expired_locks()
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_count INTEGER;
BEGIN
    UPDATE bookings
    SET status = 'expired', locked_at = NULL
    WHERE status = 'locked'
      AND locked_at < NOW() - INTERVAL '5 minutes';
    
    GET DIAGNOSTICS v_count = ROW_COUNT;
    
    IF v_count > 0 THEN
        RAISE LOG 'JayShow: Auto-released % expired seat locks', v_count;
    END IF;
    
    RETURN v_count;
END;
$$;

-- 3. Schedule the auto-release job via pg_cron (optional)
-- NOTE: pg_cron must be enabled in Supabase Dashboard -> Database -> Extensions
-- If pg_cron is not enabled, this block is skipped gracefully.
DO $$
BEGIN
    PERFORM cron.schedule(
        'release-expired-locks',
        '* * * * *',
        'SELECT auto_release_expired_locks()'
    );
    RAISE LOG '[QMT] pg_cron job "release-expired-locks" scheduled (every minute)';
EXCEPTION WHEN OTHERS THEN
    RAISE LOG '[QMT] pg_cron not available — skipping cron job setup. Enable pg_cron in Supabase Dashboard -> Database -> Extensions and re-run this block manually.';
END;
$$;


-- ============================================
-- Fix: Events RLS Policies
-- ============================================
-- Adds missing UPDATE and DELETE policies for administrators on events and event_shows.

-- 1. Events Update/Delete for Admins
CREATE POLICY "Admins can update events" 
ON events FOR UPDATE 
TO authenticated
USING ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true)
WITH CHECK ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true);

CREATE POLICY "Admins can delete events" 
ON events FOR DELETE 
TO authenticated
USING ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true);

-- 2. Event Shows Update/Delete for Admins
CREATE POLICY "Admins can update event shows" 
ON event_shows FOR UPDATE 
TO authenticated
USING ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true)
WITH CHECK ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true);

CREATE POLICY "Admins can delete event shows" 
ON event_shows FOR DELETE 
TO authenticated
USING ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true);

-- 3. Ensure theater owners can also manage event shows if they own the theatre
-- Only if the event show is at their screen
CREATE POLICY "Owners can update event shows" 
ON event_shows FOR UPDATE 
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM theater_owners to_owner
        JOIN screens s ON s.theatre_id = to_owner.theatre_id
        WHERE s.id = event_shows.screen_id
        AND to_owner.user_id = auth.uid()
        AND to_owner.role IN ('owner', 'manager')
    )
);

CREATE POLICY "Owners can delete event shows" 
ON event_shows FOR DELETE 
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM theater_owners to_owner
        JOIN screens s ON s.theatre_id = to_owner.theatre_id
        WHERE s.id = event_shows.screen_id
        AND to_owner.user_id = auth.uid()
        AND to_owner.role IN ('owner', 'manager')
    )
);


-- ============================================
-- Quick My Ticket - Final Booking System Hardening
-- ============================================
-- This migration:
-- 1. Adds partial unique indexes to prevent double bookings
-- 2. Updates confirm_bookings to support user identification
-- 3. Optimizes booking queries

-- 1. ADD PARTIAL UNIQUE INDEXES (Critical for Concurrency)
-- These ensure that for any given show/seat, there can be AT MOST ONE active booking
-- (either 'locked' or 'confirmed'). Expired/Cancelled bookings are ignored.

-- For Movie Shows
CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_active_movie_booking 
ON public.bookings (show_id, seat_id) 
WHERE status IN ('locked', 'confirmed') AND show_id IS NOT NULL;

-- For Event Shows
CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_active_event_booking 
ON public.bookings (event_show_id, seat_id) 
WHERE status IN ('locked', 'confirmed') AND event_show_id IS NOT NULL;


-- 2. UPDATE confirm_bookings 
-- Adds support for updating the user_id if a guest logs in during the flow
CREATE OR REPLACE FUNCTION confirm_bookings(
    p_booking_ids UUID[],
    p_payment_id TEXT,
    p_guest_name TEXT DEFAULT NULL,
    p_guest_email TEXT DEFAULT NULL,
    p_guest_phone TEXT DEFAULT NULL,
    p_user_id UUID DEFAULT NULL
)
RETURNS TABLE(
    confirmed_count INTEGER,
    total_amount DECIMAL
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_count INTEGER;
    v_total DECIMAL;
BEGIN
    -- Calculate total for the specific requested IDs
    SELECT total INTO v_total
    FROM calculate_booking_total(p_booking_ids);
    
    WITH confirmed AS (
        UPDATE bookings 
        SET status = 'confirmed',
            payment_id = p_payment_id,
            confirmed_at = NOW(),
            -- Only update guest details if not already present
            guest_name = COALESCE(bookings.guest_name, p_guest_name),
            guest_email = COALESCE(bookings.guest_email, p_guest_email),
            guest_phone = COALESCE(bookings.guest_phone, p_guest_phone),
            -- Link to user if provided (e.g., guest logged in before checkout)
            user_id = COALESCE(bookings.user_id, p_user_id)
        WHERE id = ANY(p_booking_ids)
          AND status = 'locked'
        RETURNING id
    )
    SELECT COUNT(*)::INTEGER INTO v_count FROM confirmed;
    
    RETURN QUERY SELECT v_count, COALESCE(v_total, 0);
END;
$$;


-- 3. PERMISSION RE-GRANT
REVOKE ALL ON FUNCTION confirm_bookings(UUID[], TEXT, TEXT, TEXT, TEXT, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION confirm_bookings(UUID[], TEXT, TEXT, TEXT, TEXT, UUID) TO service_role;


-- 4. HOUSEKEEPING: REFRESH VIEWS
-- Ensure the seat_availability view is fully optimized with the new indexes
ANALYZE bookings;


-- ============================================
-- Quick My Ticket - Fix Event Booking Price Calculation
-- Migration 014
-- ============================================

-- Safely replace calculate_booking_total to support both movie shows and event shows
-- Previously, it used an INNER JOIN on shows, which filtered out event_shows
-- and caused the 'create-order' edge function to fail during payment.

CREATE OR REPLACE FUNCTION calculate_booking_total(
    p_booking_ids UUID[],
    p_tax_rate DECIMAL DEFAULT 0.18
)
RETURNS TABLE(
    subtotal DECIMAL,
    tax DECIMAL,
    total DECIMAL,
    seat_count INTEGER
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_subtotal DECIMAL;
    v_seat_count INTEGER;
BEGIN
    -- Calculate subtotal from seats, movie shows, or event shows
    SELECT 
        COALESCE(SUM(COALESCE(s.price, sh.price, es.price, 0)), 0),
        COUNT(*)::INTEGER
    INTO v_subtotal, v_seat_count
    FROM bookings b
    JOIN seats s ON s.id = b.seat_id
    LEFT JOIN shows sh ON sh.id = b.show_id
    LEFT JOIN event_shows es ON es.id = b.event_show_id
    WHERE b.id = ANY(p_booking_ids)
      AND b.status = 'locked';  -- Only count locked bookings
    
    RETURN QUERY SELECT 
        v_subtotal,
        ROUND(v_subtotal * p_tax_rate, 2),
        v_subtotal + ROUND(v_subtotal * p_tax_rate, 2),
        v_seat_count;
END;
$$;

GRANT EXECUTE ON FUNCTION calculate_booking_total(UUID[], DECIMAL) TO authenticated;
GRANT EXECUTE ON FUNCTION calculate_booking_total(UUID[], DECIMAL) TO anon;
GRANT EXECUTE ON FUNCTION calculate_booking_total(UUID[], DECIMAL) TO service_role;


-- Migration: Update views to expose guest session IDs
-- Allows frontend to recover guest locks upon page reload and prevents "phantom locked" seats

-- Drop the views first to avoid Postgres column matching rule conflicts (ERROR: 42P16)
DROP VIEW IF EXISTS seat_availability CASCADE;
DROP VIEW IF EXISTS event_seat_availability CASCADE;

-- Recreate seat_availability view to include session_id
CREATE OR REPLACE VIEW seat_availability AS
SELECT 
    s.id AS seat_id,
    s.screen_id,
    s.row,
    s.col,
    s.tier,
    s.price AS seat_price,
    sh.id AS show_id,
    sh.price AS show_price,
    COALESCE(s.price, sh.price, 0) AS effective_price,
    CASE 
        WHEN b.status = 'confirmed' THEN 'booked'
        WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 'locked'
        ELSE 'available'
    END AS availability_status,
    b.user_id AS locked_by,
    b.id AS booking_id,
    b.locked_at,
    b.session_id AS locked_by_session -- newly added column safely at the end
FROM seats s
CROSS JOIN shows sh
LEFT JOIN LATERAL (
    SELECT * FROM bookings 
    WHERE seat_id = s.id 
      AND show_id = sh.id 
      AND (
          status = 'confirmed' 
          OR (status = 'locked' AND locked_at >= NOW() - INTERVAL '5 minutes')
      )
    ORDER BY locked_at DESC
    LIMIT 1
) b ON true
WHERE s.screen_id = sh.screen_id;

-- Recreate event_seat_availability view to include session_id
CREATE OR REPLACE VIEW event_seat_availability AS
SELECT 
    es.id AS event_show_id,
    es.event_id,
    e.title AS event_title,
    s.id AS seat_id,
    s.screen_id,
    s.row,
    s.col,
    s.tier,
    COALESCE(s.price, es.price) AS effective_price,
    b.id AS booking_id,
    b.user_id AS locked_by,
    b.locked_at,
    CASE 
        WHEN b.status = 'confirmed' THEN 'booked'
        WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 'locked'
        ELSE 'available'
    END AS availability_status,
    b.session_id AS locked_by_session -- newly added column safely at the end
FROM event_shows es
JOIN events e ON e.id = es.event_id
JOIN seats s ON s.screen_id = es.screen_id
LEFT JOIN LATERAL (
    SELECT * FROM bookings
    WHERE seat_id = s.id
      AND event_show_id = es.id
      AND (
          status = 'confirmed'
          OR (status = 'locked' AND locked_at >= NOW() - INTERVAL '5 minutes')
      )
    ORDER BY
        CASE WHEN status = 'confirmed' THEN 0 ELSE 1 END,
        locked_at DESC
    LIMIT 1
) b ON true;


-- Migration: Upgrade Owner Dashboard to support events
-- Replaces old RPC functions to unify shows and event_shows datasets

DROP FUNCTION IF EXISTS get_owner_shows(UUID, UUID, DATE);
DROP FUNCTION IF EXISTS get_owner_dashboard_stats(UUID);

CREATE OR REPLACE FUNCTION get_owner_dashboard_stats(p_user_id UUID)
RETURNS TABLE(
    total_theatres BIGINT,
    total_screens BIGINT,
    total_seats BIGINT,
    today_bookings BIGINT,
    today_revenue DECIMAL,
    currently_locked BIGINT,
    today_confirmed BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_theatre_ids UUID[];
    v_today DATE := CURRENT_DATE;
BEGIN
    SELECT ARRAY_AGG(theatre_id) INTO v_theatre_ids
    FROM theater_owners
    WHERE user_id = p_user_id;
    
    IF v_theatre_ids IS NULL THEN
        RETURN QUERY SELECT 0::BIGINT, 0::BIGINT, 0::BIGINT, 0::BIGINT, 0::DECIMAL, 0::BIGINT, 0::BIGINT;
        RETURN;
    END IF;
    
    RETURN QUERY
    WITH owned_screens AS (
        SELECT s.id AS screen_id
        FROM screens s
        WHERE s.theatre_id = ANY(v_theatre_ids)
    ),
    owned_shows AS (
        SELECT sh.id AS show_id, sh.price
        FROM shows sh
        JOIN owned_screens os ON os.screen_id = sh.screen_id
    ),
    owned_event_shows AS (
        SELECT es.id AS event_show_id, es.price
        FROM event_shows es
        JOIN owned_screens os ON os.screen_id = es.screen_id
    ),
    owned_bookings AS (
        SELECT b.*
        FROM bookings b
        WHERE (b.show_id IN (SELECT show_id FROM owned_shows)) OR (b.event_show_id IN (SELECT event_show_id FROM owned_event_shows))
    )
    SELECT
        (SELECT COUNT(*) FROM unnest(v_theatre_ids))::BIGINT AS total_theatres,
        (SELECT COUNT(*) FROM owned_screens)::BIGINT AS total_screens,
        (SELECT COUNT(*) FROM seats WHERE screen_id IN (SELECT screen_id FROM owned_screens))::BIGINT AS total_seats,
        (SELECT COUNT(*) FROM owned_bookings WHERE DATE(created_at) = v_today)::BIGINT AS today_bookings,
        COALESCE((
            SELECT SUM(
                COALESCE(
                    seats.price, 
                    (SELECT price FROM shows WHERE id = b.show_id), 
                    (SELECT price FROM event_shows WHERE id = b.event_show_id), 
                    0
                )
            )
            FROM owned_bookings b
            LEFT JOIN seats ON seats.id = b.seat_id
            WHERE DATE(b.created_at) = v_today AND b.status = 'confirmed'
        ), 0)::DECIMAL AS today_revenue,
        (SELECT COUNT(*) FROM owned_bookings WHERE status = 'locked' AND locked_at >= NOW() - INTERVAL '5 minutes')::BIGINT AS currently_locked,
        (SELECT COUNT(*) FROM owned_bookings WHERE DATE(created_at) = v_today AND status = 'confirmed')::BIGINT AS today_confirmed;
END;
$$;


CREATE OR REPLACE FUNCTION get_owner_shows(
    p_user_id UUID,
    p_theatre_id UUID DEFAULT NULL,
    p_date DATE DEFAULT CURRENT_DATE
)
RETURNS TABLE(
    id UUID,             
    type TEXT,
    title TEXT,          
    screen_name TEXT,
    theatre_name TEXT,
    start_time TIMESTAMPTZ,
    end_time TIMESTAMPTZ,
    base_price DECIMAL,
    total_seats BIGINT,
    booked_seats BIGINT,
    locked_seats BIGINT,
    available_seats BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    WITH all_unified_shows AS (
        SELECT 
            sh.id,
            'movie' AS type,
            m.title,
            sc.name AS screen_name,
            t.name AS theatre_name,
            sh.start_time,
            sh.end_time,
            sh.price AS base_price,
            sc.id AS screen_id,
            t.id AS theatre_id
        FROM shows sh
        JOIN movies m ON m.id = sh.movie_id
        JOIN screens sc ON sc.id = sh.screen_id
        JOIN theatres t ON t.id = sc.theatre_id
        
        UNION ALL
        
        SELECT 
            es.id,
            'event' AS type,
            e.title,
            sc.name AS screen_name,
            t.name AS theatre_name,
            es.start_time,
            es.end_time,
            es.price AS base_price,
            sc.id AS screen_id,
            t.id AS theatre_id
        FROM event_shows es
        JOIN events e ON e.id = es.event_id
        JOIN screens sc ON sc.id = es.screen_id
        JOIN theatres t ON t.id = sc.theatre_id
    )
    SELECT 
        u.id,
        u.type,
        u.title,
        u.screen_name,
        u.theatre_name,
        u.start_time,
        u.end_time,
        u.base_price,
        COUNT(DISTINCT seats.id) AS total_seats,
        COUNT(DISTINCT CASE WHEN b.status = 'confirmed' THEN b.id END) AS booked_seats,
        COUNT(DISTINCT CASE WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN b.id END) AS locked_seats,
        COUNT(DISTINCT seats.id) - COUNT(DISTINCT CASE WHEN b.status = 'confirmed' OR (b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes') THEN b.id END) AS available_seats
    FROM all_unified_shows u
    JOIN theater_owners to_owner ON to_owner.theatre_id = u.theatre_id
    LEFT JOIN seats ON seats.screen_id = u.screen_id
    LEFT JOIN bookings b ON ( (b.show_id = u.id AND u.type = 'movie') OR (b.event_show_id = u.id AND u.type = 'event') ) AND b.seat_id = seats.id AND b.status IN ('confirmed', 'locked')
    WHERE to_owner.user_id = p_user_id
        AND (p_theatre_id IS NULL OR u.theatre_id = p_theatre_id)
        AND DATE(u.start_time) = p_date
    GROUP BY u.id, u.type, u.title, u.screen_name, u.theatre_name, u.start_time, u.end_time, u.base_price
    ORDER BY u.start_time;
END;
$$;

GRANT EXECUTE ON FUNCTION get_owner_shows(UUID, UUID, DATE) TO authenticated;
GRANT EXECUTE ON FUNCTION get_owner_dashboard_stats(UUID) TO authenticated;


-- Migration: Admin Financials & Owner Revenue Breakdown (STABILIZED)
-- Fixes grouping ambiguities and performance bottlenecks

-- Platform Wide Stats
CREATE OR REPLACE FUNCTION get_admin_dashboard_stats()
RETURNS TABLE(
    total_revenue NUMERIC,
    total_bookings BIGINT,
    total_theatres BIGINT,
    total_owners BIGINT,
    today_revenue NUMERIC,
    today_bookings BIGINT,
    active_locks BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Only admins
    IF NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;

    RETURN QUERY
    WITH revenue_calc AS (
        -- Combine all booking sources for a unified calc
        SELECT 
            b.id,
            b.status,
            b.created_at,
            b.locked_at,
            COALESCE(
                seats.price, 
                sh.price, 
                es.price, 
                0
            ) as seat_price
        FROM bookings b
        LEFT JOIN seats ON seats.id = b.seat_id
        LEFT JOIN shows sh ON sh.id = b.show_id
        LEFT JOIN event_shows es ON es.id = b.event_show_id
    )
    SELECT
        COALESCE(SUM(seat_price) FILTER (WHERE status = 'confirmed'), 0)::NUMERIC,
        COUNT(*) FILTER (WHERE status = 'confirmed')::BIGINT,
        (SELECT COUNT(*) FROM theatres)::BIGINT,
        (SELECT COUNT(DISTINCT user_id) FROM theater_owners)::BIGINT,
        COALESCE(SUM(seat_price) FILTER (WHERE status = 'confirmed' AND DATE(created_at) = CURRENT_DATE), 0)::NUMERIC,
        COUNT(*) FILTER (WHERE status = 'confirmed' AND DATE(created_at) = CURRENT_DATE)::BIGINT,
        COUNT(*) FILTER (WHERE status = 'locked' AND locked_at >= NOW() - INTERVAL '10 minutes')::BIGINT
    FROM revenue_calc;
END;
$$;

-- Owner Revenue Breakdown
CREATE OR REPLACE FUNCTION get_admin_owner_revenue_breakdown(p_start_date DATE DEFAULT NULL, p_end_date DATE DEFAULT NULL)
RETURNS TABLE(
    owner_id UUID,
    owner_email TEXT,
    owner_name TEXT,
    theatre_names TEXT,
    revenue NUMERIC,
    booking_count BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Only admins
    IF NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;

    RETURN QUERY
    WITH owner_theatres AS (
        SELECT 
            to_owner.user_id,
            t.id as theatre_id,
            t.name as theatre_name,
            oa.email as user_email,
            oa.full_name as user_name
        FROM theater_owners to_owner
        JOIN theatres t ON t.id = to_owner.theatre_id
        LEFT JOIN owner_applications oa ON oa.user_id = to_owner.user_id AND oa.status = 'approved'
    ),
    all_owner_bookings AS (
        -- Select all confirmed bookings associated with owner theatres
        SELECT 
            ot.user_id,
            ot.user_email,
            ot.user_name,
            ot.theatre_name,
            b.id as booking_id,
            COALESCE(seats.price, sh.price, es.price, 0) as booking_price
        FROM bookings b
        LEFT JOIN shows sh ON sh.id = b.show_id
        LEFT JOIN event_shows es ON es.id = b.event_show_id
        JOIN screens s ON s.id = COALESCE(sh.screen_id, es.screen_id)
        JOIN owner_theatres ot ON ot.theatre_id = s.theatre_id
        LEFT JOIN seats ON seats.id = b.seat_id
        WHERE b.status = 'confirmed'
          AND (p_start_date IS NULL OR DATE(b.created_at) >= p_start_date)
          AND (p_end_date IS NULL OR DATE(b.created_at) <= p_end_date)
    )
    SELECT 
        user_id as owner_id,
        COALESCE(user_email, 'N/A') as owner_email,
        COALESCE(user_name, 'Unknown Owner') as owner_name,
        string_agg(DISTINCT theatre_name, ', ') as theatre_names,
        SUM(booking_price)::NUMERIC as revenue,
        COUNT(DISTINCT booking_id)::BIGINT as booking_count
    FROM all_owner_bookings
    GROUP BY user_id, user_email, user_name
    ORDER BY revenue DESC;
END;
$$;

GRANT EXECUTE ON FUNCTION get_admin_dashboard_stats() TO authenticated;
GRANT EXECUTE ON FUNCTION get_admin_owner_revenue_breakdown(DATE, DATE) TO authenticated;


