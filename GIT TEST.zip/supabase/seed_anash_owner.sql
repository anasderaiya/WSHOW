-- ============================================================
-- THEATRE OWNER & SUPER ADMIN SEED SCRIPT FOR ANASH
-- Quick My Ticket — Supabase SQL Editor
-- ============================================================
-- Purpose: Assign anashderaiya@gmail.com as the 'owner' role
--          for ALL theatres and grant Super Admin privilege.
--
-- Steps:
--   1. Open your Supabase Dashboard
--   2. Go to SQL Editor -> New Query
--   3. Paste this entire script and click "Run"
--   4. Refresh your local website dashboard page!
-- ============================================================

DO $$
DECLARE
  v_user_id UUID;
  v_theatre RECORD;
  v_count INT := 0;
BEGIN
  -- Resolve the user's UUID from their email
  SELECT id INTO v_user_id
  FROM auth.users
  WHERE email = 'anashderaiya@gmail.com'
  LIMIT 1;

  IF v_user_id IS NULL THEN
    RAISE NOTICE '❌ User anashderaiya@gmail.com not found in auth.users.';
    RAISE NOTICE '   Please sign up first at http://localhost:3001/login, then run this script again.';
    RETURN;
  END IF;

  RAISE NOTICE '✅ Found user UUID: %', v_user_id;

  -- 1. Insert/update role to 'owner' for all theatres
  FOR v_theatre IN SELECT id, name FROM theatres LOOP
    INSERT INTO theater_owners (user_id, theatre_id, role)
    VALUES (v_user_id, v_theatre.id, 'owner')
    ON CONFLICT (user_id, theatre_id) DO UPDATE
      SET role = 'owner', updated_at = NOW();

    v_count := v_count + 1;
    RAISE NOTICE '  ✓ Assigned owner role for theatre: % (%)', v_theatre.name, v_theatre.id;
  END LOOP;

  -- 2. Elevate user metadata to is_admin = true for dashboard bypass
  UPDATE auth.users
  SET raw_app_meta_data = raw_app_meta_data || '{"is_admin": true}'::jsonb,
      raw_user_meta_data = raw_user_meta_data || '{"full_name": "Anash Deraiya"}'::jsonb,
      email_confirmed_at = COALESCE(email_confirmed_at, NOW())
  WHERE id = v_user_id;

  RAISE NOTICE '';
  RAISE NOTICE '🎉 SUCCESS! anashderaiya@gmail.com is now the Owner of % theatre(s) and a Super Admin.', v_count;
  RAISE NOTICE '   Refresh your browser and access: http://localhost:3001/dashboard';

EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE '❌ Error: %', SQLERRM;
END;
$$;
