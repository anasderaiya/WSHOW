-- Migration: Production Hardening
-- Adds structural auditing and performance optimizations

-- 1. Create Transaction Logs Table for Financial Auditing
CREATE TABLE IF NOT EXISTS transaction_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
    user_id UUID, -- NULL for guest
    session_id TEXT, -- For guest tracking
    payment_provider TEXT DEFAULT 'internal',
    provider_transaction_id TEXT,
    amount NUMERIC(10, 2) NOT NULL,
    currency TEXT DEFAULT 'INR',
    status TEXT DEFAULT 'success' CHECK (status IN ('success', 'refunded', 'failed', 'pending')),
    metadata JSONB DEFAULT '{}'::JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS on transaction_logs
ALTER TABLE transaction_logs ENABLE ROW LEVEL SECURITY;

-- Policies for transaction_logs
CREATE POLICY "Admins full access trans_logs" ON transaction_logs 
    FOR ALL USING ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true);

CREATE POLICY "Users view own trans_logs" ON transaction_logs 
    FOR SELECT USING (auth.uid() = user_id OR session_id = (SELECT session_id FROM bookings WHERE id = booking_id));

-- 2. Audit Trail Trigger
-- Automatically logs when a booking is confirmed
CREATE OR REPLACE FUNCTION audit_confirmed_booking()
RETURNS TRIGGER AS $$
DECLARE
    v_amount NUMERIC;
BEGIN
    IF (NEW.status = 'confirmed' AND (OLD.status IS NULL OR OLD.status != 'confirmed')) THEN
        -- Get the amount for this booking
        SELECT COALESCE(seats.price, sh.price, es.price, 0) INTO v_amount
        FROM bookings b
        LEFT JOIN seats ON seats.id = b.seat_id
        LEFT JOIN shows sh ON sh.id = b.show_id
        LEFT JOIN event_shows es ON es.id = b.event_show_id
        WHERE b.id = NEW.id;

        INSERT INTO transaction_logs (
            booking_id, 
            user_id, 
            session_id, 
            payment_provider, 
            provider_transaction_id, 
            amount,
            metadata
        ) VALUES (
            NEW.id,
            NEW.user_id,
            NEW.session_id,
            'internal', -- Update this when real provider is added
            NEW.payment_id,
            COALESCE(v_amount, 0),
            jsonb_build_object('source', 'auto_audit_trigger', 'timestamp', NOW())
        );
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER trg_audit_booking_confirmation
AFTER UPDATE ON bookings
FOR EACH ROW
EXECUTE FUNCTION audit_confirmed_booking();

-- 3. High-Performance Indexing Strategy
-- Composite indexes for financial reporting and real-time dashboard performance

-- Optimization for: get_admin_dashboard_stats & get_owner_dashboard_stats
CREATE INDEX IF NOT EXISTS idx_bookings_financial_stat 
ON bookings (status, created_at) 
INCLUDE (show_id, event_show_id);

-- Optimization for: get_admin_owner_revenue_breakdown
CREATE INDEX IF NOT EXISTS idx_bookings_owner_reporting 
ON bookings (show_id, event_show_id) 
WHERE status = 'confirmed';

-- Optimization for: Seat Availability Views
CREATE INDEX IF NOT EXISTS idx_bookings_availability_lookup 
ON bookings (show_id, seat_id, status) 
WHERE status IN ('locked', 'confirmed');

CREATE INDEX IF NOT EXISTS idx_bookings_availability_event_lookup 
ON bookings (event_show_id, seat_id, status) 
WHERE status IN ('locked', 'confirmed');

-- Optimization for: Dashboard card counts
CREATE INDEX IF NOT EXISTS idx_bookings_realtime_badge 
ON bookings (show_id, status) 
WHERE status = 'confirmed';

CREATE INDEX IF NOT EXISTS idx_bookings_realtime_event_badge 
ON bookings (event_show_id, status) 
WHERE status = 'confirmed';

-- Optimization for: Show lookup performance
CREATE INDEX IF NOT EXISTS idx_shows_screen_time 
ON shows (screen_id, start_time);

CREATE INDEX IF NOT EXISTS idx_event_shows_screen_time 
ON event_shows (screen_id, start_time);

-- 4. Admin Security Hardening
-- Ensure RPCs are strictly restricted
GRANT SELECT ON transaction_logs TO authenticated;
GRANT SELECT ON transaction_logs TO anon; -- Allow guest to potentially view their own receipt


-- ============================================
-- Quick My Ticket - Fix Seat Layout Editor Save
-- Migration 019
-- ============================================

CREATE OR REPLACE FUNCTION update_screen_layout(
    p_screen_id UUID,
    p_seat_layout JSONB
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_theatre_id UUID;
    v_is_owner BOOLEAN;
BEGIN
    IF p_seat_layout IS NULL
       OR jsonb_typeof(p_seat_layout->'rows') IS DISTINCT FROM 'array' THEN
        RETURN json_build_object('success', false, 'error', 'Invalid seat layout');
    END IF;

    SELECT theatre_id INTO v_theatre_id
    FROM screens
    WHERE id = p_screen_id;

    IF v_theatre_id IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Screen not found');
    END IF;

    SELECT EXISTS(
        SELECT 1 FROM theater_owners
        WHERE user_id = v_user_id AND theatre_id = v_theatre_id
    ) INTO v_is_owner;

    IF NOT v_is_owner AND NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RETURN json_build_object('success', false, 'error', 'Access denied');
    END IF;

    IF EXISTS (
        SELECT 1 FROM bookings b
        JOIN shows s ON b.show_id = s.id
        WHERE s.screen_id = p_screen_id AND b.status IN ('confirmed', 'locked')

        UNION ALL

        SELECT 1 FROM bookings b
        JOIN event_shows es ON b.event_show_id = es.id
        WHERE es.screen_id = p_screen_id AND b.status IN ('confirmed', 'locked')
    ) THEN
        RETURN json_build_object('success', false, 'error', 'Cannot update layout: Active bookings exist for this screen');
    END IF;

    UPDATE screens
    SET
        seat_layout = p_seat_layout,
        rows = COALESCE((p_seat_layout->'metadata'->>'rowCount')::integer, rows),
        seats_per_row = COALESCE((p_seat_layout->'metadata'->>'maxSeatsPerRow')::integer, seats_per_row)
    WHERE id = p_screen_id;

    DELETE FROM seats WHERE screen_id = p_screen_id;

    INSERT INTO seats (screen_id, row, col, tier, price)
    SELECT
        p_screen_id,
        r->>'label',
        (s->>'id')::integer,
        s->>'type',
        (s->>'price')::integer
    FROM jsonb_array_elements(p_seat_layout->'rows') AS r
    CROSS JOIN jsonb_array_elements(r->'seats') AS s
    WHERE s IS NOT NULL AND s != 'null'::jsonb;

    RETURN json_build_object('success', true, 'message', 'Layout updated and seats synced');
END;
$$;

GRANT EXECUTE ON FUNCTION update_screen_layout(UUID, JSONB) TO authenticated;


-- ============================================
-- Quick My Ticket - Fix Seat Availability Screen Scope
-- Migration 020
-- ============================================
-- Migration 015 accidentally allowed movie seat availability to cross join
-- seats from every screen into every show. That made booking pages render
-- repeated seat numbers from unrelated screens.

CREATE OR REPLACE VIEW seat_availability AS
SELECT
    s.id AS seat_id,
    s.screen_id,
    s.row,
    s.col,
    s.tier,
    s.price AS seat_price,
    sh.id AS show_id,
    sh.price AS show_price,
    COALESCE(s.price, sh.price, 0) AS effective_price,
    CASE
        WHEN b.status = 'confirmed' THEN 'booked'
        WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 'locked'
        ELSE 'available'
    END AS availability_status,
    b.user_id AS locked_by,
    b.id AS booking_id,
    b.locked_at,
    b.session_id AS locked_by_session
FROM shows sh
JOIN seats s ON s.screen_id = sh.screen_id
LEFT JOIN LATERAL (
    SELECT *
    FROM bookings
    WHERE seat_id = s.id
      AND show_id = sh.id
      AND (
          status = 'confirmed'
          OR (status = 'locked' AND locked_at >= NOW() - INTERVAL '5 minutes')
      )
    ORDER BY
        CASE WHEN status = 'confirmed' THEN 0 ELSE 1 END,
        locked_at DESC
    LIMIT 1
) b ON true;

CREATE OR REPLACE VIEW event_seat_availability AS
SELECT
    es.id AS event_show_id,
    es.event_id,
    e.title AS event_title,
    s.id AS seat_id,
    s.screen_id,
    s.row,
    s.col,
    s.tier,
    COALESCE(s.price, es.price) AS effective_price,
    b.id AS booking_id,
    b.user_id AS locked_by,
    b.locked_at,
    CASE
        WHEN b.status = 'confirmed' THEN 'booked'
        WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 'locked'
        ELSE 'available'
    END AS availability_status,
    b.session_id AS locked_by_session
FROM event_shows es
JOIN events e ON e.id = es.event_id
JOIN seats s ON s.screen_id = es.screen_id
LEFT JOIN LATERAL (
    SELECT *
    FROM bookings
    WHERE seat_id = s.id
      AND event_show_id = es.id
      AND (
          status = 'confirmed'
          OR (status = 'locked' AND locked_at >= NOW() - INTERVAL '5 minutes')
      )
    ORDER BY
        CASE WHEN status = 'confirmed' THEN 0 ELSE 1 END,
        locked_at DESC
    LIMIT 1
) b ON true;

GRANT SELECT ON seat_availability TO authenticated;
GRANT SELECT ON seat_availability TO anon;
GRANT SELECT ON event_seat_availability TO authenticated;
GRANT SELECT ON event_seat_availability TO anon;


-- ============================================
-- Quick My Ticket - Repair Shows on Unconfigured Duplicate Screens
-- Migration 021
-- ============================================
-- Some theatres have duplicate screen names where one screen has a saved layout
-- and seats, while the duplicate has neither. Shows attached to the empty
-- duplicate cannot render or book seats. This moves unbooked shows/event shows
-- from empty duplicates to the configured screen with the same theatre + name.

WITH screen_seat_counts AS (
    SELECT
        s.id,
        s.theatre_id,
        s.name,
        s.seat_layout,
        COUNT(seats.id) AS seat_count
    FROM screens s
    LEFT JOIN seats ON seats.screen_id = s.id
    GROUP BY s.id, s.theatre_id, s.name, s.seat_layout
),
empty_screens AS (
    SELECT *
    FROM screen_seat_counts
    WHERE seat_layout IS NULL
      AND seat_count = 0
),
configured_screens AS (
    SELECT *
    FROM screen_seat_counts
    WHERE seat_layout IS NOT NULL
      AND seat_count > 0
),
screen_replacements AS (
    SELECT DISTINCT ON (empty_screens.id)
        empty_screens.id AS empty_screen_id,
        configured_screens.id AS configured_screen_id
    FROM empty_screens
    JOIN configured_screens
      ON configured_screens.theatre_id = empty_screens.theatre_id
     AND configured_screens.name = empty_screens.name
    ORDER BY
        empty_screens.id,
        configured_screens.seat_count DESC,
        configured_screens.id
)
UPDATE shows
SET screen_id = screen_replacements.configured_screen_id
FROM screen_replacements
WHERE shows.screen_id = screen_replacements.empty_screen_id
  AND NOT EXISTS (
      SELECT 1
      FROM bookings b
      WHERE b.show_id = shows.id
        AND b.status IN ('confirmed', 'locked')
  );

WITH screen_seat_counts AS (
    SELECT
        s.id,
        s.theatre_id,
        s.name,
        s.seat_layout,
        COUNT(seats.id) AS seat_count
    FROM screens s
    LEFT JOIN seats ON seats.screen_id = s.id
    GROUP BY s.id, s.theatre_id, s.name, s.seat_layout
),
empty_screens AS (
    SELECT *
    FROM screen_seat_counts
    WHERE seat_layout IS NULL
      AND seat_count = 0
),
configured_screens AS (
    SELECT *
    FROM screen_seat_counts
    WHERE seat_layout IS NOT NULL
      AND seat_count > 0
),
screen_replacements AS (
    SELECT DISTINCT ON (empty_screens.id)
        empty_screens.id AS empty_screen_id,
        configured_screens.id AS configured_screen_id
    FROM empty_screens
    JOIN configured_screens
      ON configured_screens.theatre_id = empty_screens.theatre_id
     AND configured_screens.name = empty_screens.name
    ORDER BY
        empty_screens.id,
        configured_screens.seat_count DESC,
        configured_screens.id
)
UPDATE event_shows
SET screen_id = screen_replacements.configured_screen_id
FROM screen_replacements
WHERE event_shows.screen_id = screen_replacements.empty_screen_id
  AND NOT EXISTS (
      SELECT 1
      FROM bookings b
      WHERE b.event_show_id = event_shows.id
        AND b.status IN ('confirmed', 'locked')
  );


-- ============================================
-- Quick My Ticket - Fix all Seat Layout RPCs
-- Migration 022 (FINAL FIX)
-- ============================================

-- First, drop existing functions to ensure we are starting fresh
DROP FUNCTION IF EXISTS update_screen_layout(UUID, JSONB);
DROP FUNCTION IF EXISTS get_screen_layout(UUID);

-- 1. Fix update_screen_layout
CREATE OR REPLACE FUNCTION update_screen_layout(
    p_screen_id UUID,
    p_seat_layout JSONB
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_theatre_id UUID;
    v_is_owner BOOLEAN;
BEGIN
    -- Validation
    IF p_seat_layout IS NULL 
       OR jsonb_typeof(p_seat_layout->'rows') IS DISTINCT FROM 'array' THEN
        RETURN json_build_object('success', false, 'error', 'Invalid seat layout');
    END IF;

    -- Find theatre and check permissions
    SELECT theatre_id INTO v_theatre_id
    FROM screens
    WHERE id = p_screen_id;

    IF v_theatre_id IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Screen not found');
    END IF;

    SELECT EXISTS(
        SELECT 1 FROM theater_owners
        WHERE user_id = v_user_id AND theatre_id = v_theatre_id
    ) INTO v_is_owner;

    IF NOT v_is_owner AND NOT (COALESCE((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean, false) = true) THEN
        RETURN json_build_object('success', false, 'error', 'Access denied');
    END IF;

    -- Check for active bookings
    IF EXISTS (
        SELECT 1 FROM bookings b
        JOIN shows s ON b.show_id = s.id
        WHERE s.screen_id = p_screen_id AND b.status IN ('confirmed', 'locked')
        
        UNION ALL
        
        SELECT 1 FROM bookings b
        JOIN event_shows es ON b.event_show_id = es.id
        WHERE es.screen_id = p_screen_id AND b.status IN ('confirmed', 'locked')
    ) THEN
        RETURN json_build_object('success', false, 'error', 'Cannot update layout: Active bookings exist for this screen');
    END IF;

    -- Update screen (using verified columns: seat_layout, total_seats)
    UPDATE screens
    SET 
        seat_layout = p_seat_layout,
        total_seats = COALESCE((p_seat_layout->'metadata'->>'totalSeats')::integer, total_seats)
    WHERE id = p_screen_id;

    -- Sync seats table
    DELETE FROM seats WHERE screen_id = p_screen_id;

    INSERT INTO seats (screen_id, row, col, tier, price)
    SELECT 
        p_screen_id,
        r->>'label',
        (s->>'id')::integer,
        s->>'type',
        (s->>'price')::integer
    FROM jsonb_array_elements(p_seat_layout->'rows') AS r
    CROSS JOIN jsonb_array_elements(r->'seats') AS s
    WHERE s IS NOT NULL AND s != 'null'::jsonb;

    RETURN json_build_object('success', true, 'message', 'Layout updated and seats synced');
END;
$$;

-- 2. Fix get_screen_layout
CREATE OR REPLACE FUNCTION get_screen_layout(p_screen_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_layout JSONB;
BEGIN
    -- Only select columns that actually exist!
    SELECT seat_layout
    INTO v_layout
    FROM screens
    WHERE id = p_screen_id;
    
    -- If custom layout exists, return it
    IF v_layout IS NOT NULL THEN
        RETURN v_layout;
    END IF;
    
    -- If no layout, return a simple 10x12 default
    RETURN generate_default_layout(10, 12);
END;
$$;

GRANT EXECUTE ON FUNCTION update_screen_layout(UUID, JSONB) TO authenticated;
GRANT EXECUTE ON FUNCTION get_screen_layout(UUID) TO anon, authenticated;


-- ============================================
-- Quick My Ticket - Restrict calculate_booking_total
-- Migration 023
-- ============================================
-- SECURITY: calculate_booking_total touches pricing and runs as
-- SECURITY DEFINER. It should only be callable by service_role
-- (Edge Functions), never directly by authenticated or anon users.

REVOKE ALL ON FUNCTION calculate_booking_total(UUID[], DECIMAL) FROM PUBLIC;
REVOKE ALL ON FUNCTION calculate_booking_total(UUID[], DECIMAL) FROM authenticated;
REVOKE ALL ON FUNCTION calculate_booking_total(UUID[], DECIMAL) FROM anon;
GRANT EXECUTE ON FUNCTION calculate_booking_total(UUID[], DECIMAL) TO service_role;


-- Migration: Dashboard Performance Optimization
-- Adds critical foreign key indexes and rewrites RPCs for sub-second execution

-- 1. Create missing foreign key indexes to eliminate sequential scans
CREATE INDEX IF NOT EXISTS idx_bookings_show_id ON bookings(show_id);
CREATE INDEX IF NOT EXISTS idx_bookings_event_show_id ON bookings(event_show_id);

-- Add Composite Power Indexes targeting exactly the WHERE clauses used in stats
CREATE INDEX IF NOT EXISTS idx_bookings_perf_confirmed 
ON bookings (status, created_at) 
WHERE status = 'confirmed';

CREATE INDEX IF NOT EXISTS idx_bookings_perf_locked 
ON bookings (status, locked_at) 
WHERE status = 'locked';

-- 2. Rewrite get_owner_dashboard_stats to avoid CTEs, OR clauses, and DATE() functions
CREATE OR REPLACE FUNCTION get_owner_dashboard_stats(p_user_id UUID)
RETURNS TABLE(
    total_theatres BIGINT,
    total_screens BIGINT,
    total_seats BIGINT,
    today_bookings BIGINT,
    today_revenue DECIMAL,
    currently_locked BIGINT,
    today_confirmed BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_theatre_ids UUID[];
    v_today DATE := CURRENT_DATE;
BEGIN
    SELECT ARRAY_AGG(theatre_id) INTO v_theatre_ids
    FROM theater_owners
    WHERE user_id = p_user_id;
    
    IF v_theatre_ids IS NULL THEN
        RETURN QUERY SELECT 0::BIGINT, 0::BIGINT, 0::BIGINT, 0::BIGINT, 0::DECIMAL, 0::BIGINT, 0::BIGINT;
        RETURN;
    END IF;

    RETURN QUERY
    WITH screen_data AS (
        SELECT s.id as screen_id, 
               (SELECT COUNT(*) FROM seats WHERE screen_id = s.id) as seat_count
        FROM screens s
        WHERE s.theatre_id = ANY(v_theatre_ids)
    ),
    movie_stats AS (
        SELECT 
            SUM(CASE WHEN b.created_at >= v_today AND b.created_at < (v_today + interval '1 day') THEN 1 ELSE 0 END) AS today_bookings,
            SUM(CASE WHEN b.created_at >= v_today AND b.created_at < (v_today + interval '1 day') AND b.status = 'confirmed' THEN COALESCE(seats.price, sh.price, 0) ELSE 0 END) AS today_revenue,
            SUM(CASE WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 1 ELSE 0 END) AS currently_locked,
            SUM(CASE WHEN b.created_at >= v_today AND b.created_at < (v_today + interval '1 day') AND b.status = 'confirmed' THEN 1 ELSE 0 END) AS today_confirmed
        FROM shows sh
        JOIN screen_data sd ON sd.screen_id = sh.screen_id
        JOIN bookings b ON b.show_id = sh.id
        LEFT JOIN seats ON seats.id = b.seat_id
    ),
    event_stats AS (
        SELECT 
            SUM(CASE WHEN b.created_at >= v_today AND b.created_at < (v_today + interval '1 day') THEN 1 ELSE 0 END) AS today_bookings,
            SUM(CASE WHEN b.created_at >= v_today AND b.created_at < (v_today + interval '1 day') AND b.status = 'confirmed' THEN COALESCE(seats.price, es.price, 0) ELSE 0 END) AS today_revenue,
            SUM(CASE WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 1 ELSE 0 END) AS currently_locked,
            SUM(CASE WHEN b.created_at >= v_today AND b.created_at < (v_today + interval '1 day') AND b.status = 'confirmed' THEN 1 ELSE 0 END) AS today_confirmed
        FROM event_shows es
        JOIN screen_data sd ON sd.screen_id = es.screen_id
        JOIN bookings b ON b.event_show_id = es.id
        LEFT JOIN seats ON seats.id = b.seat_id
    )
    SELECT
        (SELECT COUNT(*) FROM unnest(v_theatre_ids))::BIGINT AS total_theatres,
        (SELECT COUNT(*) FROM screen_data)::BIGINT AS total_screens,
        (SELECT COALESCE(SUM(seat_count), 0) FROM screen_data)::BIGINT AS total_seats,
        (COALESCE((SELECT today_bookings FROM movie_stats), 0) + COALESCE((SELECT today_bookings FROM event_stats), 0))::BIGINT AS today_bookings,
        (COALESCE((SELECT today_revenue FROM movie_stats), 0) + COALESCE((SELECT today_revenue FROM event_stats), 0))::DECIMAL AS today_revenue,
        (COALESCE((SELECT currently_locked FROM movie_stats), 0) + COALESCE((SELECT currently_locked FROM event_stats), 0))::BIGINT AS currently_locked,
        (COALESCE((SELECT today_confirmed FROM movie_stats), 0) + COALESCE((SELECT today_confirmed FROM event_stats), 0))::BIGINT AS today_confirmed;
END;
$$;

-- 3. Rewrite get_admin_dashboard_stats
CREATE OR REPLACE FUNCTION get_admin_dashboard_stats()
RETURNS TABLE(
    total_revenue NUMERIC,
    total_bookings BIGINT,
    total_theatres BIGINT,
    total_owners BIGINT,
    today_revenue NUMERIC,
    today_bookings BIGINT,
    active_locks BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Only admins
    IF NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;

    RETURN QUERY
    WITH movie_stats AS (
        SELECT
            SUM(COALESCE(seats.price, sh.price, 0)) FILTER (WHERE b.status = 'confirmed') AS total_revenue,
            COUNT(*) FILTER (WHERE b.status = 'confirmed') AS total_bookings,
            SUM(COALESCE(seats.price, sh.price, 0)) FILTER (WHERE b.status = 'confirmed' AND b.created_at >= CURRENT_DATE AND b.created_at < (CURRENT_DATE + interval '1 day')) AS today_revenue,
            COUNT(*) FILTER (WHERE b.status = 'confirmed' AND b.created_at >= CURRENT_DATE AND b.created_at < (CURRENT_DATE + interval '1 day')) AS today_bookings,
            COUNT(*) FILTER (WHERE b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '10 minutes') AS active_locks
        FROM bookings b
        JOIN shows sh ON sh.id = b.show_id
        LEFT JOIN seats ON seats.id = b.seat_id
    ),
    event_stats AS (
        SELECT
            SUM(COALESCE(seats.price, es.price, 0)) FILTER (WHERE b.status = 'confirmed') AS total_revenue,
            COUNT(*) FILTER (WHERE b.status = 'confirmed') AS total_bookings,
            SUM(COALESCE(seats.price, es.price, 0)) FILTER (WHERE b.status = 'confirmed' AND b.created_at >= CURRENT_DATE AND b.created_at < (CURRENT_DATE + interval '1 day')) AS today_revenue,
            COUNT(*) FILTER (WHERE b.status = 'confirmed' AND b.created_at >= CURRENT_DATE AND b.created_at < (CURRENT_DATE + interval '1 day')) AS today_bookings,
            COUNT(*) FILTER (WHERE b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '10 minutes') AS active_locks
        FROM bookings b
        JOIN event_shows es ON es.id = b.event_show_id
        LEFT JOIN seats ON seats.id = b.seat_id
    )
    SELECT
        (COALESCE((SELECT total_revenue FROM movie_stats), 0) + COALESCE((SELECT total_revenue FROM event_stats), 0))::NUMERIC,
        (COALESCE((SELECT total_bookings FROM movie_stats), 0) + COALESCE((SELECT total_bookings FROM event_stats), 0))::BIGINT,
        (SELECT COUNT(*) FROM theatres)::BIGINT,
        (SELECT COUNT(DISTINCT user_id) FROM theater_owners)::BIGINT,
        (COALESCE((SELECT today_revenue FROM movie_stats), 0) + COALESCE((SELECT today_revenue FROM event_stats), 0))::NUMERIC,
        (COALESCE((SELECT today_bookings FROM movie_stats), 0) + COALESCE((SELECT today_bookings FROM event_stats), 0))::BIGINT,
        (COALESCE((SELECT active_locks FROM movie_stats), 0) + COALESCE((SELECT active_locks FROM event_stats), 0))::BIGINT;
END;
$$;

-- 4. Rewrite get_admin_owner_revenue_breakdown
CREATE OR REPLACE FUNCTION get_admin_owner_revenue_breakdown(p_start_date DATE DEFAULT NULL, p_end_date DATE DEFAULT NULL)
RETURNS TABLE(
    owner_id UUID,
    owner_email TEXT,
    owner_name TEXT,
    theatre_names TEXT,
    revenue NUMERIC,
    booking_count BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Only admins
    IF NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;

    RETURN QUERY
    WITH owner_theatres AS (
        SELECT 
            to_owner.user_id,
            t.id as theatre_id,
            t.name as theatre_name,
            oa.email as user_email,
            oa.full_name as user_name
        FROM theater_owners to_owner
        JOIN theatres t ON t.id = to_owner.theatre_id
        LEFT JOIN owner_applications oa ON oa.user_id = to_owner.user_id AND oa.status = 'approved'
    ),
    movie_bookings AS (
        SELECT 
            s.theatre_id,
            COUNT(b.id) as booking_count,
            SUM(COALESCE(seats.price, sh.price, 0)) as revenue
        FROM bookings b
        JOIN shows sh ON sh.id = b.show_id
        JOIN screens s ON s.id = sh.screen_id
        LEFT JOIN seats ON seats.id = b.seat_id
        WHERE b.status = 'confirmed' 
            AND (p_start_date IS NULL OR b.created_at >= p_start_date)
            AND (p_end_date IS NULL OR b.created_at < (p_end_date + INTERVAL '1 day'))
        GROUP BY s.theatre_id
    ),
    event_bookings AS (
        SELECT 
            s.theatre_id,
            COUNT(b.id) as booking_count,
            SUM(COALESCE(seats.price, es.price, 0)) as revenue
        FROM bookings b
        JOIN event_shows es ON es.id = b.event_show_id
        JOIN screens s ON s.id = es.screen_id
        LEFT JOIN seats ON seats.id = b.seat_id
        WHERE b.status = 'confirmed' 
            AND (p_start_date IS NULL OR b.created_at >= p_start_date)
            AND (p_end_date IS NULL OR b.created_at < (p_end_date + INTERVAL '1 day'))
        GROUP BY s.theatre_id
    )
    SELECT 
        ot.user_id as owner_id,
        MAX(ot.user_email) as owner_email,
        MAX(ot.user_name) as owner_name,
        STRING_AGG(DISTINCT ot.theatre_name, ', ') as theatre_names,
        COALESCE(SUM(mb.revenue), 0) + COALESCE(SUM(eb.revenue), 0) as revenue,
        COALESCE(SUM(mb.booking_count), 0) + COALESCE(SUM(eb.booking_count), 0) as booking_count
    FROM owner_theatres ot
    LEFT JOIN movie_bookings mb ON mb.theatre_id = ot.theatre_id
    LEFT JOIN event_bookings eb ON eb.theatre_id = ot.theatre_id
    GROUP BY ot.user_id
    ORDER BY revenue DESC;
END;
$$;

-- 5. Optimize get_owner_shows
DROP FUNCTION IF EXISTS get_owner_shows(UUID, UUID, DATE);

CREATE OR REPLACE FUNCTION get_owner_shows(
    p_user_id UUID,
    p_theatre_id UUID DEFAULT NULL,
    p_date DATE DEFAULT CURRENT_DATE
)
RETURNS TABLE(
    id UUID,             
    type TEXT,
    title TEXT,          
    screen_name TEXT,
    theatre_name TEXT,
    start_time TIMESTAMPTZ,
    end_time TIMESTAMPTZ,
    base_price DECIMAL,
    total_seats BIGINT,
    booked_seats BIGINT,
    locked_seats BIGINT,
    available_seats BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    WITH owner_theatres AS (
        SELECT theatre_id 
        FROM theater_owners 
        WHERE user_id = p_user_id 
          AND (p_theatre_id IS NULL OR theatre_id = p_theatre_id)
    ),
    filtered_movies AS (
        SELECT 
            sh.id,
            'movie' AS type,
            m.title,
            sc.name AS screen_name,
            t.name AS theatre_name,
            sh.start_time,
            sh.end_time,
            sh.price AS base_price,
            sc.id AS screen_id,
            t.id AS theatre_id
        FROM shows sh
        JOIN movies m ON m.id = sh.movie_id
        JOIN screens sc ON sc.id = sh.screen_id
        JOIN theatres t ON t.id = sc.theatre_id
        WHERE sc.theatre_id IN (SELECT theatre_id FROM owner_theatres)
          AND sh.start_time >= p_date AND sh.start_time < (p_date + interval '1 day')
    ),
    filtered_events AS (
        SELECT 
            es.id,
            'event' AS type,
            e.title,
            sc.name AS screen_name,
            t.name AS theatre_name,
            es.start_time,
            es.end_time,
            es.price AS base_price,
            sc.id AS screen_id,
            t.id AS theatre_id
        FROM event_shows es
        JOIN events e ON e.id = es.event_id
        JOIN screens sc ON sc.id = es.screen_id
        JOIN theatres t ON t.id = sc.theatre_id
        WHERE sc.theatre_id IN (SELECT theatre_id FROM owner_theatres)
          AND es.start_time >= p_date AND es.start_time < (p_date + interval '1 day')
    ),
    all_unified_shows AS (
        SELECT * FROM filtered_movies
        UNION ALL
        SELECT * FROM filtered_events
    )
    SELECT 
        u.id,
        u.type,
        u.title,
        u.screen_name,
        u.theatre_name,
        u.start_time,
        u.end_time,
        u.base_price,
        (SELECT COUNT(*) FROM seats WHERE screen_id = u.screen_id)::BIGINT AS total_seats,
        (SELECT COUNT(*) FROM bookings b WHERE (b.show_id = u.id OR b.event_show_id = u.id) AND b.status = 'confirmed')::BIGINT AS booked_seats,
        (SELECT COUNT(*) FROM bookings b WHERE (b.show_id = u.id OR b.event_show_id = u.id) AND b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes')::BIGINT AS locked_seats,
        ((SELECT COUNT(*) FROM seats WHERE screen_id = u.screen_id) - 
         (SELECT COUNT(*) FROM bookings b WHERE (b.show_id = u.id OR b.event_show_id = u.id) AND b.status IN ('confirmed', 'locked') AND (b.status = 'confirmed' OR (b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes'))))::BIGINT AS available_seats
    FROM all_unified_shows u
    ORDER BY u.start_time;
END;
$$;



-- ============================================
-- Quick My Ticket - Security Hardening
-- Migration 025
-- ============================================

-- 1. ENABLE RLS ON REMAINING TABLES
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.seats ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.movies ENABLE ROW LEVEL SECURITY;

-- 2. BOOKINGS POLICIES
DROP POLICY IF EXISTS "Users view own bookings" ON public.bookings;
CREATE POLICY "Users view own bookings" ON public.bookings
    FOR SELECT USING (
        auth.uid() = user_id OR 
        (user_id IS NULL AND session_id IS NOT NULL)
    );

DROP POLICY IF EXISTS "Admins full access bookings" ON public.bookings;
CREATE POLICY "Admins full access bookings" ON public.bookings
    FOR ALL USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

DROP POLICY IF EXISTS "Owners view bookings for their shows" ON public.bookings;
CREATE POLICY "Owners view bookings for their shows" ON public.bookings
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM theater_owners to_
            JOIN shows s ON s.id = bookings.show_id
            WHERE to_.user_id = auth.uid() AND to_.theatre_id = (SELECT theatre_id FROM screens WHERE id = s.screen_id)
        ) OR
        EXISTS (
            SELECT 1 FROM theater_owners to_
            JOIN event_shows es ON es.id = bookings.event_show_id
            WHERE to_.user_id = auth.uid() AND to_.theatre_id = (SELECT theatre_id FROM screens WHERE id = es.screen_id)
        )
    );

-- Block direct INSERT/UPDATE/DELETE for non-admins
DROP POLICY IF EXISTS "No direct inserts for non-admins" ON public.bookings;
CREATE POLICY "No direct inserts for non-admins" ON public.bookings
    FOR INSERT WITH CHECK ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

DROP POLICY IF EXISTS "No direct updates for non-admins" ON public.bookings;
CREATE POLICY "No direct updates for non-admins" ON public.bookings
    FOR UPDATE USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true)
    WITH CHECK ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

DROP POLICY IF EXISTS "No direct deletes for non-admins" ON public.bookings;
CREATE POLICY "No direct deletes for non-admins" ON public.bookings
    FOR DELETE USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);


-- 3. SEATS POLICIES
DROP POLICY IF EXISTS "Seats are viewable by everyone" ON public.seats;
CREATE POLICY "Seats are viewable by everyone" ON public.seats
    FOR SELECT USING (true);

DROP POLICY IF EXISTS "Admins can manage seats" ON public.seats;
CREATE POLICY "Admins can manage seats" ON public.seats
    FOR ALL USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);


-- 4. MOVIES POLICIES
DROP POLICY IF EXISTS "Movies are viewable by everyone" ON public.movies;
CREATE POLICY "Movies are viewable by everyone" ON public.movies
    FOR SELECT USING (true);

DROP POLICY IF EXISTS "Admins can manage movies" ON public.movies;
CREATE POLICY "Admins can manage movies" ON public.movies
    FOR ALL USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);


-- 5. PERMISSION REFINEMENT
REVOKE ALL ON public.bookings FROM anon;
GRANT SELECT ON public.bookings TO anon;
GRANT SELECT ON public.bookings TO authenticated;


-- ============================================
-- Quick My Ticket - CRITICAL SECURITY FIX
-- Migration 026: Close Privilege Escalation
-- ============================================
-- PROBLEM: All admin checks use auth.jwt()->'user_metadata' which
-- any authenticated user can self-modify via supabase.auth.updateUser().
-- FIX: Switch every check to auth.jwt()->'app_metadata' which can
-- only be set server-side (service_role or Supabase Dashboard).
-- ============================================

-- =============================================
-- PART 1: RLS POLICIES (DROP + RECREATE)
-- =============================================

-- 1A. theater_owners
DROP POLICY IF EXISTS "Admin full access theater_owners" ON theater_owners;
CREATE POLICY "Admin full access theater_owners" ON theater_owners 
FOR ALL USING (
    (auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true
);

-- 1B. theatres
DROP POLICY IF EXISTS "Admin manage theatres" ON theatres;
CREATE POLICY "Admin manage theatres" ON theatres 
FOR ALL USING (
    (auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true
);

-- 1C. screens
DROP POLICY IF EXISTS "Admin manage screens" ON screens;
CREATE POLICY "Admin manage screens" ON screens 
FOR ALL USING (
    (auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true
);

-- 1D. shows
DROP POLICY IF EXISTS "Admin manage shows" ON shows;
CREATE POLICY "Admin manage shows" ON shows 
FOR ALL USING (
    (auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true
);

-- 1E. owner_applications
DROP POLICY IF EXISTS "Admins can view all applications" ON owner_applications;
CREATE POLICY "Admins can view all applications" ON owner_applications
    FOR SELECT USING (
        (auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true
    );

DROP POLICY IF EXISTS "Admins can update applications" ON owner_applications;
CREATE POLICY "Admins can update applications" ON owner_applications
    FOR UPDATE USING (
        (auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true
    );

-- 1F. events
DROP POLICY IF EXISTS "Admins can update events" ON events;
CREATE POLICY "Admins can update events" 
ON events FOR UPDATE 
TO authenticated
USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true)
WITH CHECK ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

DROP POLICY IF EXISTS "Admins can delete events" ON events;
CREATE POLICY "Admins can delete events" 
ON events FOR DELETE 
TO authenticated
USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

-- 1G. event_shows
DROP POLICY IF EXISTS "Admins can update event shows" ON event_shows;
CREATE POLICY "Admins can update event shows" 
ON event_shows FOR UPDATE 
TO authenticated
USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true)
WITH CHECK ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

DROP POLICY IF EXISTS "Admins can delete event shows" ON event_shows;
CREATE POLICY "Admins can delete event shows" 
ON event_shows FOR DELETE 
TO authenticated
USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

-- 1H. transaction_logs
DROP POLICY IF EXISTS "Admins full access trans_logs" ON transaction_logs;
CREATE POLICY "Admins full access trans_logs" ON transaction_logs 
    FOR ALL USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

-- 1I. bookings (already fixed in 025 but ensure consistency)
DROP POLICY IF EXISTS "Admins full access bookings" ON public.bookings;
CREATE POLICY "Admins full access bookings" ON public.bookings
    FOR ALL USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

-- 1J. seats
DROP POLICY IF EXISTS "Admins can manage seats" ON public.seats;
CREATE POLICY "Admins can manage seats" ON public.seats
    FOR ALL USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

-- 1K. movies
DROP POLICY IF EXISTS "Admins can manage movies" ON public.movies;
CREATE POLICY "Admins can manage movies" ON public.movies
    FOR ALL USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);


-- =============================================
-- PART 2: SECURITY DEFINER FUNCTIONS
-- =============================================

-- 2A. get_pending_applications
CREATE OR REPLACE FUNCTION get_pending_applications()
RETURNS TABLE(
    id UUID,
    user_id UUID,
    email TEXT,
    full_name TEXT,
    phone TEXT,
    theatre_name TEXT,
    theatre_location TEXT,
    business_license TEXT,
    message TEXT,
    status TEXT,
    created_at TIMESTAMP WITH TIME ZONE
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    IF NOT ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;
    
    RETURN QUERY
    SELECT 
        oa.id, oa.user_id, oa.email, oa.full_name, oa.phone,
        oa.theatre_name, oa.theatre_location, oa.business_license,
        oa.message, oa.status, oa.created_at
    FROM owner_applications oa
    WHERE oa.status = 'pending'
    ORDER BY oa.created_at DESC;
END;
$$;

-- 2B. approve_owner_application
CREATE OR REPLACE FUNCTION approve_owner_application(
    p_application_id UUID,
    p_admin_notes TEXT DEFAULT NULL
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_admin_id UUID := auth.uid();
    v_app RECORD;
    v_theatre_id UUID;
BEGIN
    IF NOT ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true) THEN
        RETURN json_build_object('success', false, 'error', 'Access denied: Admin only');
    END IF;
    
    SELECT * INTO v_app FROM owner_applications WHERE id = p_application_id;
    
    IF v_app IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Application not found');
    END IF;
    
    IF v_app.status != 'pending' THEN
        RETURN json_build_object('success', false, 'error', 'Application already processed');
    END IF;
    
    INSERT INTO theatres (name, location)
    VALUES (v_app.theatre_name, v_app.theatre_location)
    RETURNING id INTO v_theatre_id;
    
    INSERT INTO theater_owners (user_id, theatre_id, role)
    VALUES (v_app.user_id, v_theatre_id, 'owner');
    
    UPDATE owner_applications
    SET status = 'approved',
        reviewed_at = NOW(),
        reviewed_by = v_admin_id,
        admin_notes = p_admin_notes
    WHERE id = p_application_id;
    
    RETURN json_build_object(
        'success', true, 
        'message', 'Application approved',
        'theatre_id', v_theatre_id
    );
END;
$$;

-- 2C. reject_owner_application
CREATE OR REPLACE FUNCTION reject_owner_application(
    p_application_id UUID,
    p_admin_notes TEXT DEFAULT NULL
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_admin_id UUID := auth.uid();
BEGIN
    IF NOT ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true) THEN
        RETURN json_build_object('success', false, 'error', 'Access denied: Admin only');
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM owner_applications WHERE id = p_application_id AND status = 'pending') THEN
        RETURN json_build_object('success', false, 'error', 'Application not found or already processed');
    END IF;
    
    UPDATE owner_applications
    SET status = 'rejected',
        reviewed_at = NOW(),
        reviewed_by = v_admin_id,
        admin_notes = p_admin_notes
    WHERE id = p_application_id;
    
    RETURN json_build_object('success', true, 'message', 'Application rejected');
END;
$$;

-- 2D. update_screen_layout
CREATE OR REPLACE FUNCTION update_screen_layout(
    p_screen_id UUID,
    p_seat_layout JSONB
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_theatre_id UUID;
    v_is_owner BOOLEAN;
BEGIN
    IF p_seat_layout IS NULL 
       OR jsonb_typeof(p_seat_layout->'rows') IS DISTINCT FROM 'array' THEN
        RETURN json_build_object('success', false, 'error', 'Invalid seat layout');
    END IF;

    SELECT theatre_id INTO v_theatre_id
    FROM screens
    WHERE id = p_screen_id;

    IF v_theatre_id IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Screen not found');
    END IF;

    SELECT EXISTS(
        SELECT 1 FROM theater_owners
        WHERE user_id = v_user_id AND theatre_id = v_theatre_id
    ) INTO v_is_owner;

    IF NOT v_is_owner AND NOT (COALESCE((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean, false) = true) THEN
        RETURN json_build_object('success', false, 'error', 'Access denied');
    END IF;

    IF EXISTS (
        SELECT 1 FROM bookings b
        JOIN shows s ON b.show_id = s.id
        WHERE s.screen_id = p_screen_id AND b.status IN ('confirmed', 'locked')
        
        UNION ALL
        
        SELECT 1 FROM bookings b
        JOIN event_shows es ON b.event_show_id = es.id
        WHERE es.screen_id = p_screen_id AND b.status IN ('confirmed', 'locked')
    ) THEN
        RETURN json_build_object('success', false, 'error', 'Cannot update layout: Active bookings exist for this screen');
    END IF;

    UPDATE screens
    SET 
        seat_layout = p_seat_layout,
        total_seats = COALESCE((p_seat_layout->'metadata'->>'totalSeats')::integer, total_seats)
    WHERE id = p_screen_id;

    DELETE FROM seats WHERE screen_id = p_screen_id;

    INSERT INTO seats (screen_id, row, col, tier, price)
    SELECT 
        p_screen_id,
        r->>'label',
        (s->>'id')::integer,
        s->>'type',
        (s->>'price')::integer
    FROM jsonb_array_elements(p_seat_layout->'rows') AS r
    CROSS JOIN jsonb_array_elements(r->'seats') AS s
    WHERE s IS NOT NULL AND s != 'null'::jsonb;

    RETURN json_build_object('success', true, 'message', 'Layout updated and seats synced');
END;
$$;

-- 2E. get_admin_dashboard_stats
CREATE OR REPLACE FUNCTION get_admin_dashboard_stats()
RETURNS TABLE(
    total_revenue NUMERIC,
    total_bookings BIGINT,
    total_theatres BIGINT,
    total_owners BIGINT,
    today_revenue NUMERIC,
    today_bookings BIGINT,
    active_locks BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    IF NOT ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;

    RETURN QUERY
    WITH movie_stats AS (
        SELECT
            SUM(COALESCE(seats.price, sh.price, 0)) FILTER (WHERE b.status = 'confirmed') AS total_revenue,
            COUNT(*) FILTER (WHERE b.status = 'confirmed') AS total_bookings,
            SUM(COALESCE(seats.price, sh.price, 0)) FILTER (WHERE b.status = 'confirmed' AND b.created_at >= CURRENT_DATE AND b.created_at < (CURRENT_DATE + interval '1 day')) AS today_revenue,
            COUNT(*) FILTER (WHERE b.status = 'confirmed' AND b.created_at >= CURRENT_DATE AND b.created_at < (CURRENT_DATE + interval '1 day')) AS today_bookings,
            COUNT(*) FILTER (WHERE b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '10 minutes') AS active_locks
        FROM bookings b
        JOIN shows sh ON sh.id = b.show_id
        LEFT JOIN seats ON seats.id = b.seat_id
    ),
    event_stats AS (
        SELECT
            SUM(COALESCE(seats.price, es.price, 0)) FILTER (WHERE b.status = 'confirmed') AS total_revenue,
            COUNT(*) FILTER (WHERE b.status = 'confirmed') AS total_bookings,
            SUM(COALESCE(seats.price, es.price, 0)) FILTER (WHERE b.status = 'confirmed' AND b.created_at >= CURRENT_DATE AND b.created_at < (CURRENT_DATE + interval '1 day')) AS today_revenue,
            COUNT(*) FILTER (WHERE b.status = 'confirmed' AND b.created_at >= CURRENT_DATE AND b.created_at < (CURRENT_DATE + interval '1 day')) AS today_bookings,
            COUNT(*) FILTER (WHERE b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '10 minutes') AS active_locks
        FROM bookings b
        JOIN event_shows es ON es.id = b.event_show_id
        LEFT JOIN seats ON seats.id = b.seat_id
    )
    SELECT
        (COALESCE((SELECT total_revenue FROM movie_stats), 0) + COALESCE((SELECT total_revenue FROM event_stats), 0))::NUMERIC,
        (COALESCE((SELECT total_bookings FROM movie_stats), 0) + COALESCE((SELECT total_bookings FROM event_stats), 0))::BIGINT,
        (SELECT COUNT(*) FROM theatres)::BIGINT,
        (SELECT COUNT(DISTINCT user_id) FROM theater_owners)::BIGINT,
        (COALESCE((SELECT today_revenue FROM movie_stats), 0) + COALESCE((SELECT today_revenue FROM event_stats), 0))::NUMERIC,
        (COALESCE((SELECT today_bookings FROM movie_stats), 0) + COALESCE((SELECT today_bookings FROM event_stats), 0))::BIGINT,
        (COALESCE((SELECT active_locks FROM movie_stats), 0) + COALESCE((SELECT active_locks FROM event_stats), 0))::BIGINT;
END;
$$;

-- 2F. get_admin_owner_revenue_breakdown
CREATE OR REPLACE FUNCTION get_admin_owner_revenue_breakdown(p_start_date DATE DEFAULT NULL, p_end_date DATE DEFAULT NULL)
RETURNS TABLE(
    owner_id UUID,
    owner_email TEXT,
    owner_name TEXT,
    theatre_names TEXT,
    revenue NUMERIC,
    booking_count BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    IF NOT ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;

    RETURN QUERY
    WITH owner_theatres AS (
        SELECT 
            to_owner.user_id,
            t.id as theatre_id,
            t.name as theatre_name,
            oa.email as user_email,
            oa.full_name as user_name
        FROM theater_owners to_owner
        JOIN theatres t ON t.id = to_owner.theatre_id
        LEFT JOIN owner_applications oa ON oa.user_id = to_owner.user_id AND oa.status = 'approved'
    ),
    movie_bookings AS (
        SELECT 
            s.theatre_id,
            COUNT(b.id) as booking_count,
            SUM(COALESCE(seats.price, sh.price, 0)) as revenue
        FROM bookings b
        JOIN shows sh ON sh.id = b.show_id
        JOIN screens s ON s.id = sh.screen_id
        LEFT JOIN seats ON seats.id = b.seat_id
        WHERE b.status = 'confirmed' 
            AND (p_start_date IS NULL OR b.created_at >= p_start_date)
            AND (p_end_date IS NULL OR b.created_at < (p_end_date + INTERVAL '1 day'))
        GROUP BY s.theatre_id
    ),
    event_bookings AS (
        SELECT 
            s.theatre_id,
            COUNT(b.id) as booking_count,
            SUM(COALESCE(seats.price, es.price, 0)) as revenue
        FROM bookings b
        JOIN event_shows es ON es.id = b.event_show_id
        JOIN screens s ON s.id = es.screen_id
        LEFT JOIN seats ON seats.id = b.seat_id
        WHERE b.status = 'confirmed' 
            AND (p_start_date IS NULL OR b.created_at >= p_start_date)
            AND (p_end_date IS NULL OR b.created_at < (p_end_date + INTERVAL '1 day'))
        GROUP BY s.theatre_id
    )
    SELECT 
        ot.user_id as owner_id,
        MAX(ot.user_email) as owner_email,
        MAX(ot.user_name) as owner_name,
        STRING_AGG(DISTINCT ot.theatre_name, ', ') as theatre_names,
        COALESCE(SUM(mb.revenue), 0) + COALESCE(SUM(eb.revenue), 0) as revenue,
        COALESCE(SUM(mb.booking_count), 0) + COALESCE(SUM(eb.booking_count), 0) as booking_count
    FROM owner_theatres ot
    LEFT JOIN movie_bookings mb ON mb.theatre_id = ot.theatre_id
    LEFT JOIN event_bookings eb ON eb.theatre_id = ot.theatre_id
    GROUP BY ot.user_id
    ORDER BY revenue DESC;
END;
$$;

-- 2G. get_user_role (also reads from raw_user_meta_data — switch to raw_app_meta_data)
CREATE OR REPLACE FUNCTION get_user_role(p_user_id UUID)
RETURNS TABLE(
    is_admin BOOLEAN,
    is_theater_owner BOOLEAN,
    owned_theatre_count BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        COALESCE((au.raw_app_meta_data ->> 'is_admin')::boolean, false) AS is_admin,
        EXISTS (SELECT 1 FROM theater_owners WHERE user_id = p_user_id) AS is_theater_owner,
        (SELECT COUNT(*) FROM theater_owners WHERE user_id = p_user_id) AS owned_theatre_count
    FROM auth.users au
    WHERE au.id = p_user_id;
END;
$$;

-- 2H. user_roles view
CREATE OR REPLACE VIEW user_roles AS
SELECT 
    au.id AS user_id,
    au.email,
    COALESCE((au.raw_app_meta_data ->> 'is_admin')::boolean, false) AS is_admin,
    EXISTS (SELECT 1 FROM theater_owners WHERE user_id = au.id) AS is_theater_owner,
    (SELECT ARRAY_AGG(theatre_id) FROM theater_owners WHERE user_id = au.id) AS owned_theatre_ids
FROM auth.users au;


-- =============================================
-- PART 3: IMPORTANT — MIGRATE EXISTING ADMIN FLAG
-- =============================================
-- If you have existing admins with is_admin in user_metadata,
-- you MUST copy the flag to app_metadata via the Supabase Dashboard
-- or by running this with the service_role key:
--
-- UPDATE auth.users 
-- SET raw_app_meta_data = raw_app_meta_data || '{"is_admin": true}'::jsonb
-- WHERE raw_user_meta_data ->> 'is_admin' = 'true';
--
-- After verifying admins still work, clean up user_metadata:
-- UPDATE auth.users 
-- SET raw_user_meta_data = raw_user_meta_data - 'is_admin'
-- WHERE raw_user_meta_data ? 'is_admin';


