-- ============================================
-- Quick My Ticket - Fix Seat Layout Editor Save
-- Migration 019
-- ============================================

CREATE OR REPLACE FUNCTION update_screen_layout(
    p_screen_id UUID,
    p_seat_layout JSONB
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_theatre_id UUID;
    v_is_owner BOOLEAN;
BEGIN
    IF p_seat_layout IS NULL
       OR jsonb_typeof(p_seat_layout->'rows') IS DISTINCT FROM 'array' THEN
        RETURN json_build_object('success', false, 'error', 'Invalid seat layout');
    END IF;

    SELECT theatre_id INTO v_theatre_id
    FROM screens
    WHERE id = p_screen_id;

    IF v_theatre_id IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Screen not found');
    END IF;

    SELECT EXISTS(
        SELECT 1 FROM theater_owners
        WHERE user_id = v_user_id AND theatre_id = v_theatre_id
    ) INTO v_is_owner;

    IF NOT v_is_owner AND NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RETURN json_build_object('success', false, 'error', 'Access denied');
    END IF;

    IF EXISTS (
        SELECT 1 FROM bookings b
        JOIN shows s ON b.show_id = s.id
        WHERE s.screen_id = p_screen_id AND b.status IN ('confirmed', 'locked')

        UNION ALL

        SELECT 1 FROM bookings b
        JOIN event_shows es ON b.event_show_id = es.id
        WHERE es.screen_id = p_screen_id AND b.status IN ('confirmed', 'locked')
    ) THEN
        RETURN json_build_object('success', false, 'error', 'Cannot update layout: Active bookings exist for this screen');
    END IF;

    UPDATE screens
    SET
        seat_layout = p_seat_layout,
        rows = COALESCE((p_seat_layout->'metadata'->>'rowCount')::integer, rows),
        seats_per_row = COALESCE((p_seat_layout->'metadata'->>'maxSeatsPerRow')::integer, seats_per_row)
    WHERE id = p_screen_id;

    DELETE FROM seats WHERE screen_id = p_screen_id;

    INSERT INTO seats (screen_id, row, col, tier, price)
    SELECT
        p_screen_id,
        r->>'label',
        (s->>'id')::integer,
        s->>'type',
        (s->>'price')::integer
    FROM jsonb_array_elements(p_seat_layout->'rows') AS r
    CROSS JOIN jsonb_array_elements(r->'seats') AS s
    WHERE s IS NOT NULL AND s != 'null'::jsonb;

    RETURN json_build_object('success', true, 'message', 'Layout updated and seats synced');
END;
$$;

GRANT EXECUTE ON FUNCTION update_screen_layout(UUID, JSONB) TO authenticated;
