-- Create storage bucket for theater branding assets
INSERT INTO storage.buckets (id, name, public)
VALUES ('branding', 'branding', true)
ON CONFLICT (id) DO NOTHING;

-- Public read access on branding bucket
DROP POLICY IF EXISTS "Public read branding assets" ON storage.objects;
CREATE POLICY "Public read branding assets"
ON storage.objects FOR SELECT
USING (bucket_id = 'branding');

-- Theater owners can upload to their own folder
DROP POLICY IF EXISTS "Theater owners can upload branding" ON storage.objects;
CREATE POLICY "Theater owners can upload branding"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'branding'
  AND (storage.foldername(name))[2] IN (
    SELECT t.id::text FROM theatres t
    JOIN theater_owners to2 ON t.id = to2.theatre_id
    WHERE to2.user_id = auth.uid()
  )
);

DROP POLICY IF EXISTS "Theater owners can update branding" ON storage.objects;
CREATE POLICY "Theater owners can update branding"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'branding'
  AND (storage.foldername(name))[2] IN (
    SELECT t.id::text FROM theatres t
    JOIN theater_owners to2 ON t.id = to2.theatre_id
    WHERE to2.user_id = auth.uid()
  )
);
