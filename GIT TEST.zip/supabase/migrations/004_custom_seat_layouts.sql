-- ============================================
-- Quick My Ticket - Custom Seat Layout System
-- Migration 004
-- ============================================

-- Add seat_layout column to screens table
-- This stores the custom layout as JSON
ALTER TABLE screens ADD COLUMN IF NOT EXISTS seat_layout JSONB;

-- The seat_layout JSON structure:
-- {
--   "rows": [
--     {
--       "label": "A",           -- Row label
--       "seats": [
--         { "id": 1, "type": "regular", "price": 200 },
--         { "id": 2, "type": "regular", "price": 200 },
--         null,                  -- null = gap/aisle
--         { "id": 3, "type": "premium", "price": 300 },
--         ...
--       ]
--     },
--     ...
--   ],
--   "metadata": {
--     "totalSeats": 100,
--     "rowCount": 10,
--     "maxSeatsPerRow": 15
--   }
-- }

-- Function to update seat layout (for owners)
CREATE OR REPLACE FUNCTION update_screen_layout(
    p_screen_id UUID,
    p_seat_layout JSONB
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_theatre_id UUID;
    v_is_owner BOOLEAN;
BEGIN
    -- Get the theatre for this screen
    SELECT theatre_id INTO v_theatre_id
    FROM screens
    WHERE id = p_screen_id;
    
    IF v_theatre_id IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Screen not found');
    END IF;
    
    -- Check if user owns this theatre
    SELECT EXISTS(
        SELECT 1 FROM theater_owners
        WHERE user_id = v_user_id AND theatre_id = v_theatre_id
    ) INTO v_is_owner;
    
    -- Also allow admins
    IF NOT v_is_owner AND NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RETURN json_build_object('success', false, 'error', 'Access denied');
    END IF;
    
    -- Sync seats table.
    -- To avoid FK issues and layout/seat mismatches, only allow this if no active
    -- bookings exist, and check before changing screens.seat_layout.
    IF EXISTS (
        SELECT 1 FROM bookings b
        JOIN shows s ON b.show_id = s.id
        WHERE s.screen_id = p_screen_id AND b.status IN ('confirmed', 'locked')
    ) THEN
        RETURN json_build_object('success', false, 'error', 'Cannot update layout: Active bookings exist for this screen');
    END IF;

    -- Update the screen record after validation so failed saves leave it unchanged.
    UPDATE screens
    SET
        seat_layout = p_seat_layout,
        rows = COALESCE((p_seat_layout->'metadata'->>'rowCount')::integer, rows),
        seats_per_row = COALESCE((p_seat_layout->'metadata'->>'maxSeatsPerRow')::integer, seats_per_row)
    WHERE id = p_screen_id;

    -- Delete old seats
    DELETE FROM seats WHERE screen_id = p_screen_id;

    -- Insert new seats from JSON
    -- Expecting structure: { "rows": [ { "label": "A", "seats": [ { "id": 1, "type": "regular", "price": 200 }, null, ... ] } ] }
    INSERT INTO seats (screen_id, row, col, tier, price)
    SELECT 
        p_screen_id,
        r->>'label',
        (s->>'id')::integer,
        s->>'type',
        (s->>'price')::integer
    FROM jsonb_array_elements(p_seat_layout->'rows') AS r
    CROSS JOIN jsonb_array_elements(r->'seats') AS s
    WHERE s IS NOT NULL AND s != 'null'::jsonb;

    RETURN json_build_object('success', true, 'message', 'Layout updated and seats synced');
END;
$$;

GRANT EXECUTE ON FUNCTION update_screen_layout(UUID, JSONB) TO authenticated;

-- Function to get screen layout
CREATE OR REPLACE FUNCTION get_screen_layout(p_screen_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_layout JSONB;
    v_rows INTEGER;
    v_seats_per_row INTEGER;
BEGIN
    SELECT seat_layout, rows, seats_per_row
    INTO v_layout, v_rows, v_seats_per_row
    FROM screens
    WHERE id = p_screen_id;
    
    -- If custom layout exists, return it
    IF v_layout IS NOT NULL THEN
        RETURN v_layout;
    END IF;
    
    -- Otherwise, generate default layout from rows/seats_per_row
    RETURN generate_default_layout(v_rows, v_seats_per_row);
END;
$$;

GRANT EXECUTE ON FUNCTION get_screen_layout(UUID) TO anon, authenticated;

-- Helper function to generate default seat layout
CREATE OR REPLACE FUNCTION generate_default_layout(
    p_rows INTEGER,
    p_seats_per_row INTEGER
)
RETURNS JSONB
LANGUAGE plpgsql
AS $$
DECLARE
    v_layout JSONB := '{"rows": [], "metadata": {}}';
    v_rows JSONB := '[]';
    v_row JSONB;
    v_seats JSONB;
    v_seat JSONB;
    i INTEGER;
    j INTEGER;
    v_row_label TEXT;
    v_seat_type TEXT;
    v_price INTEGER;
BEGIN
    FOR i IN 1..COALESCE(p_rows, 10) LOOP
        -- Generate row label (A, B, C, ...)
        v_row_label := CHR(64 + i);
        
        -- Determine seat type based on row position
        IF i <= 2 THEN
            v_seat_type := 'regular';
            v_price := 200;
        ELSIF i <= COALESCE(p_rows, 10) - 2 THEN
            v_seat_type := 'premium';
            v_price := 300;
        ELSE
            v_seat_type := 'vip';
            v_price := 500;
        END IF;
        
        v_seats := '[]';
        FOR j IN 1..COALESCE(p_seats_per_row, 12) LOOP
            v_seat := json_build_object(
                'id', j,
                'type', v_seat_type,
                'price', v_price
            )::jsonb;
            v_seats := v_seats || v_seat;
        END LOOP;
        
        v_row := json_build_object(
            'label', v_row_label,
            'seats', v_seats
        )::jsonb;
        
        v_rows := v_rows || v_row;
    END LOOP;
    
    v_layout := json_build_object(
        'rows', v_rows,
        'metadata', json_build_object(
            'totalSeats', COALESCE(p_rows, 10) * COALESCE(p_seats_per_row, 12),
            'rowCount', COALESCE(p_rows, 10),
            'maxSeatsPerRow', COALESCE(p_seats_per_row, 12)
        )
    )::jsonb;
    
    RETURN v_layout;
END;
$$;
