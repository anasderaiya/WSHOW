-- Migration: Production Hardening
-- Adds structural auditing and performance optimizations

-- 1. Create Transaction Logs Table for Financial Auditing
CREATE TABLE IF NOT EXISTS transaction_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
    user_id UUID, -- NULL for guest
    session_id TEXT, -- For guest tracking
    payment_provider TEXT DEFAULT 'internal',
    provider_transaction_id TEXT,
    amount NUMERIC(10, 2) NOT NULL,
    currency TEXT DEFAULT 'INR',
    status TEXT DEFAULT 'success' CHECK (status IN ('success', 'refunded', 'failed', 'pending')),
    metadata JSONB DEFAULT '{}'::JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS on transaction_logs
ALTER TABLE transaction_logs ENABLE ROW LEVEL SECURITY;

-- Policies for transaction_logs
DROP POLICY IF EXISTS "Admins full access trans_logs" ON transaction_logs;
CREATE POLICY "Admins full access trans_logs"
ON transaction_logs 
    FOR ALL USING ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true);

DROP POLICY IF EXISTS "Users view own trans_logs" ON transaction_logs;
CREATE POLICY "Users view own trans_logs"
ON transaction_logs 
    FOR SELECT USING (auth.uid() = user_id OR session_id = (SELECT session_id FROM bookings WHERE id = booking_id));

-- 2. Audit Trail Trigger
-- Automatically logs when a booking is confirmed
CREATE OR REPLACE FUNCTION audit_confirmed_booking()
RETURNS TRIGGER AS $$
DECLARE
    v_amount NUMERIC;
BEGIN
    IF (NEW.status = 'confirmed' AND (OLD.status IS NULL OR OLD.status != 'confirmed')) THEN
        -- Get the amount for this booking
        SELECT COALESCE(seats.price, sh.price, es.price, 0) INTO v_amount
        FROM bookings b
        LEFT JOIN seats ON seats.id = b.seat_id
        LEFT JOIN shows sh ON sh.id = b.show_id
        LEFT JOIN event_shows es ON es.id = b.event_show_id
        WHERE b.id = NEW.id;

        INSERT INTO transaction_logs (
            booking_id, 
            user_id, 
            session_id, 
            payment_provider, 
            provider_transaction_id, 
            amount,
            metadata
        ) VALUES (
            NEW.id,
            NEW.user_id,
            NEW.session_id,
            'internal', -- Update this when real provider is added
            NEW.payment_id,
            COALESCE(v_amount, 0),
            jsonb_build_object('source', 'auto_audit_trigger', 'timestamp', NOW())
        );
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trg_audit_booking_confirmation ON bookings;
CREATE TRIGGER trg_audit_booking_confirmation AFTER UPDATE ON bookings
FOR EACH ROW
EXECUTE FUNCTION audit_confirmed_booking();

-- 3. High-Performance Indexing Strategy
-- Composite indexes for financial reporting and real-time dashboard performance

-- Optimization for: get_admin_dashboard_stats & get_owner_dashboard_stats
CREATE INDEX IF NOT EXISTS idx_bookings_financial_stat 
ON bookings (status, created_at) 
INCLUDE (show_id, event_show_id);

-- Optimization for: get_admin_owner_revenue_breakdown
CREATE INDEX IF NOT EXISTS idx_bookings_owner_reporting 
ON bookings (show_id, event_show_id) 
WHERE status = 'confirmed';

-- Optimization for: Seat Availability Views
CREATE INDEX IF NOT EXISTS idx_bookings_availability_lookup 
ON bookings (show_id, seat_id, status) 
WHERE status IN ('locked', 'confirmed');

CREATE INDEX IF NOT EXISTS idx_bookings_availability_event_lookup 
ON bookings (event_show_id, seat_id, status) 
WHERE status IN ('locked', 'confirmed');

-- Optimization for: Dashboard card counts
CREATE INDEX IF NOT EXISTS idx_bookings_realtime_badge 
ON bookings (show_id, status) 
WHERE status = 'confirmed';

CREATE INDEX IF NOT EXISTS idx_bookings_realtime_event_badge 
ON bookings (event_show_id, status) 
WHERE status = 'confirmed';

-- Optimization for: Show lookup performance
CREATE INDEX IF NOT EXISTS idx_shows_screen_time 
ON shows (screen_id, start_time);

CREATE INDEX IF NOT EXISTS idx_event_shows_screen_time 
ON event_shows (screen_id, start_time);

-- 4. Admin Security Hardening
-- Ensure RPCs are strictly restricted
GRANT SELECT ON transaction_logs TO authenticated;
GRANT SELECT ON transaction_logs TO anon; -- Allow guest to potentially view their own receipt
