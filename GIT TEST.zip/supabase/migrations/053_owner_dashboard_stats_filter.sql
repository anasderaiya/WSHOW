-- Migration 053: Add p_theatre_id filter to get_owner_dashboard_stats
-- This allows the dashboard to correctly show stats for a specific theatre when one is selected.

DROP FUNCTION IF EXISTS get_owner_dashboard_stats(UUID);
DROP FUNCTION IF EXISTS get_owner_dashboard_stats(UUID, UUID);

CREATE OR REPLACE FUNCTION get_owner_dashboard_stats(
    p_user_id UUID,
    p_theatre_id UUID DEFAULT NULL
)
RETURNS TABLE(
    total_theatres BIGINT,
    total_screens BIGINT,
    total_seats BIGINT,
    today_bookings BIGINT,
    today_revenue DECIMAL,
    currently_locked BIGINT,
    today_confirmed BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_theatre_ids UUID[];
    v_today DATE := CURRENT_DATE;
BEGIN
    SELECT ARRAY_AGG(theatre_id) INTO v_theatre_ids
    FROM theater_owners
    WHERE user_id = p_user_id;
    
    IF v_theatre_ids IS NULL THEN
        RETURN QUERY SELECT 0::BIGINT, 0::BIGINT, 0::BIGINT, 0::BIGINT, 0::DECIMAL, 0::BIGINT, 0::BIGINT;
        RETURN;
    END IF;

    RETURN QUERY
    WITH screen_data AS (
        SELECT s.id as screen_id, 
               (SELECT COUNT(*) FROM seats WHERE screen_id = s.id) as seat_count
        FROM screens s
        WHERE s.theatre_id = ANY(v_theatre_ids)
          AND (p_theatre_id IS NULL OR s.theatre_id = p_theatre_id)
    ),
    movie_stats AS (
        SELECT 
            SUM(CASE WHEN b.created_at >= v_today AND b.created_at < (v_today + interval '1 day') THEN 1 ELSE 0 END) AS today_bookings,
            SUM(CASE WHEN b.created_at >= v_today AND b.created_at < (v_today + interval '1 day') AND b.status = 'confirmed' THEN COALESCE(seats.price, sh.price, 0) ELSE 0 END) AS today_revenue,
            SUM(CASE WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 1 ELSE 0 END) AS currently_locked,
            SUM(CASE WHEN b.created_at >= v_today AND b.created_at < (v_today + interval '1 day') AND b.status = 'confirmed' THEN 1 ELSE 0 END) AS today_confirmed
        FROM shows sh
        JOIN screen_data sd ON sd.screen_id = sh.screen_id
        JOIN bookings b ON b.show_id = sh.id
        LEFT JOIN seats ON seats.id = b.seat_id
    ),
    event_stats AS (
        SELECT 
            SUM(CASE WHEN b.created_at >= v_today AND b.created_at < (v_today + interval '1 day') THEN 1 ELSE 0 END) AS today_bookings,
            SUM(CASE WHEN b.created_at >= v_today AND b.created_at < (v_today + interval '1 day') AND b.status = 'confirmed' THEN COALESCE(seats.price, es.price, 0) ELSE 0 END) AS today_revenue,
            SUM(CASE WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 1 ELSE 0 END) AS currently_locked,
            SUM(CASE WHEN b.created_at >= v_today AND b.created_at < (v_today + interval '1 day') AND b.status = 'confirmed' THEN 1 ELSE 0 END) AS today_confirmed
        FROM event_shows es
        JOIN screen_data sd ON sd.screen_id = es.screen_id
        JOIN bookings b ON b.event_show_id = es.id
        LEFT JOIN seats ON seats.id = b.seat_id
    )
    SELECT
        (SELECT COUNT(*) FROM unnest(v_theatre_ids) tid WHERE p_theatre_id IS NULL OR tid = p_theatre_id)::BIGINT AS total_theatres,
        (SELECT COUNT(*) FROM screen_data)::BIGINT AS total_screens,
        (SELECT COALESCE(SUM(seat_count), 0) FROM screen_data)::BIGINT AS total_seats,
        (COALESCE((SELECT today_bookings FROM movie_stats), 0) + COALESCE((SELECT today_bookings FROM event_stats), 0))::BIGINT AS today_bookings,
        (COALESCE((SELECT today_revenue FROM movie_stats), 0) + COALESCE((SELECT today_revenue FROM event_stats), 0))::DECIMAL AS today_revenue,
        (COALESCE((SELECT currently_locked FROM movie_stats), 0) + COALESCE((SELECT currently_locked FROM event_stats), 0))::BIGINT AS currently_locked,
        (COALESCE((SELECT today_confirmed FROM movie_stats), 0) + COALESCE((SELECT today_confirmed FROM event_stats), 0))::BIGINT AS today_confirmed;
END;
$$;

GRANT EXECUTE ON FUNCTION get_owner_dashboard_stats(UUID, UUID) TO authenticated;
