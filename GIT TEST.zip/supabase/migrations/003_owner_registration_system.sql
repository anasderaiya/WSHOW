-- ============================================
-- Quick My Ticket - Owner Registration & Approval System
-- Migration 003
-- ============================================

-- Table for pending owner applications
CREATE TABLE IF NOT EXISTS owner_applications (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    full_name TEXT NOT NULL,
    phone TEXT,
    theatre_name TEXT NOT NULL,
    theatre_location TEXT NOT NULL,
    business_license TEXT, -- Optional license number
    message TEXT, -- Why they want to partner
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
    admin_notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    reviewed_at TIMESTAMP WITH TIME ZONE,
    reviewed_by UUID REFERENCES auth.users(id)
);

-- Enable RLS
ALTER TABLE owner_applications ENABLE ROW LEVEL SECURITY;

-- Users can view their own applications
DROP POLICY IF EXISTS "Users can view own applications" ON owner_applications;
CREATE POLICY "Users can view own applications"
ON owner_applications
    FOR SELECT USING (auth.uid() = user_id);

-- Users can insert their own application
DROP POLICY IF EXISTS "Users can create applications" ON owner_applications;
CREATE POLICY "Users can create applications"
ON owner_applications
    FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Admins can view all applications
DROP POLICY IF EXISTS "Admins can view all applications" ON owner_applications;
CREATE POLICY "Admins can view all applications"
ON owner_applications
    FOR SELECT USING (
        (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
    );

-- Admins can update applications (approve/reject)
DROP POLICY IF EXISTS "Admins can update applications" ON owner_applications;
CREATE POLICY "Admins can update applications"
ON owner_applications
    FOR UPDATE USING (
        (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
    );

-- ============================================
-- Functions for Owner Application System
-- ============================================

-- Submit owner application
CREATE OR REPLACE FUNCTION submit_owner_application(
    p_full_name TEXT,
    p_phone TEXT,
    p_theatre_name TEXT,
    p_theatre_location TEXT,
    p_business_license TEXT DEFAULT NULL,
    p_message TEXT DEFAULT NULL
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_email TEXT;
    v_existing_app UUID;
    v_result JSON;
BEGIN
    -- Get user email
    SELECT email INTO v_email FROM auth.users WHERE id = v_user_id;
    
    IF v_email IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'User not authenticated');
    END IF;
    
    -- Check if user already has a pending or approved application
    SELECT id INTO v_existing_app 
    FROM owner_applications 
    WHERE user_id = v_user_id AND status IN ('pending', 'approved')
    LIMIT 1;
    
    IF v_existing_app IS NOT NULL THEN
        RETURN json_build_object('success', false, 'error', 'You already have a pending or approved application');
    END IF;
    
    -- Check if user is already an owner
    IF EXISTS (SELECT 1 FROM theater_owners WHERE user_id = v_user_id) THEN
        RETURN json_build_object('success', false, 'error', 'You are already a registered theater owner');
    END IF;
    
    -- Insert application
    INSERT INTO owner_applications (
        user_id, email, full_name, phone, 
        theatre_name, theatre_location, business_license, message
    ) VALUES (
        v_user_id, v_email, p_full_name, p_phone,
        p_theatre_name, p_theatre_location, p_business_license, p_message
    );
    
    RETURN json_build_object('success', true, 'message', 'Application submitted successfully');
END;
$$;

GRANT EXECUTE ON FUNCTION submit_owner_application(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated;

-- Get pending applications (for admin)
CREATE OR REPLACE FUNCTION get_pending_applications()
RETURNS TABLE(
    id UUID,
    user_id UUID,
    email TEXT,
    full_name TEXT,
    phone TEXT,
    theatre_name TEXT,
    theatre_location TEXT,
    business_license TEXT,
    message TEXT,
    status TEXT,
    created_at TIMESTAMP WITH TIME ZONE
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Check if caller is admin
    IF NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;
    
    RETURN QUERY
    SELECT 
        oa.id, oa.user_id, oa.email, oa.full_name, oa.phone,
        oa.theatre_name, oa.theatre_location, oa.business_license,
        oa.message, oa.status, oa.created_at
    FROM owner_applications oa
    WHERE oa.status = 'pending'
    ORDER BY oa.created_at DESC;
END;
$$;

GRANT EXECUTE ON FUNCTION get_pending_applications() TO authenticated;

-- Approve owner application (admin only)
CREATE OR REPLACE FUNCTION approve_owner_application(
    p_application_id UUID,
    p_admin_notes TEXT DEFAULT NULL
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_admin_id UUID := auth.uid();
    v_app RECORD;
    v_theatre_id UUID;
BEGIN
    -- Check if caller is admin
    IF NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RETURN json_build_object('success', false, 'error', 'Access denied: Admin only');
    END IF;
    
    -- Get application
    SELECT * INTO v_app FROM owner_applications WHERE id = p_application_id;
    
    IF v_app IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Application not found');
    END IF;
    
    IF v_app.status != 'pending' THEN
        RETURN json_build_object('success', false, 'error', 'Application already processed');
    END IF;
    
    -- Create the theatre
    INSERT INTO theatres (name, location)
    VALUES (v_app.theatre_name, v_app.theatre_location)
    RETURNING id INTO v_theatre_id;
    
    -- Add user as theater owner
    INSERT INTO theater_owners (user_id, theatre_id, role)
    VALUES (v_app.user_id, v_theatre_id, 'owner');
    
    -- Update application status
    UPDATE owner_applications
    SET status = 'approved',
        reviewed_at = NOW(),
        reviewed_by = v_admin_id,
        admin_notes = p_admin_notes
    WHERE id = p_application_id;
    
    RETURN json_build_object(
        'success', true, 
        'message', 'Application approved',
        'theatre_id', v_theatre_id
    );
END;
$$;

GRANT EXECUTE ON FUNCTION approve_owner_application(UUID, TEXT) TO authenticated;

-- Reject owner application (admin only)
CREATE OR REPLACE FUNCTION reject_owner_application(
    p_application_id UUID,
    p_admin_notes TEXT DEFAULT NULL
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_admin_id UUID := auth.uid();
BEGIN
    -- Check if caller is admin
    IF NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RETURN json_build_object('success', false, 'error', 'Access denied: Admin only');
    END IF;
    
    -- Check if application exists and is pending
    IF NOT EXISTS (SELECT 1 FROM owner_applications WHERE id = p_application_id AND status = 'pending') THEN
        RETURN json_build_object('success', false, 'error', 'Application not found or already processed');
    END IF;
    
    -- Update application status
    UPDATE owner_applications
    SET status = 'rejected',
        reviewed_at = NOW(),
        reviewed_by = v_admin_id,
        admin_notes = p_admin_notes
    WHERE id = p_application_id;
    
    RETURN json_build_object('success', true, 'message', 'Application rejected');
END;
$$;

GRANT EXECUTE ON FUNCTION reject_owner_application(UUID, TEXT) TO authenticated;

-- Check application status (for users)
CREATE OR REPLACE FUNCTION get_my_application_status()
RETURNS TABLE(
    id UUID,
    status TEXT,
    created_at TIMESTAMP WITH TIME ZONE,
    reviewed_at TIMESTAMP WITH TIME ZONE,
    admin_notes TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        oa.id, oa.status, oa.created_at, oa.reviewed_at, oa.admin_notes
    FROM owner_applications oa
    WHERE oa.user_id = auth.uid()
    ORDER BY oa.created_at DESC
    LIMIT 1;
END;
$$;

GRANT EXECUTE ON FUNCTION get_my_application_status() TO authenticated;
