-- Theater branding & white-label configuration
CREATE TABLE IF NOT EXISTS theater_branding (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  theater_id          UUID UNIQUE NOT NULL REFERENCES theatres(id) ON DELETE CASCADE,
  
  -- Identity
  display_name        TEXT NOT NULL,
  tagline             TEXT,
  logo_url            TEXT,
  favicon_url         TEXT,
  
  -- Colors (hex values)
  primary_color       TEXT NOT NULL DEFAULT '#e50914',
  accent_color        TEXT NOT NULL DEFAULT '#ffffff',
  background_color    TEXT NOT NULL DEFAULT '#141414',
  card_color          TEXT NOT NULL DEFAULT '#1a1a1a',
  text_color          TEXT NOT NULL DEFAULT '#ffffff',
  
  -- Domain
  subdomain           TEXT UNIQUE,            -- 'angelcineworld' → angelcineworld.quickmytickets.com
  custom_domain       TEXT UNIQUE,            -- 'tickets.angelcineworld.com'
  
  -- Contact
  whatsapp_number     TEXT,
  support_email       TEXT,
  
  -- Social
  instagram_url       TEXT,
  facebook_url        TEXT,
  
  -- Config
  active              BOOLEAN DEFAULT true,
  show_powered_by     BOOLEAN DEFAULT true,   -- 'Powered by Quick My Ticket' footer badge
  
  created_at          TIMESTAMPTZ DEFAULT NOW(),
  updated_at          TIMESTAMPTZ DEFAULT NOW()
);

-- RLS: Only the theater owner and admins can read/write their branding
ALTER TABLE theater_branding ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Theater owner can manage own branding" ON theater_branding;
CREATE POLICY "Theater owner can manage own branding"
ON theater_branding
FOR ALL
USING (
  theater_id IN (
    SELECT t.id FROM theatres t
    JOIN theater_owners to2 ON t.id = to2.theatre_id
    WHERE to2.user_id = auth.uid()
  )
)
WITH CHECK (
  theater_id IN (
    SELECT t.id FROM theatres t
    JOIN theater_owners to2 ON t.id = to2.theatre_id
    WHERE to2.user_id = auth.uid()
  )
);

DROP POLICY IF EXISTS "Admins can manage all branding" ON theater_branding;
CREATE POLICY "Admins can manage all branding"
ON theater_branding
FOR ALL
USING (
  (auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true
);

DROP POLICY IF EXISTS "Public can read active branding" ON theater_branding;
CREATE POLICY "Public can read active branding"
ON theater_branding
FOR SELECT
USING (active = true);

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_theater_branding_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS theater_branding_updated_at ON theater_branding;
CREATE TRIGGER theater_branding_updated_at BEFORE UPDATE ON theater_branding
  FOR EACH ROW EXECUTE FUNCTION update_theater_branding_timestamp();

-- Index for fast domain lookups
CREATE INDEX IF NOT EXISTS idx_theater_branding_subdomain ON theater_branding(subdomain);
CREATE INDEX IF NOT EXISTS idx_theater_branding_custom_domain ON theater_branding(custom_domain);
CREATE INDEX IF NOT EXISTS idx_theater_branding_theater_id ON theater_branding(theater_id);
