-- ============================================
-- Quick My Ticket - Fix Seat Release Issue
-- ============================================
-- This migration fixes the seat release mechanism:
-- 1. Updates lock_seat to reuse cancelled/expired bookings instead of creating new ones
-- 2. Adds a manual cleanup function that can be called from client-side
-- 3. Adds a unique partial index to prevent duplicate active bookings

-- ============================================
-- 1. ADD UNIQUE PARTIAL INDEX
-- ============================================
-- Ensures only one active booking (locked/confirmed) per seat per show
CREATE UNIQUE INDEX IF NOT EXISTS idx_bookings_active_unique 
ON bookings(show_id, seat_id) 
WHERE status IN ('locked', 'confirmed');

-- ============================================
-- 2. IMPROVED LOCK_SEAT FUNCTION
-- ============================================
-- Key fix: Instead of always INSERTing, this version will:
-- 1. First check for any cancelled/expired booking for this seat and REUSE it
-- 2. Only create a new booking if none exists

CREATE OR REPLACE FUNCTION lock_seat(
    p_show_id UUID, 
    p_seat_id UUID, 
    p_user_id UUID
)
RETURNS TABLE(
    booking_id UUID, 
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking_id UUID;
    v_existing RECORD;
    v_screen_id UUID;
    v_seat_exists BOOLEAN;
    v_reusable_booking UUID;
BEGIN
    -- Validate that the show exists and get screen_id
    SELECT screen_id INTO v_screen_id 
    FROM shows 
    WHERE id = p_show_id;
    
    IF v_screen_id IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Show not found'::TEXT;
        RETURN;
    END IF;
    
    -- Validate that the seat exists and belongs to the show's screen
    SELECT EXISTS(
        SELECT 1 FROM seats 
        WHERE id = p_seat_id AND screen_id = v_screen_id
    ) INTO v_seat_exists;
    
    IF NOT v_seat_exists THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat not found for this show'::TEXT;
        RETURN;
    END IF;
    
    -- Try to acquire a lock on existing active booking (if any)
    SELECT * INTO v_existing
    FROM bookings 
    WHERE show_id = p_show_id 
      AND seat_id = p_seat_id 
      AND status IN ('locked', 'confirmed')
    FOR UPDATE SKIP LOCKED;
    
    -- Check if seat is already taken
    IF FOUND THEN
        -- Check if it's the same user's existing lock
        IF v_existing.user_id = p_user_id AND v_existing.status = 'locked' THEN
            -- Refresh the lock timestamp
            UPDATE bookings 
            SET locked_at = NOW() 
            WHERE id = v_existing.id;
            
            RETURN QUERY SELECT v_existing.id, TRUE, 'Lock refreshed'::TEXT;
            RETURN;
        ELSE
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is already locked or booked'::TEXT;
            RETURN;
        END IF;
    END IF;
    
    -- Look for a reusable cancelled/expired booking for this seat
    SELECT id INTO v_reusable_booking
    FROM bookings
    WHERE show_id = p_show_id
      AND seat_id = p_seat_id
      AND status IN ('cancelled', 'expired')
    ORDER BY created_at DESC
    LIMIT 1
    FOR UPDATE;
    
    IF v_reusable_booking IS NOT NULL THEN
        -- Reuse existing booking record
        UPDATE bookings 
        SET status = 'locked',
            user_id = p_user_id,
            locked_at = NOW(),
            payment_id = NULL,
            confirmed_at = NULL
        WHERE id = v_reusable_booking
        RETURNING id INTO v_booking_id;
        
        RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully (reused)'::TEXT;
        RETURN;
    END IF;
    
    -- Insert new booking with lock
    INSERT INTO bookings (show_id, seat_id, user_id, status, locked_at)
    VALUES (p_show_id, p_seat_id, p_user_id, 'locked', NOW())
    RETURNING id INTO v_booking_id;
    
    RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
    
EXCEPTION
    WHEN unique_violation THEN
        -- Race condition: another transaction inserted first
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat was just locked by another user'::TEXT;
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, ('Error: ' || SQLERRM)::TEXT;
END;
$$;

-- ============================================
-- 3. CLIENT-CALLABLE CLEANUP FUNCTION
-- ============================================
-- This function can be called by authenticated users to release their own expired locks
-- It's a lighter version that doesn't require service_role

CREATE OR REPLACE FUNCTION cleanup_my_expired_locks(
    p_timeout_minutes INTEGER DEFAULT 5
)
RETURNS TABLE(
    cleaned_count INTEGER
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id UUID;
    v_count INTEGER;
BEGIN
    -- Get current user
    v_user_id := auth.uid();
    
    IF v_user_id IS NULL THEN
        RETURN QUERY SELECT 0;
        RETURN;
    END IF;
    
    -- Release user's own expired locks
    WITH expired AS (
        UPDATE bookings 
        SET status = 'expired'
        WHERE user_id = v_user_id
          AND status = 'locked' 
          AND locked_at < NOW() - (p_timeout_minutes || ' minutes')::INTERVAL
        RETURNING id
    )
    SELECT COUNT(*)::INTEGER INTO v_count FROM expired;
    
    RETURN QUERY SELECT COALESCE(v_count, 0);
END;
$$;

GRANT EXECUTE ON FUNCTION cleanup_my_expired_locks(INTEGER) TO authenticated;

-- ============================================
-- 4. FORCE RELEASE FUNCTION (for stuck seats)
-- ============================================
-- Releases ALL locks older than a specified time (service role only)
-- Call this manually if seats are stuck

CREATE OR REPLACE FUNCTION force_release_all_expired_locks(
    p_timeout_minutes INTEGER DEFAULT 5
)
RETURNS TABLE(
    released_count INTEGER,
    released_ids UUID[]
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_released_ids UUID[];
    v_count INTEGER;
BEGIN
    -- Force release ALL expired locks regardless of user
    WITH expired AS (
        UPDATE bookings 
        SET status = 'expired',
            locked_at = NULL
        WHERE status = 'locked' 
          AND locked_at < NOW() - (p_timeout_minutes || ' minutes')::INTERVAL
        RETURNING id
    )
    SELECT array_agg(id), COUNT(*)::INTEGER 
    INTO v_released_ids, v_count
    FROM expired;
    
    RETURN QUERY SELECT COALESCE(v_count, 0), COALESCE(v_released_ids, ARRAY[]::UUID[]);
END;
$$;

-- Allow both service_role AND authenticated users to call this (for emergency use)
GRANT EXECUTE ON FUNCTION force_release_all_expired_locks(INTEGER) TO authenticated;
GRANT EXECUTE ON FUNCTION force_release_all_expired_locks(INTEGER) TO service_role;

-- ============================================
-- 5. FIX STATUS CONSTRAINT AND CLEANUP
-- ============================================
-- First, ensure 'expired' is a valid status, then clean up stuck bookings

-- Drop the old constraint if it exists and recreate with 'expired'
DO $$
BEGIN
    -- Drop existing constraint if it exists
    IF EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'bookings_status_check'
    ) THEN
        ALTER TABLE bookings DROP CONSTRAINT bookings_status_check;
    END IF;
    
    -- Add constraint with 'expired' included
    ALTER TABLE bookings 
    ADD CONSTRAINT bookings_status_check 
    CHECK (status IN ('locked', 'confirmed', 'cancelled', 'expired'));
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;

-- Now run immediate cleanup to release all currently stuck locks
DO $$
DECLARE
    v_count INTEGER;
BEGIN
    -- Release all locks older than 10 minutes (likely stuck)
    UPDATE bookings 
    SET status = 'expired', locked_at = NULL
    WHERE status = 'locked' 
      AND locked_at < NOW() - INTERVAL '10 minutes';
    
    GET DIAGNOSTICS v_count = ROW_COUNT;
    RAISE NOTICE 'Released % stuck locks', v_count;
END $$;
