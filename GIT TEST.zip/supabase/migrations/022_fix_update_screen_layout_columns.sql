-- ============================================
-- Quick My Ticket - Fix all Seat Layout RPCs
-- Migration 022 (FINAL FIX)
-- ============================================

-- First, drop existing functions to ensure we are starting fresh
DROP FUNCTION IF EXISTS update_screen_layout(UUID, JSONB);
DROP FUNCTION IF EXISTS get_screen_layout(UUID);

-- 1. Fix update_screen_layout
CREATE OR REPLACE FUNCTION update_screen_layout(
    p_screen_id UUID,
    p_seat_layout JSONB
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_theatre_id UUID;
    v_is_owner BOOLEAN;
BEGIN
    -- Validation
    IF p_seat_layout IS NULL 
       OR jsonb_typeof(p_seat_layout->'rows') IS DISTINCT FROM 'array' THEN
        RETURN json_build_object('success', false, 'error', 'Invalid seat layout');
    END IF;

    -- Find theatre and check permissions
    SELECT theatre_id INTO v_theatre_id
    FROM screens
    WHERE id = p_screen_id;

    IF v_theatre_id IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Screen not found');
    END IF;

    SELECT EXISTS(
        SELECT 1 FROM theater_owners
        WHERE user_id = v_user_id AND theatre_id = v_theatre_id
    ) INTO v_is_owner;

    IF NOT v_is_owner AND NOT (COALESCE((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean, false) = true) THEN
        RETURN json_build_object('success', false, 'error', 'Access denied');
    END IF;

    -- Check for active bookings
    IF EXISTS (
        SELECT 1 FROM bookings b
        JOIN shows s ON b.show_id = s.id
        WHERE s.screen_id = p_screen_id AND b.status IN ('confirmed', 'locked')
        
        UNION ALL
        
        SELECT 1 FROM bookings b
        JOIN event_shows es ON b.event_show_id = es.id
        WHERE es.screen_id = p_screen_id AND b.status IN ('confirmed', 'locked')
    ) THEN
        RETURN json_build_object('success', false, 'error', 'Cannot update layout: Active bookings exist for this screen');
    END IF;

    -- Update screen (using verified columns: seat_layout, total_seats)
    UPDATE screens
    SET 
        seat_layout = p_seat_layout,
        total_seats = COALESCE((p_seat_layout->'metadata'->>'totalSeats')::integer, total_seats)
    WHERE id = p_screen_id;

    -- Sync seats table
    DELETE FROM seats WHERE screen_id = p_screen_id;

    INSERT INTO seats (screen_id, row, col, tier, price)
    SELECT 
        p_screen_id,
        r->>'label',
        (s->>'id')::integer,
        s->>'type',
        (s->>'price')::integer
    FROM jsonb_array_elements(p_seat_layout->'rows') AS r
    CROSS JOIN jsonb_array_elements(r->'seats') AS s
    WHERE s IS NOT NULL AND s != 'null'::jsonb;

    RETURN json_build_object('success', true, 'message', 'Layout updated and seats synced');
END;
$$;

-- 2. Fix get_screen_layout
CREATE OR REPLACE FUNCTION get_screen_layout(p_screen_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_layout JSONB;
BEGIN
    -- Only select columns that actually exist!
    SELECT seat_layout
    INTO v_layout
    FROM screens
    WHERE id = p_screen_id;
    
    -- If custom layout exists, return it
    IF v_layout IS NOT NULL THEN
        RETURN v_layout;
    END IF;
    
    -- If no layout, return a simple 10x12 default
    RETURN generate_default_layout(10, 12);
END;
$$;

GRANT EXECUTE ON FUNCTION update_screen_layout(UUID, JSONB) TO authenticated;
GRANT EXECUTE ON FUNCTION get_screen_layout(UUID) TO anon, authenticated;
