-- ============================================
-- Quick My Ticket Theater Owner System
-- ============================================
-- This migration adds:
-- 1. Theater owners table (links users to theatres)
-- 2. Updated RLS policies for multi-tenant access
-- 3. Owner-specific views and functions
-- 4. Dashboard statistics functions

-- ============================================
-- 1. THEATER OWNERS TABLE
-- ============================================
-- Links users to theatres they own/manage

CREATE TABLE IF NOT EXISTS theater_owners (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    theatre_id UUID NOT NULL REFERENCES theatres(id) ON DELETE CASCADE,
    role TEXT DEFAULT 'owner' CHECK (role IN ('owner', 'manager', 'staff')),
    permissions JSONB DEFAULT '{"can_edit_shows": true, "can_view_revenue": true, "can_manage_staff": false}'::JSONB,
    invited_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, theatre_id)
);

-- CREATE INDEX IF NOT EXISTS for quick lookups
CREATE INDEX IF NOT EXISTS idx_theater_owners_user ON theater_owners(user_id);
CREATE INDEX IF NOT EXISTS idx_theater_owners_theatre ON theater_owners(theatre_id);

-- Enable RLS
ALTER TABLE theater_owners ENABLE ROW LEVEL SECURITY;

-- ============================================
-- 2. RLS POLICIES FOR THEATER OWNERS TABLE
-- ============================================

-- Super admins can manage all theater owners
DROP POLICY IF EXISTS "Admin full access theater_owners" ON theater_owners;
CREATE POLICY "Admin full access theater_owners"
ON theater_owners 
FOR ALL USING (
    (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);

-- Theater owners can read their own assignments
DROP POLICY IF EXISTS "Owners read own assignments" ON theater_owners;
CREATE POLICY "Owners read own assignments"
ON theater_owners 
FOR SELECT USING (
    auth.uid() = user_id
);

-- Theater owners with 'owner' role can invite managers/staff to their theatres
DROP POLICY IF EXISTS "Owners can add staff" ON theater_owners;
CREATE POLICY "Owners can add staff"
ON theater_owners 
FOR INSERT WITH CHECK (
    EXISTS (
        SELECT 1 FROM theater_owners existing
        WHERE existing.theatre_id = theater_owners.theatre_id
        AND existing.user_id = auth.uid()
        AND existing.role = 'owner'
    )
    AND theater_owners.role IN ('manager', 'staff')
);


-- ============================================
-- 3. UPDATE THEATRES RLS FOR OWNER ACCESS
-- ============================================

-- Drop existing admin-only policy if exists (safely)
DO $$
BEGIN
        EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- Allow theater owners to manage their theatres
DROP POLICY IF EXISTS "Owner manage theatres" ON theatres;
CREATE POLICY "Owner manage theatres"
ON theatres 
FOR UPDATE USING (
    EXISTS (
        SELECT 1 FROM theater_owners 
        WHERE theatre_id = theatres.id 
        AND user_id = auth.uid()
        AND role IN ('owner', 'manager')
    )
);

-- Admins can do everything on theatres
DROP POLICY IF EXISTS "Admin manage theatres" ON theatres;
CREATE POLICY "Admin manage theatres"
ON theatres 
FOR ALL USING (
    (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);


-- ============================================
-- 4. UPDATE SCREENS RLS FOR OWNER ACCESS
-- ============================================

DO $$
BEGIN
        EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- Allow theater owners to manage screens in their theatres
DROP POLICY IF EXISTS "Owner manage screens" ON screens;
CREATE POLICY "Owner manage screens"
ON screens 
FOR ALL USING (
    EXISTS (
        SELECT 1 FROM theater_owners 
        WHERE theatre_id = screens.theatre_id 
        AND user_id = auth.uid()
        AND role IN ('owner', 'manager')
    )
);

-- Admins can do everything on screens
DROP POLICY IF EXISTS "Admin manage screens" ON screens;
CREATE POLICY "Admin manage screens"
ON screens 
FOR ALL USING (
    (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);


-- ============================================
-- 5. UPDATE SHOWS RLS FOR OWNER ACCESS
-- ============================================

DO $$
BEGIN
        EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- Allow theater owners to manage shows on their screens
DROP POLICY IF EXISTS "Owner manage shows" ON shows;
CREATE POLICY "Owner manage shows"
ON shows 
FOR ALL USING (
    EXISTS (
        SELECT 1 FROM theater_owners to_owner
        JOIN screens s ON s.theatre_id = to_owner.theatre_id
        WHERE s.id = shows.screen_id
        AND to_owner.user_id = auth.uid()
        AND to_owner.role IN ('owner', 'manager')
    )
);

-- Admins can do everything on shows
DROP POLICY IF EXISTS "Admin manage shows" ON shows;
CREATE POLICY "Admin manage shows"
ON shows 
FOR ALL USING (
    (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);


-- ============================================
-- 6. OWNER DASHBOARD FUNCTIONS
-- ============================================

-- Function to get theatres owned by a user
CREATE OR REPLACE FUNCTION get_owned_theatres(p_user_id UUID)
RETURNS TABLE(
    theatre_id UUID,
    theatre_name TEXT,
    location TEXT,
    role TEXT,
    screen_count BIGINT,
    total_seats BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        t.id AS theatre_id,
        t.name AS theatre_name,
        t.location,
        to_owner.role,
        COUNT(DISTINCT s.id) AS screen_count,
        COUNT(DISTINCT seats.id) AS total_seats
    FROM theater_owners to_owner
    JOIN theatres t ON t.id = to_owner.theatre_id
    LEFT JOIN screens s ON s.theatre_id = t.id
    LEFT JOIN seats ON seats.screen_id = s.id
    WHERE to_owner.user_id = p_user_id
    GROUP BY t.id, t.name, t.location, to_owner.role
    ORDER BY t.name;
END;
$$;

GRANT EXECUTE ON FUNCTION get_owned_theatres(UUID) TO authenticated;


-- Function to get dashboard statistics for a theater owner
CREATE OR REPLACE FUNCTION get_owner_dashboard_stats(p_user_id UUID)
RETURNS TABLE(
    total_theatres BIGINT,
    total_screens BIGINT,
    total_seats BIGINT,
    today_bookings BIGINT,
    today_revenue DECIMAL,
    currently_locked BIGINT,
    today_confirmed BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_theatre_ids UUID[];
    v_today DATE := CURRENT_DATE;
BEGIN
    -- Get all theatre IDs owned by this user
    SELECT ARRAY_AGG(theatre_id) INTO v_theatre_ids
    FROM theater_owners
    WHERE user_id = p_user_id;
    
    -- If user owns no theatres, return zeros
    IF v_theatre_ids IS NULL THEN
        RETURN QUERY SELECT 0::BIGINT, 0::BIGINT, 0::BIGINT, 0::BIGINT, 0::DECIMAL, 0::BIGINT, 0::BIGINT;
        RETURN;
    END IF;
    
    RETURN QUERY
    WITH owned_screens AS (
        SELECT s.id AS screen_id
        FROM screens s
        WHERE s.theatre_id = ANY(v_theatre_ids)
    ),
    owned_shows AS (
        SELECT sh.id AS show_id, sh.price
        FROM shows sh
        JOIN owned_screens os ON os.screen_id = sh.screen_id
    ),
    owned_bookings AS (
        SELECT b.*
        FROM bookings b
        JOIN owned_shows osh ON osh.show_id = b.show_id
    )
    SELECT
        (SELECT COUNT(*) FROM unnest(v_theatre_ids))::BIGINT AS total_theatres,
        (SELECT COUNT(*) FROM owned_screens)::BIGINT AS total_screens,
        (SELECT COUNT(*) FROM seats WHERE screen_id IN (SELECT screen_id FROM owned_screens))::BIGINT AS total_seats,
        (SELECT COUNT(*) FROM owned_bookings WHERE DATE(created_at) = v_today)::BIGINT AS today_bookings,
        COALESCE((
            SELECT SUM(COALESCE(seats.price, osh.price, 0))
            FROM owned_bookings ob
            JOIN owned_shows osh ON osh.show_id = ob.show_id
            JOIN seats ON seats.id = ob.seat_id
            WHERE ob.status = 'confirmed' AND DATE(ob.confirmed_at) = v_today
        ), 0)::DECIMAL AS today_revenue,
        (SELECT COUNT(*) FROM owned_bookings WHERE status = 'locked')::BIGINT AS currently_locked,
        (SELECT COUNT(*) FROM owned_bookings WHERE status = 'confirmed' AND DATE(confirmed_at) = v_today)::BIGINT AS today_confirmed;
END;
$$;

GRANT EXECUTE ON FUNCTION get_owner_dashboard_stats(UUID) TO authenticated;


-- Function to get shows for a theatre with booking counts
CREATE OR REPLACE FUNCTION get_owner_shows(
    p_user_id UUID,
    p_theatre_id UUID DEFAULT NULL,
    p_date DATE DEFAULT CURRENT_DATE
)
RETURNS TABLE(
    show_id UUID,
    movie_title TEXT,
    screen_name TEXT,
    theatre_name TEXT,
    start_time TIMESTAMPTZ,
    end_time TIMESTAMPTZ,
    base_price DECIMAL,
    total_seats BIGINT,
    booked_seats BIGINT,
    locked_seats BIGINT,
    available_seats BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        sh.id AS show_id,
        m.title AS movie_title,
        sc.name AS screen_name,
        t.name AS theatre_name,
        sh.start_time,
        sh.end_time,
        sh.price AS base_price,
        COUNT(DISTINCT seats.id) AS total_seats,
        COUNT(DISTINCT CASE WHEN b.status = 'confirmed' THEN b.id END) AS booked_seats,
        COUNT(DISTINCT CASE WHEN b.status = 'locked' THEN b.id END) AS locked_seats,
        COUNT(DISTINCT seats.id) - COUNT(DISTINCT CASE WHEN b.status IN ('confirmed', 'locked') THEN b.id END) AS available_seats
    FROM shows sh
    JOIN movies m ON m.id = sh.movie_id
    JOIN screens sc ON sc.id = sh.screen_id
    JOIN theatres t ON t.id = sc.theatre_id
    JOIN theater_owners to_owner ON to_owner.theatre_id = t.id
    LEFT JOIN seats ON seats.screen_id = sc.id
    LEFT JOIN bookings b ON b.show_id = sh.id AND b.seat_id = seats.id AND b.status IN ('confirmed', 'locked')
    WHERE to_owner.user_id = p_user_id
      AND (p_theatre_id IS NULL OR t.id = p_theatre_id)
      AND DATE(sh.start_time) = p_date
    GROUP BY sh.id, m.title, sc.name, t.name, sh.start_time, sh.end_time, sh.price
    ORDER BY sh.start_time;
END;
$$;

GRANT EXECUTE ON FUNCTION get_owner_shows(UUID, UUID, DATE) TO authenticated;


-- Function to check if user is a theater owner
CREATE OR REPLACE FUNCTION is_theater_owner(p_user_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM theater_owners WHERE user_id = p_user_id
    );
END;
$$;

GRANT EXECUTE ON FUNCTION is_theater_owner(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION is_theater_owner(UUID) TO anon;


-- ============================================
-- 7. ADD OWNER FLAG TO USER METADATA CHECK
-- ============================================

-- View to easily check user roles
CREATE OR REPLACE VIEW user_roles AS
SELECT 
    au.id AS user_id,
    au.email,
    COALESCE((au.raw_user_meta_data ->> 'is_admin')::boolean, false) AS is_admin,
    EXISTS (SELECT 1 FROM theater_owners WHERE user_id = au.id) AS is_theater_owner,
    (SELECT ARRAY_AGG(theatre_id) FROM theater_owners WHERE user_id = au.id) AS owned_theatre_ids
FROM auth.users au;

-- Note: This view uses auth.users which requires careful RLS handling
-- For security, we provide a function instead

CREATE OR REPLACE FUNCTION get_user_role(p_user_id UUID)
RETURNS TABLE(
    is_admin BOOLEAN,
    is_theater_owner BOOLEAN,
    owned_theatre_count BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        COALESCE((au.raw_user_meta_data ->> 'is_admin')::boolean, false) AS is_admin,
        EXISTS (SELECT 1 FROM theater_owners WHERE user_id = p_user_id) AS is_theater_owner,
        (SELECT COUNT(*) FROM theater_owners WHERE user_id = p_user_id) AS owned_theatre_count
    FROM auth.users au
    WHERE au.id = p_user_id;
END;
$$;

GRANT EXECUTE ON FUNCTION get_user_role(UUID) TO authenticated;


-- ============================================
-- 8. TRIGGER TO UPDATE updated_at
-- ============================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS update_theater_owners_updated_at ON theater_owners;
CREATE TRIGGER update_theater_owners_updated_at BEFORE UPDATE ON theater_owners
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();


-- ============================================
-- 9. GRANT SELECT ON theater_owners FOR OWNERSHIP CHECK
-- ============================================

GRANT SELECT ON theater_owners TO authenticated;


-- ============================================
-- 10. SAMPLE DATA (Optional - for testing)
-- ============================================
-- Uncomment to add sample theater owner assignments
-- This assumes you have existing theatres and users

/*
-- Example: Assign a user as theater owner
INSERT INTO theater_owners (user_id, theatre_id, role)
SELECT 
    'USER_UUID_HERE',
    id,
    'owner'
FROM theatres
WHERE name = 'Your Theatre Name'
ON CONFLICT DO NOTHING;
*/

-- ============================================
-- MIGRATION COMPLETE
-- ============================================
-- Next steps:
-- 1. Run this migration in Supabase SQL Editor
-- 2. Assign theater owners via admin panel or direct SQL
-- 3. Theater owners can now access owner-dashboard.html
