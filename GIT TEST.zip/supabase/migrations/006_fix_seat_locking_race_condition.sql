-- ============================================
-- Quick My Ticket - Fix Seat Locking Race Condition
-- ============================================
-- This migration fixes two critical issues:
-- 1. Race condition where multiple users can lock the same seat simultaneously
-- 2. Expired locks (older than 5 minutes) still showing as "locked" in UI
--
-- Key changes:
-- - Uses FOR UPDATE NOWAIT instead of SKIP LOCKED (fails immediately if row is locked)
-- - Auto-expires stale locks within the lock_seat function
-- - Updates seat_availability view to filter expired locks

-- ============================================
-- 1. IMPROVED LOCK_SEAT FUNCTION
-- ============================================
-- Fixes:
-- - FOR UPDATE NOWAIT: Fails immediately if another transaction has the row
-- - Auto-expires locks older than 5 minutes before checking
-- - Handles lock_not_available exception gracefully

CREATE OR REPLACE FUNCTION lock_seat(
    p_show_id UUID, 
    p_seat_id UUID, 
    p_user_id UUID
)
RETURNS TABLE(
    booking_id UUID, 
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking_id UUID;
    v_existing RECORD;
    v_screen_id UUID;
    v_seat_exists BOOLEAN;
    v_reusable_booking UUID;
    v_lock_timeout_minutes INTEGER := 5;
BEGIN
    -- Validate that the show exists and get screen_id
    SELECT screen_id INTO v_screen_id 
    FROM shows 
    WHERE id = p_show_id;
    
    IF v_screen_id IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Show not found'::TEXT;
        RETURN;
    END IF;
    
    -- Validate that the seat exists and belongs to the show's screen
    SELECT EXISTS(
        SELECT 1 FROM seats 
        WHERE id = p_seat_id AND screen_id = v_screen_id
    ) INTO v_seat_exists;
    
    IF NOT v_seat_exists THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat not found for this show'::TEXT;
        RETURN;
    END IF;
    
    -- STEP 1: Auto-expire stale locks on this specific seat FIRST
    -- This ensures expired locks don't block new bookings
    UPDATE bookings 
    SET status = 'expired', locked_at = NULL
    WHERE show_id = p_show_id 
      AND seat_id = p_seat_id 
      AND status = 'locked'
      AND locked_at < NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL;
    
    -- STEP 2: Try to acquire a lock on existing active booking
    -- Use NOWAIT to fail immediately if another transaction has the row locked
    -- This prevents race conditions where two users try to lock simultaneously
    BEGIN
        SELECT * INTO v_existing
        FROM bookings 
        WHERE show_id = p_show_id 
          AND seat_id = p_seat_id 
          AND status IN ('locked', 'confirmed')
        FOR UPDATE NOWAIT;
    EXCEPTION
        WHEN lock_not_available THEN
            -- Another transaction is currently modifying this row
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is currently being processed by another user, please try again'::TEXT;
            RETURN;
    END;
    
    -- Check if seat is already taken
    IF FOUND THEN
        -- Check if it's the same user's existing lock
        IF v_existing.user_id = p_user_id AND v_existing.status = 'locked' THEN
            -- Refresh the lock timestamp
            UPDATE bookings 
            SET locked_at = NOW() 
            WHERE id = v_existing.id;
            
            RETURN QUERY SELECT v_existing.id, TRUE, 'Lock refreshed'::TEXT;
            RETURN;
        ELSE
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is already locked or booked'::TEXT;
            RETURN;
        END IF;
    END IF;
    
    -- STEP 3: Look for a reusable cancelled/expired booking for this seat
    SELECT id INTO v_reusable_booking
    FROM bookings
    WHERE show_id = p_show_id
      AND seat_id = p_seat_id
      AND status IN ('cancelled', 'expired')
    ORDER BY created_at DESC
    LIMIT 1
    FOR UPDATE;
    
    IF v_reusable_booking IS NOT NULL THEN
        -- Reuse existing booking record
        UPDATE bookings 
        SET status = 'locked',
            user_id = p_user_id,
            locked_at = NOW(),
            payment_id = NULL,
            confirmed_at = NULL
        WHERE id = v_reusable_booking
        RETURNING id INTO v_booking_id;
        
        RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
        RETURN;
    END IF;
    
    -- STEP 4: Insert new booking with lock
    INSERT INTO bookings (show_id, seat_id, user_id, status, locked_at)
    VALUES (p_show_id, p_seat_id, p_user_id, 'locked', NOW())
    RETURNING id INTO v_booking_id;
    
    RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
    
EXCEPTION
    WHEN unique_violation THEN
        -- Race condition: another transaction inserted first (caught by unique index)
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat was just locked by another user'::TEXT;
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, ('Error: ' || SQLERRM)::TEXT;
END;
$$;

-- ============================================
-- 2. UPDATED SEAT_AVAILABILITY VIEW
-- ============================================
-- Now filters out expired locks (older than 5 minutes)
-- Expired locks show as "available" instead of "locked"

CREATE OR REPLACE VIEW seat_availability AS
SELECT 
    s.id AS seat_id,
    s.screen_id,
    s.row,
    s.col,
    s.tier,
    s.price AS seat_price,
    sh.id AS show_id,
    sh.price AS show_price,
    COALESCE(s.price, sh.price, 0) AS effective_price,
    CASE 
        WHEN b.status = 'confirmed' THEN 'booked'
        WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 'locked'
        ELSE 'available'
    END AS availability_status,
    b.user_id AS locked_by,
    b.id AS booking_id,
    b.locked_at
FROM seats s
CROSS JOIN shows sh
LEFT JOIN LATERAL (
    SELECT * FROM bookings 
    WHERE seat_id = s.id 
      AND show_id = sh.id 
      AND (
          status = 'confirmed' 
          OR (status = 'locked' AND locked_at >= NOW() - INTERVAL '5 minutes')
      )
    ORDER BY 
        CASE WHEN status = 'confirmed' THEN 0 ELSE 1 END,
        locked_at DESC
    LIMIT 1
) b ON TRUE
WHERE s.screen_id = sh.screen_id;

-- Re-grant permissions on the view (required after CREATE OR REPLACE)
GRANT SELECT ON seat_availability TO authenticated;
GRANT SELECT ON seat_availability TO anon;

-- ============================================
-- 3. IMMEDIATE CLEANUP OF ALL EXPIRED LOCKS
-- ============================================
-- Release all currently expired locks to make those seats available immediately

DO $$
DECLARE
    v_count INTEGER;
BEGIN
    UPDATE bookings 
    SET status = 'expired', locked_at = NULL
    WHERE status = 'locked' 
      AND locked_at < NOW() - INTERVAL '5 minutes';
    
    GET DIAGNOSTICS v_count = ROW_COUNT;
    RAISE NOTICE 'Released % expired locks', v_count;
END $$;
