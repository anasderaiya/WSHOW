-- ============================================
-- Quick My Ticket - Fix Guest Lock Release
-- ============================================
-- This migration:
-- 1. Updates extend_locks to support guest sessions
-- 2. Adds a pg_cron job to auto-release expired locks every minute
-- 3. Adds a direct SQL function for force-releasing all expired locks

-- 1. Update extend_locks to support session_id (guest heartbeat)
CREATE OR REPLACE FUNCTION extend_locks(
    p_booking_ids UUID[],
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    extended_count INTEGER,
    success BOOLEAN,
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_count INTEGER := 0;
    v_lock_timeout_minutes INTEGER := 5;
BEGIN
    -- Extend locks matching either user_id or session_id
    UPDATE bookings
    SET locked_at = NOW()
    WHERE id = ANY(p_booking_ids)
      AND status = 'locked'
      AND locked_at >= NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL
      AND (
          (p_user_id IS NOT NULL AND user_id = p_user_id) OR
          (p_session_id IS NOT NULL AND session_id = p_session_id)
      );
    
    GET DIAGNOSTICS v_count = ROW_COUNT;
    
    IF v_count > 0 THEN
        RETURN QUERY SELECT v_count, TRUE, format('Extended %s lock(s)', v_count)::TEXT;
    ELSE
        RETURN QUERY SELECT 0, FALSE, 'No active locks to extend'::TEXT;
    END IF;
END;
$$;

-- Grant to both authenticated and anon (guests)
GRANT EXECUTE ON FUNCTION extend_locks(UUID[], UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION extend_locks(UUID[], UUID, TEXT) TO anon;

-- 2. Auto-release expired locks directly in SQL (no Edge Function needed)
-- This runs as a simple function that pg_cron can call directly
CREATE OR REPLACE FUNCTION auto_release_expired_locks()
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_count INTEGER;
BEGIN
    UPDATE bookings
    SET status = 'expired', locked_at = NULL
    WHERE status = 'locked'
      AND locked_at < NOW() - INTERVAL '5 minutes';
    
    GET DIAGNOSTICS v_count = ROW_COUNT;
    
    IF v_count > 0 THEN
        RAISE LOG 'JayShow: Auto-released % expired seat locks', v_count;
    END IF;
    
    RETURN v_count;
END;
$$;

-- 3. Schedule the auto-release job via pg_cron (optional)
-- NOTE: pg_cron must be enabled in Supabase Dashboard -> Database -> Extensions
-- If pg_cron is not enabled, this block is skipped gracefully.
DO $$
BEGIN
    PERFORM cron.schedule(
        'release-expired-locks',
        '* * * * *',
        'SELECT auto_release_expired_locks()'
    );
    RAISE LOG '[QMT] pg_cron job "release-expired-locks" scheduled (every minute)';
EXCEPTION WHEN OTHERS THEN
    RAISE LOG '[QMT] pg_cron not available — skipping cron job setup. Enable pg_cron in Supabase Dashboard -> Database -> Extensions and re-run this block manually.';
END;
$$;
