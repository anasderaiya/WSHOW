-- Migration 042: Fix RLS for platform_settings to check app_metadata
DROP POLICY IF EXISTS "Allow admin update access to platform_settings" ON public.platform_settings;

CREATE POLICY "Allow admin update access to platform_settings"
ON public.platform_settings FOR ALL
USING (COALESCE((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean, false) = true)
WITH CHECK (COALESCE((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean, false) = true);
