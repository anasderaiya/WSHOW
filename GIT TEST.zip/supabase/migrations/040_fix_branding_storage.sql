DROP POLICY IF EXISTS "Theater owners can upload branding" ON storage.objects;
CREATE POLICY "Theater owners can upload branding"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'branding'
  AND (storage.foldername(name))[1] IN (
    SELECT t.id::text FROM theatres t
    JOIN theater_owners to2 ON t.id = to2.theatre_id
    WHERE to2.user_id = auth.uid()
  )
);

DROP POLICY IF EXISTS "Theater owners can update branding" ON storage.objects;
CREATE POLICY "Theater owners can update branding"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'branding'
  AND (storage.foldername(name))[1] IN (
    SELECT t.id::text FROM theatres t
    JOIN theater_owners to2 ON t.id = to2.theatre_id
    WHERE to2.user_id = auth.uid()
  )
);
