-- Migration: Dashboard Performance Optimization
-- Adds critical foreign key indexes and rewrites RPCs for sub-second execution

-- 1. Create missing foreign key indexes to eliminate sequential scans
CREATE INDEX IF NOT EXISTS idx_bookings_show_id ON bookings(show_id);
CREATE INDEX IF NOT EXISTS idx_bookings_event_show_id ON bookings(event_show_id);

-- Add Composite Power Indexes targeting exactly the WHERE clauses used in stats
CREATE INDEX IF NOT EXISTS idx_bookings_perf_confirmed 
ON bookings (status, created_at) 
WHERE status = 'confirmed';

CREATE INDEX IF NOT EXISTS idx_bookings_perf_locked 
ON bookings (status, locked_at) 
WHERE status = 'locked';

-- 2. Rewrite get_owner_dashboard_stats to avoid CTEs, OR clauses, and DATE() functions
CREATE OR REPLACE FUNCTION get_owner_dashboard_stats(p_user_id UUID)
RETURNS TABLE(
    total_theatres BIGINT,
    total_screens BIGINT,
    total_seats BIGINT,
    today_bookings BIGINT,
    today_revenue DECIMAL,
    currently_locked BIGINT,
    today_confirmed BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_theatre_ids UUID[];
    v_today DATE := CURRENT_DATE;
BEGIN
    SELECT ARRAY_AGG(theatre_id) INTO v_theatre_ids
    FROM theater_owners
    WHERE user_id = p_user_id;
    
    IF v_theatre_ids IS NULL THEN
        RETURN QUERY SELECT 0::BIGINT, 0::BIGINT, 0::BIGINT, 0::BIGINT, 0::DECIMAL, 0::BIGINT, 0::BIGINT;
        RETURN;
    END IF;

    RETURN QUERY
    WITH screen_data AS (
        SELECT s.id as screen_id, 
               (SELECT COUNT(*) FROM seats WHERE screen_id = s.id) as seat_count
        FROM screens s
        WHERE s.theatre_id = ANY(v_theatre_ids)
    ),
    movie_stats AS (
        SELECT 
            SUM(CASE WHEN b.created_at >= v_today AND b.created_at < (v_today + interval '1 day') THEN 1 ELSE 0 END) AS today_bookings,
            SUM(CASE WHEN b.created_at >= v_today AND b.created_at < (v_today + interval '1 day') AND b.status = 'confirmed' THEN COALESCE(seats.price, sh.price, 0) ELSE 0 END) AS today_revenue,
            SUM(CASE WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 1 ELSE 0 END) AS currently_locked,
            SUM(CASE WHEN b.created_at >= v_today AND b.created_at < (v_today + interval '1 day') AND b.status = 'confirmed' THEN 1 ELSE 0 END) AS today_confirmed
        FROM shows sh
        JOIN screen_data sd ON sd.screen_id = sh.screen_id
        JOIN bookings b ON b.show_id = sh.id
        LEFT JOIN seats ON seats.id = b.seat_id
    ),
    event_stats AS (
        SELECT 
            SUM(CASE WHEN b.created_at >= v_today AND b.created_at < (v_today + interval '1 day') THEN 1 ELSE 0 END) AS today_bookings,
            SUM(CASE WHEN b.created_at >= v_today AND b.created_at < (v_today + interval '1 day') AND b.status = 'confirmed' THEN COALESCE(seats.price, es.price, 0) ELSE 0 END) AS today_revenue,
            SUM(CASE WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 1 ELSE 0 END) AS currently_locked,
            SUM(CASE WHEN b.created_at >= v_today AND b.created_at < (v_today + interval '1 day') AND b.status = 'confirmed' THEN 1 ELSE 0 END) AS today_confirmed
        FROM event_shows es
        JOIN screen_data sd ON sd.screen_id = es.screen_id
        JOIN bookings b ON b.event_show_id = es.id
        LEFT JOIN seats ON seats.id = b.seat_id
    )
    SELECT
        (SELECT COUNT(*) FROM unnest(v_theatre_ids))::BIGINT AS total_theatres,
        (SELECT COUNT(*) FROM screen_data)::BIGINT AS total_screens,
        (SELECT COALESCE(SUM(seat_count), 0) FROM screen_data)::BIGINT AS total_seats,
        (COALESCE((SELECT today_bookings FROM movie_stats), 0) + COALESCE((SELECT today_bookings FROM event_stats), 0))::BIGINT AS today_bookings,
        (COALESCE((SELECT today_revenue FROM movie_stats), 0) + COALESCE((SELECT today_revenue FROM event_stats), 0))::DECIMAL AS today_revenue,
        (COALESCE((SELECT currently_locked FROM movie_stats), 0) + COALESCE((SELECT currently_locked FROM event_stats), 0))::BIGINT AS currently_locked,
        (COALESCE((SELECT today_confirmed FROM movie_stats), 0) + COALESCE((SELECT today_confirmed FROM event_stats), 0))::BIGINT AS today_confirmed;
END;
$$;

-- 3. Rewrite get_admin_dashboard_stats
CREATE OR REPLACE FUNCTION get_admin_dashboard_stats()
RETURNS TABLE(
    total_revenue NUMERIC,
    total_bookings BIGINT,
    total_theatres BIGINT,
    total_owners BIGINT,
    today_revenue NUMERIC,
    today_bookings BIGINT,
    active_locks BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Only admins
    IF NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;

    RETURN QUERY
    WITH movie_stats AS (
        SELECT
            SUM(COALESCE(seats.price, sh.price, 0)) FILTER (WHERE b.status = 'confirmed') AS total_revenue,
            COUNT(*) FILTER (WHERE b.status = 'confirmed') AS total_bookings,
            SUM(COALESCE(seats.price, sh.price, 0)) FILTER (WHERE b.status = 'confirmed' AND b.created_at >= CURRENT_DATE AND b.created_at < (CURRENT_DATE + interval '1 day')) AS today_revenue,
            COUNT(*) FILTER (WHERE b.status = 'confirmed' AND b.created_at >= CURRENT_DATE AND b.created_at < (CURRENT_DATE + interval '1 day')) AS today_bookings,
            COUNT(*) FILTER (WHERE b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '10 minutes') AS active_locks
        FROM bookings b
        JOIN shows sh ON sh.id = b.show_id
        LEFT JOIN seats ON seats.id = b.seat_id
    ),
    event_stats AS (
        SELECT
            SUM(COALESCE(seats.price, es.price, 0)) FILTER (WHERE b.status = 'confirmed') AS total_revenue,
            COUNT(*) FILTER (WHERE b.status = 'confirmed') AS total_bookings,
            SUM(COALESCE(seats.price, es.price, 0)) FILTER (WHERE b.status = 'confirmed' AND b.created_at >= CURRENT_DATE AND b.created_at < (CURRENT_DATE + interval '1 day')) AS today_revenue,
            COUNT(*) FILTER (WHERE b.status = 'confirmed' AND b.created_at >= CURRENT_DATE AND b.created_at < (CURRENT_DATE + interval '1 day')) AS today_bookings,
            COUNT(*) FILTER (WHERE b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '10 minutes') AS active_locks
        FROM bookings b
        JOIN event_shows es ON es.id = b.event_show_id
        LEFT JOIN seats ON seats.id = b.seat_id
    )
    SELECT
        (COALESCE((SELECT total_revenue FROM movie_stats), 0) + COALESCE((SELECT total_revenue FROM event_stats), 0))::NUMERIC,
        (COALESCE((SELECT total_bookings FROM movie_stats), 0) + COALESCE((SELECT total_bookings FROM event_stats), 0))::BIGINT,
        (SELECT COUNT(*) FROM theatres)::BIGINT,
        (SELECT COUNT(DISTINCT user_id) FROM theater_owners)::BIGINT,
        (COALESCE((SELECT today_revenue FROM movie_stats), 0) + COALESCE((SELECT today_revenue FROM event_stats), 0))::NUMERIC,
        (COALESCE((SELECT today_bookings FROM movie_stats), 0) + COALESCE((SELECT today_bookings FROM event_stats), 0))::BIGINT,
        (COALESCE((SELECT active_locks FROM movie_stats), 0) + COALESCE((SELECT active_locks FROM event_stats), 0))::BIGINT;
END;
$$;

-- 4. Rewrite get_admin_owner_revenue_breakdown
CREATE OR REPLACE FUNCTION get_admin_owner_revenue_breakdown(p_start_date DATE DEFAULT NULL, p_end_date DATE DEFAULT NULL)
RETURNS TABLE(
    owner_id UUID,
    owner_email TEXT,
    owner_name TEXT,
    theatre_names TEXT,
    revenue NUMERIC,
    booking_count BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Only admins
    IF NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;

    RETURN QUERY
    WITH owner_theatres AS (
        SELECT 
            to_owner.user_id,
            t.id as theatre_id,
            t.name as theatre_name,
            oa.email as user_email,
            oa.full_name as user_name
        FROM theater_owners to_owner
        JOIN theatres t ON t.id = to_owner.theatre_id
        LEFT JOIN owner_applications oa ON oa.user_id = to_owner.user_id AND oa.status = 'approved'
    ),
    movie_bookings AS (
        SELECT 
            s.theatre_id,
            COUNT(b.id) as booking_count,
            SUM(COALESCE(seats.price, sh.price, 0)) as revenue
        FROM bookings b
        JOIN shows sh ON sh.id = b.show_id
        JOIN screens s ON s.id = sh.screen_id
        LEFT JOIN seats ON seats.id = b.seat_id
        WHERE b.status = 'confirmed' 
            AND (p_start_date IS NULL OR b.created_at >= p_start_date)
            AND (p_end_date IS NULL OR b.created_at < (p_end_date + INTERVAL '1 day'))
        GROUP BY s.theatre_id
    ),
    event_bookings AS (
        SELECT 
            s.theatre_id,
            COUNT(b.id) as booking_count,
            SUM(COALESCE(seats.price, es.price, 0)) as revenue
        FROM bookings b
        JOIN event_shows es ON es.id = b.event_show_id
        JOIN screens s ON s.id = es.screen_id
        LEFT JOIN seats ON seats.id = b.seat_id
        WHERE b.status = 'confirmed' 
            AND (p_start_date IS NULL OR b.created_at >= p_start_date)
            AND (p_end_date IS NULL OR b.created_at < (p_end_date + INTERVAL '1 day'))
        GROUP BY s.theatre_id
    )
    SELECT 
        ot.user_id as owner_id,
        MAX(ot.user_email) as owner_email,
        MAX(ot.user_name) as owner_name,
        STRING_AGG(DISTINCT ot.theatre_name, ', ') as theatre_names,
        COALESCE(SUM(mb.revenue), 0) + COALESCE(SUM(eb.revenue), 0) as revenue,
        COALESCE(SUM(mb.booking_count), 0) + COALESCE(SUM(eb.booking_count), 0) as booking_count
    FROM owner_theatres ot
    LEFT JOIN movie_bookings mb ON mb.theatre_id = ot.theatre_id
    LEFT JOIN event_bookings eb ON eb.theatre_id = ot.theatre_id
    GROUP BY ot.user_id
    ORDER BY revenue DESC;
END;
$$;

-- 5. Optimize get_owner_shows
DROP FUNCTION IF EXISTS get_owner_shows(UUID, UUID, DATE);

CREATE OR REPLACE FUNCTION get_owner_shows(
    p_user_id UUID,
    p_theatre_id UUID DEFAULT NULL,
    p_date DATE DEFAULT CURRENT_DATE
)
RETURNS TABLE(
    id UUID,             
    type TEXT,
    title TEXT,          
    screen_name TEXT,
    theatre_name TEXT,
    start_time TIMESTAMPTZ,
    end_time TIMESTAMPTZ,
    base_price DECIMAL,
    total_seats BIGINT,
    booked_seats BIGINT,
    locked_seats BIGINT,
    available_seats BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    WITH owner_theatres AS (
        SELECT theatre_id 
        FROM theater_owners 
        WHERE user_id = p_user_id 
          AND (p_theatre_id IS NULL OR theatre_id = p_theatre_id)
    ),
    filtered_movies AS (
        SELECT 
            sh.id,
            'movie' AS type,
            m.title,
            sc.name AS screen_name,
            t.name AS theatre_name,
            sh.start_time,
            sh.end_time,
            sh.price AS base_price,
            sc.id AS screen_id,
            t.id AS theatre_id
        FROM shows sh
        JOIN movies m ON m.id = sh.movie_id
        JOIN screens sc ON sc.id = sh.screen_id
        JOIN theatres t ON t.id = sc.theatre_id
        WHERE sc.theatre_id IN (SELECT theatre_id FROM owner_theatres)
          AND sh.start_time >= p_date AND sh.start_time < (p_date + interval '1 day')
    ),
    filtered_events AS (
        SELECT 
            es.id,
            'event' AS type,
            e.title,
            sc.name AS screen_name,
            t.name AS theatre_name,
            es.start_time,
            es.end_time,
            es.price AS base_price,
            sc.id AS screen_id,
            t.id AS theatre_id
        FROM event_shows es
        JOIN events e ON e.id = es.event_id
        JOIN screens sc ON sc.id = es.screen_id
        JOIN theatres t ON t.id = sc.theatre_id
        WHERE sc.theatre_id IN (SELECT theatre_id FROM owner_theatres)
          AND es.start_time >= p_date AND es.start_time < (p_date + interval '1 day')
    ),
    all_unified_shows AS (
        SELECT * FROM filtered_movies
        UNION ALL
        SELECT * FROM filtered_events
    )
    SELECT 
        u.id,
        u.type,
        u.title,
        u.screen_name,
        u.theatre_name,
        u.start_time,
        u.end_time,
        u.base_price,
        (SELECT COUNT(*) FROM seats WHERE screen_id = u.screen_id)::BIGINT AS total_seats,
        (SELECT COUNT(*) FROM bookings b WHERE (b.show_id = u.id OR b.event_show_id = u.id) AND b.status = 'confirmed')::BIGINT AS booked_seats,
        (SELECT COUNT(*) FROM bookings b WHERE (b.show_id = u.id OR b.event_show_id = u.id) AND b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes')::BIGINT AS locked_seats,
        ((SELECT COUNT(*) FROM seats WHERE screen_id = u.screen_id) - 
         (SELECT COUNT(*) FROM bookings b WHERE (b.show_id = u.id OR b.event_show_id = u.id) AND b.status IN ('confirmed', 'locked') AND (b.status = 'confirmed' OR (b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes'))))::BIGINT AS available_seats
    FROM all_unified_shows u
    ORDER BY u.start_time;
END;
$$;
