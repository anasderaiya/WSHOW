-- ============================================
-- Quick My Ticket - Guest Booking System
-- ============================================
-- This migration adds:
-- 1. Support for guest bookings in the bookings table
-- 2. Modified seat locking RPCs to support session IDs
-- 3. Modified confirm bookings RPC to handle guest details

-- 1. Update table schema
ALTER TABLE public.bookings ALTER COLUMN user_id DROP NOT NULL;
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS session_id TEXT;
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS guest_name TEXT;
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS guest_email TEXT;
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS guest_phone TEXT;

-- 2. Update lock_seat function to support session_id
CREATE OR REPLACE FUNCTION lock_seat(
    p_show_id UUID, 
    p_seat_id UUID, 
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    booking_id UUID, 
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking_id UUID;
    v_existing RECORD;
    v_screen_id UUID;
    v_seat_exists BOOLEAN;
    v_reusable_booking UUID;
    v_lock_timeout_minutes INTEGER := 5;
BEGIN
    SELECT screen_id INTO v_screen_id 
    FROM shows 
    WHERE id = p_show_id;
    
    IF v_screen_id IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Show not found'::TEXT;
        RETURN;
    END IF;
    
    SELECT EXISTS(
        SELECT 1 FROM seats 
        WHERE id = p_seat_id AND screen_id = v_screen_id
    ) INTO v_seat_exists;
    
    IF NOT v_seat_exists THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat not found for this show'::TEXT;
        RETURN;
    END IF;
    
    UPDATE bookings 
    SET status = 'expired', locked_at = NULL
    WHERE show_id = p_show_id 
      AND seat_id = p_seat_id 
      AND status = 'locked'
      AND locked_at < NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL;
    
    BEGIN
        SELECT * INTO v_existing
        FROM bookings 
        WHERE show_id = p_show_id 
          AND seat_id = p_seat_id 
          AND status IN ('locked', 'confirmed')
        FOR UPDATE NOWAIT;
    EXCEPTION
        WHEN lock_not_available THEN
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is currently being processed by another user, please try again'::TEXT;
            RETURN;
    END;
    
    IF FOUND THEN
        IF (v_existing.user_id IS NOT NULL AND v_existing.user_id = p_user_id AND v_existing.status = 'locked') OR 
           (v_existing.session_id IS NOT NULL AND v_existing.session_id = p_session_id AND v_existing.status = 'locked') THEN
            UPDATE bookings 
            SET locked_at = NOW() 
            WHERE id = v_existing.id;
            
            RETURN QUERY SELECT v_existing.id, TRUE, 'Lock refreshed'::TEXT;
            RETURN;
        ELSE
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is already locked or booked'::TEXT;
            RETURN;
        END IF;
    END IF;
    
    SELECT id INTO v_reusable_booking
    FROM bookings
    WHERE show_id = p_show_id
      AND seat_id = p_seat_id
      AND status IN ('cancelled', 'expired')
    ORDER BY created_at DESC
    LIMIT 1
    FOR UPDATE;
    
    IF v_reusable_booking IS NOT NULL THEN
        UPDATE bookings 
        SET status = 'locked',
            user_id = p_user_id,
            session_id = p_session_id,
            locked_at = NOW(),
            payment_id = NULL,
            confirmed_at = NULL
        WHERE id = v_reusable_booking
        RETURNING id INTO v_booking_id;
        
        RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
        RETURN;
    END IF;
    
    INSERT INTO bookings (show_id, seat_id, user_id, session_id, status, locked_at)
    VALUES (p_show_id, p_seat_id, p_user_id, p_session_id, 'locked', NOW())
    RETURNING id INTO v_booking_id;
    
    RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
    
EXCEPTION
    WHEN unique_violation THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat was just locked by another user'::TEXT;
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, ('Error: ' || SQLERRM)::TEXT;
END;
$$;

GRANT EXECUTE ON FUNCTION lock_seat(UUID, UUID, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION lock_seat(UUID, UUID, UUID, TEXT) TO anon;

-- 3. Update lock_event_seat function
CREATE OR REPLACE FUNCTION lock_event_seat(
    p_event_show_id UUID, 
    p_seat_id UUID, 
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    booking_id UUID, 
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking_id UUID;
    v_existing RECORD;
    v_screen_id UUID;
    v_seat_exists BOOLEAN;
    v_reusable_booking UUID;
    v_lock_timeout_minutes INTEGER := 5;
BEGIN
    SELECT screen_id INTO v_screen_id 
    FROM event_shows 
    WHERE id = p_event_show_id;
    
    IF v_screen_id IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Event show not found'::TEXT;
        RETURN;
    END IF;
    
    SELECT EXISTS(
        SELECT 1 FROM seats 
        WHERE id = p_seat_id AND screen_id = v_screen_id
    ) INTO v_seat_exists;
    
    IF NOT v_seat_exists THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat not found for this event'::TEXT;
        RETURN;
    END IF;

    UPDATE bookings 
    SET status = 'expired', locked_at = NULL
    WHERE event_show_id = p_event_show_id 
      AND seat_id = p_seat_id 
      AND status = 'locked'
      AND locked_at < NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL;
    
    BEGIN
        SELECT * INTO v_existing
        FROM bookings 
        WHERE event_show_id = p_event_show_id 
          AND seat_id = p_seat_id 
          AND status IN ('locked', 'confirmed')
        FOR UPDATE NOWAIT;
    EXCEPTION
        WHEN lock_not_available THEN
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is being processed by another user'::TEXT;
            RETURN;
    END;
    
    IF FOUND THEN
        IF (v_existing.user_id IS NOT NULL AND v_existing.user_id = p_user_id AND v_existing.status = 'locked') OR 
           (v_existing.session_id IS NOT NULL AND v_existing.session_id = p_session_id AND v_existing.status = 'locked') THEN
            UPDATE bookings 
            SET locked_at = NOW() 
            WHERE id = v_existing.id;
            
            RETURN QUERY SELECT v_existing.id, TRUE, 'Lock refreshed'::TEXT;
            RETURN;
        ELSE
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is already locked or booked'::TEXT;
            RETURN;
        END IF;
    END IF;

    SELECT id INTO v_reusable_booking
    FROM bookings
    WHERE event_show_id = p_event_show_id
      AND seat_id = p_seat_id
      AND status IN ('cancelled', 'expired')
    ORDER BY created_at DESC
    LIMIT 1
    FOR UPDATE;
    
    IF v_reusable_booking IS NOT NULL THEN
        UPDATE bookings 
        SET status = 'locked',
            user_id = p_user_id,
            session_id = p_session_id,
            locked_at = NOW(),
            payment_id = NULL,
            confirmed_at = NULL
        WHERE id = v_reusable_booking
        RETURNING id INTO v_booking_id;
        
        RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
        RETURN;
    END IF;
    
    INSERT INTO bookings (event_show_id, seat_id, user_id, session_id, status, locked_at)
    VALUES (p_event_show_id, p_seat_id, p_user_id, p_session_id, 'locked', NOW())
    RETURNING id INTO v_booking_id;
    
    RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
    
EXCEPTION
    WHEN unique_violation THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat was just locked by another user'::TEXT;
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, ('Error: ' || SQLERRM)::TEXT;
END;
$$;

GRANT EXECUTE ON FUNCTION lock_event_seat(UUID, UUID, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION lock_event_seat(UUID, UUID, UUID, TEXT) TO anon;

-- 4. Update unlock_seat function
CREATE OR REPLACE FUNCTION unlock_seat(
    p_booking_id UUID,
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking RECORD;
BEGIN
    SELECT * INTO v_booking
    FROM bookings
    WHERE id = p_booking_id
    FOR UPDATE;
    
    IF NOT FOUND THEN
        RETURN QUERY SELECT FALSE, 'Booking not found'::TEXT;
        RETURN;
    END IF;
    
    IF (v_booking.user_id IS NOT NULL AND v_booking.user_id = p_user_id) OR
       (v_booking.session_id IS NOT NULL AND v_booking.session_id = p_session_id) THEN
        -- Ownership verified
    ELSE
        RETURN QUERY SELECT FALSE, 'Not authorized to unlock this booking'::TEXT;
        RETURN;
    END IF;
    
    IF v_booking.status != 'locked' THEN
        RETURN QUERY SELECT FALSE, ('Cannot unlock booking with status: ' || v_booking.status)::TEXT;
        RETURN;
    END IF;
    
    UPDATE bookings 
    SET status = 'cancelled', locked_at = NULL
    WHERE id = p_booking_id;
    
    RETURN QUERY SELECT TRUE, 'Seat unlocked successfully'::TEXT;
END;
$$;

GRANT EXECUTE ON FUNCTION unlock_seat(UUID, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION unlock_seat(UUID, UUID, TEXT) TO anon;

-- 5. Update confirm_bookings to accept guest details
CREATE OR REPLACE FUNCTION confirm_bookings(
    p_booking_ids UUID[],
    p_payment_id TEXT,
    p_guest_name TEXT DEFAULT NULL,
    p_guest_email TEXT DEFAULT NULL,
    p_guest_phone TEXT DEFAULT NULL
)
RETURNS TABLE(
    confirmed_count INTEGER,
    total_amount DECIMAL
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_count INTEGER;
    v_total DECIMAL;
BEGIN
    SELECT total INTO v_total
    FROM calculate_booking_total(p_booking_ids);
    
    WITH confirmed AS (
        UPDATE bookings 
        SET status = 'confirmed',
            payment_id = p_payment_id,
            confirmed_at = NOW(),
            guest_name = COALESCE(bookings.guest_name, p_guest_name),
            guest_email = COALESCE(bookings.guest_email, p_guest_email),
            guest_phone = COALESCE(bookings.guest_phone, p_guest_phone)
        WHERE id = ANY(p_booking_ids)
          AND status = 'locked'
        RETURNING id
    )
    SELECT COUNT(*)::INTEGER INTO v_count FROM confirmed;
    
    RETURN QUERY SELECT v_count, COALESCE(v_total, 0);
END;
$$;

REVOKE ALL ON FUNCTION confirm_bookings(UUID[], TEXT, TEXT, TEXT, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION confirm_bookings(UUID[], TEXT, TEXT, TEXT, TEXT) TO service_role;
