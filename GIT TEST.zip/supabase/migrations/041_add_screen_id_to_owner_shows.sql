-- Migration 041: Add screen_id to get_owner_shows RPC
-- The offline seat management feature needs the screen_id to fetch the seat layout

DROP FUNCTION IF EXISTS get_owner_shows(UUID, UUID, DATE);

CREATE OR REPLACE FUNCTION get_owner_shows(
    p_user_id UUID,
    p_theatre_id UUID DEFAULT NULL,
    p_date DATE DEFAULT CURRENT_DATE
)
RETURNS TABLE(
    show_id UUID,
    screen_id UUID,
    movie_title TEXT,
    screen_name TEXT,
    theatre_name TEXT,
    start_time TIMESTAMPTZ,
    end_time TIMESTAMPTZ,
    base_price DECIMAL,
    total_seats BIGINT,
    booked_seats BIGINT,
    locked_seats BIGINT,
    available_seats BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        sh.id AS show_id,
        sc.id AS screen_id,
        m.title AS movie_title,
        sc.name AS screen_name,
        t.name AS theatre_name,
        sh.start_time,
        sh.end_time,
        sh.price AS base_price,
        COUNT(DISTINCT seats.id) AS total_seats,
        COUNT(DISTINCT CASE WHEN b.status = 'confirmed' THEN b.id END) AS booked_seats,
        COUNT(DISTINCT CASE WHEN b.status = 'locked' THEN b.id END) AS locked_seats,
        COUNT(DISTINCT seats.id) - COUNT(DISTINCT CASE WHEN b.status IN ('confirmed', 'locked') THEN b.id END) AS available_seats
    FROM shows sh
    JOIN movies m ON m.id = sh.movie_id
    JOIN screens sc ON sc.id = sh.screen_id
    JOIN theatres t ON t.id = sc.theatre_id
    JOIN theater_owners to_owner ON to_owner.theatre_id = t.id
    LEFT JOIN seats ON seats.screen_id = sc.id
    LEFT JOIN bookings b ON b.show_id = sh.id AND b.seat_id = seats.id AND b.status IN ('confirmed', 'locked')
    WHERE to_owner.user_id = p_user_id
      AND (p_theatre_id IS NULL OR t.id = p_theatre_id)
      AND DATE(sh.start_time) = p_date
    GROUP BY sh.id, sc.id, m.title, sc.name, t.name, sh.start_time, sh.end_time, sh.price
    ORDER BY sh.start_time;
END;
$$;

GRANT EXECUTE ON FUNCTION get_owner_shows(UUID, UUID, DATE) TO authenticated;
