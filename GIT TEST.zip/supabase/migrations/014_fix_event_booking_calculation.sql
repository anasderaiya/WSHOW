-- ============================================
-- Quick My Ticket - Fix Event Booking Price Calculation
-- Migration 014
-- ============================================

-- Safely replace calculate_booking_total to support both movie shows and event shows
-- Previously, it used an INNER JOIN on shows, which filtered out event_shows
-- and caused the 'create-order' edge function to fail during payment.

CREATE OR REPLACE FUNCTION calculate_booking_total(
    p_booking_ids UUID[],
    p_tax_rate DECIMAL DEFAULT 0.18
)
RETURNS TABLE(
    subtotal DECIMAL,
    tax DECIMAL,
    total DECIMAL,
    seat_count INTEGER
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_subtotal DECIMAL;
    v_seat_count INTEGER;
BEGIN
    -- Calculate subtotal from seats, movie shows, or event shows
    SELECT 
        COALESCE(SUM(COALESCE(s.price, sh.price, es.price, 0)), 0),
        COUNT(*)::INTEGER
    INTO v_subtotal, v_seat_count
    FROM bookings b
    JOIN seats s ON s.id = b.seat_id
    LEFT JOIN shows sh ON sh.id = b.show_id
    LEFT JOIN event_shows es ON es.id = b.event_show_id
    WHERE b.id = ANY(p_booking_ids)
      AND b.status = 'locked';  -- Only count locked bookings
    
    RETURN QUERY SELECT 
        v_subtotal,
        ROUND(v_subtotal * p_tax_rate, 2),
        v_subtotal + ROUND(v_subtotal * p_tax_rate, 2),
        v_seat_count;
END;
$$;

GRANT EXECUTE ON FUNCTION calculate_booking_total(UUID[], DECIMAL) TO authenticated;
GRANT EXECUTE ON FUNCTION calculate_booking_total(UUID[], DECIMAL) TO anon;
GRANT EXECUTE ON FUNCTION calculate_booking_total(UUID[], DECIMAL) TO service_role;
