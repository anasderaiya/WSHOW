-- Migration 029: Remove test confirmation backdoor
-- =====================================================================
-- MUST run before going live. This reverses the permissions granted in
-- migration 027 that allowed unauthenticated test confirmations.

REVOKE UPDATE ON public.bookings FROM anon;
REVOKE UPDATE ON public.bookings FROM authenticated;

DROP POLICY IF EXISTS "Allow test confirmations" ON public.bookings;
