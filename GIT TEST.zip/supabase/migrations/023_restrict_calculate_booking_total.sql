-- ============================================
-- Quick My Ticket - Restrict calculate_booking_total
-- Migration 023
-- ============================================
-- SECURITY: calculate_booking_total touches pricing and runs as
-- SECURITY DEFINER. It should only be callable by service_role
-- (Edge Functions), never directly by authenticated or anon users.

REVOKE ALL ON FUNCTION calculate_booking_total(UUID[], DECIMAL) FROM PUBLIC;
REVOKE ALL ON FUNCTION calculate_booking_total(UUID[], DECIMAL) FROM authenticated;
REVOKE ALL ON FUNCTION calculate_booking_total(UUID[], DECIMAL) FROM anon;
GRANT EXECUTE ON FUNCTION calculate_booking_total(UUID[], DECIMAL) TO service_role;
