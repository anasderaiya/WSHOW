-- ============================================
-- Quick My Ticket - Repair Shows on Unconfigured Duplicate Screens
-- Migration 021
-- ============================================
-- Some theatres have duplicate screen names where one screen has a saved layout
-- and seats, while the duplicate has neither. Shows attached to the empty
-- duplicate cannot render or book seats. This moves unbooked shows/event shows
-- from empty duplicates to the configured screen with the same theatre + name.

WITH screen_seat_counts AS (
    SELECT
        s.id,
        s.theatre_id,
        s.name,
        s.seat_layout,
        COUNT(seats.id) AS seat_count
    FROM screens s
    LEFT JOIN seats ON seats.screen_id = s.id
    GROUP BY s.id, s.theatre_id, s.name, s.seat_layout
),
empty_screens AS (
    SELECT *
    FROM screen_seat_counts
    WHERE seat_layout IS NULL
      AND seat_count = 0
),
configured_screens AS (
    SELECT *
    FROM screen_seat_counts
    WHERE seat_layout IS NOT NULL
      AND seat_count > 0
),
screen_replacements AS (
    SELECT DISTINCT ON (empty_screens.id)
        empty_screens.id AS empty_screen_id,
        configured_screens.id AS configured_screen_id
    FROM empty_screens
    JOIN configured_screens
      ON configured_screens.theatre_id = empty_screens.theatre_id
     AND configured_screens.name = empty_screens.name
    ORDER BY
        empty_screens.id,
        configured_screens.seat_count DESC,
        configured_screens.id
)
UPDATE shows
SET screen_id = screen_replacements.configured_screen_id
FROM screen_replacements
WHERE shows.screen_id = screen_replacements.empty_screen_id
  AND NOT EXISTS (
      SELECT 1
      FROM bookings b
      WHERE b.show_id = shows.id
        AND b.status IN ('confirmed', 'locked')
  );

WITH screen_seat_counts AS (
    SELECT
        s.id,
        s.theatre_id,
        s.name,
        s.seat_layout,
        COUNT(seats.id) AS seat_count
    FROM screens s
    LEFT JOIN seats ON seats.screen_id = s.id
    GROUP BY s.id, s.theatre_id, s.name, s.seat_layout
),
empty_screens AS (
    SELECT *
    FROM screen_seat_counts
    WHERE seat_layout IS NULL
      AND seat_count = 0
),
configured_screens AS (
    SELECT *
    FROM screen_seat_counts
    WHERE seat_layout IS NOT NULL
      AND seat_count > 0
),
screen_replacements AS (
    SELECT DISTINCT ON (empty_screens.id)
        empty_screens.id AS empty_screen_id,
        configured_screens.id AS configured_screen_id
    FROM empty_screens
    JOIN configured_screens
      ON configured_screens.theatre_id = empty_screens.theatre_id
     AND configured_screens.name = empty_screens.name
    ORDER BY
        empty_screens.id,
        configured_screens.seat_count DESC,
        configured_screens.id
)
UPDATE event_shows
SET screen_id = screen_replacements.configured_screen_id
FROM screen_replacements
WHERE event_shows.screen_id = screen_replacements.empty_screen_id
  AND NOT EXISTS (
      SELECT 1
      FROM bookings b
      WHERE b.event_show_id = event_shows.id
        AND b.status IN ('confirmed', 'locked')
  );
