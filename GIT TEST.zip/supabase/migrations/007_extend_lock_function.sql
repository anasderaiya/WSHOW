-- ============================================
-- Quick My Ticket - Extend Lock Function
-- ============================================
-- This migration adds a function to extend seat locks
-- Used by the heartbeat/ping feature to keep locks alive
-- while the user is actively on the booking page.

-- ============================================
-- 1. EXTEND LOCKS FUNCTION
-- ============================================
-- Extends the lock duration for a user's active bookings
-- Only extends if the lock hasn't already expired

CREATE OR REPLACE FUNCTION extend_locks(
    p_booking_ids UUID[],
    p_user_id UUID
)
RETURNS TABLE(
    extended_count INTEGER,
    success BOOLEAN,
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_count INTEGER := 0;
    v_lock_timeout_minutes INTEGER := 5;
BEGIN
    -- Update locked_at timestamp for all valid bookings
    -- Only extend locks that:
    -- 1. Belong to the requesting user
    -- 2. Are still in 'locked' status
    -- 3. Haven't expired yet (locked_at within timeout period)
    UPDATE bookings
    SET locked_at = NOW()
    WHERE id = ANY(p_booking_ids)
      AND user_id = p_user_id
      AND status = 'locked'
      AND locked_at >= NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL;
    
    GET DIAGNOSTICS v_count = ROW_COUNT;
    
    IF v_count > 0 THEN
        RETURN QUERY SELECT v_count, TRUE, format('Extended %s lock(s)', v_count)::TEXT;
    ELSE
        RETURN QUERY SELECT 0, FALSE, 'No active locks to extend'::TEXT;
    END IF;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION extend_locks(UUID[], UUID) TO authenticated;

-- ============================================
-- 2. REFRESH SINGLE LOCK FUNCTION (for individual seat refresh)
-- ============================================
-- Refreshes a single booking's lock if it's still valid

CREATE OR REPLACE FUNCTION refresh_lock(
    p_booking_id UUID,
    p_user_id UUID
)
RETURNS TABLE(
    success BOOLEAN,
    new_locked_at TIMESTAMPTZ,
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_lock_timeout_minutes INTEGER := 5;
    v_new_time TIMESTAMPTZ;
BEGIN
    UPDATE bookings
    SET locked_at = NOW()
    WHERE id = p_booking_id
      AND user_id = p_user_id
      AND status = 'locked'
      AND locked_at >= NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL
    RETURNING locked_at INTO v_new_time;
    
    IF v_new_time IS NOT NULL THEN
        RETURN QUERY SELECT TRUE, v_new_time, 'Lock refreshed'::TEXT;
    ELSE
        RETURN QUERY SELECT FALSE, NULL::TIMESTAMPTZ, 'Lock expired or not found'::TEXT;
    END IF;
END;
$$;

-- Grant execute permission
GRANT EXECUTE ON FUNCTION refresh_lock(UUID, UUID) TO authenticated;
