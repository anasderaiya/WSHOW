-- Migration: Enable Realtime + Add end_time to shows
-- Enables Supabase Realtime on the bookings table for sub-second seat updates,
-- sets REPLICA IDENTITY FULL for complete old/new row data in change events,
-- and adds the end_time column to shows.

-- 1. Add end_time column to shows (if not exists)
ALTER TABLE public.shows ADD COLUMN IF NOT EXISTS end_time TIMESTAMPTZ;

-- 2. Enable Realtime on bookings table
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 
        FROM pg_publication_tables 
        WHERE pubname = 'supabase_realtime' 
        AND schemaname = 'public' 
        AND tablename = 'bookings'
    ) THEN
        ALTER PUBLICATION supabase_realtime ADD TABLE public.bookings;
    END IF;
END $$;

-- 3. Set REPLICA IDENTITY FULL so UPDATE/DELETE payloads include old row data
-- This is critical for the surgical seat update system to know the previous state
ALTER TABLE public.bookings REPLICA IDENTITY FULL;
