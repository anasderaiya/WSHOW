-- ============================================
-- Quick My Ticket — Rate Limit Seat Locking
-- ============================================
-- Prevents a single user/session from holding more than 10
-- active (locked) seats per show. This stops abuse where
-- someone rapidly locks and abandons seats via the API.
-- ============================================

-- 1. Update lock_seat to enforce per-show rate limit
CREATE OR REPLACE FUNCTION lock_seat(
    p_show_id UUID, 
    p_seat_id UUID, 
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    booking_id UUID, 
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking_id UUID;
    v_existing RECORD;
    v_screen_id UUID;
    v_seat_exists BOOLEAN;
    v_reusable_booking UUID;
    v_lock_timeout_minutes INTEGER := 5;
    v_active_locks INTEGER;
    v_max_locks INTEGER := 10;
BEGIN
    -- Validate that the show exists and get screen_id
    SELECT screen_id INTO v_screen_id 
    FROM shows 
    WHERE id = p_show_id;
    
    IF v_screen_id IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Show not found'::TEXT;
        RETURN;
    END IF;
    
    -- Validate that the seat exists and belongs to the show's screen
    SELECT EXISTS(
        SELECT 1 FROM seats 
        WHERE id = p_seat_id AND screen_id = v_screen_id
    ) INTO v_seat_exists;
    
    IF NOT v_seat_exists THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat not found for this show'::TEXT;
        RETURN;
    END IF;

    -- *** RATE LIMIT CHECK ***
    -- Count how many seats this user/session currently has locked for THIS show
    SELECT COUNT(*) INTO v_active_locks
    FROM bookings
    WHERE show_id = p_show_id
      AND status = 'locked'
      AND locked_at >= NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL
      AND (
          (p_user_id IS NOT NULL AND user_id = p_user_id)
          OR
          (p_session_id IS NOT NULL AND session_id = p_session_id)
      );

    IF v_active_locks >= v_max_locks THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 
            ('You cannot lock more than ' || v_max_locks || ' seats per show')::TEXT;
        RETURN;
    END IF;
    
    -- Auto-expire stale locks on this specific seat
    UPDATE bookings 
    SET status = 'expired', locked_at = NULL
    WHERE show_id = p_show_id 
      AND seat_id = p_seat_id 
      AND status = 'locked'
      AND locked_at < NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL;
    
    -- Try to acquire a lock on existing active booking
    BEGIN
        SELECT * INTO v_existing
        FROM bookings 
        WHERE show_id = p_show_id 
          AND seat_id = p_seat_id 
          AND status IN ('locked', 'confirmed')
        FOR UPDATE NOWAIT;
    EXCEPTION
        WHEN lock_not_available THEN
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is currently being processed by another user, please try again'::TEXT;
            RETURN;
    END;
    
    -- Check if seat is already taken
    IF FOUND THEN
        IF (v_existing.user_id IS NOT NULL AND v_existing.user_id = p_user_id AND v_existing.status = 'locked') OR 
           (v_existing.session_id IS NOT NULL AND v_existing.session_id = p_session_id AND v_existing.status = 'locked') THEN
            -- Refresh the lock timestamp
            UPDATE bookings 
            SET locked_at = NOW() 
            WHERE id = v_existing.id;
            
            RETURN QUERY SELECT v_existing.id, TRUE, 'Lock refreshed'::TEXT;
            RETURN;
        ELSE
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is already locked or booked'::TEXT;
            RETURN;
        END IF;
    END IF;
    
    -- Look for a reusable cancelled/expired booking for this seat
    SELECT id INTO v_reusable_booking
    FROM bookings
    WHERE show_id = p_show_id
      AND seat_id = p_seat_id
      AND status IN ('cancelled', 'expired')
    ORDER BY created_at DESC
    LIMIT 1
    FOR UPDATE;
    
    IF v_reusable_booking IS NOT NULL THEN
        UPDATE bookings 
        SET status = 'locked',
            user_id = p_user_id,
            session_id = p_session_id,
            locked_at = NOW(),
            payment_id = NULL,
            confirmed_at = NULL
        WHERE id = v_reusable_booking
        RETURNING id INTO v_booking_id;
        
        RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
        RETURN;
    END IF;
    
    -- Insert new booking with lock
    INSERT INTO bookings (show_id, seat_id, user_id, session_id, status, locked_at)
    VALUES (p_show_id, p_seat_id, p_user_id, p_session_id, 'locked', NOW())
    RETURNING id INTO v_booking_id;
    
    RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
    
EXCEPTION
    WHEN unique_violation THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat was just locked by another user'::TEXT;
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, ('Error: ' || SQLERRM)::TEXT;
END;
$$;

GRANT EXECUTE ON FUNCTION lock_seat(UUID, UUID, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION lock_seat(UUID, UUID, UUID, TEXT) TO anon;


-- 2. Update lock_event_seat with the same rate limit
CREATE OR REPLACE FUNCTION lock_event_seat(
    p_event_show_id UUID, 
    p_seat_id UUID, 
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    booking_id UUID, 
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking_id UUID;
    v_existing RECORD;
    v_screen_id UUID;
    v_seat_exists BOOLEAN;
    v_reusable_booking UUID;
    v_lock_timeout_minutes INTEGER := 5;
    v_active_locks INTEGER;
    v_max_locks INTEGER := 10;
BEGIN
    SELECT screen_id INTO v_screen_id 
    FROM event_shows 
    WHERE id = p_event_show_id;
    
    IF v_screen_id IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Event show not found'::TEXT;
        RETURN;
    END IF;
    
    SELECT EXISTS(
        SELECT 1 FROM seats 
        WHERE id = p_seat_id AND screen_id = v_screen_id
    ) INTO v_seat_exists;
    
    IF NOT v_seat_exists THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat not found for this event'::TEXT;
        RETURN;
    END IF;

    -- *** RATE LIMIT CHECK ***
    SELECT COUNT(*) INTO v_active_locks
    FROM bookings
    WHERE event_show_id = p_event_show_id
      AND status = 'locked'
      AND locked_at >= NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL
      AND (
          (p_user_id IS NOT NULL AND user_id = p_user_id)
          OR
          (p_session_id IS NOT NULL AND session_id = p_session_id)
      );

    IF v_active_locks >= v_max_locks THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 
            ('You cannot lock more than ' || v_max_locks || ' seats per show')::TEXT;
        RETURN;
    END IF;

    UPDATE bookings 
    SET status = 'expired', locked_at = NULL
    WHERE event_show_id = p_event_show_id 
      AND seat_id = p_seat_id 
      AND status = 'locked'
      AND locked_at < NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL;
    
    BEGIN
        SELECT * INTO v_existing
        FROM bookings 
        WHERE event_show_id = p_event_show_id 
          AND seat_id = p_seat_id 
          AND status IN ('locked', 'confirmed')
        FOR UPDATE NOWAIT;
    EXCEPTION
        WHEN lock_not_available THEN
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is being processed by another user'::TEXT;
            RETURN;
    END;
    
    IF FOUND THEN
        IF (v_existing.user_id IS NOT NULL AND v_existing.user_id = p_user_id AND v_existing.status = 'locked') OR 
           (v_existing.session_id IS NOT NULL AND v_existing.session_id = p_session_id AND v_existing.status = 'locked') THEN
            UPDATE bookings 
            SET locked_at = NOW() 
            WHERE id = v_existing.id;
            
            RETURN QUERY SELECT v_existing.id, TRUE, 'Lock refreshed'::TEXT;
            RETURN;
        ELSE
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is already locked or booked'::TEXT;
            RETURN;
        END IF;
    END IF;

    SELECT id INTO v_reusable_booking
    FROM bookings
    WHERE event_show_id = p_event_show_id
      AND seat_id = p_seat_id
      AND status IN ('cancelled', 'expired')
    ORDER BY created_at DESC
    LIMIT 1
    FOR UPDATE;
    
    IF v_reusable_booking IS NOT NULL THEN
        UPDATE bookings 
        SET status = 'locked',
            user_id = p_user_id,
            session_id = p_session_id,
            locked_at = NOW(),
            payment_id = NULL,
            confirmed_at = NULL
        WHERE id = v_reusable_booking
        RETURNING id INTO v_booking_id;
        
        RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
        RETURN;
    END IF;
    
    INSERT INTO bookings (event_show_id, seat_id, user_id, session_id, status, locked_at)
    VALUES (p_event_show_id, p_seat_id, p_user_id, p_session_id, 'locked', NOW())
    RETURNING id INTO v_booking_id;
    
    RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
    
EXCEPTION
    WHEN unique_violation THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat was just locked by another user'::TEXT;
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, ('Error: ' || SQLERRM)::TEXT;
END;
$$;

GRANT EXECUTE ON FUNCTION lock_event_seat(UUID, UUID, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION lock_event_seat(UUID, UUID, UUID, TEXT) TO anon;
