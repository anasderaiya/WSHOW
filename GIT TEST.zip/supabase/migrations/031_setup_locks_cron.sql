-- ============================================
-- Quick My Ticket — Automatic Expired Lock Cleanup
-- ============================================
-- Sets up a pg_cron job that runs every minute to release seats
-- that have been in "locked" status for more than 5 minutes
-- without a completed payment.
--
-- Prerequisites:
--   The pg_cron extension must be enabled in your Supabase project.
--   (Dashboard → Database → Extensions → pg_cron → Enable)
-- ============================================

-- 1. pg_cron must be enabled in Supabase Dashboard -> Database -> Extensions
-- We skip auto-creation here because Supabase manages extensions centrally.

-- 2. Create the cleanup function (SECURITY DEFINER so it can write to bookings)
CREATE OR REPLACE FUNCTION release_expired_locks()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_count INTEGER;
BEGIN
    UPDATE bookings
    SET status   = 'expired',
        locked_at = NULL
    WHERE status = 'locked'
      AND locked_at < NOW() - INTERVAL '5 minutes';

    GET DIAGNOSTICS v_count = ROW_COUNT;

    IF v_count > 0 THEN
        RAISE LOG '[QMT] Released % expired seat lock(s)', v_count;
    END IF;
END;
$$;

-- 3. Schedule the job to run every minute
--    cron.schedule returns the job id; we use an idempotent wrapper
--    so re-running this migration is safe.
DO $$
BEGIN
    -- Remove any previous version of this job first
    PERFORM cron.unschedule(jobid)
    FROM cron.job
    WHERE jobname = 'release-expired-locks';

    -- Schedule the new job
    PERFORM cron.schedule(
        'release-expired-locks',    -- job name (idempotent key)
        '* * * * *',                -- every minute
        'SELECT release_expired_locks();'
    );

    RAISE LOG '[QMT] pg_cron job "release-expired-locks" scheduled (every minute)';
EXCEPTION WHEN OTHERS THEN
    RAISE LOG '[QMT] pg_cron not available - skipping cron job setup. Enable pg_cron in Supabase Dashboard -> Database -> Extensions.';
END;
$$;
