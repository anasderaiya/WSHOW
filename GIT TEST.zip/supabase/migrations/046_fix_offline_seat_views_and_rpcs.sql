-- Migration 046: Fix offline seat views and RPCs for movies and events
-- 1. Redefine event_seat_availability to support 'offline' status
CREATE OR REPLACE VIEW event_seat_availability AS
SELECT
    es.id AS event_show_id,
    es.event_id,
    e.title AS event_title,
    s.id AS seat_id,
    s.screen_id,
    s.row,
    s.col,
    s.tier,
    COALESCE(s.price, es.price) AS effective_price,
    b.id AS booking_id,
    b.user_id AS locked_by,
    b.locked_at,
    CASE
        WHEN b.status = 'offline' THEN 'offline'
        WHEN b.status = 'confirmed' THEN 'booked'
        WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 'locked'
        ELSE 'available'
    END AS availability_status,
    b.session_id AS locked_by_session
FROM event_shows es
JOIN events e ON e.id = es.event_id
JOIN seats s ON s.screen_id = es.screen_id
LEFT JOIN LATERAL (
    SELECT *
    FROM bookings
    WHERE seat_id = s.id
      AND event_show_id = es.id
      AND (
          status IN ('confirmed', 'offline')
          OR (status = 'locked' AND locked_at >= NOW() - INTERVAL '5 minutes')
      )
    ORDER BY
        CASE WHEN status = 'confirmed' THEN 0 WHEN status = 'offline' THEN 1 ELSE 2 END,
        locked_at DESC
    LIMIT 1
) b ON true;

GRANT SELECT ON event_seat_availability TO authenticated;
GRANT SELECT ON event_seat_availability TO anon;


-- 2. Redefine toggle_offline_seats RPC to support both movies and events
CREATE OR REPLACE FUNCTION toggle_offline_seats(
    p_show_id UUID,
    p_seat_ids UUID[],
    p_offline BOOLEAN
) RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_owner_id UUID;
    v_is_authorized BOOLEAN;
    v_is_event BOOLEAN := FALSE;
BEGIN
    v_owner_id := auth.uid();
    
    -- Check if it is an event show
    SELECT EXISTS (
        SELECT 1 FROM event_shows WHERE id = p_show_id
    ) INTO v_is_event;

    SELECT EXISTS (
        -- Admin bypass
        SELECT 1 WHERE COALESCE((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean, false) = true
        UNION ALL
        -- Movie show authorization
        SELECT 1 FROM shows sh
        JOIN screens sc ON sh.screen_id = sc.id
        JOIN theatres t ON sc.theatre_id = t.id
        JOIN theater_owners to_owner ON to_owner.theatre_id = t.id
        WHERE NOT v_is_event AND sh.id = p_show_id 
          AND to_owner.user_id = v_owner_id 
          AND to_owner.role IN ('owner', 'manager')
        UNION ALL
        -- Event show authorization
        SELECT 1 FROM event_shows es
        JOIN screens sc ON es.screen_id = sc.id
        JOIN theatres t ON sc.theatre_id = t.id
        JOIN theater_owners to_owner ON to_owner.theatre_id = t.id
        WHERE v_is_event AND es.id = p_show_id 
          AND to_owner.user_id = v_owner_id 
          AND to_owner.role IN ('owner', 'manager')
    ) INTO v_is_authorized;

    IF NOT v_is_authorized THEN
        RAISE EXCEPTION 'Not authorized to manage this show';
    END IF;

    IF p_offline THEN
        -- Delete any non-confirmed/non-locked bookings for these seats first to avoid unique constraint issues
        IF v_is_event THEN
            DELETE FROM bookings 
            WHERE event_show_id = p_show_id 
              AND seat_id = ANY(p_seat_ids) 
              AND status IN ('offline', 'expired', 'cancelled');
              
            -- Mark as offline
            INSERT INTO bookings (event_show_id, seat_id, user_id, status, confirmed_at)
            SELECT p_show_id, s_id, COALESCE(v_owner_id, '00000000-0000-0000-0000-000000000000'::uuid), 'offline', NOW()
            FROM unnest(p_seat_ids) AS s_id;
        ELSE
            DELETE FROM bookings 
            WHERE show_id = p_show_id 
              AND seat_id = ANY(p_seat_ids) 
              AND status IN ('offline', 'expired', 'cancelled');
              
            -- Mark as offline
            INSERT INTO bookings (show_id, seat_id, user_id, status, confirmed_at)
            SELECT p_show_id, s_id, COALESCE(v_owner_id, '00000000-0000-0000-0000-000000000000'::uuid), 'offline', NOW()
            FROM unnest(p_seat_ids) AS s_id;
        END IF;
    ELSE
        -- Remove offline status
        IF v_is_event THEN
            DELETE FROM bookings
            WHERE event_show_id = p_show_id
              AND seat_id = ANY(p_seat_ids)
              AND status = 'offline';
        ELSE
            DELETE FROM bookings
            WHERE show_id = p_show_id
              AND seat_id = ANY(p_seat_ids)
              AND status = 'offline';
        END IF;
    END IF;
END;
$$;

GRANT EXECUTE ON FUNCTION toggle_offline_seats(UUID, UUID[], BOOLEAN) TO authenticated;


-- 3. Redefine get_owner_shows RPC to be a unified, event-aware show list returning screen_id and offline bookings counted in available_seats
DROP FUNCTION IF EXISTS get_owner_shows(UUID, UUID, DATE);

CREATE OR REPLACE FUNCTION get_owner_shows(
    p_user_id UUID,
    p_theatre_id UUID DEFAULT NULL,
    p_date DATE DEFAULT CURRENT_DATE
)
RETURNS TABLE(
    show_id UUID,
    screen_id UUID,
    type TEXT,
    movie_title TEXT,
    screen_name TEXT,
    theatre_name TEXT,
    start_time TIMESTAMPTZ,
    end_time TIMESTAMPTZ,
    base_price DECIMAL,
    total_seats BIGINT,
    booked_seats BIGINT,
    locked_seats BIGINT,
    available_seats BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    WITH all_unified_shows AS (
        SELECT 
            sh.id AS show_id,
            'movie' AS type,
            m.title AS movie_title,
            sc.name AS screen_name,
            t.name AS theatre_name,
            sh.start_time,
            sh.end_time,
            sh.price AS base_price,
            sc.id AS screen_id,
            t.id AS theatre_id
        FROM shows sh
        JOIN movies m ON m.id = sh.movie_id
        JOIN screens sc ON sc.id = sh.screen_id
        JOIN theatres t ON t.id = sc.theatre_id
        
        UNION ALL
        
        SELECT 
            es.id AS show_id,
            'event' AS type,
            e.title AS movie_title,
            sc.name AS screen_name,
            t.name AS theatre_name,
            es.start_time,
            es.end_time,
            es.price AS base_price,
            sc.id AS screen_id,
            t.id AS theatre_id
        FROM event_shows es
        JOIN events e ON e.id = es.event_id
        JOIN screens sc ON sc.id = es.screen_id
        JOIN theatres t ON t.id = sc.theatre_id
    )
    SELECT 
        u.show_id,
        u.screen_id,
        u.type,
        u.movie_title,
        u.screen_name,
        u.theatre_name,
        u.start_time,
        u.end_time,
        u.base_price,
        COUNT(DISTINCT seats.id) AS total_seats,
        COUNT(DISTINCT CASE WHEN b.status = 'confirmed' THEN b.id END) AS booked_seats,
        COUNT(DISTINCT CASE WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN b.id END) AS locked_seats,
        COUNT(DISTINCT seats.id) - COUNT(DISTINCT CASE WHEN b.status IN ('confirmed', 'offline') OR (b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes') THEN b.id END) AS available_seats
    FROM all_unified_shows u
    JOIN theater_owners to_owner ON to_owner.theatre_id = u.theatre_id
    LEFT JOIN seats ON seats.screen_id = u.screen_id
    LEFT JOIN bookings b ON ( (b.show_id = u.show_id AND u.type = 'movie') OR (b.event_show_id = u.show_id AND u.type = 'event') ) AND b.seat_id = seats.id AND b.status IN ('confirmed', 'locked', 'offline')
    WHERE to_owner.user_id = p_user_id
        AND (p_theatre_id IS NULL OR u.theatre_id = p_theatre_id)
        AND DATE(u.start_time) = p_date
    GROUP BY u.show_id, u.screen_id, u.type, u.movie_title, u.screen_name, u.theatre_name, u.start_time, u.end_time, u.base_price
    ORDER BY u.start_time;
END;
$$;

GRANT EXECUTE ON FUNCTION get_owner_shows(UUID, UUID, DATE) TO authenticated;
