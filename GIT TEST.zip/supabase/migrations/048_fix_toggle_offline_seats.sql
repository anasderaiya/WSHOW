-- Fix toggle_offline_seats to guard against seats actively being purchased

CREATE OR REPLACE FUNCTION toggle_offline_seats(
    p_show_id UUID,
    p_seat_ids UUID[],
    p_offline BOOLEAN
) RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_owner_id UUID;
    v_is_authorized BOOLEAN;
    v_locked_seats UUID[];
BEGIN
    v_owner_id := auth.uid();

    -- Authorization check
    SELECT EXISTS (
        SELECT 1 FROM shows sh
        JOIN screens sc ON sh.screen_id = sc.id
        JOIN theatres t ON sc.theatre_id = t.id
        WHERE sh.id = p_show_id AND t.owner_id = v_owner_id
    ) INTO v_is_authorized;

    IF NOT v_is_authorized THEN
        RAISE EXCEPTION 'Not authorized to manage this show';
    END IF;

    IF p_offline THEN
        -- Check for seats actively being purchased (locked within last 5 minutes)
        SELECT ARRAY_AGG(seat_id) INTO v_locked_seats
        FROM bookings
        WHERE show_id = p_show_id
          AND seat_id = ANY(p_seat_ids)
          AND status = 'locked'
          AND locked_at > NOW() - INTERVAL '5 minutes';

        IF v_locked_seats IS NOT NULL AND array_length(v_locked_seats, 1) > 0 THEN
            RAISE EXCEPTION 'Cannot mark offline: % seat(s) are currently being booked by customers. Try again in 5 minutes.',
                array_length(v_locked_seats, 1);
        END IF;

        -- Safe to proceed — remove stale bookings and insert offline
        DELETE FROM bookings
        WHERE show_id = p_show_id
          AND seat_id = ANY(p_seat_ids)
          AND status IN ('offline', 'expired', 'cancelled');

        INSERT INTO bookings (show_id, seat_id, user_id, status, confirmed_at)
        SELECT p_show_id, s_id, v_owner_id, 'offline', NOW()
        FROM unnest(p_seat_ids) AS s_id;

    ELSE
        -- Take seats back online — only remove offline bookings
        DELETE FROM bookings
        WHERE show_id = p_show_id
          AND seat_id = ANY(p_seat_ids)
          AND status = 'offline';
    END IF;
END;
$$;
