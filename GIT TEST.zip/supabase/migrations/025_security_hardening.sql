
-- ============================================
-- Quick My Ticket - Security Hardening
-- Migration 025
-- ============================================

-- 1. ENABLE RLS ON REMAINING TABLES
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.seats ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.movies ENABLE ROW LEVEL SECURITY;

-- 2. BOOKINGS POLICIES
DROP POLICY IF EXISTS "Users view own bookings" ON bookings;
DROP POLICY IF EXISTS "Users view own bookings" ON bookings;
CREATE POLICY "Users view own bookings"
ON bookings
    FOR SELECT USING (
        auth.uid() = user_id OR 
        (user_id IS NULL AND session_id IS NOT NULL)
    );

DROP POLICY IF EXISTS "Admins full access bookings" ON bookings;
DROP POLICY IF EXISTS "Admins full access bookings" ON bookings;
CREATE POLICY "Admins full access bookings"
ON bookings
    FOR ALL USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

DROP POLICY IF EXISTS "Owners view bookings for their shows" ON bookings;
DROP POLICY IF EXISTS "Owners view bookings for their shows" ON bookings;
CREATE POLICY "Owners view bookings for their shows"
ON bookings
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM theater_owners to_
            JOIN shows s ON s.id = bookings.show_id
            WHERE to_.user_id = auth.uid() AND to_.theatre_id = (SELECT theatre_id FROM screens WHERE id = s.screen_id)
        ) OR
        EXISTS (
            SELECT 1 FROM theater_owners to_
            JOIN event_shows es ON es.id = bookings.event_show_id
            WHERE to_.user_id = auth.uid() AND to_.theatre_id = (SELECT theatre_id FROM screens WHERE id = es.screen_id)
        )
    );

-- Block direct INSERT/UPDATE/DELETE for non-admins
DROP POLICY IF EXISTS "No direct inserts for non-admins" ON bookings;
DROP POLICY IF EXISTS "No direct inserts for non-admins" ON bookings;
CREATE POLICY "No direct inserts for non-admins"
ON bookings
    FOR INSERT WITH CHECK ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

DROP POLICY IF EXISTS "No direct updates for non-admins" ON bookings;
DROP POLICY IF EXISTS "No direct updates for non-admins" ON bookings;
CREATE POLICY "No direct updates for non-admins"
ON bookings
    FOR UPDATE USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true)
    WITH CHECK ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

DROP POLICY IF EXISTS "No direct deletes for non-admins" ON bookings;
DROP POLICY IF EXISTS "No direct deletes for non-admins" ON bookings;
CREATE POLICY "No direct deletes for non-admins"
ON bookings
    FOR DELETE USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);


-- 3. SEATS POLICIES
DROP POLICY IF EXISTS "Seats are viewable by everyone" ON seats;
DROP POLICY IF EXISTS "Seats are viewable by everyone" ON bookings;
CREATE POLICY "Seats are viewable by everyone"
ON seats
    FOR SELECT USING (true);

DROP POLICY IF EXISTS "Admins can manage seats" ON seats;
DROP POLICY IF EXISTS "Admins can manage seats" ON bookings;
CREATE POLICY "Admins can manage seats"
ON seats
    FOR ALL USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);


-- 4. MOVIES POLICIES
DROP POLICY IF EXISTS "Movies are viewable by everyone" ON movies;
DROP POLICY IF EXISTS "Movies are viewable by everyone" ON bookings;
CREATE POLICY "Movies are viewable by everyone"
ON movies
    FOR SELECT USING (true);

DROP POLICY IF EXISTS "Admins can manage movies" ON movies;
DROP POLICY IF EXISTS "Admins can manage movies" ON bookings;
CREATE POLICY "Admins can manage movies"
ON movies
    FOR ALL USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);


-- 5. PERMISSION REFINEMENT
REVOKE ALL ON bookings FROM anon;
GRANT SELECT ON bookings TO anon;
GRANT SELECT ON bookings TO authenticated;
