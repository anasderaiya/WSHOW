-- Migration 036: Add razorpay_account_id for Razorpay Route
ALTER TABLE public.theatres ADD COLUMN IF NOT EXISTS razorpay_account_id TEXT;
