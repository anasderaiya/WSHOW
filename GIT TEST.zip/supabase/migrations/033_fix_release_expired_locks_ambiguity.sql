-- ============================================
-- Fix Ambiguous release_expired_locks Function
-- ============================================
-- The previous migration (031) created a version of release_expired_locks()
-- with no arguments. This conflicts with the original version created in
-- migration 001 which had an optional parameter `p_lock_timeout_minutes INTEGER DEFAULT 5`.
-- Since both can be called with zero arguments, Postgres throws an ambiguity error.
-- We drop the void version and update the pg_cron job to explicitly cast/call
-- the correct version.

-- 1. Drop the conflicting void function (without dropping the one with arguments)
DROP FUNCTION IF EXISTS release_expired_locks();

-- 2. Redefine the parameterized function to ensure it clears locked_at = NULL
CREATE OR REPLACE FUNCTION release_expired_locks(
    p_lock_timeout_minutes INTEGER DEFAULT 5
)
RETURNS TABLE(
    released_count INTEGER,
    released_ids UUID[]
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_released_ids UUID[];
    v_count INTEGER;
BEGIN
    WITH expired AS (
        UPDATE bookings 
        SET status = 'expired', 
            locked_at = NULL
        WHERE status = 'locked' 
          AND locked_at < NOW() - (p_lock_timeout_minutes || ' minutes')::INTERVAL
        RETURNING id
    )
    SELECT array_agg(id), COUNT(*)::INTEGER 
    INTO v_released_ids, v_count
    FROM expired;
    
    RETURN QUERY SELECT COALESCE(v_count, 0), COALESCE(v_released_ids, ARRAY[]::UUID[]);
END;
$$;

-- Only allow service role to execute (for cron/edge function)
REVOKE ALL ON FUNCTION release_expired_locks(INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION release_expired_locks(INTEGER) TO service_role;

-- 3. Ensure the cron job is using the proper parameterized one
DO $$
BEGIN
    -- Remove the old job
    PERFORM cron.unschedule('release-expired-locks');

    -- Re-schedule explicitly passing the default 5 to avoid any potential ambiguity
    PERFORM cron.schedule(
        'release-expired-locks',
        '* * * * *',
        'SELECT release_expired_locks(5);'
    );

    RAISE LOG '[QMT] pg_cron job "release-expired-locks" fixed and rescheduled';
EXCEPTION WHEN OTHERS THEN
    RAISE LOG '[QMT] pg_cron not available - skipping cron job update. Enable pg_cron in Supabase Dashboard -> Database -> Extensions.';
END;
$$;
