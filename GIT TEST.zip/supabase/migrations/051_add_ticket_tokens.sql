-- Migration 051: Add Cryptographic Ticket Tokens to prevent IDOR

-- 1. Add ticket_token column
ALTER TABLE bookings 
ADD COLUMN IF NOT EXISTS ticket_token UUID UNIQUE;

-- 2. Create index for fast lookups
CREATE INDEX IF NOT EXISTS idx_bookings_ticket_token ON bookings(ticket_token);

-- 3. Update confirm_bookings to generate ticket_token
CREATE OR REPLACE FUNCTION confirm_bookings(
    p_booking_ids UUID[],
    p_payment_id TEXT,
    p_guest_name TEXT DEFAULT NULL,
    p_guest_email TEXT DEFAULT NULL,
    p_guest_phone TEXT DEFAULT NULL,
    p_user_id UUID DEFAULT NULL
)
RETURNS TABLE(
    confirmed_count INTEGER,
    total_amount DECIMAL
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_count INTEGER;
    v_total DECIMAL;
BEGIN
    -- Calculate total for the specific requested IDs
    SELECT total INTO v_total
    FROM calculate_booking_total(p_booking_ids);
    
    WITH confirmed AS (
        UPDATE bookings 
        SET status = 'confirmed',
            payment_id = p_payment_id,
            confirmed_at = NOW(),
            ticket_token = gen_random_uuid(), -- Generate secure UUIDv4 token
            -- Only update guest details if not already present
            guest_name = COALESCE(bookings.guest_name, p_guest_name),
            guest_email = COALESCE(bookings.guest_email, p_guest_email),
            guest_phone = COALESCE(bookings.guest_phone, p_guest_phone),
            -- Link to user if provided (e.g., guest logged in before checkout)
            user_id = COALESCE(bookings.user_id, p_user_id)
        WHERE id = ANY(p_booking_ids)
          AND status = 'locked'
        RETURNING id
    )
    SELECT COUNT(*)::INTEGER INTO v_count FROM confirmed;
    
    RETURN QUERY SELECT v_count, COALESCE(v_total, 0);
END;
$$;

-- Ensure permissions
REVOKE ALL ON FUNCTION confirm_bookings(UUID[], TEXT, TEXT, TEXT, TEXT, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION confirm_bookings(UUID[], TEXT, TEXT, TEXT, TEXT, UUID) TO service_role;

-- 4. Create secure read-only RPC for frontend ticket viewing
CREATE OR REPLACE FUNCTION get_ticket_by_token(p_token UUID)
RETURNS TABLE (
  booking_id UUID,
  seat_label TEXT,
  seat_tier TEXT,
  movie_title TEXT,
  event_title TEXT,
  poster_url TEXT,
  show_time TIMESTAMPTZ,
  theatre_name TEXT,
  screen_name TEXT,
  qr_code_data TEXT,
  guest_name TEXT,
  guest_email TEXT,
  amount_paid DECIMAL
) 
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    b.id,
    s.row || s.col AS seat_label,
    s.tier AS seat_tier,
    m.title AS movie_title,
    e.title AS event_title,
    COALESCE(m.poster_url, e.poster_url) AS poster_url,
    COALESCE(sh.start_time, es.start_time) AS show_time,
    COALESCE(t.name, et.name) AS theatre_name,
    COALESCE(sc.name, esc.name) AS screen_name,
    b.id::text || '|' || b.ticket_token::text AS qr_code_data,
    b.guest_name,
    b.guest_email,
    b.price AS amount_paid
  FROM bookings b
  JOIN seats s ON b.seat_id = s.id
  -- Handle both Movie Shows and Event Shows
  LEFT JOIN shows sh ON b.show_id = sh.id
  LEFT JOIN movies m ON sh.movie_id = m.id
  LEFT JOIN screens sc ON sh.screen_id = sc.id
  LEFT JOIN theatres t ON sc.theatre_id = t.id
  LEFT JOIN event_shows es ON b.event_show_id = es.id
  LEFT JOIN events e ON es.event_id = e.id
  LEFT JOIN screens esc ON es.screen_id = esc.id
  LEFT JOIN theatres et ON esc.theatre_id = et.id
  WHERE b.ticket_token = p_token
  AND b.status = 'confirmed';
END;
$$;

-- Allow anon and authenticated users to read tickets by token
GRANT EXECUTE ON FUNCTION get_ticket_by_token(UUID) TO anon;
GRANT EXECUTE ON FUNCTION get_ticket_by_token(UUID) TO authenticated;
