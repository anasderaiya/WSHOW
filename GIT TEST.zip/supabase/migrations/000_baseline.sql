-- ============================================
-- Quick My Ticket Baseline Schema
-- ============================================
-- Reconstructed from frontend queries to provide the foundational tables.
-- These tables were originally created manually via the Supabase UI.

-- 1. Theatres
CREATE TABLE IF NOT EXISTS theatres (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    location TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE theatres ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public theatres are viewable by everyone" ON theatres;
CREATE POLICY "Public theatres are viewable by everyone"
ON theatres FOR SELECT USING (true);
DROP POLICY IF EXISTS "Admins can insert theatres" ON theatres;
CREATE POLICY "Admins can insert theatres"
ON theatres FOR INSERT WITH CHECK (true);
DROP POLICY IF EXISTS "Admins can update theatres" ON theatres;
CREATE POLICY "Admins can update theatres"
ON theatres FOR UPDATE USING (true);
DROP POLICY IF EXISTS "Admins can delete theatres" ON theatres;
CREATE POLICY "Admins can delete theatres"
ON theatres FOR DELETE USING (true);

-- 2. Screens
CREATE TABLE IF NOT EXISTS screens (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    theatre_id UUID REFERENCES theatres(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    seat_layout JSONB,
    total_seats INTEGER,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE screens ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public screens are viewable by everyone" ON screens;
CREATE POLICY "Public screens are viewable by everyone"
ON screens FOR SELECT USING (true);
DROP POLICY IF EXISTS "Admins can insert screens" ON screens;
CREATE POLICY "Admins can insert screens"
ON screens FOR INSERT WITH CHECK (true);
DROP POLICY IF EXISTS "Admins can update screens" ON screens;
CREATE POLICY "Admins can update screens"
ON screens FOR UPDATE USING (true);
DROP POLICY IF EXISTS "Admins can delete screens" ON screens;
CREATE POLICY "Admins can delete screens"
ON screens FOR DELETE USING (true);

-- 3. Movies
CREATE TABLE IF NOT EXISTS movies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    description TEXT,
    poster_url TEXT,
    duration_minutes INTEGER,
    genre TEXT,
    rating TEXT,
    release_date DATE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE movies ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public movies are viewable by everyone" ON movies;
CREATE POLICY "Public movies are viewable by everyone"
ON movies FOR SELECT USING (true);
DROP POLICY IF EXISTS "Admins can insert movies" ON movies;
CREATE POLICY "Admins can insert movies"
ON movies FOR INSERT WITH CHECK (true);
DROP POLICY IF EXISTS "Admins can update movies" ON movies;
CREATE POLICY "Admins can update movies"
ON movies FOR UPDATE USING (true);
DROP POLICY IF EXISTS "Admins can delete movies" ON movies;
CREATE POLICY "Admins can delete movies"
ON movies FOR DELETE USING (true);

-- 4. Shows
CREATE TABLE IF NOT EXISTS shows (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    movie_id UUID REFERENCES movies(id) ON DELETE CASCADE,
    screen_id UUID REFERENCES screens(id) ON DELETE CASCADE,
    start_time TIMESTAMPTZ NOT NULL,
    price DECIMAL DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE shows ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public shows are viewable by everyone" ON shows;
CREATE POLICY "Public shows are viewable by everyone"
ON shows FOR SELECT USING (true);
DROP POLICY IF EXISTS "Admins can insert shows" ON shows;
CREATE POLICY "Admins can insert shows"
ON shows FOR INSERT WITH CHECK (true);
DROP POLICY IF EXISTS "Admins can update shows" ON shows;
CREATE POLICY "Admins can update shows"
ON shows FOR UPDATE USING (true);
DROP POLICY IF EXISTS "Admins can delete shows" ON shows;
CREATE POLICY "Admins can delete shows"
ON shows FOR DELETE USING (true);

-- 5. Seats
CREATE TABLE IF NOT EXISTS seats (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    screen_id UUID REFERENCES screens(id) ON DELETE CASCADE,
    row TEXT NOT NULL,
    col INTEGER NOT NULL,
    tier TEXT,
    price DECIMAL DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE seats ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public seats are viewable by everyone" ON seats;
CREATE POLICY "Public seats are viewable by everyone"
ON seats FOR SELECT USING (true);
DROP POLICY IF EXISTS "Admins can insert seats" ON seats;
CREATE POLICY "Admins can insert seats"
ON seats FOR INSERT WITH CHECK (true);
DROP POLICY IF EXISTS "Admins can update seats" ON seats;
CREATE POLICY "Admins can update seats"
ON seats FOR UPDATE USING (true);
DROP POLICY IF EXISTS "Admins can delete seats" ON seats;
CREATE POLICY "Admins can delete seats"
ON seats FOR DELETE USING (true);

-- 6. Bookings
CREATE TABLE IF NOT EXISTS bookings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    show_id UUID REFERENCES shows(id) ON DELETE CASCADE,
    seat_id UUID REFERENCES seats(id) ON DELETE CASCADE,
    user_id UUID, -- References auth.users(id) inherently 
    session_id TEXT,
    status TEXT DEFAULT 'locked' CHECK (status IN ('locked', 'confirmed', 'cancelled', 'expired')),
    locked_at TIMESTAMPTZ,
    confirmed_at TIMESTAMPTZ,
    payment_id TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users can view own bookings" ON bookings;
CREATE POLICY "Users can view own bookings"
ON bookings FOR SELECT USING (true); -- Relaxed for baseline, restricted in functions
DROP POLICY IF EXISTS "Users can insert bookings" ON bookings;
CREATE POLICY "Users can insert bookings"
ON bookings FOR INSERT WITH CHECK (true);
DROP POLICY IF EXISTS "Users can update own bookings" ON bookings;
CREATE POLICY "Users can update own bookings"
ON bookings FOR UPDATE USING (true);
DROP POLICY IF EXISTS "Users can delete own bookings" ON bookings;
CREATE POLICY "Users can delete own bookings"
ON bookings FOR DELETE USING (true);
