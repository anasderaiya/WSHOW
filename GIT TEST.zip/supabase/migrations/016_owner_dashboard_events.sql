-- Migration: Upgrade Owner Dashboard to support events
-- Replaces old RPC functions to unify shows and event_shows datasets

DROP FUNCTION IF EXISTS get_owner_shows(UUID, UUID, DATE);
DROP FUNCTION IF EXISTS get_owner_dashboard_stats(UUID);

CREATE OR REPLACE FUNCTION get_owner_dashboard_stats(p_user_id UUID)
RETURNS TABLE(
    total_theatres BIGINT,
    total_screens BIGINT,
    total_seats BIGINT,
    today_bookings BIGINT,
    today_revenue DECIMAL,
    currently_locked BIGINT,
    today_confirmed BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_theatre_ids UUID[];
    v_today DATE := CURRENT_DATE;
BEGIN
    SELECT ARRAY_AGG(theatre_id) INTO v_theatre_ids
    FROM theater_owners
    WHERE user_id = p_user_id;
    
    IF v_theatre_ids IS NULL THEN
        RETURN QUERY SELECT 0::BIGINT, 0::BIGINT, 0::BIGINT, 0::BIGINT, 0::DECIMAL, 0::BIGINT, 0::BIGINT;
        RETURN;
    END IF;
    
    RETURN QUERY
    WITH owned_screens AS (
        SELECT s.id AS screen_id
        FROM screens s
        WHERE s.theatre_id = ANY(v_theatre_ids)
    ),
    owned_shows AS (
        SELECT sh.id AS show_id, sh.price
        FROM shows sh
        JOIN owned_screens os ON os.screen_id = sh.screen_id
    ),
    owned_event_shows AS (
        SELECT es.id AS event_show_id, es.price
        FROM event_shows es
        JOIN owned_screens os ON os.screen_id = es.screen_id
    ),
    owned_bookings AS (
        SELECT b.*
        FROM bookings b
        WHERE (b.show_id IN (SELECT show_id FROM owned_shows)) OR (b.event_show_id IN (SELECT event_show_id FROM owned_event_shows))
    )
    SELECT
        (SELECT COUNT(*) FROM unnest(v_theatre_ids))::BIGINT AS total_theatres,
        (SELECT COUNT(*) FROM owned_screens)::BIGINT AS total_screens,
        (SELECT COUNT(*) FROM seats WHERE screen_id IN (SELECT screen_id FROM owned_screens))::BIGINT AS total_seats,
        (SELECT COUNT(*) FROM owned_bookings WHERE DATE(created_at) = v_today)::BIGINT AS today_bookings,
        COALESCE((
            SELECT SUM(
                COALESCE(
                    seats.price, 
                    (SELECT price FROM shows WHERE id = b.show_id), 
                    (SELECT price FROM event_shows WHERE id = b.event_show_id), 
                    0
                )
            )
            FROM owned_bookings b
            LEFT JOIN seats ON seats.id = b.seat_id
            WHERE DATE(b.created_at) = v_today AND b.status = 'confirmed'
        ), 0)::DECIMAL AS today_revenue,
        (SELECT COUNT(*) FROM owned_bookings WHERE status = 'locked' AND locked_at >= NOW() - INTERVAL '5 minutes')::BIGINT AS currently_locked,
        (SELECT COUNT(*) FROM owned_bookings WHERE DATE(created_at) = v_today AND status = 'confirmed')::BIGINT AS today_confirmed;
END;
$$;


CREATE OR REPLACE FUNCTION get_owner_shows(
    p_user_id UUID,
    p_theatre_id UUID DEFAULT NULL,
    p_date DATE DEFAULT CURRENT_DATE
)
RETURNS TABLE(
    id UUID,             
    type TEXT,
    title TEXT,          
    screen_name TEXT,
    theatre_name TEXT,
    start_time TIMESTAMPTZ,
    end_time TIMESTAMPTZ,
    base_price DECIMAL,
    total_seats BIGINT,
    booked_seats BIGINT,
    locked_seats BIGINT,
    available_seats BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    WITH all_unified_shows AS (
        SELECT 
            sh.id,
            'movie' AS type,
            m.title,
            sc.name AS screen_name,
            t.name AS theatre_name,
            sh.start_time,
            sh.end_time,
            sh.price AS base_price,
            sc.id AS screen_id,
            t.id AS theatre_id
        FROM shows sh
        JOIN movies m ON m.id = sh.movie_id
        JOIN screens sc ON sc.id = sh.screen_id
        JOIN theatres t ON t.id = sc.theatre_id
        
        UNION ALL
        
        SELECT 
            es.id,
            'event' AS type,
            e.title,
            sc.name AS screen_name,
            t.name AS theatre_name,
            es.start_time,
            es.end_time,
            es.price AS base_price,
            sc.id AS screen_id,
            t.id AS theatre_id
        FROM event_shows es
        JOIN events e ON e.id = es.event_id
        JOIN screens sc ON sc.id = es.screen_id
        JOIN theatres t ON t.id = sc.theatre_id
    )
    SELECT 
        u.id,
        u.type,
        u.title,
        u.screen_name,
        u.theatre_name,
        u.start_time,
        u.end_time,
        u.base_price,
        COUNT(DISTINCT seats.id) AS total_seats,
        COUNT(DISTINCT CASE WHEN b.status = 'confirmed' THEN b.id END) AS booked_seats,
        COUNT(DISTINCT CASE WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN b.id END) AS locked_seats,
        COUNT(DISTINCT seats.id) - COUNT(DISTINCT CASE WHEN b.status = 'confirmed' OR (b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes') THEN b.id END) AS available_seats
    FROM all_unified_shows u
    JOIN theater_owners to_owner ON to_owner.theatre_id = u.theatre_id
    LEFT JOIN seats ON seats.screen_id = u.screen_id
    LEFT JOIN bookings b ON ( (b.show_id = u.id AND u.type = 'movie') OR (b.event_show_id = u.id AND u.type = 'event') ) AND b.seat_id = seats.id AND b.status IN ('confirmed', 'locked')
    WHERE to_owner.user_id = p_user_id
        AND (p_theatre_id IS NULL OR u.theatre_id = p_theatre_id)
        AND DATE(u.start_time) = p_date
    GROUP BY u.id, u.type, u.title, u.screen_name, u.theatre_name, u.start_time, u.end_time, u.base_price
    ORDER BY u.start_time;
END;
$$;

GRANT EXECUTE ON FUNCTION get_owner_shows(UUID, UUID, DATE) TO authenticated;
GRANT EXECUTE ON FUNCTION get_owner_dashboard_stats(UUID) TO authenticated;
