-- ============================================
-- Quick My Ticket - CRITICAL SECURITY FIX
-- Migration 026: Close Privilege Escalation
-- ============================================
-- PROBLEM: All admin checks use auth.jwt()->'user_metadata' which
-- any authenticated user can self-modify via supabase.auth.updateUser().
-- FIX: Switch every check to auth.jwt()->'app_metadata' which can
-- only be set server-side (service_role or Supabase Dashboard).
-- ============================================

-- =============================================
-- PART 1: RLS POLICIES (DROP + RECREATE)
-- =============================================

-- 1A. theater_owners
DROP POLICY IF EXISTS "Admin full access theater_owners" ON theater_owners;
CREATE POLICY "Admin full access theater_owners"
ON theater_owners 
FOR ALL USING (
    (auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true
);

-- 1B. theatres
DROP POLICY IF EXISTS "Admin manage theatres" ON theatres;
CREATE POLICY "Admin manage theatres"
ON theatres 
FOR ALL USING (
    (auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true
);

-- 1C. screens
DROP POLICY IF EXISTS "Admin manage screens" ON screens;
CREATE POLICY "Admin manage screens"
ON screens 
FOR ALL USING (
    (auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true
);

-- 1D. shows
DROP POLICY IF EXISTS "Admin manage shows" ON shows;
CREATE POLICY "Admin manage shows"
ON shows 
FOR ALL USING (
    (auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true
);

-- 1E. owner_applications
DROP POLICY IF EXISTS "Admins can view all applications" ON owner_applications;
CREATE POLICY "Admins can view all applications"
ON owner_applications
    FOR SELECT USING (
        (auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true
    );

DROP POLICY IF EXISTS "Admins can update applications" ON owner_applications;
CREATE POLICY "Admins can update applications"
ON owner_applications
    FOR UPDATE USING (
        (auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true
    );

-- 1F. events
DROP POLICY IF EXISTS "Admins can update events" ON events;
CREATE POLICY "Admins can update events"
ON events FOR UPDATE 
TO authenticated
USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true)
WITH CHECK ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

DROP POLICY IF EXISTS "Admins can delete events" ON events;
CREATE POLICY "Admins can delete events"
ON events FOR DELETE 
TO authenticated
USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

-- 1G. event_shows
DROP POLICY IF EXISTS "Admins can update event shows" ON event_shows;
CREATE POLICY "Admins can update event shows"
ON event_shows FOR UPDATE 
TO authenticated
USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true)
WITH CHECK ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

DROP POLICY IF EXISTS "Admins can delete event shows" ON event_shows;
CREATE POLICY "Admins can delete event shows"
ON event_shows FOR DELETE 
TO authenticated
USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

-- 1H. transaction_logs
DROP POLICY IF EXISTS "Admins full access trans_logs" ON transaction_logs;
CREATE POLICY "Admins full access trans_logs"
ON transaction_logs 
    FOR ALL USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

-- 1I. bookings (already fixed in 025 but ensure consistency)
DROP POLICY IF EXISTS "Admins full access bookings" ON public.bookings;
DROP POLICY IF EXISTS "Admins full access bookings" ON public.bookings;
CREATE POLICY "Admins full access bookings"
ON public.bookings
    FOR ALL USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

-- 1J. seats
DROP POLICY IF EXISTS "Admins can manage seats" ON public.seats;
DROP POLICY IF EXISTS "Admins can manage seats" ON public.seats;
CREATE POLICY "Admins can manage seats"
ON public.seats
    FOR ALL USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);

-- 1K. movies
DROP POLICY IF EXISTS "Admins can manage movies" ON public.movies;
DROP POLICY IF EXISTS "Admins can manage movies" ON public.movies;
CREATE POLICY "Admins can manage movies"
ON public.movies
    FOR ALL USING ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true);


-- =============================================
-- PART 2: SECURITY DEFINER FUNCTIONS
-- =============================================

-- 2A. get_pending_applications
CREATE OR REPLACE FUNCTION get_pending_applications()
RETURNS TABLE(
    id UUID,
    user_id UUID,
    email TEXT,
    full_name TEXT,
    phone TEXT,
    theatre_name TEXT,
    theatre_location TEXT,
    business_license TEXT,
    message TEXT,
    status TEXT,
    created_at TIMESTAMP WITH TIME ZONE
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    IF NOT ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;
    
    RETURN QUERY
    SELECT 
        oa.id, oa.user_id, oa.email, oa.full_name, oa.phone,
        oa.theatre_name, oa.theatre_location, oa.business_license,
        oa.message, oa.status, oa.created_at
    FROM owner_applications oa
    WHERE oa.status = 'pending'
    ORDER BY oa.created_at DESC;
END;
$$;

-- 2B. approve_owner_application
CREATE OR REPLACE FUNCTION approve_owner_application(
    p_application_id UUID,
    p_admin_notes TEXT DEFAULT NULL
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_admin_id UUID := auth.uid();
    v_app RECORD;
    v_theatre_id UUID;
BEGIN
    IF NOT ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true) THEN
        RETURN json_build_object('success', false, 'error', 'Access denied: Admin only');
    END IF;
    
    SELECT * INTO v_app FROM owner_applications WHERE id = p_application_id;
    
    IF v_app IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Application not found');
    END IF;
    
    IF v_app.status != 'pending' THEN
        RETURN json_build_object('success', false, 'error', 'Application already processed');
    END IF;
    
    INSERT INTO theatres (name, location)
    VALUES (v_app.theatre_name, v_app.theatre_location)
    RETURNING id INTO v_theatre_id;
    
    INSERT INTO theater_owners (user_id, theatre_id, role)
    VALUES (v_app.user_id, v_theatre_id, 'owner');
    
    UPDATE owner_applications
    SET status = 'approved',
        reviewed_at = NOW(),
        reviewed_by = v_admin_id,
        admin_notes = p_admin_notes
    WHERE id = p_application_id;
    
    RETURN json_build_object(
        'success', true, 
        'message', 'Application approved',
        'theatre_id', v_theatre_id
    );
END;
$$;

-- 2C. reject_owner_application
CREATE OR REPLACE FUNCTION reject_owner_application(
    p_application_id UUID,
    p_admin_notes TEXT DEFAULT NULL
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_admin_id UUID := auth.uid();
BEGIN
    IF NOT ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true) THEN
        RETURN json_build_object('success', false, 'error', 'Access denied: Admin only');
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM owner_applications WHERE id = p_application_id AND status = 'pending') THEN
        RETURN json_build_object('success', false, 'error', 'Application not found or already processed');
    END IF;
    
    UPDATE owner_applications
    SET status = 'rejected',
        reviewed_at = NOW(),
        reviewed_by = v_admin_id,
        admin_notes = p_admin_notes
    WHERE id = p_application_id;
    
    RETURN json_build_object('success', true, 'message', 'Application rejected');
END;
$$;

-- 2D. update_screen_layout
CREATE OR REPLACE FUNCTION update_screen_layout(
    p_screen_id UUID,
    p_seat_layout JSONB
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_theatre_id UUID;
    v_is_owner BOOLEAN;
BEGIN
    IF p_seat_layout IS NULL 
       OR jsonb_typeof(p_seat_layout->'rows') IS DISTINCT FROM 'array' THEN
        RETURN json_build_object('success', false, 'error', 'Invalid seat layout');
    END IF;

    SELECT theatre_id INTO v_theatre_id
    FROM screens
    WHERE id = p_screen_id;

    IF v_theatre_id IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Screen not found');
    END IF;

    SELECT EXISTS(
        SELECT 1 FROM theater_owners
        WHERE user_id = v_user_id AND theatre_id = v_theatre_id
    ) INTO v_is_owner;

    IF NOT v_is_owner AND NOT (COALESCE((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean, false) = true) THEN
        RETURN json_build_object('success', false, 'error', 'Access denied');
    END IF;

    IF EXISTS (
        SELECT 1 FROM bookings b
        JOIN shows s ON b.show_id = s.id
        WHERE s.screen_id = p_screen_id AND b.status IN ('confirmed', 'locked')
        
        UNION ALL
        
        SELECT 1 FROM bookings b
        JOIN event_shows es ON b.event_show_id = es.id
        WHERE es.screen_id = p_screen_id AND b.status IN ('confirmed', 'locked')
    ) THEN
        RETURN json_build_object('success', false, 'error', 'Cannot update layout: Active bookings exist for this screen');
    END IF;

    UPDATE screens
    SET 
        seat_layout = p_seat_layout,
        total_seats = COALESCE((p_seat_layout->'metadata'->>'totalSeats')::integer, total_seats)
    WHERE id = p_screen_id;

    DELETE FROM seats WHERE screen_id = p_screen_id;

    INSERT INTO seats (screen_id, row, col, tier, price)
    SELECT 
        p_screen_id,
        r->>'label',
        (s->>'id')::integer,
        s->>'type',
        (s->>'price')::integer
    FROM jsonb_array_elements(p_seat_layout->'rows') AS r
    CROSS JOIN jsonb_array_elements(r->'seats') AS s
    WHERE s IS NOT NULL AND s != 'null'::jsonb;

    RETURN json_build_object('success', true, 'message', 'Layout updated and seats synced');
END;
$$;

-- 2E. get_admin_dashboard_stats
CREATE OR REPLACE FUNCTION get_admin_dashboard_stats()
RETURNS TABLE(
    total_revenue NUMERIC,
    total_bookings BIGINT,
    total_theatres BIGINT,
    total_owners BIGINT,
    today_revenue NUMERIC,
    today_bookings BIGINT,
    active_locks BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    IF NOT ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;

    RETURN QUERY
    WITH movie_stats AS (
        SELECT
            SUM(COALESCE(seats.price, sh.price, 0)) FILTER (WHERE b.status = 'confirmed') AS total_revenue,
            COUNT(*) FILTER (WHERE b.status = 'confirmed') AS total_bookings,
            SUM(COALESCE(seats.price, sh.price, 0)) FILTER (WHERE b.status = 'confirmed' AND b.created_at >= CURRENT_DATE AND b.created_at < (CURRENT_DATE + interval '1 day')) AS today_revenue,
            COUNT(*) FILTER (WHERE b.status = 'confirmed' AND b.created_at >= CURRENT_DATE AND b.created_at < (CURRENT_DATE + interval '1 day')) AS today_bookings,
            COUNT(*) FILTER (WHERE b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '10 minutes') AS active_locks
        FROM bookings b
        JOIN shows sh ON sh.id = b.show_id
        LEFT JOIN seats ON seats.id = b.seat_id
    ),
    event_stats AS (
        SELECT
            SUM(COALESCE(seats.price, es.price, 0)) FILTER (WHERE b.status = 'confirmed') AS total_revenue,
            COUNT(*) FILTER (WHERE b.status = 'confirmed') AS total_bookings,
            SUM(COALESCE(seats.price, es.price, 0)) FILTER (WHERE b.status = 'confirmed' AND b.created_at >= CURRENT_DATE AND b.created_at < (CURRENT_DATE + interval '1 day')) AS today_revenue,
            COUNT(*) FILTER (WHERE b.status = 'confirmed' AND b.created_at >= CURRENT_DATE AND b.created_at < (CURRENT_DATE + interval '1 day')) AS today_bookings,
            COUNT(*) FILTER (WHERE b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '10 minutes') AS active_locks
        FROM bookings b
        JOIN event_shows es ON es.id = b.event_show_id
        LEFT JOIN seats ON seats.id = b.seat_id
    )
    SELECT
        (COALESCE((SELECT total_revenue FROM movie_stats), 0) + COALESCE((SELECT total_revenue FROM event_stats), 0))::NUMERIC,
        (COALESCE((SELECT total_bookings FROM movie_stats), 0) + COALESCE((SELECT total_bookings FROM event_stats), 0))::BIGINT,
        (SELECT COUNT(*) FROM theatres)::BIGINT,
        (SELECT COUNT(DISTINCT user_id) FROM theater_owners)::BIGINT,
        (COALESCE((SELECT today_revenue FROM movie_stats), 0) + COALESCE((SELECT today_revenue FROM event_stats), 0))::NUMERIC,
        (COALESCE((SELECT today_bookings FROM movie_stats), 0) + COALESCE((SELECT today_bookings FROM event_stats), 0))::BIGINT,
        (COALESCE((SELECT active_locks FROM movie_stats), 0) + COALESCE((SELECT active_locks FROM event_stats), 0))::BIGINT;
END;
$$;

-- 2F. get_admin_owner_revenue_breakdown
CREATE OR REPLACE FUNCTION get_admin_owner_revenue_breakdown(p_start_date DATE DEFAULT NULL, p_end_date DATE DEFAULT NULL)
RETURNS TABLE(
    owner_id UUID,
    owner_email TEXT,
    owner_name TEXT,
    theatre_names TEXT,
    revenue NUMERIC,
    booking_count BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    IF NOT ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;

    RETURN QUERY
    WITH owner_theatres AS (
        SELECT 
            to_owner.user_id,
            t.id as theatre_id,
            t.name as theatre_name,
            oa.email as user_email,
            oa.full_name as user_name
        FROM theater_owners to_owner
        JOIN theatres t ON t.id = to_owner.theatre_id
        LEFT JOIN owner_applications oa ON oa.user_id = to_owner.user_id AND oa.status = 'approved'
    ),
    movie_bookings AS (
        SELECT 
            s.theatre_id,
            COUNT(b.id) as booking_count,
            SUM(COALESCE(seats.price, sh.price, 0)) as revenue
        FROM bookings b
        JOIN shows sh ON sh.id = b.show_id
        JOIN screens s ON s.id = sh.screen_id
        LEFT JOIN seats ON seats.id = b.seat_id
        WHERE b.status = 'confirmed' 
            AND (p_start_date IS NULL OR b.created_at >= p_start_date)
            AND (p_end_date IS NULL OR b.created_at < (p_end_date + INTERVAL '1 day'))
        GROUP BY s.theatre_id
    ),
    event_bookings AS (
        SELECT 
            s.theatre_id,
            COUNT(b.id) as booking_count,
            SUM(COALESCE(seats.price, es.price, 0)) as revenue
        FROM bookings b
        JOIN event_shows es ON es.id = b.event_show_id
        JOIN screens s ON s.id = es.screen_id
        LEFT JOIN seats ON seats.id = b.seat_id
        WHERE b.status = 'confirmed' 
            AND (p_start_date IS NULL OR b.created_at >= p_start_date)
            AND (p_end_date IS NULL OR b.created_at < (p_end_date + INTERVAL '1 day'))
        GROUP BY s.theatre_id
    )
    SELECT 
        ot.user_id as owner_id,
        MAX(ot.user_email) as owner_email,
        MAX(ot.user_name) as owner_name,
        STRING_AGG(DISTINCT ot.theatre_name, ', ') as theatre_names,
        COALESCE(SUM(mb.revenue), 0) + COALESCE(SUM(eb.revenue), 0) as revenue,
        COALESCE(SUM(mb.booking_count), 0) + COALESCE(SUM(eb.booking_count), 0) as booking_count
    FROM owner_theatres ot
    LEFT JOIN movie_bookings mb ON mb.theatre_id = ot.theatre_id
    LEFT JOIN event_bookings eb ON eb.theatre_id = ot.theatre_id
    GROUP BY ot.user_id
    ORDER BY revenue DESC;
END;
$$;

-- 2G. get_user_role (also reads from raw_user_meta_data — switch to raw_app_meta_data)
CREATE OR REPLACE FUNCTION get_user_role(p_user_id UUID)
RETURNS TABLE(
    is_admin BOOLEAN,
    is_theater_owner BOOLEAN,
    owned_theatre_count BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        COALESCE((au.raw_app_meta_data ->> 'is_admin')::boolean, false) AS is_admin,
        EXISTS (SELECT 1 FROM theater_owners WHERE user_id = p_user_id) AS is_theater_owner,
        (SELECT COUNT(*) FROM theater_owners WHERE user_id = p_user_id) AS owned_theatre_count
    FROM auth.users au
    WHERE au.id = p_user_id;
END;
$$;

-- 2H. user_roles view
CREATE OR REPLACE VIEW user_roles AS
SELECT 
    au.id AS user_id,
    au.email,
    COALESCE((au.raw_app_meta_data ->> 'is_admin')::boolean, false) AS is_admin,
    EXISTS (SELECT 1 FROM theater_owners WHERE user_id = au.id) AS is_theater_owner,
    (SELECT ARRAY_AGG(theatre_id) FROM theater_owners WHERE user_id = au.id) AS owned_theatre_ids
FROM auth.users au;


-- =============================================
-- PART 3: IMPORTANT — MIGRATE EXISTING ADMIN FLAG
-- =============================================
-- If you have existing admins with is_admin in user_metadata,
-- you MUST copy the flag to app_metadata via the Supabase Dashboard
-- or by running this with the service_role key:
--
-- UPDATE auth.users 
-- SET raw_app_meta_data = raw_app_meta_data || '{"is_admin": true}'::jsonb
-- WHERE raw_user_meta_data ->> 'is_admin' = 'true';
--
-- After verifying admins still work, clean up user_metadata:
-- UPDATE auth.users 
-- SET raw_user_meta_data = raw_user_meta_data - 'is_admin'
-- WHERE raw_user_meta_data ? 'is_admin';
