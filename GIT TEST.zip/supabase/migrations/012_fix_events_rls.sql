-- ============================================
-- Fix: Events RLS Policies
-- ============================================
-- Adds missing UPDATE and DELETE policies for administrators on events and event_shows.

-- 1. Events Update/Delete for Admins
DROP POLICY IF EXISTS "Admins can update events" ON events;
CREATE POLICY "Admins can update events"
ON events FOR UPDATE 
TO authenticated
USING ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true)
WITH CHECK ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true);

DROP POLICY IF EXISTS "Admins can delete events" ON events;
CREATE POLICY "Admins can delete events"
ON events FOR DELETE 
TO authenticated
USING ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true);

-- 2. Event Shows Update/Delete for Admins
DROP POLICY IF EXISTS "Admins can update event shows" ON event_shows;
CREATE POLICY "Admins can update event shows"
ON event_shows FOR UPDATE 
TO authenticated
USING ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true)
WITH CHECK ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true);

DROP POLICY IF EXISTS "Admins can delete event shows" ON event_shows;
CREATE POLICY "Admins can delete event shows"
ON event_shows FOR DELETE 
TO authenticated
USING ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true);

-- 3. Ensure theater owners can also manage event shows if they own the theatre
-- Only if the event show is at their screen
DROP POLICY IF EXISTS "Owners can update event shows" ON event_shows;
CREATE POLICY "Owners can update event shows"
ON event_shows FOR UPDATE 
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM theater_owners to_owner
        JOIN screens s ON s.theatre_id = to_owner.theatre_id
        WHERE s.id = event_shows.screen_id
        AND to_owner.user_id = auth.uid()
        AND to_owner.role IN ('owner', 'manager')
    )
);

DROP POLICY IF EXISTS "Owners can delete event shows" ON event_shows;
CREATE POLICY "Owners can delete event shows"
ON event_shows FOR DELETE 
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM theater_owners to_owner
        JOIN screens s ON s.theatre_id = to_owner.theatre_id
        WHERE s.id = event_shows.screen_id
        AND to_owner.user_id = auth.uid()
        AND to_owner.role IN ('owner', 'manager')
    )
);
