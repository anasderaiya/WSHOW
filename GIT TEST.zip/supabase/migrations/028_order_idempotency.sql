-- Migration 028: Add razorpay_order_id for order creation idempotency
-- =====================================================================
-- When create-order is called, the Razorpay order ID is stored on
-- the booking rows. On retry, the Edge Function checks for an existing
-- order before creating a new one, preventing duplicate charges.

ALTER TABLE bookings
    ADD COLUMN IF NOT EXISTS razorpay_order_id text;

-- Index for fast lookup during idempotency check
CREATE INDEX IF NOT EXISTS idx_bookings_razorpay_order_id
    ON bookings (razorpay_order_id)
    WHERE razorpay_order_id IS NOT NULL;

COMMENT ON COLUMN bookings.razorpay_order_id IS 'Razorpay order ID stored at order creation for idempotency on retry';
