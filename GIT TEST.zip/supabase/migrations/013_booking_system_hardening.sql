-- ============================================
-- Quick My Ticket - Final Booking System Hardening
-- ============================================
-- This migration:
-- 1. Adds partial unique indexes to prevent double bookings
-- 2. Updates confirm_bookings to support user identification
-- 3. Optimizes booking queries

-- 1. ADD PARTIAL UNIQUE INDEXES (Critical for Concurrency)
-- These ensure that for any given show/seat, there can be AT MOST ONE active booking
-- (either 'locked' or 'confirmed'). Expired/Cancelled bookings are ignored.

-- For Movie Shows
CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_active_movie_booking 
ON public.bookings (show_id, seat_id) 
WHERE status IN ('locked', 'confirmed') AND show_id IS NOT NULL;

-- For Event Shows
CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_active_event_booking 
ON public.bookings (event_show_id, seat_id) 
WHERE status IN ('locked', 'confirmed') AND event_show_id IS NOT NULL;


-- 2. UPDATE confirm_bookings 
-- Adds support for updating the user_id if a guest logs in during the flow
CREATE OR REPLACE FUNCTION confirm_bookings(
    p_booking_ids UUID[],
    p_payment_id TEXT,
    p_guest_name TEXT DEFAULT NULL,
    p_guest_email TEXT DEFAULT NULL,
    p_guest_phone TEXT DEFAULT NULL,
    p_user_id UUID DEFAULT NULL
)
RETURNS TABLE(
    confirmed_count INTEGER,
    total_amount DECIMAL
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_count INTEGER;
    v_total DECIMAL;
BEGIN
    -- Calculate total for the specific requested IDs
    SELECT total INTO v_total
    FROM calculate_booking_total(p_booking_ids);
    
    WITH confirmed AS (
        UPDATE bookings 
        SET status = 'confirmed',
            payment_id = p_payment_id,
            confirmed_at = NOW(),
            -- Only update guest details if not already present
            guest_name = COALESCE(bookings.guest_name, p_guest_name),
            guest_email = COALESCE(bookings.guest_email, p_guest_email),
            guest_phone = COALESCE(bookings.guest_phone, p_guest_phone),
            -- Link to user if provided (e.g., guest logged in before checkout)
            user_id = COALESCE(bookings.user_id, p_user_id)
        WHERE id = ANY(p_booking_ids)
          AND status = 'locked'
        RETURNING id
    )
    SELECT COUNT(*)::INTEGER INTO v_count FROM confirmed;
    
    RETURN QUERY SELECT v_count, COALESCE(v_total, 0);
END;
$$;


-- 3. PERMISSION RE-GRANT
REVOKE ALL ON FUNCTION confirm_bookings(UUID[], TEXT, TEXT, TEXT, TEXT, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION confirm_bookings(UUID[], TEXT, TEXT, TEXT, TEXT, UUID) TO service_role;


-- 4. HOUSEKEEPING: REFRESH VIEWS
-- Ensure the seat_availability view is fully optimized with the new indexes
ANALYZE bookings;
