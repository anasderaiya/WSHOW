-- Migration 037: Platform Settings and dynamic fees
CREATE TABLE IF NOT EXISTS public.platform_settings (
    key VARCHAR PRIMARY KEY,
    value JSONB NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.platform_settings ENABLE ROW LEVEL SECURITY;

-- Everyone can read settings
DROP POLICY IF EXISTS "Allow public read access to platform_settings" ON public.platform_settings;
CREATE POLICY "Allow public read access to platform_settings"
ON public.platform_settings FOR SELECT USING (true);

-- Only admins can update
DROP POLICY IF EXISTS "Allow admin update access to platform_settings" ON public.platform_settings;
CREATE POLICY "Allow admin update access to platform_settings"
ON public.platform_settings FOR ALL
USING (auth.jwt() ->> 'is_admin' = 'true')
WITH CHECK (auth.jwt() ->> 'is_admin' = 'true');

-- Insert default convenience fee (Fixed ₹20 per ticket)
INSERT INTO public.platform_settings (key, value)
VALUES ('convenience_fee', '{"type": "fixed", "amount": 20}')
ON CONFLICT (key) DO NOTHING;

-- Safely replace calculate_booking_total to include convenience fee
DROP FUNCTION IF EXISTS calculate_booking_total(UUID[], DECIMAL);

CREATE OR REPLACE FUNCTION calculate_booking_total(
    p_booking_ids UUID[],
    p_tax_rate DECIMAL DEFAULT 0.18
)
RETURNS TABLE(
    subtotal DECIMAL,
    convenience_fee DECIMAL,
    tax DECIMAL,
    total DECIMAL,
    seat_count INTEGER
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_subtotal DECIMAL;
    v_seat_count INTEGER;
    v_fee_setting JSONB;
    v_convenience_fee DECIMAL := 0;
BEGIN
    -- Calculate subtotal from seats, movie shows, or event shows
    SELECT 
        COALESCE(SUM(COALESCE(s.price, sh.price, es.price, 0)), 0),
        COUNT(*)::INTEGER
    INTO v_subtotal, v_seat_count
    FROM bookings b
    JOIN seats s ON s.id = b.seat_id
    LEFT JOIN shows sh ON sh.id = b.show_id
    LEFT JOIN event_shows es ON es.id = b.event_show_id
    WHERE b.id = ANY(p_booking_ids)
      AND b.status = 'locked';  -- Only count locked bookings
      
    -- Get convenience fee setting
    SELECT value INTO v_fee_setting FROM platform_settings WHERE key = 'convenience_fee';
    
    IF v_fee_setting IS NOT NULL THEN
        IF v_fee_setting->>'type' = 'fixed' THEN
            v_convenience_fee := (v_fee_setting->>'amount')::DECIMAL * v_seat_count;
        ELSIF v_fee_setting->>'type' = 'percentage' THEN
            v_convenience_fee := ROUND(v_subtotal * (v_fee_setting->>'amount')::DECIMAL / 100, 2);
        END IF;
    END IF;
    
    RETURN QUERY SELECT 
        v_subtotal,
        v_convenience_fee,
        ROUND((v_subtotal + v_convenience_fee) * p_tax_rate, 2),
        v_subtotal + v_convenience_fee + ROUND((v_subtotal + v_convenience_fee) * p_tax_rate, 2),
        v_seat_count;
END;
$$;

GRANT EXECUTE ON FUNCTION calculate_booking_total(UUID[], DECIMAL) TO authenticated;
GRANT EXECUTE ON FUNCTION calculate_booking_total(UUID[], DECIMAL) TO anon;
GRANT EXECUTE ON FUNCTION calculate_booking_total(UUID[], DECIMAL) TO service_role;
