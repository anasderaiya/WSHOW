-- Migration 044: Fix toggle_offline_seats owner check
CREATE OR REPLACE FUNCTION toggle_offline_seats(
    p_show_id UUID,
    p_seat_ids UUID[],
    p_offline BOOLEAN
) RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_owner_id UUID;
    v_is_authorized BOOLEAN;
BEGIN
    v_owner_id := auth.uid();
    
    SELECT EXISTS (
        -- Admin bypass
        SELECT 1 WHERE COALESCE((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean, false) = true
        UNION ALL
        -- Theatre owner/manager check via theater_owners table
        SELECT 1 FROM shows sh
        JOIN screens sc ON sh.screen_id = sc.id
        JOIN theatres t ON sc.theatre_id = t.id
        JOIN theater_owners to_owner ON to_owner.theatre_id = t.id
        WHERE sh.id = p_show_id 
          AND to_owner.user_id = v_owner_id 
          AND to_owner.role IN ('owner', 'manager')
    ) INTO v_is_authorized;

    IF NOT v_is_authorized THEN
        RAISE EXCEPTION 'Not authorized to manage this show';
    END IF;

    IF p_offline THEN
        -- Delete any non-confirmed/non-locked bookings for these seats first to avoid unique constraint issues
        DELETE FROM bookings 
        WHERE show_id = p_show_id 
          AND seat_id = ANY(p_seat_ids) 
          AND status IN ('offline', 'expired', 'cancelled');
          
        -- Mark as offline
        INSERT INTO bookings (show_id, seat_id, user_id, status, confirmed_at)
        SELECT p_show_id, s_id, COALESCE(v_owner_id, '00000000-0000-0000-0000-000000000000'::uuid), 'offline', NOW()
        FROM unnest(p_seat_ids) AS s_id;
    ELSE
        -- Remove offline status
        DELETE FROM bookings
        WHERE show_id = p_show_id
          AND seat_id = ANY(p_seat_ids)
          AND status = 'offline';
    END IF;
END;
$$;

GRANT EXECUTE ON FUNCTION toggle_offline_seats(UUID, UUID[], BOOLEAN) TO authenticated;
