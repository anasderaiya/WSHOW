-- Migration 050: (placeholder)
-- This migration number was skipped during development.
-- Added as a no-op placeholder to maintain sequence continuity.
-- No schema changes.
SELECT 1;
