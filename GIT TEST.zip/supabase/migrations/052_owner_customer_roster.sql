-- ============================================
-- Quick My Ticket - Owner Customer Roster
-- ============================================
-- Adds RPC to get confirmed bookings and guest details for a specific show

DROP FUNCTION IF EXISTS get_customer_bookings_for_show(UUID, TEXT, UUID);

CREATE OR REPLACE FUNCTION get_customer_bookings_for_show(
    p_show_id UUID,
    p_type TEXT,
    p_user_id UUID
)
RETURNS TABLE (
    booking_id UUID,
    seat_id UUID,
    seat_row VARCHAR,
    seat_col VARCHAR,
    price DECIMAL,
    guest_name TEXT,
    guest_email TEXT,
    guest_phone TEXT,
    created_at TIMESTAMPTZ,
    status TEXT,
    payment_id TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_is_owner BOOLEAN;
BEGIN
    -- Verify ownership
    IF p_type = 'event' THEN
        SELECT EXISTS (
            SELECT 1 FROM event_shows es
            JOIN screens s ON es.screen_id = s.id
            JOIN theater_owners to_owner ON s.theatre_id = to_owner.theatre_id
            WHERE es.id = p_show_id AND to_owner.user_id = p_user_id
        ) INTO v_is_owner;
    ELSE
        SELECT EXISTS (
            SELECT 1 FROM shows sh
            JOIN screens s ON sh.screen_id = s.id
            JOIN theater_owners to_owner ON s.theatre_id = to_owner.theatre_id
            WHERE sh.id = p_show_id AND to_owner.user_id = p_user_id
        ) INTO v_is_owner;
    END IF;

    IF NOT v_is_owner THEN
        RAISE EXCEPTION 'Not authorized to view bookings for this show';
    END IF;

    -- Return bookings
    IF p_type = 'event' THEN
        RETURN QUERY
        SELECT 
            b.id AS booking_id,
            b.seat_id,
            s.row AS seat_row,
            s.col AS seat_col,
            s.price,
            b.guest_name,
            b.guest_email,
            b.guest_phone,
            b.created_at,
            b.status,
            b.payment_id
        FROM bookings b
        JOIN seats s ON b.seat_id = s.id
        WHERE b.event_show_id = p_show_id
          AND b.status = 'confirmed'
        ORDER BY b.created_at DESC;
    ELSE
        RETURN QUERY
        SELECT 
            b.id AS booking_id,
            b.seat_id,
            s.row AS seat_row,
            s.col AS seat_col,
            s.price,
            b.guest_name,
            b.guest_email,
            b.guest_phone,
            b.created_at,
            b.status,
            b.payment_id
        FROM bookings b
        JOIN seats s ON b.seat_id = s.id
        WHERE b.show_id = p_show_id
          AND b.status = 'confirmed'
        ORDER BY b.created_at DESC;
    END IF;
END;
$$;

GRANT EXECUTE ON FUNCTION get_customer_bookings_for_show(UUID, TEXT, UUID) TO authenticated;
