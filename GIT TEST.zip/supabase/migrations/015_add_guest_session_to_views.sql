-- Migration: Update views to expose guest session IDs
-- Allows frontend to recover guest locks upon page reload and prevents "phantom locked" seats

-- Drop the views first to avoid Postgres column matching rule conflicts (ERROR: 42P16)
DROP VIEW IF EXISTS seat_availability CASCADE;
DROP VIEW IF EXISTS event_seat_availability CASCADE;

-- Recreate seat_availability view to include session_id
CREATE OR REPLACE VIEW seat_availability AS
SELECT 
    s.id AS seat_id,
    s.screen_id,
    s.row,
    s.col,
    s.tier,
    s.price AS seat_price,
    sh.id AS show_id,
    sh.price AS show_price,
    COALESCE(s.price, sh.price, 0) AS effective_price,
    CASE 
        WHEN b.status = 'confirmed' THEN 'booked'
        WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 'locked'
        ELSE 'available'
    END AS availability_status,
    b.user_id AS locked_by,
    b.id AS booking_id,
    b.locked_at,
    b.session_id AS locked_by_session -- newly added column safely at the end
FROM seats s
CROSS JOIN shows sh
LEFT JOIN LATERAL (
    SELECT * FROM bookings 
    WHERE seat_id = s.id 
      AND show_id = sh.id 
      AND (
          status = 'confirmed' 
          OR (status = 'locked' AND locked_at >= NOW() - INTERVAL '5 minutes')
      )
    ORDER BY locked_at DESC
    LIMIT 1
) b ON true
WHERE s.screen_id = sh.screen_id;

-- Recreate event_seat_availability view to include session_id
CREATE OR REPLACE VIEW event_seat_availability AS
SELECT 
    es.id AS event_show_id,
    es.event_id,
    e.title AS event_title,
    s.id AS seat_id,
    s.screen_id,
    s.row,
    s.col,
    s.tier,
    COALESCE(s.price, es.price) AS effective_price,
    b.id AS booking_id,
    b.user_id AS locked_by,
    b.locked_at,
    CASE 
        WHEN b.status = 'confirmed' THEN 'booked'
        WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 'locked'
        ELSE 'available'
    END AS availability_status,
    b.session_id AS locked_by_session -- newly added column safely at the end
FROM event_shows es
JOIN events e ON e.id = es.event_id
JOIN seats s ON s.screen_id = es.screen_id
LEFT JOIN LATERAL (
    SELECT * FROM bookings
    WHERE seat_id = s.id
      AND event_show_id = es.id
      AND (
          status = 'confirmed'
          OR (status = 'locked' AND locked_at >= NOW() - INTERVAL '5 minutes')
      )
    ORDER BY
        CASE WHEN status = 'confirmed' THEN 0 ELSE 1 END,
        locked_at DESC
    LIMIT 1
) b ON true;
