-- Migration 056: Deploy-Ready Security & Bug Fixes
-- 1. Fix get_ticket_by_token returning blank amount_paid by coalescing s.price, sh.price, es.price
-- 2. Upgrade get_customer_bookings_for_show to use auth.uid() directly for session validation

-- ============================================
-- Fix get_ticket_by_token
-- ============================================
DROP FUNCTION IF EXISTS get_ticket_by_token(UUID);

CREATE OR REPLACE FUNCTION get_ticket_by_token(p_token UUID)
RETURNS TABLE (
  booking_id UUID,
  seat_label TEXT,
  seat_tier TEXT,
  movie_title TEXT,
  event_title TEXT,
  poster_url TEXT,
  show_time TIMESTAMPTZ,
  theatre_name TEXT,
  screen_name TEXT,
  qr_code_data TEXT,
  guest_name TEXT,
  guest_email TEXT,
  amount_paid DECIMAL
) 
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    b.id,
    s.row || s.col AS seat_label,
    s.tier AS seat_tier,
    m.title AS movie_title,
    e.title AS event_title,
    COALESCE(m.poster_url, e.poster_url) AS poster_url,
    COALESCE(sh.start_time, es.start_time) AS show_time,
    COALESCE(t.name, et.name) AS theatre_name,
    COALESCE(sc.name, esc.name) AS screen_name,
    b.id::text || '|' || b.ticket_token::text AS qr_code_data,
    b.guest_name,
    b.guest_email,
    COALESCE(s.price, sh.price, es.price, 0)::DECIMAL AS amount_paid
  FROM bookings b
  JOIN seats s ON b.seat_id = s.id
  -- Handle both Movie Shows and Event Shows
  LEFT JOIN shows sh ON b.show_id = sh.id
  LEFT JOIN movies m ON sh.movie_id = m.id
  LEFT JOIN screens sc ON sh.screen_id = sc.id
  LEFT JOIN theatres t ON sc.theatre_id = t.id
  LEFT JOIN event_shows es ON b.event_show_id = es.id
  LEFT JOIN events e ON es.event_id = e.id
  LEFT JOIN screens esc ON es.screen_id = esc.id
  LEFT JOIN theatres et ON esc.theatre_id = et.id
  WHERE b.ticket_token = p_token
  AND b.status = 'confirmed';
END;
$$;

GRANT EXECUTE ON FUNCTION get_ticket_by_token(UUID) TO anon;
GRANT EXECUTE ON FUNCTION get_ticket_by_token(UUID) TO authenticated;


-- ============================================
-- Secure get_customer_bookings_for_show
-- ============================================
DROP FUNCTION IF EXISTS get_customer_bookings_for_show(UUID, TEXT, UUID);
DROP FUNCTION IF EXISTS get_customer_bookings_for_show(UUID, TEXT);

CREATE OR REPLACE FUNCTION get_customer_bookings_for_show(
    p_show_id UUID,
    p_type TEXT
)
RETURNS TABLE (
    booking_id UUID,
    seat_id UUID,
    seat_row VARCHAR,
    seat_col VARCHAR,
    price DECIMAL,
    guest_name TEXT,
    guest_email TEXT,
    guest_phone TEXT,
    created_at TIMESTAMPTZ,
    status TEXT,
    payment_id TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_is_owner BOOLEAN;
BEGIN
    -- Verify ownership securely using auth.uid() directly
    IF p_type = 'event' THEN
        SELECT EXISTS (
            SELECT 1 FROM event_shows es
            JOIN screens s ON es.screen_id = s.id
            JOIN theater_owners to_owner ON s.theatre_id = to_owner.theatre_id
            WHERE es.id = p_show_id AND to_owner.user_id = auth.uid()
        ) INTO v_is_owner;
    ELSE
        SELECT EXISTS (
            SELECT 1 FROM shows sh
            JOIN screens s ON sh.screen_id = s.id
            JOIN theater_owners to_owner ON s.theatre_id = to_owner.theatre_id
            WHERE sh.id = p_show_id AND to_owner.user_id = auth.uid()
        ) INTO v_is_owner;
    END IF;

    IF NOT v_is_owner THEN
        RAISE EXCEPTION 'Not authorized to view bookings for this show';
    END IF;

    -- Return bookings
    IF p_type = 'event' THEN
        RETURN QUERY
        SELECT 
            b.id AS booking_id,
            b.seat_id,
            s.row AS seat_row,
            s.col AS seat_col,
            s.price,
            b.guest_name,
            b.guest_email,
            b.guest_phone,
            b.created_at,
            b.status,
            b.payment_id
        FROM bookings b
        JOIN seats s ON b.seat_id = s.id
        WHERE b.event_show_id = p_show_id
          AND b.status = 'confirmed'
        ORDER BY b.created_at DESC;
    ELSE
        RETURN QUERY
        SELECT 
            b.id AS booking_id,
            b.seat_id,
            s.row AS seat_row,
            s.col AS seat_col,
            s.price,
            b.guest_name,
            b.guest_email,
            b.guest_phone,
            b.created_at,
            b.status,
            b.payment_id
        FROM bookings b
        JOIN seats s ON b.seat_id = s.id
        WHERE b.show_id = p_show_id
          AND b.status = 'confirmed'
        ORDER BY b.created_at DESC;
    END IF;
END;
$$;

GRANT EXECUTE ON FUNCTION get_customer_bookings_for_show(UUID, TEXT) TO authenticated;
