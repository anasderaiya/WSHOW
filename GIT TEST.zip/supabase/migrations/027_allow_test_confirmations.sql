
-- ============================================
-- Quick My Ticket - Allow Test Confirmations
-- Migration 027
-- ============================================

-- Grant UPDATE permission to allow frontend testing of the booking flow
GRANT UPDATE ON public.bookings TO anon;
GRANT UPDATE ON public.bookings TO authenticated;

-- Add a policy that allows ANYONE to confirm a booking IF:
-- 1. The booking is currently 'locked'
-- 2. they are setting the status to 'confirmed'
-- 3. The payment_id starts with 'TEST_'
-- This allows developers to test the full flow without a backend/edge function.

DROP POLICY IF EXISTS "Allow test confirmations" ON public.bookings;
DROP POLICY IF EXISTS "Allow test confirmations" ON public.bookings;
CREATE POLICY "Allow test confirmations"
ON public.bookings
    FOR UPDATE
    USING (status = 'locked')
    WITH CHECK (
        status = 'confirmed' AND 
        payment_id LIKE 'TEST_%' AND
        confirmed_at IS NOT NULL
    );
