-- ============================================
-- QuickIt - Add Theatre for Existing Owners
-- Migration 008
-- ============================================
-- Run this in Supabase SQL Editor to allow
-- existing theater owners to add more theatres

-- Allow existing theater owners to create new theatres
CREATE OR REPLACE FUNCTION add_theatre_for_owner(
    p_name TEXT,
    p_location TEXT,
    p_address TEXT DEFAULT NULL,
    p_phone TEXT DEFAULT NULL,
    p_email TEXT DEFAULT NULL
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_theatre_id UUID;
    v_is_owner BOOLEAN;
BEGIN
    -- Check if user is already a theater owner
    SELECT EXISTS(
        SELECT 1 FROM theater_owners WHERE user_id = v_user_id
    ) INTO v_is_owner;
    
    IF NOT v_is_owner THEN
        RETURN json_build_object('success', false, 'error', 'You must be an existing theater owner to add theatres');
    END IF;
    
    -- Create the theatre
    INSERT INTO theatres (name, location, address, phone, email)
    VALUES (p_name, p_location, p_address, p_phone, p_email)
    RETURNING id INTO v_theatre_id;
    
    -- Link owner to the new theatre
    INSERT INTO theater_owners (user_id, theatre_id, role)
    VALUES (v_user_id, v_theatre_id, 'owner');
    
    RETURN json_build_object(
        'success', true, 
        'message', 'Theatre added successfully',
        'theatre_id', v_theatre_id
    );
END;
$$;

GRANT EXECUTE ON FUNCTION add_theatre_for_owner(TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated;

-- Add missing columns to theatres if they don't exist
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'theatres' AND column_name = 'address') THEN
        ALTER TABLE theatres ADD COLUMN address TEXT;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'theatres' AND column_name = 'phone') THEN
        ALTER TABLE theatres ADD COLUMN phone TEXT;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'theatres' AND column_name = 'email') THEN
        ALTER TABLE theatres ADD COLUMN email TEXT;
    END IF;
END $$;
