-- ============================================
-- Quick My Ticket Events System
-- ============================================
-- This migration adds:
-- 1. Events table for concerts, sports, comedy shows, etc.
-- 2. Event shows table linking events to venues
-- 3. Modified bookings support for events
-- 4. Event availability view
-- 5. RLS policies for events

-- ============================================
-- 1. EVENTS TABLE
-- ============================================

CREATE TABLE IF NOT EXISTS events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    description TEXT,
    category TEXT NOT NULL DEFAULT 'concert',
    poster_url TEXT,
    banner_url TEXT,
    organizer TEXT,
    venue_name TEXT,
    city TEXT,
    tags TEXT[] DEFAULT '{}',
    is_featured BOOLEAN DEFAULT FALSE,
    status TEXT DEFAULT 'upcoming' CHECK (status IN ('upcoming', 'ongoing', 'completed', 'cancelled')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Add indexes
CREATE INDEX IF NOT EXISTS idx_events_category ON events(category);
CREATE INDEX IF NOT EXISTS idx_events_status ON events(status);
CREATE INDEX IF NOT EXISTS idx_events_featured ON events(is_featured) WHERE is_featured = TRUE;
CREATE INDEX IF NOT EXISTS idx_events_city ON events(city);

-- ============================================
-- 2. EVENT SHOWS TABLE
-- ============================================
-- Links events to venues/screens for seat booking

CREATE TABLE IF NOT EXISTS event_shows (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    event_id UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    screen_id UUID REFERENCES screens(id) ON DELETE SET NULL,
    start_time TIMESTAMPTZ NOT NULL,
    end_time TIMESTAMPTZ,
    price DECIMAL(10,2) DEFAULT 0,
    status TEXT DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'ongoing', 'completed', 'cancelled')),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Add indexes
CREATE INDEX IF NOT EXISTS idx_event_shows_event ON event_shows(event_id);
CREATE INDEX IF NOT EXISTS idx_event_shows_screen ON event_shows(screen_id);
CREATE INDEX IF NOT EXISTS idx_event_shows_start ON event_shows(start_time);

-- ============================================
-- 3. MODIFY BOOKINGS TABLE
-- ============================================
-- Add event_show_id column for event bookings

ALTER TABLE bookings 
ADD COLUMN IF NOT EXISTS event_show_id UUID REFERENCES event_shows(id) ON DELETE CASCADE;

-- Update constraint: either show_id OR event_show_id must be set
-- Note: We allow both to be NULL temporarily during migration
CREATE INDEX IF NOT EXISTS idx_bookings_event_show ON bookings(event_show_id) 
WHERE event_show_id IS NOT NULL;

-- ============================================
-- 4. EVENT SEAT LOCKING FUNCTION
-- ============================================

CREATE OR REPLACE FUNCTION lock_event_seat(
    p_event_show_id UUID, 
    p_seat_id UUID, 
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    booking_id UUID, 
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking_id UUID;
    v_existing RECORD;
    v_screen_id UUID;
    v_seat_exists BOOLEAN;
BEGIN
    -- Validate that the event show exists and get screen_id
    SELECT screen_id INTO v_screen_id 
    FROM event_shows 
    WHERE id = p_event_show_id;
    
    IF v_screen_id IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Event show not found'::TEXT;
        RETURN;
    END IF;
    
    -- Validate that the seat exists and belongs to the event's screen
    SELECT EXISTS(
        SELECT 1 FROM seats 
        WHERE id = p_seat_id AND screen_id = v_screen_id
    ) INTO v_seat_exists;
    
    IF NOT v_seat_exists THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat not found for this event'::TEXT;
        RETURN;
    END IF;
    
    -- Try to acquire a lock on existing booking (if any)
    SELECT * INTO v_existing
    FROM bookings 
    WHERE event_show_id = p_event_show_id 
      AND seat_id = p_seat_id 
      AND status IN ('locked', 'confirmed')
    FOR UPDATE NOWAIT;
    
    -- Check if seat is already taken
    IF FOUND THEN
        IF ((v_existing.user_id IS NOT NULL AND v_existing.user_id = p_user_id) OR
            (v_existing.user_id IS NULL AND v_existing.session_id = p_session_id)) AND v_existing.status = 'locked' THEN
            UPDATE bookings 
            SET locked_at = NOW() 
            WHERE id = v_existing.id;
            
            RETURN QUERY SELECT v_existing.id, TRUE, 'Lock refreshed'::TEXT;
            RETURN;
        ELSIF v_existing.status = 'locked' AND v_existing.locked_at < NOW() - INTERVAL '5 minutes' THEN
            -- Steal the lock! Expire the old one.
            UPDATE bookings SET status = 'expired' WHERE id = v_existing.id;
        ELSE
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is already locked or booked'::TEXT;
            RETURN;
        END IF;
    END IF;
    
    -- Insert new booking with lock
    INSERT INTO bookings (event_show_id, seat_id, user_id, session_id, status, locked_at)
    VALUES (p_event_show_id, p_seat_id, p_user_id, p_session_id, 'locked', NOW())
    RETURNING id INTO v_booking_id;
    
    RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
    
EXCEPTION
    WHEN lock_not_available THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is being processed by another user'::TEXT;
    WHEN unique_violation THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat was just locked by another user'::TEXT;
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, ('Error: ' || SQLERRM)::TEXT;
END;
$$;

GRANT EXECUTE ON FUNCTION lock_event_seat(UUID, UUID, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION lock_event_seat(UUID, UUID, UUID, TEXT) TO anon;

-- ============================================
-- 5. EVENT SEAT AVAILABILITY VIEW
-- ============================================

CREATE OR REPLACE VIEW event_seat_availability AS
SELECT 
    es.id AS event_show_id,
    es.event_id,
    e.title AS event_title,
    s.id AS seat_id,
    s.screen_id,
    s.row,
    s.col,
    s.tier,
    COALESCE(s.price, es.price) AS effective_price,
    b.id AS booking_id,
    b.user_id AS locked_by,
    b.locked_at,
    CASE 
        WHEN b.status = 'confirmed' THEN 'booked'
        WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 'locked'
        ELSE 'available'
    END AS availability_status
FROM event_shows es
JOIN events e ON e.id = es.event_id
JOIN seats s ON s.screen_id = es.screen_id
LEFT JOIN bookings b ON b.seat_id = s.id 
    AND b.event_show_id = es.id 
    AND b.status IN ('locked', 'confirmed');

-- ============================================
-- 6. RLS POLICIES FOR EVENTS
-- ============================================

ALTER TABLE events ENABLE ROW LEVEL SECURITY;
ALTER TABLE event_shows ENABLE ROW LEVEL SECURITY;

-- Events: everyone can read
DROP POLICY IF EXISTS "Events are viewable by everyone" ON events;
CREATE POLICY "Events are viewable by everyone"
ON events FOR SELECT
TO anon, authenticated
USING (true);

-- Events: only authenticated users can insert (for now)
DROP POLICY IF EXISTS "Authenticated users can create events" ON events;
CREATE POLICY "Authenticated users can create events"
ON events FOR INSERT
TO authenticated
WITH CHECK (true);

-- Event shows: everyone can read
DROP POLICY IF EXISTS "Event shows are viewable by everyone" ON event_shows;
CREATE POLICY "Event shows are viewable by everyone"
ON event_shows FOR SELECT
TO anon, authenticated
USING (true);

-- Event shows: authenticated users can create
DROP POLICY IF EXISTS "Authenticated users can create event shows" ON event_shows;
CREATE POLICY "Authenticated users can create event shows"
ON event_shows FOR INSERT
TO authenticated
WITH CHECK (true);

-- ============================================
-- 7. SAMPLE DATA FOR TESTING
-- ============================================

INSERT INTO events (id, title, description, category, poster_url, organizer, venue_name, city, tags, is_featured, status)
VALUES 
    ('e0000001-0001-0001-0001-000000000001', 'Arijit Singh Live', 'Experience the magic of Arijit Singh live in concert. An evening of soulful melodies and unforgettable music.', 'concert', 'https://image.tmdb.org/t/p/w500/aymjrprSz3kNjMHzDNlBp9kSVIw.jpg', 'BookMyShow Live', 'Jawaharlal Nehru Stadium', 'Mumbai', ARRAY['music', 'bollywood', 'live'], TRUE, 'upcoming'),
    ('e0000002-0002-0002-0002-000000000002', 'IPL 2026: MI vs CSK', 'The biggest rivalry in cricket! Watch Mumbai Indians take on Chennai Super Kings.', 'sports', 'https://image.tmdb.org/t/p/w500/dMPxdcMhs0VZlbgjNmKvAdzfyWe.jpg', 'BCCI', 'Wankhede Stadium', 'Mumbai', ARRAY['cricket', 'ipl', 'sports'], TRUE, 'upcoming'),
    ('e0000003-0003-0003-0003-000000000003', 'Zakir Khan Stand-Up Comedy', 'Join Zakir Khan for a night of laughter and relatable comedy about life, love, and everything in between.', 'comedy', 'https://image.tmdb.org/t/p/w500/9gk7adHYeDvHkCSEqAvQNLV5Ber.jpg', 'ZK Entertainment', 'NCPA', 'Mumbai', ARRAY['comedy', 'standup', 'hindi'], FALSE, 'upcoming'),
    ('e0000004-0004-0004-0004-000000000004', 'Sunburn Music Festival', 'Indias biggest electronic dance music festival featuring world-renowned DJs.', 'festival', 'https://image.tmdb.org/t/p/w500/5P1i4ydN5XWk8h3WnBB9JjMzMJA.jpg', 'Sunburn', 'Vagator Beach', 'Goa', ARRAY['edm', 'festival', 'music', 'party'], TRUE, 'upcoming'),
    ('e0000005-0005-0005-0005-000000000005', 'India vs Australia Test', 'Day 1 of the historic India vs Australia test match at the iconic Eden Gardens.', 'sports', 'https://image.tmdb.org/t/p/w500/udDclJoHjfjb8Ekgsd4FDteOkCU.jpg', 'BCCI', 'Eden Gardens', 'Kolkata', ARRAY['cricket', 'test', 'india'], FALSE, 'upcoming')
ON CONFLICT (id) DO NOTHING;

-- ============================================
-- 8. GRANT PERMISSIONS
-- ============================================

GRANT SELECT ON events TO anon, authenticated;
GRANT SELECT ON event_shows TO anon, authenticated;
GRANT SELECT ON event_seat_availability TO anon, authenticated;
GRANT INSERT, UPDATE ON events TO authenticated;
GRANT INSERT, UPDATE ON event_shows TO authenticated;
