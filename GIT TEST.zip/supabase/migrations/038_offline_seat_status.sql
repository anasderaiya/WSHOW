
-- 1. Drop existing constraint
ALTER TABLE bookings DROP CONSTRAINT IF EXISTS bookings_status_check;

-- 2. Add new constraint with 'offline'
ALTER TABLE bookings ADD CONSTRAINT bookings_status_check 
CHECK (status IN ('locked', 'confirmed', 'cancelled', 'expired', 'offline'));

-- 3. Update the view to include offline
CREATE OR REPLACE VIEW seat_availability AS
SELECT
    s.id AS seat_id,
    s.screen_id,
    s.row,
    s.col,
    s.tier,
    s.price AS seat_price,
    sh.id AS show_id,
    sh.price AS show_price,
    COALESCE(s.price, sh.price, 0) AS effective_price,
    CASE
        WHEN b.status = 'offline' THEN 'offline'
        WHEN b.status = 'confirmed' THEN 'booked'
        WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 'locked'
        ELSE 'available'
    END AS availability_status,
    b.user_id AS locked_by,
    b.id AS booking_id,
    b.locked_at,
    b.session_id AS locked_by_session
FROM shows sh
JOIN seats s ON s.screen_id = sh.screen_id
LEFT JOIN LATERAL (
    SELECT *
    FROM bookings
    WHERE seat_id = s.id
      AND show_id = sh.id
      AND (
          status IN ('confirmed', 'offline')
          OR (status = 'locked' AND locked_at >= NOW() - INTERVAL '5 minutes')
      )
    ORDER BY locked_at DESC
    LIMIT 1
) b ON true;

-- 4. Create an RPC to toggle offline seats
CREATE OR REPLACE FUNCTION toggle_offline_seats(
    p_show_id UUID,
    p_seat_ids UUID[],
    p_offline BOOLEAN
) RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_owner_id UUID;
    v_is_authorized BOOLEAN;
BEGIN
    v_owner_id := auth.uid();
    
    SELECT EXISTS (
        SELECT 1 FROM shows sh
        JOIN screens sc ON sh.screen_id = sc.id
        JOIN theatres t ON sc.theatre_id = t.id
        WHERE sh.id = p_show_id AND t.owner_id = v_owner_id
    ) INTO v_is_authorized;

    IF NOT v_is_authorized THEN
        RAISE EXCEPTION 'Not authorized to manage this show';
    END IF;

    IF p_offline THEN
        DELETE FROM bookings 
        WHERE show_id = p_show_id 
          AND seat_id = ANY(p_seat_ids) 
          AND status IN ('offline', 'expired', 'cancelled');
          
        INSERT INTO bookings (show_id, seat_id, user_id, status, confirmed_at)
        SELECT p_show_id, s_id, v_owner_id, 'offline', NOW()
        FROM unnest(p_seat_ids) AS s_id;
    ELSE
        DELETE FROM bookings
        WHERE show_id = p_show_id
          AND seat_id = ANY(p_seat_ids)
          AND status = 'offline';
    END IF;
END;
$$;

