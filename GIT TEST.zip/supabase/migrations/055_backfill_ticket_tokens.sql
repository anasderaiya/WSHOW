-- Migration 055: Backfill ticket_token for existing confirmed bookings

UPDATE bookings 
SET ticket_token = gen_random_uuid()
WHERE status = 'confirmed' AND ticket_token IS NULL;
