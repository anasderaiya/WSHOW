-- Migration 030: Fix get_admin_owner_revenue_breakdown return type
-- =================================================================
-- The SUM() aggregate over a bigint column (COUNT) returns numeric,
-- which conflicted with the function signature expecting a bigint.
-- We cast the final sum back to bigint.

CREATE OR REPLACE FUNCTION get_admin_owner_revenue_breakdown(p_start_date DATE DEFAULT NULL, p_end_date DATE DEFAULT NULL)
RETURNS TABLE(
    owner_id UUID,
    owner_email TEXT,
    owner_name TEXT,
    theatre_names TEXT,
    revenue NUMERIC,
    booking_count BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    IF NOT ((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;

    RETURN QUERY
    WITH owner_theatres AS (
        SELECT 
            to_owner.user_id,
            t.id as theatre_id,
            t.name as theatre_name,
            oa.email as user_email,
            oa.full_name as user_name
        FROM theater_owners to_owner
        JOIN theatres t ON t.id = to_owner.theatre_id
        LEFT JOIN owner_applications oa ON oa.user_id = to_owner.user_id AND oa.status = 'approved'
    ),
    movie_bookings AS (
        SELECT 
            s.theatre_id,
            COUNT(b.id) as booking_count,
            SUM(COALESCE(seats.price, sh.price, 0)) as revenue
        FROM bookings b
        JOIN shows sh ON sh.id = b.show_id
        JOIN screens s ON s.id = sh.screen_id
        LEFT JOIN seats ON seats.id = b.seat_id
        WHERE b.status = 'confirmed' 
            AND (p_start_date IS NULL OR b.created_at >= p_start_date)
            AND (p_end_date IS NULL OR b.created_at < (p_end_date + INTERVAL '1 day'))
        GROUP BY s.theatre_id
    ),
    event_bookings AS (
        SELECT 
            s.theatre_id,
            COUNT(b.id) as booking_count,
            SUM(COALESCE(seats.price, es.price, 0)) as revenue
        FROM bookings b
        JOIN event_shows es ON es.id = b.event_show_id
        JOIN screens s ON s.id = es.screen_id
        LEFT JOIN seats ON seats.id = b.seat_id
        WHERE b.status = 'confirmed' 
            AND (p_start_date IS NULL OR b.created_at >= p_start_date)
            AND (p_end_date IS NULL OR b.created_at < (p_end_date + INTERVAL '1 day'))
        GROUP BY s.theatre_id
    )
    SELECT 
        ot.user_id as owner_id,
        MAX(ot.user_email) as owner_email,
        MAX(ot.user_name) as owner_name,
        STRING_AGG(DISTINCT ot.theatre_name, ', ') as theatre_names,
        COALESCE(SUM(mb.revenue), 0) + COALESCE(SUM(eb.revenue), 0) as revenue,
        (COALESCE(SUM(mb.booking_count), 0) + COALESCE(SUM(eb.booking_count), 0))::BIGINT as booking_count
    FROM owner_theatres ot
    LEFT JOIN movie_bookings mb ON mb.theatre_id = ot.theatre_id
    LEFT JOIN event_bookings eb ON eb.theatre_id = ot.theatre_id
    GROUP BY ot.user_id
    ORDER BY revenue DESC;
END;
$$;

GRANT EXECUTE ON FUNCTION get_admin_owner_revenue_breakdown(DATE, DATE) TO authenticated;
