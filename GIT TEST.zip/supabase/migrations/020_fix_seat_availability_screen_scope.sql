-- ============================================
-- Quick My Ticket - Fix Seat Availability Screen Scope
-- Migration 020
-- ============================================
-- Migration 015 accidentally allowed movie seat availability to cross join
-- seats from every screen into every show. That made booking pages render
-- repeated seat numbers from unrelated screens.

CREATE OR REPLACE VIEW seat_availability AS
SELECT
    s.id AS seat_id,
    s.screen_id,
    s.row,
    s.col,
    s.tier,
    s.price AS seat_price,
    sh.id AS show_id,
    sh.price AS show_price,
    COALESCE(s.price, sh.price, 0) AS effective_price,
    CASE
        WHEN b.status = 'confirmed' THEN 'booked'
        WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 'locked'
        ELSE 'available'
    END AS availability_status,
    b.user_id AS locked_by,
    b.id AS booking_id,
    b.locked_at,
    b.session_id AS locked_by_session
FROM shows sh
JOIN seats s ON s.screen_id = sh.screen_id
LEFT JOIN LATERAL (
    SELECT *
    FROM bookings
    WHERE seat_id = s.id
      AND show_id = sh.id
      AND (
          status = 'confirmed'
          OR (status = 'locked' AND locked_at >= NOW() - INTERVAL '5 minutes')
      )
    ORDER BY
        CASE WHEN status = 'confirmed' THEN 0 ELSE 1 END,
        locked_at DESC
    LIMIT 1
) b ON true;

CREATE OR REPLACE VIEW event_seat_availability AS
SELECT
    es.id AS event_show_id,
    es.event_id,
    e.title AS event_title,
    s.id AS seat_id,
    s.screen_id,
    s.row,
    s.col,
    s.tier,
    COALESCE(s.price, es.price) AS effective_price,
    b.id AS booking_id,
    b.user_id AS locked_by,
    b.locked_at,
    CASE
        WHEN b.status = 'confirmed' THEN 'booked'
        WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 'locked'
        ELSE 'available'
    END AS availability_status,
    b.session_id AS locked_by_session
FROM event_shows es
JOIN events e ON e.id = es.event_id
JOIN seats s ON s.screen_id = es.screen_id
LEFT JOIN LATERAL (
    SELECT *
    FROM bookings
    WHERE seat_id = s.id
      AND event_show_id = es.id
      AND (
          status = 'confirmed'
          OR (status = 'locked' AND locked_at >= NOW() - INTERVAL '5 minutes')
      )
    ORDER BY
        CASE WHEN status = 'confirmed' THEN 0 ELSE 1 END,
        locked_at DESC
    LIMIT 1
) b ON true;

GRANT SELECT ON seat_availability TO authenticated;
GRANT SELECT ON seat_availability TO anon;
GRANT SELECT ON event_seat_availability TO authenticated;
GRANT SELECT ON event_seat_availability TO anon;
