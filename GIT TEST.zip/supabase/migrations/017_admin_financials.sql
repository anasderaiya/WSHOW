-- Migration: Admin Financials & Owner Revenue Breakdown (STABILIZED)
-- Fixes grouping ambiguities and performance bottlenecks

-- Platform Wide Stats
CREATE OR REPLACE FUNCTION get_admin_dashboard_stats()
RETURNS TABLE(
    total_revenue NUMERIC,
    total_bookings BIGINT,
    total_theatres BIGINT,
    total_owners BIGINT,
    today_revenue NUMERIC,
    today_bookings BIGINT,
    active_locks BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Only admins
    IF NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;

    RETURN QUERY
    WITH revenue_calc AS (
        -- Combine all booking sources for a unified calc
        SELECT 
            b.id,
            b.status,
            b.created_at,
            b.locked_at,
            COALESCE(
                seats.price, 
                sh.price, 
                es.price, 
                0
            ) as seat_price
        FROM bookings b
        LEFT JOIN seats ON seats.id = b.seat_id
        LEFT JOIN shows sh ON sh.id = b.show_id
        LEFT JOIN event_shows es ON es.id = b.event_show_id
    )
    SELECT
        COALESCE(SUM(seat_price) FILTER (WHERE status = 'confirmed'), 0)::NUMERIC,
        COUNT(*) FILTER (WHERE status = 'confirmed')::BIGINT,
        (SELECT COUNT(*) FROM theatres)::BIGINT,
        (SELECT COUNT(DISTINCT user_id) FROM theater_owners)::BIGINT,
        COALESCE(SUM(seat_price) FILTER (WHERE status = 'confirmed' AND DATE(created_at) = CURRENT_DATE), 0)::NUMERIC,
        COUNT(*) FILTER (WHERE status = 'confirmed' AND DATE(created_at) = CURRENT_DATE)::BIGINT,
        COUNT(*) FILTER (WHERE status = 'locked' AND locked_at >= NOW() - INTERVAL '10 minutes')::BIGINT
    FROM revenue_calc;
END;
$$;

-- Owner Revenue Breakdown
CREATE OR REPLACE FUNCTION get_admin_owner_revenue_breakdown(p_start_date DATE DEFAULT NULL, p_end_date DATE DEFAULT NULL)
RETURNS TABLE(
    owner_id UUID,
    owner_email TEXT,
    owner_name TEXT,
    theatre_names TEXT,
    revenue NUMERIC,
    booking_count BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Only admins
    IF NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;

    RETURN QUERY
    WITH owner_theatres AS (
        SELECT 
            to_owner.user_id,
            t.id as theatre_id,
            t.name as theatre_name,
            oa.email as user_email,
            oa.full_name as user_name
        FROM theater_owners to_owner
        JOIN theatres t ON t.id = to_owner.theatre_id
        LEFT JOIN owner_applications oa ON oa.user_id = to_owner.user_id AND oa.status = 'approved'
    ),
    all_owner_bookings AS (
        -- Select all confirmed bookings associated with owner theatres
        SELECT 
            ot.user_id,
            ot.user_email,
            ot.user_name,
            ot.theatre_name,
            b.id as booking_id,
            COALESCE(seats.price, sh.price, es.price, 0) as booking_price
        FROM bookings b
        LEFT JOIN shows sh ON sh.id = b.show_id
        LEFT JOIN event_shows es ON es.id = b.event_show_id
        JOIN screens s ON s.id = COALESCE(sh.screen_id, es.screen_id)
        JOIN owner_theatres ot ON ot.theatre_id = s.theatre_id
        LEFT JOIN seats ON seats.id = b.seat_id
        WHERE b.status = 'confirmed'
          AND (p_start_date IS NULL OR DATE(b.created_at) >= p_start_date)
          AND (p_end_date IS NULL OR DATE(b.created_at) <= p_end_date)
    )
    SELECT 
        user_id as owner_id,
        COALESCE(user_email, 'N/A') as owner_email,
        COALESCE(user_name, 'Unknown Owner') as owner_name,
        string_agg(DISTINCT theatre_name, ', ') as theatre_names,
        SUM(booking_price)::NUMERIC as revenue,
        COUNT(DISTINCT booking_id)::BIGINT as booking_count
    FROM all_owner_bookings
    GROUP BY user_id, user_email, user_name
    ORDER BY revenue DESC;
END;
$$;

GRANT EXECUTE ON FUNCTION get_admin_dashboard_stats() TO authenticated;
GRANT EXECUTE ON FUNCTION get_admin_owner_revenue_breakdown(DATE, DATE) TO authenticated;
