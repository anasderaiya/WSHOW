-- Migration 049: Restore event support in toggle_offline_seats + locked seat guard
-- Migration 048 regressed 046's event-aware logic. This migration merges both:
--   * 046's event auto-detection, dual-path inserts, theater_owners auth, admin bypass
--   * 048's locked-seat guard (reject if seats are actively being purchased)

CREATE OR REPLACE FUNCTION toggle_offline_seats(
    p_show_id UUID,
    p_seat_ids UUID[],
    p_offline BOOLEAN
) RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_owner_id UUID;
    v_is_authorized BOOLEAN;
    v_is_event BOOLEAN := FALSE;
    v_locked_seats UUID[];
BEGIN
    v_owner_id := auth.uid();

    -- Detect show type: event show or movie show
    SELECT EXISTS (
        SELECT 1 FROM event_shows WHERE id = p_show_id
    ) INTO v_is_event;

    -- Authorization: admin bypass + theater_owners role check
    SELECT EXISTS (
        -- Admin bypass
        SELECT 1 WHERE COALESCE((auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean, false) = true
        UNION ALL
        -- Movie show authorization
        SELECT 1 FROM shows sh
        JOIN screens sc ON sh.screen_id = sc.id
        JOIN theatres t ON sc.theatre_id = t.id
        JOIN theater_owners to_owner ON to_owner.theatre_id = t.id
        WHERE NOT v_is_event AND sh.id = p_show_id
          AND to_owner.user_id = v_owner_id
          AND to_owner.role IN ('owner', 'manager')
        UNION ALL
        -- Event show authorization
        SELECT 1 FROM event_shows es
        JOIN screens sc ON es.screen_id = sc.id
        JOIN theatres t ON sc.theatre_id = t.id
        JOIN theater_owners to_owner ON to_owner.theatre_id = t.id
        WHERE v_is_event AND es.id = p_show_id
          AND to_owner.user_id = v_owner_id
          AND to_owner.role IN ('owner', 'manager')
    ) INTO v_is_authorized;

    IF NOT v_is_authorized THEN
        RAISE EXCEPTION 'Not authorized to manage this show';
    END IF;

    IF p_offline THEN
        -- *** LOCKED SEAT GUARD (from migration 048) ***
        -- Check for seats actively being purchased (locked within last 5 minutes)
        IF v_is_event THEN
            SELECT ARRAY_AGG(seat_id) INTO v_locked_seats
            FROM bookings
            WHERE event_show_id = p_show_id
              AND seat_id = ANY(p_seat_ids)
              AND status = 'locked'
              AND locked_at > NOW() - INTERVAL '5 minutes';
        ELSE
            SELECT ARRAY_AGG(seat_id) INTO v_locked_seats
            FROM bookings
            WHERE show_id = p_show_id
              AND seat_id = ANY(p_seat_ids)
              AND status = 'locked'
              AND locked_at > NOW() - INTERVAL '5 minutes';
        END IF;

        IF v_locked_seats IS NOT NULL AND array_length(v_locked_seats, 1) > 0 THEN
            RAISE EXCEPTION 'Cannot mark offline: % seat(s) are currently being booked by customers. Try again in 5 minutes.',
                array_length(v_locked_seats, 1);
        END IF;

        -- Safe to proceed — clean stale bookings and insert offline
        IF v_is_event THEN
            DELETE FROM bookings
            WHERE event_show_id = p_show_id
              AND seat_id = ANY(p_seat_ids)
              AND status IN ('offline', 'expired', 'cancelled');

            INSERT INTO bookings (event_show_id, seat_id, user_id, status, confirmed_at)
            SELECT p_show_id, s_id, COALESCE(v_owner_id, '00000000-0000-0000-0000-000000000000'::uuid), 'offline', NOW()
            FROM unnest(p_seat_ids) AS s_id;
        ELSE
            DELETE FROM bookings
            WHERE show_id = p_show_id
              AND seat_id = ANY(p_seat_ids)
              AND status IN ('offline', 'expired', 'cancelled');

            INSERT INTO bookings (show_id, seat_id, user_id, status, confirmed_at)
            SELECT p_show_id, s_id, COALESCE(v_owner_id, '00000000-0000-0000-0000-000000000000'::uuid), 'offline', NOW()
            FROM unnest(p_seat_ids) AS s_id;
        END IF;
    ELSE
        -- Take seats back online — only remove offline bookings
        IF v_is_event THEN
            DELETE FROM bookings
            WHERE event_show_id = p_show_id
              AND seat_id = ANY(p_seat_ids)
              AND status = 'offline';
        ELSE
            DELETE FROM bookings
            WHERE show_id = p_show_id
              AND seat_id = ANY(p_seat_ids)
              AND status = 'offline';
        END IF;
    END IF;
END;
$$;
