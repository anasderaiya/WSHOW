-- ============================================
-- Quick My Ticket Scalability Improvements
-- ============================================
-- This migration adds:
-- 1. Atomic seat locking function (prevents race conditions)
-- 2. Lock expiry mechanism (releases abandoned locks)
-- 3. Performance indexes
-- 4. Seat availability view (optimized queries)
-- 5. Server-side price calculation function

-- ============================================
-- 1. ATOMIC SEAT LOCKING FUNCTION
-- ============================================
-- This function uses row-level locking to prevent race conditions
-- when multiple users try to lock the same seat simultaneously.

CREATE OR REPLACE FUNCTION lock_seat(
    p_show_id UUID, 
    p_seat_id UUID, 
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    booking_id UUID, 
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER  -- Runs with function owner's permissions
AS $$
DECLARE
    v_booking_id UUID;
    v_existing RECORD;
    v_screen_id UUID;
    v_seat_exists BOOLEAN;
BEGIN
    -- Validate that the show exists and get screen_id
    SELECT screen_id INTO v_screen_id 
    FROM shows 
    WHERE id = p_show_id;
    
    IF v_screen_id IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Show not found'::TEXT;
        RETURN;
    END IF;
    
    -- Validate that the seat exists and belongs to the show's screen
    SELECT EXISTS(
        SELECT 1 FROM seats 
        WHERE id = p_seat_id AND screen_id = v_screen_id
    ) INTO v_seat_exists;
    
    IF NOT v_seat_exists THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat not found for this show'::TEXT;
        RETURN;
    END IF;
    
    -- Try to acquire a lock on existing booking (if any)
    -- SKIP LOCKED ensures we don't wait for other transactions
    SELECT * INTO v_existing
    FROM bookings 
    WHERE show_id = p_show_id 
      AND seat_id = p_seat_id 
      AND status IN ('locked', 'confirmed')
    FOR UPDATE SKIP LOCKED;
    
    -- Check if seat is already taken
    IF FOUND THEN
        -- Check if it's the same user's existing lock
        IF ((v_existing.user_id IS NOT NULL AND v_existing.user_id = p_user_id) OR
            (v_existing.user_id IS NULL AND v_existing.session_id = p_session_id)) AND v_existing.status = 'locked' THEN
            -- Refresh the lock timestamp
            UPDATE bookings 
            SET locked_at = NOW() 
            WHERE id = v_existing.id;
            
            RETURN QUERY SELECT v_existing.id, TRUE, 'Lock refreshed'::TEXT;
            RETURN;
        ELSE
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is already locked or booked'::TEXT;
            RETURN;
        END IF;
    END IF;
    
    -- Insert new booking with lock
    INSERT INTO bookings (show_id, seat_id, user_id, session_id, status, locked_at)
    VALUES (p_show_id, p_seat_id, p_user_id, p_session_id, 'locked', NOW())
    RETURNING id INTO v_booking_id;
    
    RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
    
EXCEPTION
    WHEN unique_violation THEN
        -- Race condition: another transaction inserted first
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat was just locked by another user'::TEXT;
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, ('Error: ' || SQLERRM)::TEXT;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION lock_seat(UUID, UUID, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION lock_seat(UUID, UUID, UUID, TEXT) TO anon;


-- ============================================
-- 2. LOCK EXPIRY FUNCTION
-- ============================================
-- This function releases locks that have been held for too long.
-- Should be called periodically via a cron job or Edge Function.

CREATE OR REPLACE FUNCTION release_expired_locks(
    p_lock_timeout_minutes INTEGER DEFAULT 5
)
RETURNS TABLE(
    released_count INTEGER,
    released_ids UUID[]
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_released_ids UUID[];
    v_count INTEGER;
BEGIN
    -- Update expired locks to 'expired' status
    WITH expired AS (
        UPDATE bookings 
        SET status = 'expired'
        WHERE status = 'locked' 
          AND locked_at < NOW() - (p_lock_timeout_minutes || ' minutes')::INTERVAL
        RETURNING id
    )
    SELECT array_agg(id), COUNT(*)::INTEGER 
    INTO v_released_ids, v_count
    FROM expired;
    
    RETURN QUERY SELECT COALESCE(v_count, 0), COALESCE(v_released_ids, ARRAY[]::UUID[]);
END;
$$;

-- Only allow service role to execute (for cron/edge function)
REVOKE ALL ON FUNCTION release_expired_locks(INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION release_expired_locks(INTEGER) TO service_role;


-- ============================================
-- 3. SERVER-SIDE PRICE CALCULATION
-- ============================================
-- Calculates the total price for a set of bookings.
-- Used by Edge Functions to verify payment amounts.

CREATE OR REPLACE FUNCTION calculate_booking_total(
    p_booking_ids UUID[],
    p_tax_rate DECIMAL DEFAULT 0.18
)
RETURNS TABLE(
    subtotal DECIMAL,
    tax DECIMAL,
    total DECIMAL,
    seat_count INTEGER
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_subtotal DECIMAL;
    v_seat_count INTEGER;
BEGIN
    -- Calculate subtotal from seats or show prices
    SELECT 
        COALESCE(SUM(COALESCE(s.price, sh.price, 0)), 0),
        COUNT(*)::INTEGER
    INTO v_subtotal, v_seat_count
    FROM bookings b
    JOIN seats s ON s.id = b.seat_id
    JOIN shows sh ON sh.id = b.show_id
    WHERE b.id = ANY(p_booking_ids)
      AND b.status = 'locked';  -- Only count locked bookings
    
    RETURN QUERY SELECT 
        v_subtotal,
        ROUND(v_subtotal * p_tax_rate, 2),
        ROUND(v_subtotal * (1 + p_tax_rate), 2),
        v_seat_count;
END;
$$;

GRANT EXECUTE ON FUNCTION calculate_booking_total(UUID[], DECIMAL) TO authenticated;
GRANT EXECUTE ON FUNCTION calculate_booking_total(UUID[], DECIMAL) TO service_role;


-- ============================================
-- 4. PERFORMANCE INDEXES
-- ============================================
-- These indexes optimize common queries in the application.

-- Index for finding bookings by show and status (seat availability)
CREATE INDEX IF NOT EXISTS idx_bookings_show_status 
ON bookings(show_id, status) 
WHERE status IN ('locked', 'confirmed');

-- Index for finding bookings by seat and show (locking check)
CREATE INDEX IF NOT EXISTS idx_bookings_seat_show 
ON bookings(seat_id, show_id);

-- Index for user's bookings
CREATE INDEX IF NOT EXISTS idx_bookings_user_status 
ON bookings(user_id, status);

-- Index for expired locks cleanup
CREATE INDEX IF NOT EXISTS idx_bookings_locked_at 
ON bookings(locked_at) 
WHERE status = 'locked';

-- Index for shows by movie (movie details page)
CREATE INDEX IF NOT EXISTS idx_shows_movie_date 
ON shows(movie_id, start_time);

-- Index for seats by screen (seat grid loading)
CREATE INDEX IF NOT EXISTS idx_seats_screen_position 
ON seats(screen_id, row, col);


-- ============================================
-- 5. SEAT AVAILABILITY VIEW
-- ============================================
-- This view provides an optimized way to fetch seat states.

CREATE OR REPLACE VIEW seat_availability AS
SELECT 
    s.id AS seat_id,
    s.screen_id,
    s.row,
    s.col,
    s.tier,
    s.price AS seat_price,
    sh.id AS show_id,
    sh.price AS show_price,
    COALESCE(s.price, sh.price, 0) AS effective_price,
    CASE 
        WHEN b.status = 'confirmed' THEN 'booked'
        WHEN b.status = 'locked' THEN 'locked'
        ELSE 'available'
    END AS availability_status,
    b.user_id AS locked_by,
    b.id AS booking_id,
    b.locked_at
FROM seats s
CROSS JOIN shows sh
LEFT JOIN LATERAL (
    SELECT * FROM bookings 
    WHERE seat_id = s.id 
      AND show_id = sh.id 
      AND status IN ('locked', 'confirmed')
    LIMIT 1
) b ON TRUE
WHERE s.screen_id = sh.screen_id;

-- Grant select on the view
GRANT SELECT ON seat_availability TO authenticated;
GRANT SELECT ON seat_availability TO anon;


-- ============================================
-- 6. UNLOCK SEAT FUNCTION
-- ============================================
-- Safely unlocks a seat (user can only unlock their own locks)

CREATE OR REPLACE FUNCTION unlock_seat(
    p_booking_id UUID,
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking RECORD;
BEGIN
    -- Get the booking
    SELECT * INTO v_booking
    FROM bookings
    WHERE id = p_booking_id
    FOR UPDATE;
    
    IF NOT FOUND THEN
        RETURN QUERY SELECT FALSE, 'Booking not found'::TEXT;
        RETURN;
    END IF;
    
    -- Verify ownership
    IF (v_booking.user_id IS NOT NULL AND v_booking.user_id != p_user_id) OR
       (v_booking.user_id IS NULL AND v_booking.session_id != p_session_id) THEN
        RETURN QUERY SELECT FALSE, 'Not authorized to unlock this booking'::TEXT;
        RETURN;
    END IF;
    
    -- Can only unlock 'locked' status
    IF v_booking.status != 'locked' THEN
        RETURN QUERY SELECT FALSE, ('Cannot unlock booking with status: ' || v_booking.status)::TEXT;
        RETURN;
    END IF;
    
    -- Update to cancelled
    UPDATE bookings 
    SET status = 'cancelled', locked_at = NULL
    WHERE id = p_booking_id;
    
    RETURN QUERY SELECT TRUE, 'Seat unlocked successfully'::TEXT;
END;
$$;

GRANT EXECUTE ON FUNCTION unlock_seat(UUID, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION unlock_seat(UUID, UUID, TEXT) TO anon;


-- ============================================
-- 7. CONFIRM BOOKING FUNCTION (for Edge Function)
-- ============================================
-- Confirms bookings after successful payment verification.
-- Only callable by service_role (Edge Functions).

CREATE OR REPLACE FUNCTION confirm_bookings(
    p_booking_ids UUID[],
    p_payment_id TEXT
)
RETURNS TABLE(
    confirmed_count INTEGER,
    total_amount DECIMAL
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_count INTEGER;
    v_total DECIMAL;
BEGIN
    -- Calculate total before confirming
    SELECT total INTO v_total
    FROM calculate_booking_total(p_booking_ids);
    
    -- Confirm all bookings
    WITH confirmed AS (
        UPDATE bookings 
        SET status = 'confirmed',
            payment_id = p_payment_id,
            confirmed_at = NOW()
        WHERE id = ANY(p_booking_ids)
          AND status = 'locked'
        RETURNING id
    )
    SELECT COUNT(*)::INTEGER INTO v_count FROM confirmed;
    
    RETURN QUERY SELECT v_count, COALESCE(v_total, 0);
END;
$$;

REVOKE ALL ON FUNCTION confirm_bookings(UUID[], TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION confirm_bookings(UUID[], TEXT) TO service_role;


-- ============================================
-- 8. OPTIONAL: Add status check constraint
-- ============================================
-- Ensure only valid statuses are used

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'bookings_status_check'
    ) THEN
        ALTER TABLE bookings 
        ADD CONSTRAINT bookings_status_check 
        CHECK (status IN ('locked', 'confirmed', 'cancelled', 'expired'));
    END IF;
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;


-- ============================================
-- 9. LOCK TIMEOUT SETTING (optional)
-- ============================================
-- Store the lock timeout in a settings table or as a constant

-- Create a simple settings table if needed
CREATE TABLE IF NOT EXISTS app_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    description TEXT,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Insert default lock timeout (5 minutes)
INSERT INTO app_settings (key, value, description)
VALUES ('lock_timeout_minutes', '5', 'How long a seat lock remains valid before expiring')
ON CONFLICT (key) DO NOTHING;

GRANT SELECT ON app_settings TO authenticated;
GRANT SELECT ON app_settings TO anon;
