-- Fix platform_settings admin RLS
-- Migration 037 used user-controlled JWT claim instead of app_metadata
-- This is the same vulnerability fixed in migration 026 for other tables

DROP POLICY IF EXISTS "Allow admin update access to platform_settings" ON public.platform_settings;

CREATE POLICY "Allow admin update access to platform_settings"
ON public.platform_settings FOR ALL
USING (
  (auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true
)
WITH CHECK (
  (auth.jwt() -> 'app_metadata' ->> 'is_admin')::boolean = true
);
