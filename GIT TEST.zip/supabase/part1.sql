-- ============================================
-- Quick My Ticket Baseline Schema
-- ============================================
-- Reconstructed from frontend queries to provide the foundational tables.
-- These tables were originally created manually via the Supabase UI.

-- 1. Theatres
CREATE TABLE IF NOT EXISTS theatres (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    location TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE theatres ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public theatres are viewable by everyone" ON theatres FOR SELECT USING (true);
CREATE POLICY "Admins can insert theatres" ON theatres FOR INSERT WITH CHECK (true);
CREATE POLICY "Admins can update theatres" ON theatres FOR UPDATE USING (true);
CREATE POLICY "Admins can delete theatres" ON theatres FOR DELETE USING (true);

-- 2. Screens
CREATE TABLE IF NOT EXISTS screens (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    theatre_id UUID REFERENCES theatres(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    seat_layout JSONB,
    total_seats INTEGER,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE screens ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public screens are viewable by everyone" ON screens FOR SELECT USING (true);
CREATE POLICY "Admins can insert screens" ON screens FOR INSERT WITH CHECK (true);
CREATE POLICY "Admins can update screens" ON screens FOR UPDATE USING (true);
CREATE POLICY "Admins can delete screens" ON screens FOR DELETE USING (true);

-- 3. Movies
CREATE TABLE IF NOT EXISTS movies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    description TEXT,
    poster_url TEXT,
    duration_minutes INTEGER,
    genre TEXT,
    rating TEXT,
    release_date DATE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE movies ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public movies are viewable by everyone" ON movies FOR SELECT USING (true);
CREATE POLICY "Admins can insert movies" ON movies FOR INSERT WITH CHECK (true);
CREATE POLICY "Admins can update movies" ON movies FOR UPDATE USING (true);
CREATE POLICY "Admins can delete movies" ON movies FOR DELETE USING (true);

-- 4. Shows
CREATE TABLE IF NOT EXISTS shows (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    movie_id UUID REFERENCES movies(id) ON DELETE CASCADE,
    screen_id UUID REFERENCES screens(id) ON DELETE CASCADE,
    start_time TIMESTAMPTZ NOT NULL,
    price DECIMAL DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE shows ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public shows are viewable by everyone" ON shows FOR SELECT USING (true);
CREATE POLICY "Admins can insert shows" ON shows FOR INSERT WITH CHECK (true);
CREATE POLICY "Admins can update shows" ON shows FOR UPDATE USING (true);
CREATE POLICY "Admins can delete shows" ON shows FOR DELETE USING (true);

-- 5. Seats
CREATE TABLE IF NOT EXISTS seats (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    screen_id UUID REFERENCES screens(id) ON DELETE CASCADE,
    row TEXT NOT NULL,
    col INTEGER NOT NULL,
    tier TEXT,
    price DECIMAL DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE seats ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public seats are viewable by everyone" ON seats FOR SELECT USING (true);
CREATE POLICY "Admins can insert seats" ON seats FOR INSERT WITH CHECK (true);
CREATE POLICY "Admins can update seats" ON seats FOR UPDATE USING (true);
CREATE POLICY "Admins can delete seats" ON seats FOR DELETE USING (true);

-- 6. Bookings
CREATE TABLE IF NOT EXISTS bookings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    show_id UUID REFERENCES shows(id) ON DELETE CASCADE,
    seat_id UUID REFERENCES seats(id) ON DELETE CASCADE,
    user_id UUID, -- References auth.users(id) inherently 
    session_id TEXT,
    status TEXT DEFAULT 'locked' CHECK (status IN ('locked', 'confirmed', 'cancelled', 'expired')),
    locked_at TIMESTAMPTZ,
    confirmed_at TIMESTAMPTZ,
    payment_id TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own bookings" ON bookings FOR SELECT USING (true); -- Relaxed for baseline, restricted in functions
CREATE POLICY "Users can insert bookings" ON bookings FOR INSERT WITH CHECK (true);
CREATE POLICY "Users can update own bookings" ON bookings FOR UPDATE USING (true);
CREATE POLICY "Users can delete own bookings" ON bookings FOR DELETE USING (true);


-- ============================================
-- Quick My Ticket Scalability Improvements
-- ============================================
-- This migration adds:
-- 1. Atomic seat locking function (prevents race conditions)
-- 2. Lock expiry mechanism (releases abandoned locks)
-- 3. Performance indexes
-- 4. Seat availability view (optimized queries)
-- 5. Server-side price calculation function

-- ============================================
-- 1. ATOMIC SEAT LOCKING FUNCTION
-- ============================================
-- This function uses row-level locking to prevent race conditions
-- when multiple users try to lock the same seat simultaneously.

CREATE OR REPLACE FUNCTION lock_seat(
    p_show_id UUID, 
    p_seat_id UUID, 
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    booking_id UUID, 
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER  -- Runs with function owner's permissions
AS $$
DECLARE
    v_booking_id UUID;
    v_existing RECORD;
    v_screen_id UUID;
    v_seat_exists BOOLEAN;
BEGIN
    -- Validate that the show exists and get screen_id
    SELECT screen_id INTO v_screen_id 
    FROM shows 
    WHERE id = p_show_id;
    
    IF v_screen_id IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Show not found'::TEXT;
        RETURN;
    END IF;
    
    -- Validate that the seat exists and belongs to the show's screen
    SELECT EXISTS(
        SELECT 1 FROM seats 
        WHERE id = p_seat_id AND screen_id = v_screen_id
    ) INTO v_seat_exists;
    
    IF NOT v_seat_exists THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat not found for this show'::TEXT;
        RETURN;
    END IF;
    
    -- Try to acquire a lock on existing booking (if any)
    -- SKIP LOCKED ensures we don't wait for other transactions
    SELECT * INTO v_existing
    FROM bookings 
    WHERE show_id = p_show_id 
      AND seat_id = p_seat_id 
      AND status IN ('locked', 'confirmed')
    FOR UPDATE SKIP LOCKED;
    
    -- Check if seat is already taken
    IF FOUND THEN
        -- Check if it's the same user's existing lock
        IF ((v_existing.user_id IS NOT NULL AND v_existing.user_id = p_user_id) OR
            (v_existing.user_id IS NULL AND v_existing.session_id = p_session_id)) AND v_existing.status = 'locked' THEN
            -- Refresh the lock timestamp
            UPDATE bookings 
            SET locked_at = NOW() 
            WHERE id = v_existing.id;
            
            RETURN QUERY SELECT v_existing.id, TRUE, 'Lock refreshed'::TEXT;
            RETURN;
        ELSE
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is already locked or booked'::TEXT;
            RETURN;
        END IF;
    END IF;
    
    -- Insert new booking with lock
    INSERT INTO bookings (show_id, seat_id, user_id, session_id, status, locked_at)
    VALUES (p_show_id, p_seat_id, p_user_id, p_session_id, 'locked', NOW())
    RETURNING id INTO v_booking_id;
    
    RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
    
EXCEPTION
    WHEN unique_violation THEN
        -- Race condition: another transaction inserted first
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat was just locked by another user'::TEXT;
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, ('Error: ' || SQLERRM)::TEXT;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION lock_seat(UUID, UUID, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION lock_seat(UUID, UUID, UUID, TEXT) TO anon;


-- ============================================
-- 2. LOCK EXPIRY FUNCTION
-- ============================================
-- This function releases locks that have been held for too long.
-- Should be called periodically via a cron job or Edge Function.

CREATE OR REPLACE FUNCTION release_expired_locks(
    p_lock_timeout_minutes INTEGER DEFAULT 5
)
RETURNS TABLE(
    released_count INTEGER,
    released_ids UUID[]
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_released_ids UUID[];
    v_count INTEGER;
BEGIN
    -- Update expired locks to 'expired' status
    WITH expired AS (
        UPDATE bookings 
        SET status = 'expired'
        WHERE status = 'locked' 
          AND locked_at < NOW() - (p_lock_timeout_minutes || ' minutes')::INTERVAL
        RETURNING id
    )
    SELECT array_agg(id), COUNT(*)::INTEGER 
    INTO v_released_ids, v_count
    FROM expired;
    
    RETURN QUERY SELECT COALESCE(v_count, 0), COALESCE(v_released_ids, ARRAY[]::UUID[]);
END;
$$;

-- Only allow service role to execute (for cron/edge function)
REVOKE ALL ON FUNCTION release_expired_locks(INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION release_expired_locks(INTEGER) TO service_role;


-- ============================================
-- 3. SERVER-SIDE PRICE CALCULATION
-- ============================================
-- Calculates the total price for a set of bookings.
-- Used by Edge Functions to verify payment amounts.

CREATE OR REPLACE FUNCTION calculate_booking_total(
    p_booking_ids UUID[],
    p_tax_rate DECIMAL DEFAULT 0.18
)
RETURNS TABLE(
    subtotal DECIMAL,
    tax DECIMAL,
    total DECIMAL,
    seat_count INTEGER
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_subtotal DECIMAL;
    v_seat_count INTEGER;
BEGIN
    -- Calculate subtotal from seats or show prices
    SELECT 
        COALESCE(SUM(COALESCE(s.price, sh.price, 0)), 0),
        COUNT(*)::INTEGER
    INTO v_subtotal, v_seat_count
    FROM bookings b
    JOIN seats s ON s.id = b.seat_id
    JOIN shows sh ON sh.id = b.show_id
    WHERE b.id = ANY(p_booking_ids)
      AND b.status = 'locked';  -- Only count locked bookings
    
    RETURN QUERY SELECT 
        v_subtotal,
        ROUND(v_subtotal * p_tax_rate, 2),
        ROUND(v_subtotal * (1 + p_tax_rate), 2),
        v_seat_count;
END;
$$;

GRANT EXECUTE ON FUNCTION calculate_booking_total(UUID[], DECIMAL) TO authenticated;
GRANT EXECUTE ON FUNCTION calculate_booking_total(UUID[], DECIMAL) TO service_role;


-- ============================================
-- 4. PERFORMANCE INDEXES
-- ============================================
-- These indexes optimize common queries in the application.

-- Index for finding bookings by show and status (seat availability)
CREATE INDEX IF NOT EXISTS idx_bookings_show_status 
ON bookings(show_id, status) 
WHERE status IN ('locked', 'confirmed');

-- Index for finding bookings by seat and show (locking check)
CREATE INDEX IF NOT EXISTS idx_bookings_seat_show 
ON bookings(seat_id, show_id);

-- Index for user's bookings
CREATE INDEX IF NOT EXISTS idx_bookings_user_status 
ON bookings(user_id, status);

-- Index for expired locks cleanup
CREATE INDEX IF NOT EXISTS idx_bookings_locked_at 
ON bookings(locked_at) 
WHERE status = 'locked';

-- Index for shows by movie (movie details page)
CREATE INDEX IF NOT EXISTS idx_shows_movie_date 
ON shows(movie_id, start_time);

-- Index for seats by screen (seat grid loading)
CREATE INDEX IF NOT EXISTS idx_seats_screen_position 
ON seats(screen_id, row, col);


-- ============================================
-- 5. SEAT AVAILABILITY VIEW
-- ============================================
-- This view provides an optimized way to fetch seat states.

CREATE OR REPLACE VIEW seat_availability AS
SELECT 
    s.id AS seat_id,
    s.screen_id,
    s.row,
    s.col,
    s.tier,
    s.price AS seat_price,
    sh.id AS show_id,
    sh.price AS show_price,
    COALESCE(s.price, sh.price, 0) AS effective_price,
    CASE 
        WHEN b.status = 'confirmed' THEN 'booked'
        WHEN b.status = 'locked' THEN 'locked'
        ELSE 'available'
    END AS availability_status,
    b.user_id AS locked_by,
    b.id AS booking_id,
    b.locked_at
FROM seats s
CROSS JOIN shows sh
LEFT JOIN LATERAL (
    SELECT * FROM bookings 
    WHERE seat_id = s.id 
      AND show_id = sh.id 
      AND status IN ('locked', 'confirmed')
    LIMIT 1
) b ON TRUE
WHERE s.screen_id = sh.screen_id;

-- Grant select on the view
GRANT SELECT ON seat_availability TO authenticated;
GRANT SELECT ON seat_availability TO anon;


-- ============================================
-- 6. UNLOCK SEAT FUNCTION
-- ============================================
-- Safely unlocks a seat (user can only unlock their own locks)

CREATE OR REPLACE FUNCTION unlock_seat(
    p_booking_id UUID,
    p_user_id UUID DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking RECORD;
BEGIN
    -- Get the booking
    SELECT * INTO v_booking
    FROM bookings
    WHERE id = p_booking_id
    FOR UPDATE;
    
    IF NOT FOUND THEN
        RETURN QUERY SELECT FALSE, 'Booking not found'::TEXT;
        RETURN;
    END IF;
    
    -- Verify ownership
    IF (v_booking.user_id IS NOT NULL AND v_booking.user_id != p_user_id) OR
       (v_booking.user_id IS NULL AND v_booking.session_id != p_session_id) THEN
        RETURN QUERY SELECT FALSE, 'Not authorized to unlock this booking'::TEXT;
        RETURN;
    END IF;
    
    -- Can only unlock 'locked' status
    IF v_booking.status != 'locked' THEN
        RETURN QUERY SELECT FALSE, ('Cannot unlock booking with status: ' || v_booking.status)::TEXT;
        RETURN;
    END IF;
    
    -- Update to cancelled
    UPDATE bookings 
    SET status = 'cancelled', locked_at = NULL
    WHERE id = p_booking_id;
    
    RETURN QUERY SELECT TRUE, 'Seat unlocked successfully'::TEXT;
END;
$$;

GRANT EXECUTE ON FUNCTION unlock_seat(UUID, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION unlock_seat(UUID, UUID, TEXT) TO anon;


-- ============================================
-- 7. CONFIRM BOOKING FUNCTION (for Edge Function)
-- ============================================
-- Confirms bookings after successful payment verification.
-- Only callable by service_role (Edge Functions).

CREATE OR REPLACE FUNCTION confirm_bookings(
    p_booking_ids UUID[],
    p_payment_id TEXT
)
RETURNS TABLE(
    confirmed_count INTEGER,
    total_amount DECIMAL
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_count INTEGER;
    v_total DECIMAL;
BEGIN
    -- Calculate total before confirming
    SELECT total INTO v_total
    FROM calculate_booking_total(p_booking_ids);
    
    -- Confirm all bookings
    WITH confirmed AS (
        UPDATE bookings 
        SET status = 'confirmed',
            payment_id = p_payment_id,
            confirmed_at = NOW()
        WHERE id = ANY(p_booking_ids)
          AND status = 'locked'
        RETURNING id
    )
    SELECT COUNT(*)::INTEGER INTO v_count FROM confirmed;
    
    RETURN QUERY SELECT v_count, COALESCE(v_total, 0);
END;
$$;

REVOKE ALL ON FUNCTION confirm_bookings(UUID[], TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION confirm_bookings(UUID[], TEXT) TO service_role;


-- ============================================
-- 8. OPTIONAL: Add status check constraint
-- ============================================
-- Ensure only valid statuses are used

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'bookings_status_check'
    ) THEN
        ALTER TABLE bookings 
        ADD CONSTRAINT bookings_status_check 
        CHECK (status IN ('locked', 'confirmed', 'cancelled', 'expired'));
    END IF;
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;


-- ============================================
-- 9. LOCK TIMEOUT SETTING (optional)
-- ============================================
-- Store the lock timeout in a settings table or as a constant

-- Create a simple settings table if needed
CREATE TABLE IF NOT EXISTS app_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    description TEXT,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Insert default lock timeout (5 minutes)
INSERT INTO app_settings (key, value, description)
VALUES ('lock_timeout_minutes', '5', 'How long a seat lock remains valid before expiring')
ON CONFLICT (key) DO NOTHING;

GRANT SELECT ON app_settings TO authenticated;
GRANT SELECT ON app_settings TO anon;


-- ============================================
-- Quick My Ticket Theater Owner System
-- ============================================
-- This migration adds:
-- 1. Theater owners table (links users to theatres)
-- 2. Updated RLS policies for multi-tenant access
-- 3. Owner-specific views and functions
-- 4. Dashboard statistics functions

-- ============================================
-- 1. THEATER OWNERS TABLE
-- ============================================
-- Links users to theatres they own/manage

CREATE TABLE IF NOT EXISTS theater_owners (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    theatre_id UUID NOT NULL REFERENCES theatres(id) ON DELETE CASCADE,
    role TEXT DEFAULT 'owner' CHECK (role IN ('owner', 'manager', 'staff')),
    permissions JSONB DEFAULT '{"can_edit_shows": true, "can_view_revenue": true, "can_manage_staff": false}'::JSONB,
    invited_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, theatre_id)
);

-- Create index for quick lookups
CREATE INDEX IF NOT EXISTS idx_theater_owners_user ON theater_owners(user_id);
CREATE INDEX IF NOT EXISTS idx_theater_owners_theatre ON theater_owners(theatre_id);

-- Enable RLS
ALTER TABLE theater_owners ENABLE ROW LEVEL SECURITY;

-- ============================================
-- 2. RLS POLICIES FOR THEATER OWNERS TABLE
-- ============================================

-- Super admins can manage all theater owners
CREATE POLICY "Admin full access theater_owners" ON theater_owners 
FOR ALL USING (
    (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);

-- Theater owners can read their own assignments
CREATE POLICY "Owners read own assignments" ON theater_owners 
FOR SELECT USING (
    auth.uid() = user_id
);

-- Theater owners with 'owner' role can invite managers/staff to their theatres
CREATE POLICY "Owners can add staff" ON theater_owners 
FOR INSERT WITH CHECK (
    EXISTS (
        SELECT 1 FROM theater_owners existing
        WHERE existing.theatre_id = theater_owners.theatre_id
        AND existing.user_id = auth.uid()
        AND existing.role = 'owner'
    )
    AND theater_owners.role IN ('manager', 'staff')
);


-- ============================================
-- 3. UPDATE THEATRES RLS FOR OWNER ACCESS
-- ============================================

-- Drop existing admin-only policy if exists (safely)
DO $$
BEGIN
    DROP POLICY IF EXISTS "Admin write" ON theatres;
    DROP POLICY IF EXISTS "Admin full access" ON theatres;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- Allow theater owners to manage their theatres
CREATE POLICY "Owner manage theatres" ON theatres 
FOR UPDATE USING (
    EXISTS (
        SELECT 1 FROM theater_owners 
        WHERE theatre_id = theatres.id 
        AND user_id = auth.uid()
        AND role IN ('owner', 'manager')
    )
);

-- Admins can do everything on theatres
CREATE POLICY "Admin manage theatres" ON theatres 
FOR ALL USING (
    (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);


-- ============================================
-- 4. UPDATE SCREENS RLS FOR OWNER ACCESS
-- ============================================

DO $$
BEGIN
    DROP POLICY IF EXISTS "Admin write" ON screens;
    DROP POLICY IF EXISTS "Admin full access" ON screens;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- Allow theater owners to manage screens in their theatres
CREATE POLICY "Owner manage screens" ON screens 
FOR ALL USING (
    EXISTS (
        SELECT 1 FROM theater_owners 
        WHERE theatre_id = screens.theatre_id 
        AND user_id = auth.uid()
        AND role IN ('owner', 'manager')
    )
);

-- Admins can do everything on screens
CREATE POLICY "Admin manage screens" ON screens 
FOR ALL USING (
    (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);


-- ============================================
-- 5. UPDATE SHOWS RLS FOR OWNER ACCESS
-- ============================================

DO $$
BEGIN
    DROP POLICY IF EXISTS "Admin write" ON shows;
    DROP POLICY IF EXISTS "Admin full access" ON shows;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- Allow theater owners to manage shows on their screens
CREATE POLICY "Owner manage shows" ON shows 
FOR ALL USING (
    EXISTS (
        SELECT 1 FROM theater_owners to_owner
        JOIN screens s ON s.theatre_id = to_owner.theatre_id
        WHERE s.id = shows.screen_id
        AND to_owner.user_id = auth.uid()
        AND to_owner.role IN ('owner', 'manager')
    )
);

-- Admins can do everything on shows
CREATE POLICY "Admin manage shows" ON shows 
FOR ALL USING (
    (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
);


-- ============================================
-- 6. OWNER DASHBOARD FUNCTIONS
-- ============================================

-- Function to get theatres owned by a user
CREATE OR REPLACE FUNCTION get_owned_theatres(p_user_id UUID)
RETURNS TABLE(
    theatre_id UUID,
    theatre_name TEXT,
    location TEXT,
    role TEXT,
    screen_count BIGINT,
    total_seats BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        t.id AS theatre_id,
        t.name AS theatre_name,
        t.location,
        to_owner.role,
        COUNT(DISTINCT s.id) AS screen_count,
        COUNT(DISTINCT seats.id) AS total_seats
    FROM theater_owners to_owner
    JOIN theatres t ON t.id = to_owner.theatre_id
    LEFT JOIN screens s ON s.theatre_id = t.id
    LEFT JOIN seats ON seats.screen_id = s.id
    WHERE to_owner.user_id = p_user_id
    GROUP BY t.id, t.name, t.location, to_owner.role
    ORDER BY t.name;
END;
$$;

GRANT EXECUTE ON FUNCTION get_owned_theatres(UUID) TO authenticated;


-- Function to get dashboard statistics for a theater owner
CREATE OR REPLACE FUNCTION get_owner_dashboard_stats(p_user_id UUID)
RETURNS TABLE(
    total_theatres BIGINT,
    total_screens BIGINT,
    total_seats BIGINT,
    today_bookings BIGINT,
    today_revenue DECIMAL,
    currently_locked BIGINT,
    today_confirmed BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_theatre_ids UUID[];
    v_today DATE := CURRENT_DATE;
BEGIN
    -- Get all theatre IDs owned by this user
    SELECT ARRAY_AGG(theatre_id) INTO v_theatre_ids
    FROM theater_owners
    WHERE user_id = p_user_id;
    
    -- If user owns no theatres, return zeros
    IF v_theatre_ids IS NULL THEN
        RETURN QUERY SELECT 0::BIGINT, 0::BIGINT, 0::BIGINT, 0::BIGINT, 0::DECIMAL, 0::BIGINT, 0::BIGINT;
        RETURN;
    END IF;
    
    RETURN QUERY
    WITH owned_screens AS (
        SELECT s.id AS screen_id
        FROM screens s
        WHERE s.theatre_id = ANY(v_theatre_ids)
    ),
    owned_shows AS (
        SELECT sh.id AS show_id, sh.price
        FROM shows sh
        JOIN owned_screens os ON os.screen_id = sh.screen_id
    ),
    owned_bookings AS (
        SELECT b.*
        FROM bookings b
        JOIN owned_shows osh ON osh.show_id = b.show_id
    )
    SELECT
        (SELECT COUNT(*) FROM unnest(v_theatre_ids))::BIGINT AS total_theatres,
        (SELECT COUNT(*) FROM owned_screens)::BIGINT AS total_screens,
        (SELECT COUNT(*) FROM seats WHERE screen_id IN (SELECT screen_id FROM owned_screens))::BIGINT AS total_seats,
        (SELECT COUNT(*) FROM owned_bookings WHERE DATE(created_at) = v_today)::BIGINT AS today_bookings,
        COALESCE((
            SELECT SUM(COALESCE(seats.price, osh.price, 0))
            FROM owned_bookings ob
            JOIN owned_shows osh ON osh.show_id = ob.show_id
            JOIN seats ON seats.id = ob.seat_id
            WHERE ob.status = 'confirmed' AND DATE(ob.confirmed_at) = v_today
        ), 0)::DECIMAL AS today_revenue,
        (SELECT COUNT(*) FROM owned_bookings WHERE status = 'locked')::BIGINT AS currently_locked,
        (SELECT COUNT(*) FROM owned_bookings WHERE status = 'confirmed' AND DATE(confirmed_at) = v_today)::BIGINT AS today_confirmed;
END;
$$;

GRANT EXECUTE ON FUNCTION get_owner_dashboard_stats(UUID) TO authenticated;


-- Function to get shows for a theatre with booking counts
CREATE OR REPLACE FUNCTION get_owner_shows(
    p_user_id UUID,
    p_theatre_id UUID DEFAULT NULL,
    p_date DATE DEFAULT CURRENT_DATE
)
RETURNS TABLE(
    show_id UUID,
    movie_title TEXT,
    screen_name TEXT,
    theatre_name TEXT,
    start_time TIMESTAMPTZ,
    end_time TIMESTAMPTZ,
    base_price DECIMAL,
    total_seats BIGINT,
    booked_seats BIGINT,
    locked_seats BIGINT,
    available_seats BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        sh.id AS show_id,
        m.title AS movie_title,
        sc.name AS screen_name,
        t.name AS theatre_name,
        sh.start_time,
        sh.end_time,
        sh.price AS base_price,
        COUNT(DISTINCT seats.id) AS total_seats,
        COUNT(DISTINCT CASE WHEN b.status = 'confirmed' THEN b.id END) AS booked_seats,
        COUNT(DISTINCT CASE WHEN b.status = 'locked' THEN b.id END) AS locked_seats,
        COUNT(DISTINCT seats.id) - COUNT(DISTINCT CASE WHEN b.status IN ('confirmed', 'locked') THEN b.id END) AS available_seats
    FROM shows sh
    JOIN movies m ON m.id = sh.movie_id
    JOIN screens sc ON sc.id = sh.screen_id
    JOIN theatres t ON t.id = sc.theatre_id
    JOIN theater_owners to_owner ON to_owner.theatre_id = t.id
    LEFT JOIN seats ON seats.screen_id = sc.id
    LEFT JOIN bookings b ON b.show_id = sh.id AND b.seat_id = seats.id AND b.status IN ('confirmed', 'locked')
    WHERE to_owner.user_id = p_user_id
      AND (p_theatre_id IS NULL OR t.id = p_theatre_id)
      AND DATE(sh.start_time) = p_date
    GROUP BY sh.id, m.title, sc.name, t.name, sh.start_time, sh.end_time, sh.price
    ORDER BY sh.start_time;
END;
$$;

GRANT EXECUTE ON FUNCTION get_owner_shows(UUID, UUID, DATE) TO authenticated;


-- Function to check if user is a theater owner
CREATE OR REPLACE FUNCTION is_theater_owner(p_user_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM theater_owners WHERE user_id = p_user_id
    );
END;
$$;

GRANT EXECUTE ON FUNCTION is_theater_owner(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION is_theater_owner(UUID) TO anon;


-- ============================================
-- 7. ADD OWNER FLAG TO USER METADATA CHECK
-- ============================================

-- View to easily check user roles
CREATE OR REPLACE VIEW user_roles AS
SELECT 
    au.id AS user_id,
    au.email,
    COALESCE((au.raw_user_meta_data ->> 'is_admin')::boolean, false) AS is_admin,
    EXISTS (SELECT 1 FROM theater_owners WHERE user_id = au.id) AS is_theater_owner,
    (SELECT ARRAY_AGG(theatre_id) FROM theater_owners WHERE user_id = au.id) AS owned_theatre_ids
FROM auth.users au;

-- Note: This view uses auth.users which requires careful RLS handling
-- For security, we provide a function instead

CREATE OR REPLACE FUNCTION get_user_role(p_user_id UUID)
RETURNS TABLE(
    is_admin BOOLEAN,
    is_theater_owner BOOLEAN,
    owned_theatre_count BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        COALESCE((au.raw_user_meta_data ->> 'is_admin')::boolean, false) AS is_admin,
        EXISTS (SELECT 1 FROM theater_owners WHERE user_id = p_user_id) AS is_theater_owner,
        (SELECT COUNT(*) FROM theater_owners WHERE user_id = p_user_id) AS owned_theatre_count
    FROM auth.users au
    WHERE au.id = p_user_id;
END;
$$;

GRANT EXECUTE ON FUNCTION get_user_role(UUID) TO authenticated;


-- ============================================
-- 8. TRIGGER TO UPDATE updated_at
-- ============================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS update_theater_owners_updated_at ON theater_owners;
CREATE TRIGGER update_theater_owners_updated_at
    BEFORE UPDATE ON theater_owners
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();


-- ============================================
-- 9. GRANT SELECT ON theater_owners FOR OWNERSHIP CHECK
-- ============================================

GRANT SELECT ON theater_owners TO authenticated;


-- ============================================
-- 10. SAMPLE DATA (Optional - for testing)
-- ============================================
-- Uncomment to add sample theater owner assignments
-- This assumes you have existing theatres and users

/*
-- Example: Assign a user as theater owner
INSERT INTO theater_owners (user_id, theatre_id, role)
SELECT 
    'USER_UUID_HERE',
    id,
    'owner'
FROM theatres
WHERE name = 'Your Theatre Name'
ON CONFLICT DO NOTHING;
*/

-- ============================================
-- MIGRATION COMPLETE
-- ============================================
-- Next steps:
-- 1. Run this migration in Supabase SQL Editor
-- 2. Assign theater owners via admin panel or direct SQL
-- 3. Theater owners can now access owner-dashboard.html


-- ============================================
-- Quick My Ticket - Owner Registration & Approval System
-- Migration 003
-- ============================================

-- Table for pending owner applications
CREATE TABLE IF NOT EXISTS owner_applications (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    full_name TEXT NOT NULL,
    phone TEXT,
    theatre_name TEXT NOT NULL,
    theatre_location TEXT NOT NULL,
    business_license TEXT, -- Optional license number
    message TEXT, -- Why they want to partner
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
    admin_notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    reviewed_at TIMESTAMP WITH TIME ZONE,
    reviewed_by UUID REFERENCES auth.users(id)
);

-- Enable RLS
ALTER TABLE owner_applications ENABLE ROW LEVEL SECURITY;

-- Users can view their own applications
CREATE POLICY "Users can view own applications" ON owner_applications
    FOR SELECT USING (auth.uid() = user_id);

-- Users can insert their own application
CREATE POLICY "Users can create applications" ON owner_applications
    FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Admins can view all applications
CREATE POLICY "Admins can view all applications" ON owner_applications
    FOR SELECT USING (
        (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
    );

-- Admins can update applications (approve/reject)
CREATE POLICY "Admins can update applications" ON owner_applications
    FOR UPDATE USING (
        (auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true
    );

-- ============================================
-- Functions for Owner Application System
-- ============================================

-- Submit owner application
CREATE OR REPLACE FUNCTION submit_owner_application(
    p_full_name TEXT,
    p_phone TEXT,
    p_theatre_name TEXT,
    p_theatre_location TEXT,
    p_business_license TEXT DEFAULT NULL,
    p_message TEXT DEFAULT NULL
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_email TEXT;
    v_existing_app UUID;
    v_result JSON;
BEGIN
    -- Get user email
    SELECT email INTO v_email FROM auth.users WHERE id = v_user_id;
    
    IF v_email IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'User not authenticated');
    END IF;
    
    -- Check if user already has a pending or approved application
    SELECT id INTO v_existing_app 
    FROM owner_applications 
    WHERE user_id = v_user_id AND status IN ('pending', 'approved')
    LIMIT 1;
    
    IF v_existing_app IS NOT NULL THEN
        RETURN json_build_object('success', false, 'error', 'You already have a pending or approved application');
    END IF;
    
    -- Check if user is already an owner
    IF EXISTS (SELECT 1 FROM theater_owners WHERE user_id = v_user_id) THEN
        RETURN json_build_object('success', false, 'error', 'You are already a registered theater owner');
    END IF;
    
    -- Insert application
    INSERT INTO owner_applications (
        user_id, email, full_name, phone, 
        theatre_name, theatre_location, business_license, message
    ) VALUES (
        v_user_id, v_email, p_full_name, p_phone,
        p_theatre_name, p_theatre_location, p_business_license, p_message
    );
    
    RETURN json_build_object('success', true, 'message', 'Application submitted successfully');
END;
$$;

GRANT EXECUTE ON FUNCTION submit_owner_application(TEXT, TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated;

-- Get pending applications (for admin)
CREATE OR REPLACE FUNCTION get_pending_applications()
RETURNS TABLE(
    id UUID,
    user_id UUID,
    email TEXT,
    full_name TEXT,
    phone TEXT,
    theatre_name TEXT,
    theatre_location TEXT,
    business_license TEXT,
    message TEXT,
    status TEXT,
    created_at TIMESTAMP WITH TIME ZONE
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Check if caller is admin
    IF NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RAISE EXCEPTION 'Access denied: Admin only';
    END IF;
    
    RETURN QUERY
    SELECT 
        oa.id, oa.user_id, oa.email, oa.full_name, oa.phone,
        oa.theatre_name, oa.theatre_location, oa.business_license,
        oa.message, oa.status, oa.created_at
    FROM owner_applications oa
    WHERE oa.status = 'pending'
    ORDER BY oa.created_at DESC;
END;
$$;

GRANT EXECUTE ON FUNCTION get_pending_applications() TO authenticated;

-- Approve owner application (admin only)
CREATE OR REPLACE FUNCTION approve_owner_application(
    p_application_id UUID,
    p_admin_notes TEXT DEFAULT NULL
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_admin_id UUID := auth.uid();
    v_app RECORD;
    v_theatre_id UUID;
BEGIN
    -- Check if caller is admin
    IF NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RETURN json_build_object('success', false, 'error', 'Access denied: Admin only');
    END IF;
    
    -- Get application
    SELECT * INTO v_app FROM owner_applications WHERE id = p_application_id;
    
    IF v_app IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Application not found');
    END IF;
    
    IF v_app.status != 'pending' THEN
        RETURN json_build_object('success', false, 'error', 'Application already processed');
    END IF;
    
    -- Create the theatre
    INSERT INTO theatres (name, location)
    VALUES (v_app.theatre_name, v_app.theatre_location)
    RETURNING id INTO v_theatre_id;
    
    -- Add user as theater owner
    INSERT INTO theater_owners (user_id, theatre_id, role)
    VALUES (v_app.user_id, v_theatre_id, 'owner');
    
    -- Update application status
    UPDATE owner_applications
    SET status = 'approved',
        reviewed_at = NOW(),
        reviewed_by = v_admin_id,
        admin_notes = p_admin_notes
    WHERE id = p_application_id;
    
    RETURN json_build_object(
        'success', true, 
        'message', 'Application approved',
        'theatre_id', v_theatre_id
    );
END;
$$;

GRANT EXECUTE ON FUNCTION approve_owner_application(UUID, TEXT) TO authenticated;

-- Reject owner application (admin only)
CREATE OR REPLACE FUNCTION reject_owner_application(
    p_application_id UUID,
    p_admin_notes TEXT DEFAULT NULL
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_admin_id UUID := auth.uid();
BEGIN
    -- Check if caller is admin
    IF NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RETURN json_build_object('success', false, 'error', 'Access denied: Admin only');
    END IF;
    
    -- Check if application exists and is pending
    IF NOT EXISTS (SELECT 1 FROM owner_applications WHERE id = p_application_id AND status = 'pending') THEN
        RETURN json_build_object('success', false, 'error', 'Application not found or already processed');
    END IF;
    
    -- Update application status
    UPDATE owner_applications
    SET status = 'rejected',
        reviewed_at = NOW(),
        reviewed_by = v_admin_id,
        admin_notes = p_admin_notes
    WHERE id = p_application_id;
    
    RETURN json_build_object('success', true, 'message', 'Application rejected');
END;
$$;

GRANT EXECUTE ON FUNCTION reject_owner_application(UUID, TEXT) TO authenticated;

-- Check application status (for users)
CREATE OR REPLACE FUNCTION get_my_application_status()
RETURNS TABLE(
    id UUID,
    status TEXT,
    created_at TIMESTAMP WITH TIME ZONE,
    reviewed_at TIMESTAMP WITH TIME ZONE,
    admin_notes TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        oa.id, oa.status, oa.created_at, oa.reviewed_at, oa.admin_notes
    FROM owner_applications oa
    WHERE oa.user_id = auth.uid()
    ORDER BY oa.created_at DESC
    LIMIT 1;
END;
$$;

GRANT EXECUTE ON FUNCTION get_my_application_status() TO authenticated;


-- ============================================
-- Quick My Ticket - Custom Seat Layout System
-- Migration 004
-- ============================================

-- Add seat_layout column to screens table
-- This stores the custom layout as JSON
ALTER TABLE screens ADD COLUMN IF NOT EXISTS seat_layout JSONB;

-- The seat_layout JSON structure:
-- {
--   "rows": [
--     {
--       "label": "A",           -- Row label
--       "seats": [
--         { "id": 1, "type": "regular", "price": 200 },
--         { "id": 2, "type": "regular", "price": 200 },
--         null,                  -- null = gap/aisle
--         { "id": 3, "type": "premium", "price": 300 },
--         ...
--       ]
--     },
--     ...
--   ],
--   "metadata": {
--     "totalSeats": 100,
--     "rowCount": 10,
--     "maxSeatsPerRow": 15
--   }
-- }

-- Function to update seat layout (for owners)
CREATE OR REPLACE FUNCTION update_screen_layout(
    p_screen_id UUID,
    p_seat_layout JSONB
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_theatre_id UUID;
    v_is_owner BOOLEAN;
BEGIN
    -- Get the theatre for this screen
    SELECT theatre_id INTO v_theatre_id
    FROM screens
    WHERE id = p_screen_id;
    
    IF v_theatre_id IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Screen not found');
    END IF;
    
    -- Check if user owns this theatre
    SELECT EXISTS(
        SELECT 1 FROM theater_owners
        WHERE user_id = v_user_id AND theatre_id = v_theatre_id
    ) INTO v_is_owner;
    
    -- Also allow admins
    IF NOT v_is_owner AND NOT ((auth.jwt() -> 'user_metadata' ->> 'is_admin')::boolean = true) THEN
        RETURN json_build_object('success', false, 'error', 'Access denied');
    END IF;
    
    -- Sync seats table.
    -- To avoid FK issues and layout/seat mismatches, only allow this if no active
    -- bookings exist, and check before changing screens.seat_layout.
    IF EXISTS (
        SELECT 1 FROM bookings b
        JOIN shows s ON b.show_id = s.id
        WHERE s.screen_id = p_screen_id AND b.status IN ('confirmed', 'locked')
    ) THEN
        RETURN json_build_object('success', false, 'error', 'Cannot update layout: Active bookings exist for this screen');
    END IF;

    -- Update the screen record after validation so failed saves leave it unchanged.
    UPDATE screens
    SET
        seat_layout = p_seat_layout,
        rows = COALESCE((p_seat_layout->'metadata'->>'rowCount')::integer, rows),
        seats_per_row = COALESCE((p_seat_layout->'metadata'->>'maxSeatsPerRow')::integer, seats_per_row)
    WHERE id = p_screen_id;

    -- Delete old seats
    DELETE FROM seats WHERE screen_id = p_screen_id;

    -- Insert new seats from JSON
    -- Expecting structure: { "rows": [ { "label": "A", "seats": [ { "id": 1, "type": "regular", "price": 200 }, null, ... ] } ] }
    INSERT INTO seats (screen_id, row, col, tier, price)
    SELECT 
        p_screen_id,
        r->>'label',
        (s->>'id')::integer,
        s->>'type',
        (s->>'price')::integer
    FROM jsonb_array_elements(p_seat_layout->'rows') AS r
    CROSS JOIN jsonb_array_elements(r->'seats') AS s
    WHERE s IS NOT NULL AND s != 'null'::jsonb;

    RETURN json_build_object('success', true, 'message', 'Layout updated and seats synced');
END;
$$;

GRANT EXECUTE ON FUNCTION update_screen_layout(UUID, JSONB) TO authenticated;

-- Function to get screen layout
CREATE OR REPLACE FUNCTION get_screen_layout(p_screen_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_layout JSONB;
    v_rows INTEGER;
    v_seats_per_row INTEGER;
BEGIN
    SELECT seat_layout, rows, seats_per_row
    INTO v_layout, v_rows, v_seats_per_row
    FROM screens
    WHERE id = p_screen_id;
    
    -- If custom layout exists, return it
    IF v_layout IS NOT NULL THEN
        RETURN v_layout;
    END IF;
    
    -- Otherwise, generate default layout from rows/seats_per_row
    RETURN generate_default_layout(v_rows, v_seats_per_row);
END;
$$;

GRANT EXECUTE ON FUNCTION get_screen_layout(UUID) TO anon, authenticated;

-- Helper function to generate default seat layout
CREATE OR REPLACE FUNCTION generate_default_layout(
    p_rows INTEGER,
    p_seats_per_row INTEGER
)
RETURNS JSONB
LANGUAGE plpgsql
AS $$
DECLARE
    v_layout JSONB := '{"rows": [], "metadata": {}}';
    v_rows JSONB := '[]';
    v_row JSONB;
    v_seats JSONB;
    v_seat JSONB;
    i INTEGER;
    j INTEGER;
    v_row_label TEXT;
    v_seat_type TEXT;
    v_price INTEGER;
BEGIN
    FOR i IN 1..COALESCE(p_rows, 10) LOOP
        -- Generate row label (A, B, C, ...)
        v_row_label := CHR(64 + i);
        
        -- Determine seat type based on row position
        IF i <= 2 THEN
            v_seat_type := 'regular';
            v_price := 200;
        ELSIF i <= COALESCE(p_rows, 10) - 2 THEN
            v_seat_type := 'premium';
            v_price := 300;
        ELSE
            v_seat_type := 'vip';
            v_price := 500;
        END IF;
        
        v_seats := '[]';
        FOR j IN 1..COALESCE(p_seats_per_row, 12) LOOP
            v_seat := json_build_object(
                'id', j,
                'type', v_seat_type,
                'price', v_price
            )::jsonb;
            v_seats := v_seats || v_seat;
        END LOOP;
        
        v_row := json_build_object(
            'label', v_row_label,
            'seats', v_seats
        )::jsonb;
        
        v_rows := v_rows || v_row;
    END LOOP;
    
    v_layout := json_build_object(
        'rows', v_rows,
        'metadata', json_build_object(
            'totalSeats', COALESCE(p_rows, 10) * COALESCE(p_seats_per_row, 12),
            'rowCount', COALESCE(p_rows, 10),
            'maxSeatsPerRow', COALESCE(p_seats_per_row, 12)
        )
    )::jsonb;
    
    RETURN v_layout;
END;
$$;


-- ============================================
-- Quick My Ticket - Fix Seat Release Issue
-- ============================================
-- This migration fixes the seat release mechanism:
-- 1. Updates lock_seat to reuse cancelled/expired bookings instead of creating new ones
-- 2. Adds a manual cleanup function that can be called from client-side
-- 3. Adds a unique partial index to prevent duplicate active bookings

-- ============================================
-- 1. ADD UNIQUE PARTIAL INDEX
-- ============================================
-- Ensures only one active booking (locked/confirmed) per seat per show
CREATE UNIQUE INDEX IF NOT EXISTS idx_bookings_active_unique 
ON bookings(show_id, seat_id) 
WHERE status IN ('locked', 'confirmed');

-- ============================================
-- 2. IMPROVED LOCK_SEAT FUNCTION
-- ============================================
-- Key fix: Instead of always INSERTing, this version will:
-- 1. First check for any cancelled/expired booking for this seat and REUSE it
-- 2. Only create a new booking if none exists

CREATE OR REPLACE FUNCTION lock_seat(
    p_show_id UUID, 
    p_seat_id UUID, 
    p_user_id UUID
)
RETURNS TABLE(
    booking_id UUID, 
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking_id UUID;
    v_existing RECORD;
    v_screen_id UUID;
    v_seat_exists BOOLEAN;
    v_reusable_booking UUID;
BEGIN
    -- Validate that the show exists and get screen_id
    SELECT screen_id INTO v_screen_id 
    FROM shows 
    WHERE id = p_show_id;
    
    IF v_screen_id IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Show not found'::TEXT;
        RETURN;
    END IF;
    
    -- Validate that the seat exists and belongs to the show's screen
    SELECT EXISTS(
        SELECT 1 FROM seats 
        WHERE id = p_seat_id AND screen_id = v_screen_id
    ) INTO v_seat_exists;
    
    IF NOT v_seat_exists THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat not found for this show'::TEXT;
        RETURN;
    END IF;
    
    -- Try to acquire a lock on existing active booking (if any)
    SELECT * INTO v_existing
    FROM bookings 
    WHERE show_id = p_show_id 
      AND seat_id = p_seat_id 
      AND status IN ('locked', 'confirmed')
    FOR UPDATE SKIP LOCKED;
    
    -- Check if seat is already taken
    IF FOUND THEN
        -- Check if it's the same user's existing lock
        IF v_existing.user_id = p_user_id AND v_existing.status = 'locked' THEN
            -- Refresh the lock timestamp
            UPDATE bookings 
            SET locked_at = NOW() 
            WHERE id = v_existing.id;
            
            RETURN QUERY SELECT v_existing.id, TRUE, 'Lock refreshed'::TEXT;
            RETURN;
        ELSE
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is already locked or booked'::TEXT;
            RETURN;
        END IF;
    END IF;
    
    -- Look for a reusable cancelled/expired booking for this seat
    SELECT id INTO v_reusable_booking
    FROM bookings
    WHERE show_id = p_show_id
      AND seat_id = p_seat_id
      AND status IN ('cancelled', 'expired')
    ORDER BY created_at DESC
    LIMIT 1
    FOR UPDATE;
    
    IF v_reusable_booking IS NOT NULL THEN
        -- Reuse existing booking record
        UPDATE bookings 
        SET status = 'locked',
            user_id = p_user_id,
            locked_at = NOW(),
            payment_id = NULL,
            confirmed_at = NULL
        WHERE id = v_reusable_booking
        RETURNING id INTO v_booking_id;
        
        RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully (reused)'::TEXT;
        RETURN;
    END IF;
    
    -- Insert new booking with lock
    INSERT INTO bookings (show_id, seat_id, user_id, status, locked_at)
    VALUES (p_show_id, p_seat_id, p_user_id, 'locked', NOW())
    RETURNING id INTO v_booking_id;
    
    RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
    
EXCEPTION
    WHEN unique_violation THEN
        -- Race condition: another transaction inserted first
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat was just locked by another user'::TEXT;
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, ('Error: ' || SQLERRM)::TEXT;
END;
$$;

-- ============================================
-- 3. CLIENT-CALLABLE CLEANUP FUNCTION
-- ============================================
-- This function can be called by authenticated users to release their own expired locks
-- It's a lighter version that doesn't require service_role

CREATE OR REPLACE FUNCTION cleanup_my_expired_locks(
    p_timeout_minutes INTEGER DEFAULT 5
)
RETURNS TABLE(
    cleaned_count INTEGER
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id UUID;
    v_count INTEGER;
BEGIN
    -- Get current user
    v_user_id := auth.uid();
    
    IF v_user_id IS NULL THEN
        RETURN QUERY SELECT 0;
        RETURN;
    END IF;
    
    -- Release user's own expired locks
    WITH expired AS (
        UPDATE bookings 
        SET status = 'expired'
        WHERE user_id = v_user_id
          AND status = 'locked' 
          AND locked_at < NOW() - (p_timeout_minutes || ' minutes')::INTERVAL
        RETURNING id
    )
    SELECT COUNT(*)::INTEGER INTO v_count FROM expired;
    
    RETURN QUERY SELECT COALESCE(v_count, 0);
END;
$$;

GRANT EXECUTE ON FUNCTION cleanup_my_expired_locks(INTEGER) TO authenticated;

-- ============================================
-- 4. FORCE RELEASE FUNCTION (for stuck seats)
-- ============================================
-- Releases ALL locks older than a specified time (service role only)
-- Call this manually if seats are stuck

CREATE OR REPLACE FUNCTION force_release_all_expired_locks(
    p_timeout_minutes INTEGER DEFAULT 5
)
RETURNS TABLE(
    released_count INTEGER,
    released_ids UUID[]
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_released_ids UUID[];
    v_count INTEGER;
BEGIN
    -- Force release ALL expired locks regardless of user
    WITH expired AS (
        UPDATE bookings 
        SET status = 'expired',
            locked_at = NULL
        WHERE status = 'locked' 
          AND locked_at < NOW() - (p_timeout_minutes || ' minutes')::INTERVAL
        RETURNING id
    )
    SELECT array_agg(id), COUNT(*)::INTEGER 
    INTO v_released_ids, v_count
    FROM expired;
    
    RETURN QUERY SELECT COALESCE(v_count, 0), COALESCE(v_released_ids, ARRAY[]::UUID[]);
END;
$$;

-- Allow both service_role AND authenticated users to call this (for emergency use)
GRANT EXECUTE ON FUNCTION force_release_all_expired_locks(INTEGER) TO authenticated;
GRANT EXECUTE ON FUNCTION force_release_all_expired_locks(INTEGER) TO service_role;

-- ============================================
-- 5. FIX STATUS CONSTRAINT AND CLEANUP
-- ============================================
-- First, ensure 'expired' is a valid status, then clean up stuck bookings

-- Drop the old constraint if it exists and recreate with 'expired'
DO $$
BEGIN
    -- Drop existing constraint if it exists
    IF EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'bookings_status_check'
    ) THEN
        ALTER TABLE bookings DROP CONSTRAINT bookings_status_check;
    END IF;
    
    -- Add constraint with 'expired' included
    ALTER TABLE bookings 
    ADD CONSTRAINT bookings_status_check 
    CHECK (status IN ('locked', 'confirmed', 'cancelled', 'expired'));
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;

-- Now run immediate cleanup to release all currently stuck locks
DO $$
DECLARE
    v_count INTEGER;
BEGIN
    -- Release all locks older than 10 minutes (likely stuck)
    UPDATE bookings 
    SET status = 'expired', locked_at = NULL
    WHERE status = 'locked' 
      AND locked_at < NOW() - INTERVAL '10 minutes';
    
    GET DIAGNOSTICS v_count = ROW_COUNT;
    RAISE NOTICE 'Released % stuck locks', v_count;
END $$;


-- ============================================
-- Quick My Ticket - Fix Seat Locking Race Condition
-- ============================================
-- This migration fixes two critical issues:
-- 1. Race condition where multiple users can lock the same seat simultaneously
-- 2. Expired locks (older than 5 minutes) still showing as "locked" in UI
--
-- Key changes:
-- - Uses FOR UPDATE NOWAIT instead of SKIP LOCKED (fails immediately if row is locked)
-- - Auto-expires stale locks within the lock_seat function
-- - Updates seat_availability view to filter expired locks

-- ============================================
-- 1. IMPROVED LOCK_SEAT FUNCTION
-- ============================================
-- Fixes:
-- - FOR UPDATE NOWAIT: Fails immediately if another transaction has the row
-- - Auto-expires locks older than 5 minutes before checking
-- - Handles lock_not_available exception gracefully

CREATE OR REPLACE FUNCTION lock_seat(
    p_show_id UUID, 
    p_seat_id UUID, 
    p_user_id UUID
)
RETURNS TABLE(
    booking_id UUID, 
    success BOOLEAN, 
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_booking_id UUID;
    v_existing RECORD;
    v_screen_id UUID;
    v_seat_exists BOOLEAN;
    v_reusable_booking UUID;
    v_lock_timeout_minutes INTEGER := 5;
BEGIN
    -- Validate that the show exists and get screen_id
    SELECT screen_id INTO v_screen_id 
    FROM shows 
    WHERE id = p_show_id;
    
    IF v_screen_id IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Show not found'::TEXT;
        RETURN;
    END IF;
    
    -- Validate that the seat exists and belongs to the show's screen
    SELECT EXISTS(
        SELECT 1 FROM seats 
        WHERE id = p_seat_id AND screen_id = v_screen_id
    ) INTO v_seat_exists;
    
    IF NOT v_seat_exists THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat not found for this show'::TEXT;
        RETURN;
    END IF;
    
    -- STEP 1: Auto-expire stale locks on this specific seat FIRST
    -- This ensures expired locks don't block new bookings
    UPDATE bookings 
    SET status = 'expired', locked_at = NULL
    WHERE show_id = p_show_id 
      AND seat_id = p_seat_id 
      AND status = 'locked'
      AND locked_at < NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL;
    
    -- STEP 2: Try to acquire a lock on existing active booking
    -- Use NOWAIT to fail immediately if another transaction has the row locked
    -- This prevents race conditions where two users try to lock simultaneously
    BEGIN
        SELECT * INTO v_existing
        FROM bookings 
        WHERE show_id = p_show_id 
          AND seat_id = p_seat_id 
          AND status IN ('locked', 'confirmed')
        FOR UPDATE NOWAIT;
    EXCEPTION
        WHEN lock_not_available THEN
            -- Another transaction is currently modifying this row
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is currently being processed by another user, please try again'::TEXT;
            RETURN;
    END;
    
    -- Check if seat is already taken
    IF FOUND THEN
        -- Check if it's the same user's existing lock
        IF v_existing.user_id = p_user_id AND v_existing.status = 'locked' THEN
            -- Refresh the lock timestamp
            UPDATE bookings 
            SET locked_at = NOW() 
            WHERE id = v_existing.id;
            
            RETURN QUERY SELECT v_existing.id, TRUE, 'Lock refreshed'::TEXT;
            RETURN;
        ELSE
            RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat is already locked or booked'::TEXT;
            RETURN;
        END IF;
    END IF;
    
    -- STEP 3: Look for a reusable cancelled/expired booking for this seat
    SELECT id INTO v_reusable_booking
    FROM bookings
    WHERE show_id = p_show_id
      AND seat_id = p_seat_id
      AND status IN ('cancelled', 'expired')
    ORDER BY created_at DESC
    LIMIT 1
    FOR UPDATE;
    
    IF v_reusable_booking IS NOT NULL THEN
        -- Reuse existing booking record
        UPDATE bookings 
        SET status = 'locked',
            user_id = p_user_id,
            locked_at = NOW(),
            payment_id = NULL,
            confirmed_at = NULL
        WHERE id = v_reusable_booking
        RETURNING id INTO v_booking_id;
        
        RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
        RETURN;
    END IF;
    
    -- STEP 4: Insert new booking with lock
    INSERT INTO bookings (show_id, seat_id, user_id, status, locked_at)
    VALUES (p_show_id, p_seat_id, p_user_id, 'locked', NOW())
    RETURNING id INTO v_booking_id;
    
    RETURN QUERY SELECT v_booking_id, TRUE, 'Seat locked successfully'::TEXT;
    
EXCEPTION
    WHEN unique_violation THEN
        -- Race condition: another transaction inserted first (caught by unique index)
        RETURN QUERY SELECT NULL::UUID, FALSE, 'Seat was just locked by another user'::TEXT;
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::UUID, FALSE, ('Error: ' || SQLERRM)::TEXT;
END;
$$;

-- ============================================
-- 2. UPDATED SEAT_AVAILABILITY VIEW
-- ============================================
-- Now filters out expired locks (older than 5 minutes)
-- Expired locks show as "available" instead of "locked"

CREATE OR REPLACE VIEW seat_availability AS
SELECT 
    s.id AS seat_id,
    s.screen_id,
    s.row,
    s.col,
    s.tier,
    s.price AS seat_price,
    sh.id AS show_id,
    sh.price AS show_price,
    COALESCE(s.price, sh.price, 0) AS effective_price,
    CASE 
        WHEN b.status = 'confirmed' THEN 'booked'
        WHEN b.status = 'locked' AND b.locked_at >= NOW() - INTERVAL '5 minutes' THEN 'locked'
        ELSE 'available'
    END AS availability_status,
    b.user_id AS locked_by,
    b.id AS booking_id,
    b.locked_at
FROM seats s
CROSS JOIN shows sh
LEFT JOIN LATERAL (
    SELECT * FROM bookings 
    WHERE seat_id = s.id 
      AND show_id = sh.id 
      AND (
          status = 'confirmed' 
          OR (status = 'locked' AND locked_at >= NOW() - INTERVAL '5 minutes')
      )
    ORDER BY 
        CASE WHEN status = 'confirmed' THEN 0 ELSE 1 END,
        locked_at DESC
    LIMIT 1
) b ON TRUE
WHERE s.screen_id = sh.screen_id;

-- Re-grant permissions on the view (required after CREATE OR REPLACE)
GRANT SELECT ON seat_availability TO authenticated;
GRANT SELECT ON seat_availability TO anon;

-- ============================================
-- 3. IMMEDIATE CLEANUP OF ALL EXPIRED LOCKS
-- ============================================
-- Release all currently expired locks to make those seats available immediately

DO $$
DECLARE
    v_count INTEGER;
BEGIN
    UPDATE bookings 
    SET status = 'expired', locked_at = NULL
    WHERE status = 'locked' 
      AND locked_at < NOW() - INTERVAL '5 minutes';
    
    GET DIAGNOSTICS v_count = ROW_COUNT;
    RAISE NOTICE 'Released % expired locks', v_count;
END $$;


-- ============================================
-- Quick My Ticket - Extend Lock Function
-- ============================================
-- This migration adds a function to extend seat locks
-- Used by the heartbeat/ping feature to keep locks alive
-- while the user is actively on the booking page.

-- ============================================
-- 1. EXTEND LOCKS FUNCTION
-- ============================================
-- Extends the lock duration for a user's active bookings
-- Only extends if the lock hasn't already expired

CREATE OR REPLACE FUNCTION extend_locks(
    p_booking_ids UUID[],
    p_user_id UUID
)
RETURNS TABLE(
    extended_count INTEGER,
    success BOOLEAN,
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_count INTEGER := 0;
    v_lock_timeout_minutes INTEGER := 5;
BEGIN
    -- Update locked_at timestamp for all valid bookings
    -- Only extend locks that:
    -- 1. Belong to the requesting user
    -- 2. Are still in 'locked' status
    -- 3. Haven't expired yet (locked_at within timeout period)
    UPDATE bookings
    SET locked_at = NOW()
    WHERE id = ANY(p_booking_ids)
      AND user_id = p_user_id
      AND status = 'locked'
      AND locked_at >= NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL;
    
    GET DIAGNOSTICS v_count = ROW_COUNT;
    
    IF v_count > 0 THEN
        RETURN QUERY SELECT v_count, TRUE, format('Extended %s lock(s)', v_count)::TEXT;
    ELSE
        RETURN QUERY SELECT 0, FALSE, 'No active locks to extend'::TEXT;
    END IF;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION extend_locks(UUID[], UUID) TO authenticated;

-- ============================================
-- 2. REFRESH SINGLE LOCK FUNCTION (for individual seat refresh)
-- ============================================
-- Refreshes a single booking's lock if it's still valid

CREATE OR REPLACE FUNCTION refresh_lock(
    p_booking_id UUID,
    p_user_id UUID
)
RETURNS TABLE(
    success BOOLEAN,
    new_locked_at TIMESTAMPTZ,
    message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_lock_timeout_minutes INTEGER := 5;
    v_new_time TIMESTAMPTZ;
BEGIN
    UPDATE bookings
    SET locked_at = NOW()
    WHERE id = p_booking_id
      AND user_id = p_user_id
      AND status = 'locked'
      AND locked_at >= NOW() - (v_lock_timeout_minutes || ' minutes')::INTERVAL
    RETURNING locked_at INTO v_new_time;
    
    IF v_new_time IS NOT NULL THEN
        RETURN QUERY SELECT TRUE, v_new_time, 'Lock refreshed'::TEXT;
    ELSE
        RETURN QUERY SELECT FALSE, NULL::TIMESTAMPTZ, 'Lock expired or not found'::TEXT;
    END IF;
END;
$$;

-- Grant execute permission
GRANT EXECUTE ON FUNCTION refresh_lock(UUID, UUID) TO authenticated;


-- ============================================
-- QuickIt - Add Theatre for Existing Owners
-- Migration 008
-- ============================================
-- Run this in Supabase SQL Editor to allow
-- existing theater owners to add more theatres

-- Allow existing theater owners to create new theatres
CREATE OR REPLACE FUNCTION add_theatre_for_owner(
    p_name TEXT,
    p_location TEXT,
    p_address TEXT DEFAULT NULL,
    p_phone TEXT DEFAULT NULL,
    p_email TEXT DEFAULT NULL
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id UUID := auth.uid();
    v_theatre_id UUID;
    v_is_owner BOOLEAN;
BEGIN
    -- Check if user is already a theater owner
    SELECT EXISTS(
        SELECT 1 FROM theater_owners WHERE user_id = v_user_id
    ) INTO v_is_owner;
    
    IF NOT v_is_owner THEN
        RETURN json_build_object('success', false, 'error', 'You must be an existing theater owner to add theatres');
    END IF;
    
    -- Create the theatre
    INSERT INTO theatres (name, location, address, phone, email)
    VALUES (p_name, p_location, p_address, p_phone, p_email)
    RETURNING id INTO v_theatre_id;
    
    -- Link owner to the new theatre
    INSERT INTO theater_owners (user_id, theatre_id, role)
    VALUES (v_user_id, v_theatre_id, 'owner');
    
    RETURN json_build_object(
        'success', true, 
        'message', 'Theatre added successfully',
        'theatre_id', v_theatre_id
    );
END;
$$;

GRANT EXECUTE ON FUNCTION add_theatre_for_owner(TEXT, TEXT, TEXT, TEXT, TEXT) TO authenticated;

-- Add missing columns to theatres if they don't exist
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'theatres' AND column_name = 'address') THEN
        ALTER TABLE theatres ADD COLUMN address TEXT;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'theatres' AND column_name = 'phone') THEN
        ALTER TABLE theatres ADD COLUMN phone TEXT;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'theatres' AND column_name = 'email') THEN
        ALTER TABLE theatres ADD COLUMN email TEXT;
    END IF;
END $$;


