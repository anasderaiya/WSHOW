#!/bin/bash
# Usage: ./scripts/deploy-theater.sh <theater_id> <theater_name> <subdomain>
# Requires: .env file in project root with SUPABASE_URL, SUPABASE_ANON_KEY, MASTER_RAZORPAY_KEY

set -e

# Load env file
if [ -f "$(dirname "$0")/../.env" ]; then
  export $(grep -v '^#' "$(dirname "$0")/../.env" | xargs)
else
  echo "❌ .env file not found. Copy .env.example to .env and fill in values."
  exit 1
fi

THEATER_ID="$1"
THEATER_NAME="$2"
SUBDOMAIN="$3"

if [[ -z "$THEATER_ID" || -z "$THEATER_NAME" || -z "$SUBDOMAIN" ]]; then
  echo "Usage: $0 <theater_id> <theater_name> <subdomain>"
  exit 1
fi

if [[ -z "$SUPABASE_URL" || -z "$SUPABASE_ANON_KEY" || -z "$MASTER_RAZORPAY_KEY" ]]; then
  echo "❌ Missing required env vars. Check your .env file."
  exit 1
fi

echo "🎬 Deploying theater: $THEATER_NAME ($SUBDOMAIN)"

BUILD_DIR="./builds/$SUBDOMAIN"
rm -rf "$BUILD_DIR"
cp -r ./public "$BUILD_DIR"

sed -i "s|%%THEATER_ID%%|$THEATER_ID|g"             "$BUILD_DIR/assets/js/config.js"
sed -i "s|%%THEATER_NAME%%|$THEATER_NAME|g"         "$BUILD_DIR/assets/js/config.js"
sed -i "s|%%SUPABASE_URL%%|$SUPABASE_URL|g"         "$BUILD_DIR/assets/js/config.js"
sed -i "s|%%SUPABASE_ANON_KEY%%|$SUPABASE_ANON_KEY|g" "$BUILD_DIR/assets/js/config.js"
sed -i "s|%%RAZORPAY_KEY%%|$MASTER_RAZORPAY_KEY|g"  "$BUILD_DIR/assets/js/config.js"
sed -i "s|%%DEPLOYMENT_ENV%%|production|g"           "$BUILD_DIR/assets/js/config.js"

# Also replace %%RAZORPAY_KEY%% in seats.html meta tag (fallback for payment.js)
sed -i "s|%%RAZORPAY_KEY%%|$MASTER_RAZORPAY_KEY|g"  "$BUILD_DIR/seats.html"

cd "$BUILD_DIR"
vercel --name "qmt-$SUBDOMAIN" --prod

echo "✅ Live at: https://$SUBDOMAIN.quickmytickets.com"
