#!/bin/bash
# scripts/redeploy-all.sh
# Rebuild and redeploy both demo white-label sites

theaters=(
  "demo-cinema"
  "qmt-demo-cinema"
)

# Load env file
if [ -f "./.env" ]; then
  export $(grep -v '^#' .env | xargs)
fi

for t in "${theaters[@]}"; do
  echo "🎬 Rebuilding: $t"
  
  # 1. Copy fresh public files
  rm -rf "builds/$t"
  cp -r ./public "builds/$t"
  
  # 2. Inject configuration placeholders
  THEATER_ID="dddd58fe-82c1-45fc-aadf-79613cbdb122"
  THEATER_NAME="Demo cinema"
  
  sed -i "s|%%THEATER_ID%%|$THEATER_ID|g"             "builds/$t/assets/js/config.js"
  sed -i "s|%%THEATER_NAME%%|$THEATER_NAME|g"         "builds/$t/assets/js/config.js"
  sed -i "s|%%SUPABASE_URL%%|$SUPABASE_URL|g"         "builds/$t/assets/js/config.js"
  sed -i "s|%%SUPABASE_ANON_KEY%%|$SUPABASE_ANON_KEY|g" "builds/$t/assets/js/config.js"
  sed -i "s|%%RAZORPAY_KEY%%|$MASTER_RAZORPAY_KEY|g"  "builds/$t/assets/js/config.js"
  sed -i "s|%%DEPLOYMENT_ENV%%|production|g"           "builds/$t/assets/js/config.js"
  
  # Replace in seats.html meta tag
  sed -i "s|%%RAZORPAY_KEY%%|$MASTER_RAZORPAY_KEY|g"  "builds/$t/seats.html"
  
  # 3. Deploy to Vercel if available
  if command -v vercel &> /dev/null; then
    echo "🚀 Deploying $t to Vercel..."
    (cd "builds/$t" && vercel --prod)
  else
    echo "⚠️ vercel CLI not found. Rebuild completed locally."
  fi
  echo "✅ Rebuilt: $t"
done
