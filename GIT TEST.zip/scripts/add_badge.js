const fs = require('fs');
const path = require('path');

const publicDir = path.join(__dirname, '..', 'public');
const badgeHtml = `
    <!-- Powered By Badge -->
    <div class="powered-by-badge">
        <span>Powered by</span>
        <a href="https://quickmytickets.com" target="_blank" rel="noopener">
            <img src="/assets/images/qmt-badge.png" alt="Quick My Ticket" height="20">
        </a>
    </div>
`;

function injectBadge(filePath) {
    let content = fs.readFileSync(filePath, 'utf8');
    
    // Check if already injected
    if (content.includes('powered-by-badge')) {
        console.log(`[SKIP] Already has badge: ${path.basename(filePath)}`);
        return;
    }

    // Try to inject before </footer>
    if (content.includes('</footer>')) {
        content = content.replace('</footer>', `${badgeHtml}\n</footer>`);
        fs.writeFileSync(filePath, content, 'utf8');
        console.log(`[OK] Injected before </footer>: ${path.basename(filePath)}`);
        return;
    }

    // Try to inject before </main> if no footer
    if (content.includes('</main>')) {
        content = content.replace('</main>', `${badgeHtml}\n</main>`);
        fs.writeFileSync(filePath, content, 'utf8');
        console.log(`[OK] Injected before </main>: ${path.basename(filePath)}`);
        return;
    }

    // Fallback to before </body>
    if (content.includes('</body>')) {
        content = content.replace('</body>', `${badgeHtml}\n</body>`);
        fs.writeFileSync(filePath, content, 'utf8');
        console.log(`[OK] Injected before </body>: ${path.basename(filePath)}`);
        return;
    }

    console.log(`[WARN] Could not find insertion point: ${path.basename(filePath)}`);
}

const files = fs.readdirSync(publicDir).filter(f => f.endsWith('.html'));
files.forEach(file => {
    injectBadge(path.join(publicDir, file));
});
