/**
 * Quick My Ticket - Add Show Page for Theater Owners
 * ====================================================
 * Allows theater owners to add shows to their theatres
 */

// State
let currentUser = null;
let ownedTheatres = [];



document.addEventListener('DOMContentLoaded', async () => {
    await initAddShowPage();
});

/**
 * Initialize the add show page
 */
async function initAddShowPage() {
    const loadingEl = document.getElementById('loading-state');
    const accessDenied = document.getElementById('access-denied');
    const mainContent = document.getElementById('add-show-content');

    try {
        currentUser = await JayShow.getUser();



        if (!currentUser) {
            window.location.href = 'owner-login.html';
            return;
        }

        // Check if user is theater owner
        const isOwner = await checkIsTheaterOwner(currentUser.id);

        if (!isOwner) {
            loadingEl.classList.add('hidden');
            accessDenied.classList.remove('hidden');
            return;
        }

        // User is authorized - show content
        loadingEl.classList.add('hidden');
        mainContent.classList.remove('hidden');

        // Set default date to today
        document.getElementById('show-date').valueAsDate = new Date();

        // Load data
        await Promise.all([
            loadOwnedTheatres(),
            loadMovies(),
            loadRecentShows()
        ]);

        // Setup event listeners
        setupEventListeners();

        // Update user info in navbar
        updateNavbar();

    } catch (error) {
        console.error('Init error:', error);
        loadingEl.classList.add('hidden');
        accessDenied.classList.remove('hidden');
    }
}

/**
 * Check if user is a theater owner
 */
async function checkIsTheaterOwner(userId) {
    const client = JayShow.getSupabaseClient();

    const { data, error } = await client.rpc('is_theater_owner', { p_user_id: userId });

    if (error) {
        // Fallback: check table directly
        const { data: owners, error: ownerError } = await client
            .from('theater_owners')
            .select('id')
            .eq('user_id', userId)
            .limit(1);

        return !ownerError && owners && owners.length > 0;
    }

    return data === true;
}

/**
 * Load theatres owned by current user
 */
async function loadOwnedTheatres() {
    const client = JayShow.getSupabaseClient();
    const theatreSelect = document.getElementById('theatre-select');

    try {
        let theatres;

        // Use RPC function to get owned theatres
            const { data, error } = await client.rpc('get_owned_theatres', {
                p_user_id: currentUser.id
            });
            if (error) throw error;

            // Get full theatre data
            const theatreIds = (data || []).map(t => t.theatre_id);
            if (theatreIds.length > 0) {
                const { data: theatreData } = await client
                    .from('theatres')
                    .select('*, screens(id, name, seat_layout)')
                    .in('id', theatreIds);
                theatres = theatreData || [];
            } else {
                theatres = [];
            }

        ownedTheatres = theatres;

        // Populate dropdown
        theatreSelect.innerHTML = '<option value="">Select Theatre</option>' +
            theatres.map(t => `<option value="${t.id}">${escapeHtml(t.name)} - ${escapeHtml(t.location || '')}</option>`).join('');

    } catch (error) {
        console.error('Error loading theatres:', error);
        theatreSelect.innerHTML = '<option value="">Failed to load theatres</option>';
    }
}

/**
 * Load screens for selected theatre
 */
async function loadScreens(theatreId) {
    const screenSelect = document.getElementById('screen-select');

    if (!theatreId) {
        screenSelect.innerHTML = '<option value="">Select Theatre First</option>';
        screenSelect.disabled = true;
        return;
    }

    const theatre = ownedTheatres.find(t => t.id === theatreId);
    const screens = theatre?.screens || [];

    if (screens.length === 0) {
        screenSelect.innerHTML = '<option value="">No screens available</option>';
        screenSelect.disabled = true;
        return;
    }

    screenSelect.innerHTML = '<option value="">Select Screen</option>' +
        screens.map(s => {
            const isConfigured = !!s.seat_layout?.metadata?.totalSeats;
            const seatCount = s.seat_layout?.metadata?.totalSeats || 0;
            return `
                <option value="${s.id}" ${isConfigured ? '' : 'disabled'}>
                    ${escapeHtml(s.name)}${isConfigured ? ` - ${seatCount} seats` : ' - layout not configured'}
                </option>
            `;
        }).join('');
    screenSelect.disabled = false;
}

/**
 * Load all movies
 */
async function loadMovies() {
    const client = JayShow.getSupabaseClient();
    const movieSelect = document.getElementById('movie-select');

    try {
        const { data: movies, error } = await client
            .from('movies')
            .select('*')
            .order('title');

        if (error) throw error;

        movieSelect.innerHTML = '<option value="">Select Movie</option>' +
            (movies || []).map(m => `<option value="${m.id}">${escapeHtml(m.title)} (${(m.duration_minutes || m.duration) || '?'} min)</option>`).join('');

    } catch (error) {
        console.error('Error loading movies:', error);
        movieSelect.innerHTML = '<option value="">Failed to load movies</option>';
    }
}

/**
 * Load recent shows
 */
async function loadRecentShows() {
    const client = JayShow.getSupabaseClient();
    const container = document.getElementById('recent-shows');

    try {
        let query = client
            .from('shows')
            .select(`
                *,
                movies (id, title),
                screens (id, name, theatre_id, theatres(name))
            `)
            .order('created_at', { ascending: false })
            .limit(10);

        // Filter by owned theatres
        if (ownedTheatres.length > 0) {
            const theatreIds = ownedTheatres.map(t => t.id);
            query = query.in('screens.theatre_id', theatreIds);
        }

        const { data: shows, error } = await query;

        if (error) throw error;

        if (!shows || shows.length === 0) {
            container.innerHTML = '<p class="text-muted">No shows created yet</p>';
            return;
        }

        container.innerHTML = shows.map(show => {
            const date = new Date(show.start_time);
            const dateStr = date.toLocaleDateString();
            const timeStr = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

            return `
                <div class="show-card">
                    <div class="show-info">
                        <div class="show-title">${escapeHtml(show.movies?.title || 'Unknown')}</div>
                        <div class="show-meta">
                            <span>${JayShow.icon('calendar', 'inline-icon')} ${dateStr}</span>
                            <span>${JayShow.icon('clock', 'inline-icon')} ${timeStr}</span>
                            <span>${JayShow.icon('monitor', 'inline-icon')} ${escapeHtml(show.screens?.name || '')}</span>
                        </div>
                    </div>
                    <div class="show-badges">
                        <span class="show-stat-badge available">₹${show.price || 200}</span>
                    </div>
                </div>
            `;
        }).join('');

    } catch (error) {
        console.error('Error loading shows:', error);
        container.innerHTML = '<p class="text-muted">Failed to load shows</p>';
    }
}

/**
 * Setup event listeners
 */
function setupEventListeners() {
    // Theatre selection changes screens
    document.getElementById('theatre-select').addEventListener('change', (e) => {
        loadScreens(e.target.value);
    });

    // Form submission
    document.getElementById('add-show-form').addEventListener('submit', handleCreateShow);

    // Logout
    document.getElementById('logout-btn').addEventListener('click', async () => {
        await JayShow.signOut();
        window.location.href = 'index.html';
    });
}

/**
 * Handle show creation
 */
async function handleCreateShow(e) {
    e.preventDefault();
    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');
    const feedback = document.getElementById('form-feedback');

    const movieId = document.getElementById('movie-select').value;
    const screenId = document.getElementById('screen-select').value;
    const showDate = document.getElementById('show-date').value;
    const showTime = document.getElementById('show-time').value;
    const showEndTime = document.getElementById('show-end-time')?.value;
    const price = parseFloat(document.getElementById('show-price').value) || 200;

    // Validate
    if (!movieId || !screenId || !showDate || !showTime) {
        showFeedback(feedback, 'Please fill all required fields', 'error');
        return;
    }

    // Combine date and time
    const startTime = new Date(`${showDate}T${showTime}`);
    const endTime = showEndTime ? new Date(`${showDate}T${showEndTime}`) : null;

    if (startTime < new Date()) {
        showFeedback(feedback, 'Show time cannot be in the past', 'error');
        return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = 'Creating...';

    try {
        const client = JayShow.getSupabaseClient();
        const insertData = {
            movie_id: movieId,
            screen_id: screenId,
            start_time: startTime.toISOString(),
            price
        };
        if (endTime) {
            insertData.end_time = endTime.toISOString();
        }

        const { data, error } = await client
            .from('shows')
            .insert(insertData)
            .select()
            .single();

        if (error) throw error;

        showFeedback(feedback, 'Show created successfully!', 'success');
        form.reset();
        document.getElementById('show-date').valueAsDate = new Date();

        // Refresh recent shows
        await loadRecentShows();

        showToast('Show created successfully!');

    } catch (err) {
        console.error('Error creating show:', err);
        showFeedback(feedback, err.message || 'Failed to create show', 'error');
    } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Create Show';
    }
}

/**
 * Show form feedback
 */
function showFeedback(element, message, type) {
    element.textContent = message;
    element.className = `form-feedback ${type}`;
    element.classList.remove('hidden');

    if (type === 'success') {
        setTimeout(() => {
            element.classList.add('hidden');
        }, 5000);
    }
}

/**
 * Update navbar with user info
 */
function updateNavbar() {
    const emailSpan = document.querySelector('.user-email');
    if (emailSpan && currentUser) {
        emailSpan.textContent = currentUser.email;
        emailSpan.classList.remove('hidden');
    }
}

/**
 * Show toast notification
 */
function showToast(message) {
    const toast = document.getElementById('toast');
    const messageEl = document.getElementById('toast-message');

    messageEl.textContent = message;
    toast.classList.remove('hidden');
    toast.classList.add('show');

    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.classList.add('hidden'), 300);
    }, 3000);
}