/**
 * Quick My Ticket - Supabase Client Helpers
 * ==========================================
 * 
 * This module provides a centralized Supabase client and helper functions
 * for authentication, seat booking, and real-time subscriptions.
 * 
 * SECURITY NOTES:
 * ---------------
 * - NEVER include the Service Role Key in client-side code
 * - The SUPABASE_ANON_KEY is designed for client use with Row Level Security (RLS)
 * - All sensitive operations should be protected by RLS policies on your Supabase tables
 * - Payment verification must happen server-side in Edge Functions
 * 
 * ABOUT THE ANON KEY:
 * -------------------
 * The SUPABASE_ANON_KEY below is NOT a secret. It is the public/anonymous
 * key intended for client-side use. It grants only the permissions allowed
 * by your Row Level Security (RLS) policies. Do NOT confuse it with the
 * Service Role Key, which MUST stay server-side only.
 * 
 * Environment Variables (replace placeholders before deployment):
 * - SUPABASE_URL: Your Supabase project URL
 * - SUPABASE_ANON_KEY: Your Supabase anonymous/public key
 */

// ============================================
// Configuration - Replace with your values
// ============================================
// SUPABASE_ANON_KEY is safe for client-side use when RLS is
// properly configured. It is NOT a secret. Do not confuse with
// the Service Role Key which must never appear in client code.
// Replace these values if rotating keys or use build-time injection.
const SUPABASE_URL = document.querySelector('meta[name="supabase-url"]')?.getAttribute('content') || 'YOUR_SUPABASE_URL';
const SUPABASE_ANON_KEY = document.querySelector('meta[name="supabase-anon-key"]')?.getAttribute('content') || 'YOUR_SUPABASE_ANON_KEY';

// ============================================
// White-Label Branding Loader
// ============================================
window.JayShow = window.JayShow || {};

/**
 * Resolves and returns the current active theater ID for multi-tenant isolation.
 * Looks in URL search params, URL hash, config settings, and session storage fallback.
 * 
 * @returns {string|null} Resolved theater UUID, or null if on main QuickMyTicket platform
 */
JayShow.getCurrentTheaterId = function() {
    try {
        const urlParams = new URLSearchParams(window.location.search);
        const hashParams = new URLSearchParams(window.location.hash.substring(1));
        let theaterId = urlParams.get('theater') || hashParams.get('theater') || window.QMT_CONFIG?.THEATER_ID;
        
        // Store preview ID in session so navigation keeps the branding
        if (urlParams.get('theater') || hashParams.get('theater')) {
            const val = urlParams.get('theater') || hashParams.get('theater');
            sessionStorage.setItem('preview_theater_id', val);
        } else if (sessionStorage.getItem('preview_theater_id') && (!theaterId || theaterId === '%%THEATER_ID%%')) {
            theaterId = sessionStorage.getItem('preview_theater_id');
        }

        if (theaterId && theaterId !== '%%THEATER_ID%%') {
            return theaterId;
        }
    } catch (e) {
        console.warn('⚠️ Error resolving current theater ID:', e.message);
    }
    return null;
};

// ============================================
// Supabase Client Singleton
// ============================================
// IMPORTANT: This MUST be declared before loadBranding / loadPlatformSettings
// because `let` variables have a Temporal Dead Zone (TDZ). Accessing a `let`
// variable before its declaration line throws a ReferenceError. Since
// loadBranding and loadPlatformSettings call getSupabaseClient() during
// initial script execution, the `let supabaseClient` must be initialised first.
let supabaseClient = null;

/**
 * Creates and returns the Supabase client instance.
 * Uses a singleton pattern to avoid multiple client instances.
 * 
 * @returns {Object} Supabase client instance
 */
function getSupabaseClient() {
    if (!supabaseClient) {
        // Check if supabase-js is loaded via CDN
        if (typeof supabase === 'undefined' || typeof supabase.createClient !== 'function') {
            console.error('Supabase JS library not loaded. Make sure to include the CDN script.');
            return null;
        }
        supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    }
    return supabaseClient;
}

// ============================================
// Platform Settings Loader
// ============================================

JayShow.loadPlatformSettings = async function() {
    try {
        // Use hoisted getSupabaseClient function directly if the global JayShow property is not yet assigned
        const client = typeof getSupabaseClient === 'function' ? getSupabaseClient() : null;
        if (!client) {
            console.warn('⚙️ Platform settings: Supabase client is not available yet. Retrying in 100ms...');
            if (!window._loadSettingsRetries) window._loadSettingsRetries = 0;
            if (window._loadSettingsRetries < 50) {
                window._loadSettingsRetries++;
                setTimeout(JayShow.loadPlatformSettings, 100);
            }
            return;
        }
        window._loadSettingsRetries = 0; // Reset retries on success

        const { data, error } = await client
            .from('platform_settings')
            .select('value')
            .eq('key', 'convenience_fee')
            .single();

        if (error) {
            console.warn('⚙️ Platform settings: Error loading convenience fee:', error.message);
            return;
        }

        if (data && data.value) {
            window.platformConvenienceFee = data.value;
            console.log('⚙️ Platform settings: Convenience fee loaded:', data.value.type, data.value.amount);
        } else {
            console.log('⚙️ Platform settings: No convenience fee configured');
        }
    } catch (err) {
        console.error('Error loading platform settings:', err);
    }
};

// Auto-initialize settings on load
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        JayShow.loadPlatformSettings();
    });
} else {
    JayShow.loadPlatformSettings();
}

JayShow.loadBranding = async function() {
    console.log('🎨 loadBranding: Initializing white-label branding check...');
    try {
        const theaterId = JayShow.getCurrentTheaterId();
        console.log('🎨 loadBranding: Final resolved theaterId:', theaterId);

        if (!theaterId) {
            console.log('🎨 loadBranding: No valid theaterId found. Aborting white-label load.');
            return;
        }

        // Use hoisted getSupabaseClient function directly if the global JayShow property is not yet assigned
        const client = typeof getSupabaseClient === 'function' ? getSupabaseClient() : null;
        if (!client) {
            console.warn('🎨 loadBranding: Supabase client is not available yet. Retrying in 100ms...');
            if (!window._loadBrandingRetries) window._loadBrandingRetries = 0;
            if (window._loadBrandingRetries < 50) {
                window._loadBrandingRetries++;
                setTimeout(JayShow.loadBranding, 100);
            }
            return;
        }
        window._loadBrandingRetries = 0; // Reset retries on success

        console.log('🎨 loadBranding: Querying theater_branding for theater_id:', theaterId);
        const { data: branding, error } = await client
          .from('theater_branding')
          .select('*')
          .eq('theater_id', theaterId)
          .single();

        if (error) {
            console.error('🎨 loadBranding: Database query error:', error);
            return;
        }
        
        if (!branding) {
            console.warn('🎨 loadBranding: No branding configuration returned from DB!');
            return;
        }

        console.log('🎨 loadBranding: Successfully retrieved branding data:', branding);

        // Apply CSS variables to root
        const root = document.documentElement;
        root.style.setProperty('--brand-primary',    branding.primary_color);
        root.style.setProperty('--brand-accent',     branding.accent_color);
        root.style.setProperty('--brand-bg',         branding.background_color);
        root.style.setProperty('--brand-card',       branding.card_color);
        root.style.setProperty('--brand-text',       branding.text_color);

        console.log('🎨 loadBranding: Applied CSS colors to root:', {
            '--brand-primary': branding.primary_color,
            '--brand-accent': branding.accent_color,
            '--brand-bg': branding.background_color,
            '--brand-card': branding.card_color,
            '--brand-text': branding.text_color
        });

        // Apply logo
        const logoEls = document.querySelectorAll('.site-logo, .nav-logo, .navbar-brand img, .brand-logo');
        console.log(`🎨 loadBranding: Found ${logoEls.length} logo elements to update.`);
        if (branding.logo_url) {
          logoEls.forEach((el, idx) => {
            el.src = branding.logo_url;
            el.alt = branding.display_name;
            console.log(`🎨 loadBranding: Updated logo element #${idx}`, el);
          });
        }

        // Apply page title (handle all casing variants)
        if (branding.display_name) {
          const currentTitle = document.title;
          document.title = currentTitle
            .replace(/Quick my Ticket/gi, branding.display_name)
            .replace(/Quick My Ticket/gi, branding.display_name);
          console.log('🎨 loadBranding: Updated document title to:', document.title);

          // Update meta description
          const metaDesc = document.querySelector('meta[name="description"]');
          if (metaDesc) {
            metaDesc.setAttribute('content',
              metaDesc.getAttribute('content')
                .replace(/Quick my Ticket/gi, branding.display_name)
                .replace(/Quick My Ticket/gi, branding.display_name)
            );
          }
        }

        // Apply favicon
        if (branding.favicon_url) {
          let favicon = document.querySelector("link[rel='icon']");
          if (!favicon) {
            favicon = document.createElement('link');
            favicon.rel = 'icon';
            document.head.appendChild(favicon);
          }
          favicon.href = branding.favicon_url;
          console.log('🎨 loadBranding: Applied favicon url:', branding.favicon_url);
        }

        // Show/hide "Powered by" badge
        const poweredBy = document.querySelector('.powered-by-badge');
        if (poweredBy) {
          poweredBy.style.display = branding.show_powered_by ? 'flex' : 'none';
          console.log('🎨 loadBranding: Show powered-by badge:', branding.show_powered_by);
        }

        // ── White-label text replacement across the entire page ──
        if (branding.display_name) {
          // Helper: replace all case variants of the platform name
          const replaceBrand = (text) => text
            .replace(/Quick\s*my\s*Tickets?/gi, branding.display_name)
            .replace(/Quick\s*My\s*Tickets?/gi, branding.display_name);

          // Replace in all footer elements (some pages use <footer class="footer">, others use plain <footer>)
          document.querySelectorAll('footer, .footer').forEach(footer => {
            footer.querySelectorAll('p, strong, span').forEach(el => {
              el.childNodes.forEach(node => {
                if (node.nodeType === Node.TEXT_NODE) {
                  node.textContent = replaceBrand(node.textContent);
                }
              });
              // Also handle &copy; / © inside innerHTML (entity encoded)
              if (el.tagName === 'P' && (el.innerHTML.includes('©') || el.innerHTML.includes('&copy;'))) {
                el.innerHTML = replaceBrand(el.innerHTML);
              }
            });
          });

          // Replace in FAQ subtitles and other body text
          document.querySelectorAll('.faq-subtitle, .faq p, .section-subtitle').forEach(el => {
            el.childNodes.forEach(node => {
              if (node.nodeType === Node.TEXT_NODE) {
                node.textContent = replaceBrand(node.textContent);
              }
            });
          });

          console.log('🎨 loadBranding: All visible brand text replaced with:', branding.display_name);
        }

        // Store branding globally for use by other modules
        window.QMT_BRANDING = branding;

    } catch (err) {
        console.error('🎨 loadBranding: Exception occurred during execution:', err);
    }
};

// Call immediately on DOM ready or if already ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => JayShow.loadBranding());
} else {
    JayShow.loadBranding();
}

// Add hash change listener to dynamically update branding without full reload
window.addEventListener('hashchange', () => {
    console.log('🎨 loadBranding: Hash changed, re-initializing branding...');
    JayShow.loadBranding();
});

// ============================================
// Dynamic Asset Loading (DOMPurify for XSS)
// ============================================
(function() {
    if (typeof window !== 'undefined' && !window.DOMPurify) {
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/dompurify@3.1.2/dist/purify.min.js';
        script.async = true;
        document.head.appendChild(script);
    }
})();



// ============================================
// Authentication Helpers
// ============================================

/**
 * Gets the currently authenticated user.
 * 
 * @returns {Promise<Object|null>} User object or null if not authenticated
 */
async function getUser() {
    const client = getSupabaseClient();
    if (!client) return null;

    const { data: { user }, error } = await client.auth.getUser();
    if (error) {
        if (error.message?.toLowerCase().includes('auth session missing')) {
            return null;
        }
        console.error('Error getting user:', error.message);
        return null;
    }
    return user;
}

/**
 * Signs in a user with email and password.
 * 
 * @param {string} email - User's email address
 * @param {string} password - User's password
 * @returns {Promise<Object>} Object containing user data or error
 */
async function signIn(email, password) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const { data, error } = await client.auth.signInWithPassword({
        email,
        password
    });

    if (error) {
        console.error('Sign in error:', error.message);
        return { data: null, error };
    }

    return { data, error: null };
}

/**
 * Signs up a new user with email and password.
 * 
 * @param {string} email - User's email address
 * @param {string} password - User's password
 * @returns {Promise<Object>} Object containing user data or error
 */
async function signUp(email, password) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const { data, error } = await client.auth.signUp({
        email,
        password
    });

    if (error) {
        console.error('Sign up error:', error.message);
        return { data: null, error };
    }

    return { data, error: null };
}

/**
 * Signs out the current user.
 * 
 * @returns {Promise<Object>} Object containing error if any
 */
async function signOut() {
    const client = getSupabaseClient();
    if (!client) return { error: { message: 'Client not initialized' } };

    const { error } = await client.auth.signOut();

    if (error) {
        console.error('Sign out error:', error.message);
        return { error };
    }

    return { error: null };
}

/**
 * Listens for authentication state changes.
 * 
 * @param {Function} callback - Function to call on auth state change
 * @returns {Object} Subscription object with unsubscribe method
 */
function onAuthStateChange(callback) {
    const client = getSupabaseClient();
    if (!client) return { data: { subscription: { unsubscribe: () => { } } } };

    return client.auth.onAuthStateChange((event, session) => {
        callback(event, session);
    });
}

// ============================================
// Seat Booking Helpers
// ============================================

/**
 * Gets or creates a guest session ID for unauthenticated users.
 * 
 * @returns {string} Session ID
 */
function getGuestSessionId() {
    let sessionId = null;
    try {
        sessionId = sessionStorage.getItem('qmyticket_guest_session_id');
    } catch (e) {
        console.warn('⚠️ Accessing sessionStorage is blocked or unavailable:', e.message);
    }
    
    if (!sessionId) {
        // Generate a cryptographically secure UUID.
        // crypto.randomUUID() is preferred but not available in all contexts
        // (e.g. insecure HTTP). The fallback uses crypto.getRandomValues()
        // which IS available everywhere and is NOT predictable like Math.random().
        if (typeof crypto.randomUUID === 'function') {
            sessionId = crypto.randomUUID();
        } else {
            // Fallback: crypto.getRandomValues-based UUID v4
            const bytes = new Uint8Array(16);
            crypto.getRandomValues(bytes);
            bytes[6] = (bytes[6] & 0x0f) | 0x40; // version 4
            bytes[8] = (bytes[8] & 0x3f) | 0x80; // variant 1
            const hex = Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
            sessionId = `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20)}`;
        }
        try {
            sessionStorage.setItem('qmyticket_guest_session_id', sessionId);
        } catch (e) {
            console.warn('⚠️ Could not save guest session ID in sessionStorage:', e.message);
        }
    }
    return sessionId;
}

/**
 * Locks a seat using atomic database function.
 * Uses row-level locking to prevent race conditions.
 * 
 * @param {string} showId - ID of the show
 * @param {string} seatId - ID of the seat to lock
 * @returns {Promise<Object>} Object containing booking data or error
 */
async function lockSeat(showId, seatId) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const user = await getUser();
    const userId = user ? user.id : null;
    const sessionId = user ? null : getGuestSessionId();
    // Use atomic RPC function for race-condition-safe locking
    const { data, error } = await client.rpc('lock_seat', {
        p_show_id: showId,
        p_seat_id: seatId,
        p_user_id: userId,
        p_session_id: sessionId
    });

    if (error) {
        console.error('Error locking seat:', error.message);
        return { data: null, error };
    }

    // RPC returns array with single result
    const result = data?.[0];

    if (!result || !result.success) {
        return {
            data: null,
            error: { message: result?.message || 'Failed to lock seat' }
        };
    }

    return {
        data: { id: result.booking_id, message: result.message },
        error: null
    };
}

/**
 * Unlocks a booking (sets status to 'cancelled').
 * Uses atomic database function to ensure proper authorization.
 * 
 * @param {string} bookingId - ID of the booking to unlock
 * @returns {Promise<Object>} Object containing result or error
 */
async function unlockBooking(bookingId) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const user = await getUser();
    const userId = user ? user.id : null;
    const sessionId = user ? null : getGuestSessionId();
    
    // Use atomic RPC function for safe unlocking
    const { data, error } = await client.rpc('unlock_seat', {
        p_booking_id: bookingId,
        p_user_id: userId,
        p_session_id: sessionId
    });

    if (error) {
        console.error('Error unlocking booking:', error.message);
        return { data: null, error };
    }

    const result = data?.[0];

    if (!result || !result.success) {
        return {
            data: null,
            error: { message: result?.message || 'Failed to unlock seat' }
        };
    }

    return { data: { success: true, message: result.message }, error: null };
}

/**
 * Finalizes a booking after successful payment.
 * Updates status to 'confirmed' and stores payment reference.
 * 
// ============================================
// Seat State Helpers
// ============================================

/**
 * Fetches the current state of all seats for a show.
 * Uses the optimized seat_availability view for better performance.
 * Falls back to manual query if view doesn't exist.
 * 
 * @param {string} showId - ID of the show
 * @returns {Promise<Object>} Object containing seat states or error
 */
async function fetchSeatStates(showId) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    // Get current user to identify their own bookings
    const user = await getUser();

    const { data: showScreen, error: showScreenError } = await client
        .from('shows')
        .select('screen_id')
        .eq('id', showId)
        .single();

    if (showScreenError) {
        console.error('Error fetching show screen:', showScreenError.message);
        return { data: null, error: showScreenError };
    }

    // Try using the optimized view first
    const { data: viewData, error: viewError } = await client
        .from('seat_availability')
        .select('*')
        .eq('show_id', showId)
        .eq('screen_id', showScreen.screen_id)
        .order('row')
        .order('col');

    if (!viewError && viewData) {
        // View exists and worked - map to expected format
        const seatStates = viewData.map(seat => {
            let state = seat.availability_status || 'available';

            // Mark user's own locked seats as 'selected'
            const isUserLocked = user && seat.locked_by === user.id;
            const isGuestLocked = !user && seat.locked_by_session === getGuestSessionId();
            
            if (state === 'locked' && (isUserLocked || isGuestLocked)) {
                state = 'selected';
            }

            return {
                id: seat.seat_id,
                screen_id: seat.screen_id,
                row: seat.row,
                col: seat.col,
                tier: seat.tier,
                price: seat.effective_price,
                state,
                booking: seat.booking_id ? {
                    id: seat.booking_id,
                    user_id: seat.locked_by,
                    locked_at: seat.locked_at
                } : null
            };
        });

        return { data: seatStates, error: null };
    }

    // Fallback to manual query (view might not exist)
    JayShow.debugLog('Falling back to manual seat query (view not available)');

    // Get all seats for this screen
    const { data: seats, error: seatsError } = await client
        .from('seats')
        .select('*')
        .eq('screen_id', showScreen.screen_id)
        .order('row')
        .order('col');

    if (seatsError) {
        console.error('Error fetching seats:', seatsError.message);
        return { data: null, error: seatsError };
    }

    // Get all active bookings for this show
    const { data: bookings, error: bookingsError } = await client
        .from('bookings')
        .select('id, seat_id, status, user_id, locked_at')
        .eq('show_id', showId)
        .in('status', ['locked', 'confirmed', 'offline']);

    if (bookingsError) {
        console.error('Error fetching bookings:', bookingsError.message);
        return { data: null, error: bookingsError };
    }

    // Merge seat data with booking status
    // Filter out expired locks (older than 5 minutes)
    const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();
    const bookingMap = {};
    bookings.forEach(b => {
        // Include confirmed bookings, offline bookings, and non-expired locked bookings
        if (b.status === 'confirmed' ||
            b.status === 'offline' ||
            (b.status === 'locked' && b.locked_at && b.locked_at >= fiveMinutesAgo)) {
            bookingMap[b.seat_id] = b;
        }
    });

    const seatStates = seats.map(seat => {
        const booking = bookingMap[seat.id];
        let state = 'available';

        if (booking) {
            if (booking.status === 'confirmed') {
                state = 'booked';
            } else if (booking.status === 'offline') {
                state = 'offline';
            } else if (booking.status === 'locked') {
                // Check if it's the current user's lock
                state = (user && booking.user_id === user.id) ? 'selected' : 'locked';
            }
        }

        return {
            ...seat,
            state,
            booking: booking || null
        };
    });

    return { data: seatStates, error: null };
}

/**
 * Subscribes to real-time booking updates for a show.
 * Calls the callback whenever a booking is created, updated, or deleted.
 * 
 * @param {string} showId - ID of the show to subscribe to
 * @param {Function} callback - Function to call on booking changes
 * @returns {Object} Subscription object with unsubscribe method
 */
function subscribeBookings(showId, callback) {
    const client = getSupabaseClient();
    if (!client) {
        console.error('Client not initialized for realtime subscription');
        return { unsubscribe: () => { } };
    }

    const channel = client
        .channel(`bookings-${showId}`)
        .on(
            'postgres_changes',
            {
                event: '*', // Listen to all events (INSERT, UPDATE, DELETE)
                schema: 'public',
                table: 'bookings',
                filter: `show_id=eq.${showId}`
            },
            (payload) => {
                callback(payload);
            }
        )
        .subscribe();

    return {
        unsubscribe: () => {
            client.removeChannel(channel);
        }
    };
}

// ============================================
// Data Fetching Helpers
// ============================================

/**
 * Fetches the custom seat layout for a screen.
 * 
 * @param {string} screenId - ID of the screen
 * @returns {Promise<Object>} Object containing layout data or error
 */
async function fetchScreenLayout(screenId) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const { data: screen, error: screenError } = await client
        .from('screens')
        .select('seat_layout')
        .eq('id', screenId)
        .single();

    if (!screenError && screen?.seat_layout) {
        return { data: screen.seat_layout, error: null, source: 'screens.seat_layout' };
    }

    const { data, error } = await client.rpc('get_screen_layout', { p_screen_id: screenId });
    if (!error && data) {
        return { data, error: null, source: 'get_screen_layout' };
    }

    return {
        data: generateDefaultScreenLayout(10, 12),
        error: screenError || error || null,
        source: 'generated-default'
    };
}

function generateDefaultScreenLayout(rowCount, seatsPerRow) {
    const rows = [];
    for (let i = 0; i < rowCount; i++) {
        const label = String.fromCharCode(65 + i);
        const seats = [];

        for (let j = 1; j <= seatsPerRow; j++) {
            let type = 'regular';
            let price = 200;

            if (i >= rowCount - 2 && rowCount > 4) {
                type = 'vip';
                price = 500;
            } else if (i >= 2) {
                type = 'premium';
                price = 300;
            }

            seats.push({ id: j, type, price });
        }

        rows.push({ label, seats });
    }

    return {
        rows,
        metadata: {
            totalSeats: rowCount * seatsPerRow,
            rowCount,
            maxSeatsPerRow: seatsPerRow
        }
    };
}


/**
 * Fetches all movies.
 * 
 * @returns {Promise<Object>} Object containing movies array or error
 */
async function fetchMovies() {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const theaterId = typeof JayShow.getCurrentTheaterId === 'function' ? JayShow.getCurrentTheaterId() : null;
    
    if (theaterId) {
        // Query the shows scheduled at this specific theater
        const { data: shows, error: showsError } = await client
            .from('shows')
            .select(`
                movie_id,
                screens!inner (
                    theatre_id
                )
            `)
            .eq('screens.theatre_id', theaterId);

        if (showsError) {
            console.error('Error fetching shows for theater filtering:', showsError.message);
            return { data: null, error: showsError };
        }

        if (!shows || shows.length === 0) {
            return { data: [], error: null };
        }

        // Get unique movie IDs from the shows
        const allowedMovieIds = Array.from(new Set(shows.map(s => s.movie_id).filter(id => !!id)));

        if (allowedMovieIds.length === 0) {
            return { data: [], error: null };
        }

        // Fetch movies that are scheduled at this theater
        const { data, error } = await client
            .from('movies')
            .select('*')
            .in('id', allowedMovieIds)
            .order('created_at', { ascending: false });

        return { data, error };
    } else {
        // No theater ID, return all movies (for Quick My Ticket platform)
        const { data, error } = await client
            .from('movies')
            .select('*')
            .order('created_at', { ascending: false });

        return { data, error };
    }
}

/**
 * Fetches a single movie by ID.
 * 
 * @param {string} movieId - ID of the movie
 * @returns {Promise<Object>} Object containing movie data or error
 */
async function fetchMovie(movieId) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const { data, error } = await client
        .from('movies')
        .select('*')
        .eq('id', movieId)
        .single();

    return { data, error };
}

// ============================================
// Events Data Fetching
// ============================================

/**
 * Fetches all events.
 * 
 * @returns {Promise<Object>} Object containing events array or error
 */
async function fetchEvents() {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const theaterId = typeof JayShow.getCurrentTheaterId === 'function' ? JayShow.getCurrentTheaterId() : null;

    if (theaterId) {
        // Fetch only upcoming event shows for this theater
        const { data: eventShows, error: showsError } = await client
            .from('event_shows')
            .select(`
                event_id,
                screens!inner (
                    theatre_id
                )
            `)
            .eq('screens.theatre_id', theaterId);

        if (showsError) {
            console.error('Error fetching event shows for filtering:', showsError.message);
            return { data: null, error: showsError };
        }

        if (!eventShows || eventShows.length === 0) {
            return { data: [], error: null };
        }

        const allowedEventIds = Array.from(new Set(eventShows.map(es => es.event_id).filter(id => !!id)));

        if (allowedEventIds.length === 0) {
            return { data: [], error: null };
        }

        const { data, error } = await client
            .from('events')
            .select('*')
            .eq('status', 'upcoming')
            .in('id', allowedEventIds)
            .order('created_at', { ascending: false });

        return { data, error };
    } else {
        const { data, error } = await client
            .from('events')
            .select('*')
            .eq('status', 'upcoming')
            .order('created_at', { ascending: false });

        return { data, error };
    }
}

/**
 * Fetches a single event by ID.
 * 
 * @param {string} eventId - ID of the event
 * @returns {Promise<Object>} Object containing event data or error
 */
async function fetchEvent(eventId) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const { data, error } = await client
        .from('events')
        .select('*')
        .eq('id', eventId)
        .single();

    return { data, error };
}

/**
 * Fetches shows for an event with screen and venue details.
 * 
 * @param {string} eventId - ID of the event
 * @returns {Promise<Object>} Object containing event shows array or error
 */
/**
 * Fetches shows for an event with screen and venue details.
 * Restricts shows to the current theater on white-label domains.
 * 
 * @param {string} eventId - ID of the event
 * @returns {Promise<Object>} Object containing event shows array or error
 */
async function fetchEventShows(eventId) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const theaterId = typeof JayShow.getCurrentTheaterId === 'function' ? JayShow.getCurrentTheaterId() : null;

    let query;
    if (theaterId) {
        query = client
            .from('event_shows')
            .select(`
                *,
                screens!inner (
                    id,
                    name,
                    seat_layout,
                    theatres (
                        id,
                        name,
                        location
                    )
                )
            `)
            .eq('event_id', eventId)
            .eq('screens.theatre_id', theaterId);
    } else {
        query = client
            .from('event_shows')
            .select(`
                *,
                screens (
                    id,
                    name,
                    seat_layout,
                    theatres (
                        id,
                        name,
                        location
                    )
                )
            `)
            .eq('event_id', eventId);
    }

    const { data, error } = await query.order('start_time', { ascending: true });

    return { data, error };
}

/**
 * Fetches a single event show by ID.
 * Validates theater ownership on white-label domains.
 * 
 * @param {string} eventShowId - ID of the event show
 * @returns {Promise<Object>} Object containing event show data or error
 */
async function fetchEventShow(eventShowId) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const theaterId = typeof JayShow.getCurrentTheaterId === 'function' ? JayShow.getCurrentTheaterId() : null;

    let query;
    if (theaterId) {
        query = client
            .from('event_shows')
            .select(`
                *,
                events (*),
                screens!inner (
                    id,
                    name,
                    seat_layout,
                    theatres!inner (*)
                )
            `)
            .eq('id', eventShowId)
            .eq('screens.theatre_id', theaterId);
    } else {
        query = client
            .from('event_shows')
            .select(`
                *,
                events (*),
                screens (
                    id,
                    name,
                    seat_layout,
                    theatres (*)
                )
            `)
            .eq('id', eventShowId);
    }

    const { data, error } = await query.single();

    if (!error && data && theaterId) {
        const showTheatreId = data.screens?.theatre_id || data.screens?.theatres?.id;
        if (showTheatreId !== theaterId) {
            console.error('🚫 Security Isolation: Event show does not belong to this theater.');
            return { data: null, error: { message: 'Access Denied: This show is not available for this theater.' } };
        }
    }

    return { data, error };
}

/**
 * Locks a seat for an event show.
 * Uses atomic database function to prevent race conditions.
 * 
 * @param {string} eventShowId - ID of the event show
 * @param {string} seatId - ID of the seat to lock
 * @returns {Promise<Object>} Object containing booking data or error
 */
async function lockEventSeat(eventShowId, seatId) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const user = await getUser();
    const userId = user ? user.id : null;
    const sessionId = user ? null : getGuestSessionId();

    const { data, error } = await client.rpc('lock_event_seat', {
        p_event_show_id: eventShowId,
        p_seat_id: seatId,
        p_user_id: userId,
        p_session_id: sessionId
    });

    if (error) {
        console.error('Error locking event seat:', error.message);
        return { data: null, error };
    }

    const result = data?.[0];

    if (!result || !result.success) {
        return {
            data: null,
            error: { message: result?.message || 'Failed to lock seat' }
        };
    }

    return {
        data: { id: result.booking_id, message: result.message },
        error: null
    };
}

/**
 * Fetches seat states for an event show.
 * 
 * @param {string} eventShowId - ID of the event show
 * @returns {Promise<Object>} Object containing seat states or error
 */
async function fetchEventSeatStates(eventShowId) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const user = await getUser();

    const { data: eventShowScreen, error: eventShowScreenError } = await client
        .from('event_shows')
        .select('screen_id')
        .eq('id', eventShowId)
        .single();

    if (eventShowScreenError) {
        console.error('Error fetching event show screen:', eventShowScreenError.message);
        return { data: null, error: eventShowScreenError };
    }

    const { data: viewData, error: viewError } = await client
        .from('event_seat_availability')
        .select('*')
        .eq('event_show_id', eventShowId)
        .eq('screen_id', eventShowScreen.screen_id)
        .order('row')
        .order('col');

    if (!viewError && viewData) {
        const seatStates = viewData.map(seat => {
            let state = seat.availability_status || 'available';

            const isUserLocked = user && seat.locked_by === user.id;
            const isGuestLocked = !user && seat.locked_by_session === getGuestSessionId();
            
            if (state === 'locked' && (isUserLocked || isGuestLocked)) {
                state = 'selected';
            }

            return {
                id: seat.seat_id,
                screen_id: seat.screen_id,
                row: seat.row,
                col: seat.col,
                tier: seat.tier,
                price: seat.effective_price,
                state,
                booking: seat.booking_id ? {
                    id: seat.booking_id,
                    user_id: seat.locked_by,
                    locked_at: seat.locked_at
                } : null
            };
        });

        return { data: seatStates, error: null };
    }

    return { data: null, error: viewError };
}

/**
 * Subscribes to real-time booking updates for an event show.
 * Calls the callback whenever a booking is created, updated, or deleted.
 * 
 * @param {string} eventShowId - ID of the event show to subscribe to
 * @param {Function} callback - Function to call on booking changes
 * @returns {Object} Subscription object with unsubscribe method
 */
function subscribeEventBookings(eventShowId, callback) {
    const client = getSupabaseClient();
    if (!client) {
        console.error('Client not initialized for realtime subscription');
        return { unsubscribe: () => { } };
    }

    const channel = client
        .channel(`events-bookings-${eventShowId}`)
        .on(
            'postgres_changes',
            {
                event: '*', // Listen to all events (INSERT, UPDATE, DELETE)
                schema: 'public',
                table: 'bookings',
                filter: `event_show_id=eq.${eventShowId}`
            },
            (payload) => {
                callback(payload);
            }
        )
        .subscribe();

    return {
        unsubscribe: () => {
            client.removeChannel(channel);
        }
    };
}

/**
 * Fetches shows for a movie with screen and theatre details.
 * 
 * @param {string} movieId - ID of the movie
 * @returns {Promise<Object>} Object containing shows array or error
 */
/**
 * Fetches shows for a movie with screen and theatre details.
 * Restricts shows to the current theater on white-label domains.
 * 
 * @param {string} movieId - ID of the movie
 * @returns {Promise<Object>} Object containing shows array or error
 */
async function fetchShowsForMovie(movieId) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const theaterId = typeof JayShow.getCurrentTheaterId === 'function' ? JayShow.getCurrentTheaterId() : null;

    let query;
    if (theaterId) {
        query = client
            .from('shows')
            .select(`
                *,
                screens!inner (
                    id,
                    name,
                    seat_layout,
                    theatres (
                        id,
                        name,
                        location
                    )
                )
            `)
            .eq('movie_id', movieId)
            .eq('screens.theatre_id', theaterId);
    } else {
        query = client
            .from('shows')
            .select(`
                *,
                screens (
                    id,
                    name,
                    seat_layout,
                    theatres (
                        id,
                        name,
                        location
                    )
                )
            `)
            .eq('movie_id', movieId);
    }

    const { data, error } = await query.order('start_time', { ascending: true });

    return { data, error };
}

/**
 * Fetches a single show with all related details.
 * Validates theater ownership on white-label domains.
 * 
 * @param {string} showId - ID of the show
 * @returns {Promise<Object>} Object containing show data or error
 */
async function fetchShow(showId) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const theaterId = typeof JayShow.getCurrentTheaterId === 'function' ? JayShow.getCurrentTheaterId() : null;

    let query;
    if (theaterId) {
        query = client
            .from('shows')
            .select(`
                *,
                movies (*),
                screens!inner (
                    id,
                    name,
                    seat_layout,
                    theatres!inner (*)
                )
            `)
            .eq('id', showId)
            .eq('screens.theatre_id', theaterId);
    } else {
        query = client
            .from('shows')
            .select(`
                *,
                movies (*),
                screens (
                    id,
                    name,
                    seat_layout,
                    theatres (*)
                )
            `)
            .eq('id', showId);
    }

    const { data, error } = await query.single();

    if (!error && data && theaterId) {
        const showTheatreId = data.screens?.theatre_id || data.screens?.theatres?.id;
        if (showTheatreId !== theaterId) {
            console.error('🚫 Security Isolation: Show does not belong to this theater.');
            return { data: null, error: { message: 'Access Denied: This show is not available for this theater.' } };
        }
    }

    return { data, error };
}

/**
 * Fetches user's bookings.
 * 
 * @param {string} userId - ID of the user (optional, defaults to current user)
 * @returns {Promise<Object>} Object containing bookings array or error
 */
async function fetchUserBookings(userId = null) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    if (!userId) {
        const user = await getUser();
        if (!user) return { data: null, error: { message: 'Not authenticated' } };
        userId = user.id;
    }

    const { data, error } = await client
        .from('bookings')
        .select(`
            *,
            seats (*),
            shows (
                *,
                movies (*),
                screens (
                    *,
                    theatres (*)
                )
            )
        `)
        .eq('user_id', userId)
        .eq('status', 'confirmed')
        .order('created_at', { ascending: false });

    return { data, error };
}

// ============================================
// Theater Owner Helpers
// ============================================

/**
 * Checks if a user is a theater owner.
 * 
 * @param {string} userId - User ID to check (optional, defaults to current user)
 * @returns {Promise<boolean>} True if user is a theater owner
 */
async function isTheaterOwner(userId = null) {
    const client = getSupabaseClient();
    if (!client) return false;

    if (!userId) {
        const user = await getUser();
        if (!user) return false;
        userId = user.id;
    }

    // Try RPC function first
    const { data, error } = await client.rpc('is_theater_owner', { p_user_id: userId });

    if (!error && data !== null) {
        return data === true;
    }

    // Fallback: check table directly
    const { data: owners, error: ownerError } = await client
        .from('theater_owners')
        .select('id')
        .eq('user_id', userId)
        .limit(1);

    return !ownerError && owners && owners.length > 0;
}

/**
 * Gets the role of the current user (admin, theater owner, or regular user).
 * 
 * @returns {Promise<Object>} Object with is_admin, is_theater_owner, and owned_theatre_count
 */
async function getUserRole() {
    const client = getSupabaseClient();
    if (!client) return { is_admin: false, is_theater_owner: false, owned_theatre_count: 0 };

    const user = await getUser();
    if (!user) return { is_admin: false, is_theater_owner: false, owned_theatre_count: 0 };

    // Check admin status from metadata
    const isAdmin = user.app_metadata?.is_admin === true;

    // Check theater owner status
    const { data: owners } = await client
        .from('theater_owners')
        .select('id')
        .eq('user_id', user.id);

    return {
        is_admin: isAdmin,
        is_theater_owner: owners && owners.length > 0,
        owned_theatre_count: owners?.length || 0
    };
}

/**
 * Fetches theatres owned by a user.
 * 
 * @param {string} userId - User ID (optional, defaults to current user)
 * @returns {Promise<Object>} Object containing theatres array or error
 */
async function fetchOwnedTheatres(userId = null) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    if (!userId) {
        const user = await getUser();
        if (!user) return { data: null, error: { message: 'Not authenticated' } };
        userId = user.id;
    }

    // Try RPC function first
    const { data, error } = await client.rpc('get_owned_theatres', { p_user_id: userId });

    if (!error) {
        return { data, error: null };
    }

    // Fallback: manual query
    const { data: owners, error: ownerError } = await client
        .from('theater_owners')
        .select(`
            role,
            theatres (
                id,
                name,
                location,
                screens (id)
            )
        `)
        .eq('user_id', userId);

    if (ownerError) {
        return { data: null, error: ownerError };
    }

    const theatres = owners?.map(o => ({
        theatre_id: o.theatres.id,
        theatre_name: o.theatres.name,
        location: o.theatres.location,
        role: o.role,
        screen_count: o.theatres.screens?.length || 0
    })) || [];

    return { data: theatres, error: null };
}

// ============================================
// Seat Cleanup Helpers
// ============================================

/**
 * Cleans up the current user's expired seat locks.
 * Call this when loading the seat selection page to release any stuck locks.
 * 
 * @param {number} timeoutMinutes - Lock timeout in minutes (default 5)
 * @returns {Promise<Object>} Object containing cleaned_count or error
 */
async function cleanupExpiredLocks(timeoutMinutes = 5) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const { data, error } = await client.rpc('cleanup_my_expired_locks', {
        p_timeout_minutes: timeoutMinutes
    });

    if (error) {
        console.warn('Could not cleanup expired locks:', error.message);
        return { data: null, error };
    }

    const result = data?.[0] || { cleaned_count: 0 };
    if (result.cleaned_count > 0) {
        JayShow.debugLog(`Cleaned up ${result.cleaned_count} expired locks`);
    }

    return { data: result, error: null };
}

/**
 * Force releases ALL expired seat locks (emergency use).
 * Use this if seats are stuck and not releasing properly.
 * 
 * @param {number} timeoutMinutes - Lock timeout in minutes (default 5)
 * @returns {Promise<Object>} Object containing released_count and released_ids or error
 */
async function forceReleaseAllLocks(timeoutMinutes = 5) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const { data, error } = await client.rpc('force_release_all_expired_locks', {
        p_timeout_minutes: timeoutMinutes
    });

    if (error) {
        console.error('Could not force release locks:', error.message);
        return { data: null, error };
    }

    const result = data?.[0] || { released_count: 0, released_ids: [] };
    JayShow.debugLog(`Force released ${result.released_count} locks`);

    return { data: result, error: null };
}

// ============================================
// Lock Extension Helpers (Heartbeat)
// ============================================

/**
 * Extends the lock duration for active bookings.
 * Called periodically (heartbeat) to keep locks alive while user is on page.
 * 
 * @param {string[]} bookingIds - Array of booking IDs to extend
 * @returns {Promise<Object>} Object containing extended_count or error
 */
async function extendLocks(bookingIds) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    if (!bookingIds || bookingIds.length === 0) {
        return { data: { extended_count: 0 }, error: null };
    }

    const user = await getUser();
    const userId = user ? user.id : null;
    const sessionId = user ? null : getGuestSessionId();

    const { data, error } = await client.rpc('extend_locks', {
        p_booking_ids: bookingIds,
        p_user_id: userId,
        p_session_id: sessionId
    });

    if (error) {
        console.warn('Could not extend locks:', error.message);
        return { data: null, error };
    }

    const result = data?.[0] || { extended_count: 0, success: false };
    if (result.extended_count > 0) {
        JayShow.debugLog(`♻️ Extended ${result.extended_count} lock(s)`);
    }

    return { data: result, error: null };
}

// ============================================
// Inline SVG Icon Helper (for JS templates)
// ============================================

/**
 * Returns an inline SVG icon string for use in JS template literals.
 * Uses minimalist monochrome Lucide-style icons.
 * 
 * @param {string} name - Icon name
 * @param {string} cls - Optional extra CSS class
 * @returns {string} SVG markup string
 */
function icon(name, cls = 'inline-icon') {
    const icons = {
        'film': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M7 3v18"/><path d="M17 3v18"/><path d="M3 7h4"/><path d="M17 7h4"/><path d="M3 12h18"/><path d="M3 17h4"/><path d="M17 17h4"/></svg>',
        'ticket': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"/><path d="M13 5v2"/><path d="M13 17v2"/><path d="M13 11v2"/></svg>',
        'map-pin': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/></svg>',
        'building': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><rect width="16" height="20" x="4" y="2" rx="2" ry="2"/><path d="M9 22v-4h6v4"/><path d="M8 6h.01"/><path d="M16 6h.01"/><path d="M12 6h.01"/><path d="M12 10h.01"/><path d="M12 14h.01"/><path d="M16 10h.01"/><path d="M16 14h.01"/><path d="M8 10h.01"/><path d="M8 14h.01"/></svg>',
        'monitor': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="14" x="2" y="3" rx="2"/><line x1="8" x2="16" y1="21" y2="21"/><line x1="12" x2="12" y1="17" y2="21"/></svg>',
        'calendar': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/></svg>',
        'drama': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" x2="9.01" y1="9" y2="9"/><line x1="15" x2="15.01" y1="9" y2="9"/></svg>',
        'music': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>',
        'trophy': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20 7 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"/></svg>',
        'laugh': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M18 13a6 6 0 0 1-6 5 6 6 0 0 1-6-5h12Z"/><line x1="9" x2="9.01" y1="9" y2="9"/><line x1="15" x2="15.01" y1="9" y2="9"/></svg>',
        'tent': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 21 14 3"/><path d="M20.5 21 10 3"/><path d="M15.5 21 12 15l-3.5 6"/><path d="M2 21h20"/></svg>',
        'target': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>',
        'mic': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" x2="12" y1="19" y2="22"/></svg>',
        'building-2': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"/><path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"/><path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"/><path d="M10 6h4"/><path d="M10 10h4"/><path d="M10 14h4"/><path d="M10 18h4"/></svg>',
        'trash-2': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></svg>',
        'flame': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/></svg>',
        'zap': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"/></svg>',
        'gift': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13"/><path d="M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7"/><path d="M7.5 8a2.5 2.5 0 0 1 0-5A4.8 8 0 0 1 12 8a4.8 8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5"/></svg>',
        'user': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
        'heart': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>',
        'lock': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',
        'timer': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><line x1="10" x2="14" y1="2" y2="2"/><line x1="12" x2="15" y1="14" y2="11"/><circle cx="12" cy="14" r="8"/></svg>',
        'armchair': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M19 9V6a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v3"/><path d="M3 16a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-5a2 2 0 0 0-4 0v1.5a.5.5 0 0 1-.5.5h-9a.5.5 0 0 1-.5-.5V11a2 2 0 0 0-4 0z"/><path d="M5 18v2"/><path d="M19 18v2"/></svg>',
        'printer': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6"/><rect x="6" y="14" width="12" height="8" rx="1"/></svg>',
        'party-popper': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M5.8 11.3 2 22l10.7-3.79"/><path d="M4 3h.01"/><path d="M22 8h.01"/><path d="M15 2h.01"/><path d="M22 20h.01"/><path d="m22 2-2.24.75a2.9 2.9 0 0 0-1.96 3.12c.1.86-.57 1.63-1.45 1.63h-.38c-.86 0-1.6.6-1.76 1.44L14 10"/><path d="m22 13-.82-.33c-.86-.34-1.82.2-1.98 1.11c-.11.7-.72 1.22-1.43 1.22H17"/><path d="m11 2 .33.82c.34.86-.2 1.82-1.11 1.98C9.52 4.9 9 5.52 9 6.23V7"/><path d="M11 13c1.93 1.93 2.83 4.17 2 5-.83.83-3.07-.07-5-2-1.93-1.93-2.83-4.17-2-5 .83-.83 3.07.07 5 2Z"/></svg>',
        'file-text': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/></svg>',
        'move-h': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 8 22 12 18 16"/><polyline points="6 8 2 12 6 16"/><line x1="2" x2="22" y1="12" y2="12"/></svg>',
        'projector': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M5 7 3 5"/><path d="M9 6V3"/><path d="m13 7 2-2"/><circle cx="9" cy="13" r="3"/><path d="M11.83 12H20a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h2.17"/><path d="M16 16h2"/></svg>',
        'wrench': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>',
        'popcorn': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a2 2 0 0 0 0-4 2 2 0 0 0-4 0 2 2 0 0 0-4 0 2 2 0 0 0-4 0 2 2 0 0 0 0 4"/><path d="M10 22 9 8"/><path d="m14 22 1-14"/><path d="M5 8h14l-1.5 14h-11z"/></svg>',
        'clapperboard': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M7 3v18"/><path d="M17 3v18"/><path d="M3 7h4"/><path d="M17 7h4"/><path d="M3 12h18"/><path d="M3 17h4"/><path d="M17 17h4"/></svg>',
        'users': '<svg class="' + cls + '" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
    };
    return icons[name] || `<span class="${cls}"></span>`;
}

// ============================================
// Export (for module bundlers or global scope)
// ============================================

// ============================================
// Shared Utilities
// ============================================

/**
 * Escapes HTML entities to prevent XSS in template literals.
 * Centralised here so every page can use JayShow.escapeHtml()
 * instead of duplicating the function.
 *
 * @param {string} text - Text to escape
 * @returns {string} Escaped text
 */
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

/**
 * Sanitizes an HTML string using DOMPurify if loaded, or strips scripts as a fallback.
 * Allows safe rendering of trusted markup with dynamic content.
 *
 * @param {string} html - HTML string to sanitize
 * @returns {string} Sanitized HTML string
 */
function sanitize(html) {
    if (!html) return '';
    if (window.DOMPurify) {
        return window.DOMPurify.sanitize(html);
    }
    // Fallback: strip script tags to prevent immediate script execution if CDN is down/delayed
    console.warn('[JayShow] DOMPurify not loaded yet, using fallback regex sanitizer');
    return html.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
}

const DEBUG = false; // set true locally only
function debugLog(...args) { if (DEBUG) console.log(...args); }
// Make functions available globally for vanilla JS usage
Object.assign(window.JayShow, {
    // Configuration
    SUPABASE_URL,
    
    // Client
    getSupabaseClient,
    getAnonKey: () => SUPABASE_ANON_KEY,

    // Auth
    getUser,
    signIn,
    signUp,
    signOut,
    onAuthStateChange,

    // Guest Session
    getGuestSessionId,

    // Booking
    lockSeat,
    unlockBooking,

    // Seat States
    fetchSeatStates,
    subscribeBookings,

    // Seat Cleanup & Extension
    cleanupExpiredLocks,
    forceReleaseAllLocks,
    extendLocks,

    // Data Fetching
    fetchMovies,
    fetchMovie,
    fetchShowsForMovie,
    fetchShow,
    fetchUserBookings,
    fetchScreenLayout,

    // Theater Owner
    isTheaterOwner,
    getUserRole,
    fetchOwnedTheatres,

    // Events
    fetchEvents,
    fetchEvent,
    fetchEventShows,
    fetchEventShow,
    lockEventSeat,
    fetchEventSeatStates,
    subscribeEventBookings,

    // Icons
    icon,

    // Shared Utilities
    escapeHtml,
    sanitize,
    debugLog,

    showToast(message, type = 'info', duration = 4000) {
        const existing = document.getElementById('qmt-toast');
        if (existing) existing.remove();
        
        const toast = document.createElement('div');
        toast.id = 'qmt-toast';
        toast.style.cssText = `
            position: fixed;
            bottom: 80px;
            left: 50%;
            transform: translateX(-50%);
            background: ${type === 'error' ? '#ef4444' : 'var(--bg-card)'};
            color: white;
            padding: 12px 24px;
            border-radius: 999px;
            font-size: 0.875rem;
            font-weight: 500;
            z-index: 9999;
            box-shadow: 0 8px 32px rgba(0,0,0,0.4);
            animation: slideUp 0.3s ease;
            max-width: 90vw;
            text-align: center;
        `;
        toast.textContent = message;
        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), duration);
    },

    // UI Helpers (Moved to global scope)
    updateNavbar: async function() {
        const navbarUser = document.getElementById('navbar-user');
        const loginLink = document.getElementById('login-link');
        const logoutBtn = document.getElementById('logout-btn');
        const adminLink = document.getElementById('admin-link');
        const ownerLink = document.getElementById('owner-link');
        const profileLink = document.getElementById('profile-link');

        if (!navbarUser) return;

        const user = await this.getUser();

        if (user) {
            // User is logged in
            if (loginLink) loginLink.classList.add('hidden');
            if (logoutBtn) logoutBtn.classList.remove('hidden');
            if (profileLink) profileLink.classList.remove('hidden');

            // Show user email
            const emailSpan = navbarUser.querySelector('.user-email');
            if (emailSpan) {
                emailSpan.textContent = user.email;
                emailSpan.classList.remove('hidden');
            }

            // Show admin link if user is admin
            if (adminLink && user.app_metadata?.is_admin === true) {
                adminLink.classList.remove('hidden');
            }

            // Show owner link if user is a theater owner
            if (ownerLink) {
                try {
                    const isOwner = await this.isTheaterOwner();
                    if (isOwner) {
                        ownerLink.classList.remove('hidden');
                    }
                } catch (error) {
                    console.error('Error checking owner status:', error);
                }
            }

            // Attach logout handler
            if (logoutBtn && !logoutBtn.dataset.hasHandler) {
                logoutBtn.addEventListener('click', async () => {
                    const { error } = await this.signOut();
                    if (!error) window.location.reload();
                });
                logoutBtn.dataset.hasHandler = 'true';
            }

            // Mobile Profile Link
            const mobileProfileLink = document.getElementById('mobile-profile-link');
            if (mobileProfileLink) {
                mobileProfileLink.href = 'profile.html';
                const label = mobileProfileLink.querySelector('span:not(.nav-icon)') || mobileProfileLink;
                if (label && label.lastChild && label.lastChild.nodeType === Node.TEXT_NODE) {
                    label.lastChild.textContent = ' Profile';
                }
            }
        } else {
            // User is not logged in
            if (loginLink) loginLink.classList.remove('hidden');
            if (logoutBtn) logoutBtn.classList.add('hidden');
            if (adminLink) adminLink.classList.add('hidden');
            if (ownerLink) ownerLink.classList.add('hidden');
            if (profileLink) profileLink.classList.add('hidden');

            const emailSpan = navbarUser.querySelector('.user-email');
            if (emailSpan) {
                emailSpan.classList.add('hidden');
                emailSpan.textContent = '';
            }

            // Mobile Profile Link
            const mobileProfileLink = document.getElementById('mobile-profile-link');
            if (mobileProfileLink) {
                mobileProfileLink.href = 'login.html';
                const label = mobileProfileLink.querySelector('span:not(.nav-icon)') || mobileProfileLink;
                if (label && label.lastChild && label.lastChild.nodeType === Node.TEXT_NODE) {
                    label.lastChild.textContent = ' Profile';
                }
            }
        }

        // Highlight active mobile nav tab
        this.updateMobileNavActiveState();
    },

    /**
     * Updates the active class on mobile bottom navigation based on current path
     */
    updateMobileNavActiveState() {
        const mobileNav = document.getElementById('mobile-nav');
        if (!mobileNav) return;

        const links = mobileNav.querySelectorAll('a');
        const currentPath = window.location.pathname;
        const page = currentPath.split('/').pop() || 'index.html';

        links.forEach(link => {
            const href = link.getAttribute('href');
            const isActive = href === page || 
                             (page === 'movie.html' && href === 'index.html') || 
                             (page === 'seats.html' && href === 'index.html') ||
                             (page === 'profile.html' && href === 'profile.html');
            
            if (isActive) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    }
});



// ============================================
// PWA Service Worker Registration
// ============================================
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then((registration) => {
                console.log('[PWA] Service Worker registered, scope:', registration.scope);
            })
            .catch((err) => {
                // Silently fail - expected on file:// protocol
                console.log('[PWA] Service Worker registration skipped:', err.message);
            });
    });
}

// Global error handler — catches silent Supabase failures
window.addEventListener('unhandledrejection', (event) => {
    const reason = event.reason;
    const message = reason?.message || 'Something went wrong';
    
    // Don't show toast for cancelled payments or auth redirects
    if (message.includes('cancelled') || 
        message.includes('AbortError') ||
        message.includes('JWT')) return;
    
    // Show a non-blocking toast notification
    JayShow.showToast('Connection error. Please check your network.', 'error');
    
    if (typeof DEBUG !== 'undefined' && DEBUG) console.error('Unhandled rejection:', reason);
});

window.addEventListener('error', (event) => {
    if (typeof DEBUG !== 'undefined' && DEBUG) console.error('Global error:', event.error);
});
