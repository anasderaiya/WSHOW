/**
 * Quick My Ticket - Admin Panel Logic
 * ====================================
 * 
 * Handles admin CRUD operations:
 * - Create theatres
 * - Create screens with seat configuration
 * - Auto-generate seats
 * - Add movies
 * - Create shows
 * 
 * NOTE: Client-side admin check is for UX only.
 * Server-side RLS policies must enforce admin access.
 */


// ============================================
// State Management
// ============================================
let editingId = null;
let editingType = null;

document.addEventListener('DOMContentLoaded', async () => {
    await initAdminPage();
});

/**
 * Initializes the admin page with access control.
 */
async function initAdminPage() {
    const adminContent = document.getElementById('admin-content');
    const accessDenied = document.getElementById('access-denied');

    // Check if user is admin
    const user = await JayShow.getUser();

    if (!user) {
        // Redirect to admin-specific login page
        window.location.href = 'admin-login.html';
        return;
    }

    const isAdmin = user.app_metadata?.is_admin === true;

    if (!isAdmin) {
        if (adminContent) adminContent.classList.add('hidden');
        if (accessDenied) accessDenied.classList.remove('hidden');
        return;
    }

    // User is admin - show content and initialize forms
    if (adminContent) adminContent.classList.remove('hidden');
    if (accessDenied) accessDenied.classList.add('hidden');

    // Load existing data for dropdowns
    await Promise.all([
        loadOverviewStats(),
        loadOwnerRevenueBreakdown(),
        loadTheatres(),
        loadMovies(),
        loadOwnerApplications()
    ]);

    // Setup form handlers
    setupForms();
}

// ============================================
// Data Loading
// ============================================

/**
 * Loads theatres and populates dropdowns.
 */
async function loadTheatres() {
    const client = JayShow.getSupabaseClient();
    const { data: theatres, error } = await client
        .from('theatres')
        .select('*')
        .order('name');

    if (error) {
        console.error('Error loading theatres:', error);
        return;
    }

    // Populate theatre dropdown
    const theatreSelect = document.getElementById('theatre-select');
    if (theatreSelect) {
        theatreSelect.innerHTML = '<option value="">Select Theatre</option>' +
            theatres.map(t => `<option value="${t.id}">${escapeHtml(t.name)}</option>`).join('');
    }

    // Also load screens
    await loadScreens();

    // Update theatre list display
    updateTheatreList(theatres);
}

/**
 * Loads screens for the selected theatre.
 */
async function loadScreens(theatreId = null) {
    const client = JayShow.getSupabaseClient();

    let query = client.from('screens').select('*, theatres(name)').order('name');
    if (theatreId) {
        query = query.eq('theatre_id', theatreId);
    }

    const { data: screens, error } = await query;

    if (error) {
        console.error('Error loading screens:', error);
        return;
    }

    // Populate screen dropdown for shows
    const screenSelect = document.getElementById('screen-select');
    if (screenSelect) {
        screenSelect.innerHTML = '<option value="">Select Screen</option>' +
            screens.map(s => `<option value="${s.id}">${escapeHtml(s.theatres?.name)} - ${escapeHtml(s.name)}</option>`).join('');
    }

    updateScreenList(screens);
}

/**
 * Loads platform-wide financial stats
 */
async function loadOverviewStats() {
    const client = JayShow.getSupabaseClient();
    try {
        const { data, error } = await client.rpc('get_admin_dashboard_stats');
        if (error) throw error;

        const stats = data?.[0] || {};
        
        animateAdminStatUpdate('admin-total-revenue', `₹${parseFloat(stats.total_revenue || 0).toLocaleString()}`);
        animateAdminStatUpdate('admin-today-revenue', `₹${parseFloat(stats.today_revenue || 0).toLocaleString()}`);
        animateAdminStatUpdate('admin-total-bookings', parseInt(stats.total_bookings || 0).toLocaleString());
        animateAdminStatUpdate('admin-active-locks', parseInt(stats.active_locks || 0).toLocaleString());

    } catch (err) {
        console.error('Error loading overview stats:', err);
    }
}

/**
 * Loads revenue breakdown per theater owner
 */
async function loadOwnerRevenueBreakdown() {
    const listContainer = document.getElementById('owner-revenue-list');
    const startDate = document.getElementById('revenue-start-date').value;
    const endDate = document.getElementById('revenue-end-date').value;

    if (listContainer) listContainer.innerHTML = '<p class="text-muted">Loading financials...</p>';

    try {
        const client = JayShow.getSupabaseClient();
        const { data: owners, error } = await client.rpc('get_admin_owner_revenue_breakdown', {
            p_start_date: startDate || null,
            p_end_date: endDate || null
        });

        if (error) throw error;

        if (!owners || owners.length === 0) {
            listContainer.innerHTML = '<p class="text-muted" style="padding: 2rem; text-align: center;">No revenue data found for selected criteria</p>';
            return;
        }

        listContainer.innerHTML = `
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Owner</th>
                        <th>Theatres</th>
                        <th>Bookings</th>
                        <th>Total Revenue</th>
                        <th>Progress</th>
                    </tr>
                </thead>
                <tbody>
                    ${owners.map(o => {
                        const maxRevenue = Math.max(...owners.map(x => x.revenue)) || 1;
                        const percent = (o.revenue / maxRevenue) * 100;
                        return `
                            <tr>
                                <td>
                                    <div style="font-weight: 600;">${escapeHtml(o.owner_name)}</div>
                                    <div style="font-size: 0.75rem; color: #64748b;">${escapeHtml(o.owner_email)}</div>
                                </td>
                                <td style="max-width: 250px; font-size: 0.8rem; color: #64748b;">${escapeHtml(o.theatre_names)}</td>
                                <td>${o.booking_count}</td>
                                <td style="font-weight: 700;">₹${parseFloat(o.revenue || 0).toLocaleString()}</td>
                                <td style="width: 150px;">
                                    <div style="height: 6px; width: 100%; background: #f1f5f9; border-radius: 3px; overflow: hidden;">
                                        <div style="height: 100%; width: ${percent}%; background: var(--primary);"></div>
                                    </div>
                                </td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        `;

    } catch (err) {
        console.error('Error loading owner breakdown:', err);
        if (listContainer) listContainer.innerHTML = '<p class="text-danger">Failed to load financial breakdown</p>';
    }
}

/**
 * Animated stat update helper
 */
function animateAdminStatUpdate(id, newValue) {
    const el = document.getElementById(id);
    if (!el) return;
    
    el.style.opacity = '0';
    el.style.transform = 'translateY(10px)';
    
    setTimeout(() => {
        el.textContent = newValue;
        el.style.transition = 'all 0.4s cubic-bezier(0.17, 0.67, 0.83, 0.67)';
        el.style.opacity = '1';
        el.style.transform = 'translateY(0)';
    }, 200);
}

window.loadOverviewStats = loadOverviewStats;
window.loadOwnerRevenueBreakdown = loadOwnerRevenueBreakdown;


/**
 * Loads movies and populates dropdowns.
 */
async function loadMovies() {
    const { data: movies, error } = await JayShow.fetchMovies();

    if (error) {
        console.error('Error loading movies:', error);
        return;
    }

    // Populate movie dropdown
    const movieSelect = document.getElementById('movie-select');
    if (movieSelect) {
        movieSelect.innerHTML = '<option value="">Select Movie</option>' +
            movies.map(m => `<option value="${m.id}">${escapeHtml(m.title)}</option>`).join('');
    }

    updateMovieList(movies);
}

/**
 * Loads pending owner applications.
 */
async function loadOwnerApplications() {
    const listContainer = document.getElementById('applications-list');
    if (!listContainer) return;

    const client = JayShow.getSupabaseClient();

    try {
        const { data, error } = await client.rpc('get_pending_applications');

        if (error) {
            console.log('Note: Owner applications table may not exist yet');
            listContainer.innerHTML = '<p style="color: var(--text-muted);">No pending applications</p>';
            return;
        }

        if (!data || data.length === 0) {
            listContainer.innerHTML = '<p style="color: var(--text-muted);">No pending applications</p>';
            return;
        }

        listContainer.innerHTML = `
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Theatre</th>
                        <th>Location</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    ${data.map(app => `
                        <tr data-id="${app.id}">
                            <td>${new Date(app.created_at).toLocaleDateString()}</td>
                            <td>${escapeHtml(app.full_name)}</td>
                            <td>${escapeHtml(app.email)}</td>
                            <td>${escapeHtml(app.theatre_name)}</td>
                            <td>${escapeHtml(app.theatre_location)}</td>
                            <td>
                                <button class="btn btn-success btn-sm" onclick="approveApplication('${app.id}')">
                                    ✓ Approve
                                </button>
                                <button class="btn btn-danger btn-sm" onclick="rejectApplication('${app.id}')">
                                    ✗ Reject
                                </button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    } catch (err) {
        console.error('Error loading applications:', err);
        listContainer.innerHTML = '<p style="color: var(--text-muted);">Could not load applications</p>';
    }
}

/**
 * Approves an owner application.
 */
async function approveApplication(appId) {
    if (!confirm('Approve this application? This will create a theatre and owner account.')) return;

    const client = JayShow.getSupabaseClient();
    const { data, error } = await client.rpc('approve_owner_application', {
        p_application_id: appId,
        p_admin_notes: 'Approved by admin'
    });

    if (error) {
        alert('Error: ' + error.message);
        return;
    }

    if (data && !data.success) {
        alert('Error: ' + data.error);
        return;
    }

    alert('Application approved! Theatre created successfully.');
    loadOwnerApplications();
    loadTheatres(); // Refresh theatres list
}

/**
 * Rejects an owner application.
 */
async function rejectApplication(appId) {
    const reason = prompt('Reason for rejection (optional):');
    if (reason === null) return; // Cancelled

    const client = JayShow.getSupabaseClient();
    const { data, error } = await client.rpc('reject_owner_application', {
        p_application_id: appId,
        p_admin_notes: reason || 'Application rejected'
    });

    if (error) {
        alert('Error: ' + error.message);
        return;
    }

    if (data && !data.success) {
        alert('Error: ' + data.error);
        return;
    }

    alert('Application rejected.');
    loadOwnerApplications();
}

// Make functions available globally
window.approveApplication = approveApplication;
window.rejectApplication = rejectApplication;

/**
 * Sets up tab switching logic
 */
function setupTabs() {
    const tabs = document.querySelectorAll('.admin-tab-btn');
    const groups = document.querySelectorAll('.admin-entity-group');

    tabs.forEach(tab => {
        // Inject icons once on initialization
        const iconName = tab.dataset.icon;
        if (iconName && !tab.querySelector('svg')) {
            const label = tab.textContent.trim();
            const iconHtml = JayShow.icon(iconName, 'inline-icon');
            tab.innerHTML = `${iconHtml} <span>${label}</span>`;
        }

        tab.addEventListener('click', () => {
            const target = tab.dataset.tab;

            // Update tab UI
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');

            // Update group UI
            groups.forEach(group => {
                if (group.id === target) {
                    group.classList.add('active');
                } else {
                    group.classList.remove('active');
                }
            });
        });
    });
}

// ============================================
// Form Handlers
// ============================================

/**
 * Sets up all form submission handlers.
 */
function setupForms() {
    // Theatre form
    const theatreForm = document.getElementById('theatre-form');
    if (theatreForm) {
        theatreForm.addEventListener('submit', handleCreateTheatre);
    }

    // Screen form
    const screenForm = document.getElementById('screen-form');
    if (screenForm) {
        screenForm.addEventListener('submit', handleCreateScreen);
    }

    // Movie form
    const movieForm = document.getElementById('movie-form');
    if (movieForm) {
        movieForm.addEventListener('submit', handleCreateMovie);
    }

    // Show form
    const showForm = document.getElementById('show-form');
    if (showForm) {
        showForm.addEventListener('submit', handleCreateShow);
    }

    // Event form
    const eventForm = document.getElementById('event-form');
    if (eventForm) {
        eventForm.addEventListener('submit', handleCreateEvent);
    }

    // Event show form
    const eventShowForm = document.getElementById('event-show-form');
    if (eventShowForm) {
        eventShowForm.addEventListener('submit', handleCreateEventShow);
    }

    // Theatre selection change
    const theatreSelect = document.getElementById('theatre-select');
    if (theatreSelect) {
        theatreSelect.addEventListener('change', (e) => {
            loadScreens(e.target.value || null);
        });
    }

    // Movie show list listener
    const movieSelect = document.getElementById('movie-select');
    if (movieSelect) {
        movieSelect.onchange = () => loadMovieShows(movieSelect.value);
    }

    // Event show list listener
    const eventSelect = document.getElementById('event-select');
    if (eventSelect) {
        eventSelect.onchange = () => loadEventShows(eventSelect.value);
    }

    // Load events data
    loadEvents();

    // Setup tabs
    setupTabs();
}

/**
 * Handles theatre creation.
 * 
 * @param {Event} e - Form submit event
 */
async function handleCreateTheatre(e) {
    e.preventDefault();
    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');

    const name = document.getElementById('theatre-name').value.trim();
    const location = document.getElementById('theatre-location').value.trim();
    const razorpay_account_id = document.getElementById('theatre-razorpay')?.value.trim() || null;

    if (!name) {
        showFormError(form, 'Theatre name is required');
        return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = 'Creating...';

    try {
        const client = JayShow.getSupabaseClient();
        const { data, error } = editingId && editingType === 'theatre'
            ? await client.from('theatres').update({ name, location, razorpay_account_id }).eq('id', editingId).select().single()
            : await client.from('theatres').insert({ name, location, razorpay_account_id }).select().single();

        if (error) throw error;

        showFormSuccess(form, `Theatre "${name}" ${editingId ? 'updated' : 'created'} successfully!`);
        cancelEdit('theatre');
        await loadTheatres();

    } catch (err) {
        showFormError(form, err.message);
    } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Create Theatre';
    }
}

/**
 * Handles screen creation with auto-generated seats.
 * 
 * @param {Event} e - Form submit event
 */
async function handleCreateScreen(e) {
    e.preventDefault();
    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');

    const theatreId = document.getElementById('theatre-select').value;
    const name = document.getElementById('screen-name').value.trim();
    const rows = parseInt(document.getElementById('seat-rows').value) || 10;
    const cols = parseInt(document.getElementById('seat-cols').value) || 15;
    const regularPrice = parseFloat(document.getElementById('regular-price').value) || 150;
    const premiumPrice = parseFloat(document.getElementById('premium-price').value) || 250;
    const vipPrice = parseFloat(document.getElementById('vip-price').value) || 400;

    if (!theatreId || !name) {
        showFormError(form, 'Please select a theatre and enter screen name');
        return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = 'Creating...';

    try {
        const client = JayShow.getSupabaseClient();

        if (editingId && editingType === 'screen') {
            const { data, error } = await client
                .from('screens')
                .update({ theatre_id: theatreId, name })
                .eq('id', editingId)
                .select()
                .single();
            if (error) throw error;
            showFormSuccess(form, `Screen "${name}" updated successfully!`);
        } else {
            // Create screen (original logic)
            const { data: screen, error: screenError } = await client
                .from('screens')
                .insert({
                    theatre_id: theatreId,
                    name,
                    total_seats: rows * cols
                })
                .select()
                .single();

            if (screenError) throw screenError;

            // Generate seats and initial layout
            const seats = [];
            const layoutRows = [];
            const rowLabels = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

            for (let r = 0; r < rows; r++) {
                const rowLabel = rowLabels[r] || `R${r + 1}`;
                const rowSeats = [];
                for (let c = 1; c <= cols; c++) {
                    let tier = 'regular';
                    let price = regularPrice;
                    if (r >= rows - 2) { tier = 'vip'; price = vipPrice; }
                    else if (r >= Math.floor(rows / 2)) { tier = 'premium'; price = premiumPrice; }
                    seats.push({ screen_id: screen.id, row: rowLabel, col: c, tier, price });
                    rowSeats.push({ id: c, type: tier, price: price });
                }
                layoutRows.push({ label: rowLabel, seats: rowSeats });
            }

            const initialLayout = {
                rows: layoutRows,
                metadata: { totalSeats: seats.length, rowCount: rows, maxSeatsPerRow: cols }
            };

            await client.from('screens').update({ seat_layout: initialLayout }).eq('id', screen.id);
            const { error: seatsError } = await client.from('seats').insert(seats);
            if (seatsError) throw seatsError;

            showFormSuccess(form, `Screen "${name}" created with ${seats.length} seats!`);
        }

        cancelEdit('screen');
        await loadScreens();

    } catch (err) {
        showFormError(form, err.message);
    } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = editingId ? 'Update Screen' : 'Create Screen & Seats';
    }
}

/**
 * Handles movie creation.
 * 
 * @param {Event} e - Form submit event
 */
async function handleCreateMovie(e) {
    e.preventDefault();
    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');

    const title = document.getElementById('movie-title').value.trim();
    const description = document.getElementById('movie-description').value.trim();
    const posterUrl = document.getElementById('movie-poster').value.trim();
    const duration = parseInt(document.getElementById('movie-duration').value) || null;
    const genre = document.getElementById('movie-genre').value.trim();
    const rating = parseFloat(document.getElementById('movie-rating').value) || null;
    const releaseDate = document.getElementById('movie-release').value || null;

    if (!title) {
        showFormError(form, 'Movie title is required');
        return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = 'Adding...';

    try {
        const client = JayShow.getSupabaseClient();
        const { data, error } = editingId && editingType === 'movie'
            ? await client.from('movies').update({
                title,
                description,
                poster_url: posterUrl,
                duration_minutes: duration,
                genre,
                rating,
                release_date: releaseDate
            }).eq('id', editingId).select().single()
            : await client.from('movies').insert({
                title,
                description,
                poster_url: posterUrl,
                duration_minutes: duration,
                genre,
                rating,
                release_date: releaseDate
            }).select().single();

        if (error) throw error;

        showFormSuccess(form, `Movie "${title}" ${editingId ? 'updated' : 'added'} successfully!`);
        cancelEdit('movie');
        await loadMovies();

    } catch (err) {
        showFormError(form, err.message);
    } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Add Movie';
    }
}

/**
 * Handles show creation.
 * 
 * @param {Event} e - Form submit event
 */
async function handleCreateShow(e) {
    e.preventDefault();
    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');

    const movieId = document.getElementById('movie-select').value;
    const screenId = document.getElementById('screen-select').value;
    const startTime = document.getElementById('show-start').value;
    const endTime = document.getElementById('show-end').value;
    const price = parseFloat(document.getElementById('show-price').value) || 200;

    if (!movieId || !screenId || !startTime) {
        showFormError(form, 'Please fill all required fields');
        return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = 'Creating...';

    try {
        const client = JayShow.getSupabaseClient();
        const { data, error } = editingId && editingType === 'movie-show'
            ? await client
                .from('shows')
                .update({
                    movie_id: movieId,
                    screen_id: screenId,
                    start_time: new Date(startTime).toISOString(),
                    end_time: endTime ? new Date(endTime).toISOString() : null,
                    price
                })
                .eq('id', editingId)
                .select()
                .single()
            : await client
                .from('shows')
                .insert({
                    movie_id: movieId,
                    screen_id: screenId,
                    start_time: new Date(startTime).toISOString(),
                    end_time: endTime ? new Date(endTime).toISOString() : null,
                    price
                })
                .select()
                .single();

        if (error) throw error;

        showFormSuccess(form, `Show ${editingId ? 'updated' : 'created'} successfully!`);
        cancelEdit('show');
        await loadMovieShows(movieId);

    } catch (err) {
        showFormError(form, err.message);
    } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = editingId ? 'Update Show' : 'Create Show';
    }
}

// ============================================
// UI Updates
// ============================================

/**
 * Loads shows for a specific movie.
 * @param {string} movieId 
 */
async function loadMovieShows(movieId) {
    const listContainer = document.getElementById('movie-show-list');
    if (!listContainer) return;

    if (!movieId) {
        listContainer.innerHTML = '<p style="color: var(--text-muted);">Select a movie to see its shows</p>';
        return;
    }

    const client = JayShow.getSupabaseClient();
    const { data: shows, error } = await client
        .from('shows')
        .select('*, screens(name, theatres(name))')
        .eq('movie_id', movieId)
        .order('start_time');

    if (error) {
        console.error('Error loading shows:', error);
        listContainer.innerHTML = '<p style="color: var(--text-muted);">Error loading shows</p>';
        return;
    }

    updateMovieShowList(shows || []);
}

/**
 * Updates the movie show list display.
 * @param {Array} shows 
 */
function updateMovieShowList(shows) {
    const listContainer = document.getElementById('movie-show-list');
    if (!listContainer) return;

    if (!shows || shows.length === 0) {
        listContainer.innerHTML = '<p style="color: var(--text-muted);">No shows for this movie</p>';
        return;
    }

    listContainer.innerHTML = `
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Date/Time</th>
                    <th>Venue</th>
                    <th>Price</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                ${shows.map(s => `
                    <tr>
                        <td>${new Date(s.start_time).toLocaleString()}</td>
                        <td>${escapeHtml(s.screens?.theatres?.name || '')} - ${escapeHtml(s.screens?.name || '')}</td>
                        <td>₹${s.price}</td>
                        <td>
                            <div class="table-actions">
                                <button class="btn btn-ghost btn-xs" onclick="editMovieShow('${s.id}')">
                                    ${JayShow.icon('wrench', 'inline-icon')}
                                </button>
                                <button class="btn btn-danger btn-xs" onclick="deleteMovieShow('${s.id}', '${s.movie_id}')">
                                    ${JayShow.icon('trash-2', 'inline-icon')}
                                </button>
                            </div>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

/**
 * Updates the theatre list display.
 * 
 * @param {Array} theatres - Array of theatre objects
 */
function updateTheatreList(theatres) {
    const listContainer = document.getElementById('theatre-list');
    if (!listContainer) return;

    if (!theatres || theatres.length === 0) {
        listContainer.innerHTML = '<p style="color: var(--text-muted);">No theatres yet</p>';
        return;
    }

    listContainer.innerHTML = `
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Location</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                ${theatres.map(t => `
                    <tr>
                        <td>${escapeHtml(t.name)}</td>
                        <td>${escapeHtml(t.location || '-')}</td>
                        <td>
                            <div class="table-actions">
                                <button class="btn btn-ghost btn-xs" onclick="editTheatre('${t.id}')">
                                    ${JayShow.icon('wrench', 'inline-icon')}
                                </button>
                                <button class="btn btn-danger btn-xs" onclick="deleteTheatre('${t.id}')">
                                    ${JayShow.icon('trash-2', 'inline-icon')}
                                </button>
                            </div>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

/**
 * Updates the screen list display.
 * 
 * @param {Array} screens - Array of screen objects
 */
function updateScreenList(screens) {
    const listContainer = document.getElementById('screen-list');
    if (!listContainer) return;

    if (!screens || screens.length === 0) {
        listContainer.innerHTML = '<p style="color: var(--text-muted);">No screens yet</p>';
        return;
    }

    listContainer.innerHTML = `
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Theatre</th>
                    <th>Screen</th>
                    <th>Seats</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                ${screens.map(s => `
                    <tr>
                        <td>${escapeHtml(s.theatres?.name || '-')}</td>
                        <td>${escapeHtml(s.name)}</td>
                        <td>${s.total_seats || '-'}</td>
                        <td>
                            <div class="table-actions">
                                <button class="btn btn-ghost btn-xs" onclick="editScreen('${s.id}')">
                                    ${JayShow.icon('wrench', 'inline-icon')}
                                </button>
                                <button class="btn btn-danger btn-xs" onclick="deleteScreen('${s.id}')">
                                    ${JayShow.icon('trash-2', 'inline-icon')}
                                </button>
                            </div>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

/**
 * Updates the movie list display.
 * 
 * @param {Array} movies - Array of movie objects
 */
function updateMovieList(movies) {
    const listContainer = document.getElementById('movie-list');
    if (!listContainer) return;

    if (!movies || movies.length === 0) {
        listContainer.innerHTML = '<p style="color: var(--text-muted);">No movies yet</p>';
        return;
    }

    listContainer.innerHTML = `
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Genre</th>
                    <th>Duration</th>
                    <th>Rating</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                ${movies.map(m => `
                    <tr>
                        <td>${escapeHtml(m.title)}</td>
                        <td>${escapeHtml(m.genre || '-')}</td>
                        <td>${m.duration_minutes ? m.duration_minutes + ' min' : '-'}</td>
                        <td>${m.rating ? '★ ' + parseFloat(m.rating).toFixed(1) : '-'}</td>
                        <td>
                            <div class="table-actions">
                                <button class="btn btn-ghost btn-xs" onclick="editMovie('${m.id}')">
                                    ${JayShow.icon('wrench', 'inline-icon')}
                                </button>
                                <button class="btn btn-danger btn-xs" onclick="deleteMovie('${m.id}')">
                                    ${JayShow.icon('trash-2', 'inline-icon')}
                                </button>
                            </div>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

// ============================================
// Events Management
// ============================================

/**
 * Loads events and populates dropdowns.
 */
async function loadEvents() {
    const { data: events, error } = await JayShow.fetchEvents();

    if (error) {
        console.error('Error loading events:', error);
        updateEventList([]);
        return;
    }

    // Populate event dropdown
    const eventSelect = document.getElementById('event-select');
    if (eventSelect) {
        eventSelect.innerHTML = '<option value="">Select Event</option>' +
            (events || []).map(e => `<option value="${e.id}">${escapeHtml(e.title)} (${e.category})</option>`).join('');
    }

    // Also populate screen dropdown for event shows
    const eventScreenSelect = document.getElementById('event-screen-select');
    if (eventScreenSelect) {
        const client = JayShow.getSupabaseClient();
        const { data: screens } = await client
            .from('screens')
            .select('*, theatres(name)')
            .order('name');

        eventScreenSelect.innerHTML = '<option value="">Select Venue</option>' +
            (screens || []).map(s => `<option value="${s.id}">${escapeHtml(s.theatres?.name)} - ${escapeHtml(s.name)}</option>`).join('');
    }

    updateEventList(events || []);
}

/**
 * Loads event shows for a specific event.
 * @param {string} eventId - Event ID
 */
async function loadEventShows(eventId) {
    const listContainer = document.getElementById('event-show-list');
    if (!listContainer) return;

    if (!eventId) {
        listContainer.innerHTML = '<p style="color: var(--text-muted);">Select an event to see its shows</p>';
        return;
    }

    const client = JayShow.getSupabaseClient();
    const { data: shows, error } = await client
        .from('event_shows')
        .select('*, screens(name, theatres(name))')
        .eq('event_id', eventId)
        .order('start_time');

    if (error) {
        console.error('Error loading event shows:', error);
        listContainer.innerHTML = '<p style="color: var(--text-muted);">Error loading shows</p>';
        return;
    }

    updateEventShowList(shows || []);
}

/**
 * Handles event creation.
 * @param {Event} e - Form submit event
 */
async function handleCreateEvent(e) {
    e.preventDefault();
    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');

    const title = document.getElementById('event-title').value.trim();
    const description = document.getElementById('event-description').value.trim();
    const category = document.getElementById('event-category').value;
    const organizer = document.getElementById('event-organizer').value.trim();
    const venueName = document.getElementById('event-venue').value.trim();
    const city = document.getElementById('event-city').value.trim();
    const posterUrl = document.getElementById('event-poster').value.trim();
    const tagsInput = document.getElementById('event-tags').value.trim();
    const isFeatured = document.getElementById('event-featured').checked;

    if (!title || !category) {
        showFormError(form, 'Event title and category are required');
        return;
    }

    // Parse tags
    const tags = tagsInput ? tagsInput.split(',').map(t => t.trim()).filter(t => t) : [];

    submitBtn.disabled = true;
    submitBtn.textContent = 'Adding...';

    try {
        const client = JayShow.getSupabaseClient();
        const { data, error } = editingId && editingType === 'event'
            ? await client
                .from('events')
                .update({
                    title,
                    description,
                    category,
                    organizer,
                    venue_name: venueName,
                    city,
                    poster_url: posterUrl,
                    tags,
                    is_featured: isFeatured,
                    status: 'upcoming'
                })
                .eq('id', editingId)
                .select()
                .single()
            : await client
                .from('events')
                .insert({
                    title,
                    description,
                    category,
                    organizer,
                    venue_name: venueName,
                    city,
                    poster_url: posterUrl,
                    tags,
                    is_featured: isFeatured,
                    status: 'upcoming'
                })
                .select()
                .single();

        if (error) throw error;

        showFormSuccess(form, `Event "${title}" ${editingId ? 'updated' : 'added'} successfully!`);
        cancelEdit('event');
        await loadEvents();

    } catch (err) {
        showFormError(form, err.message);
    } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = editingId ? 'Update Event' : 'Add Event';
    }
}

/**
 * Handles event show creation.
 * @param {Event} e - Form submit event
 */
async function handleCreateEventShow(e) {
    e.preventDefault();
    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');

    const eventId = document.getElementById('event-select').value;
    const screenId = document.getElementById('event-screen-select').value;
    const startTime = document.getElementById('event-show-start').value;
    const endTime = document.getElementById('event-show-end').value;
    const price = parseFloat(document.getElementById('event-show-price').value) || 499;

    if (!eventId || !screenId || !startTime) {
        showFormError(form, 'Please fill all required fields');
        return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = 'Creating...';

    try {
        const client = JayShow.getSupabaseClient();
        const { data, error } = editingId && editingType === 'event-show'
            ? await client
                .from('event_shows')
                .update({
                    event_id: eventId,
                    screen_id: screenId,
                    start_time: new Date(startTime).toISOString(),
                    end_time: endTime ? new Date(endTime).toISOString() : null,
                    price,
                    status: 'scheduled'
                })
                .eq('id', editingId)
                .select()
                .single()
            : await client
                .from('event_shows')
                .insert({
                    event_id: eventId,
                    screen_id: screenId,
                    start_time: new Date(startTime).toISOString(),
                    end_time: endTime ? new Date(endTime).toISOString() : null,
                    price,
                    status: 'scheduled'
                })
                .select()
                .single();

        if (error) throw error;

        showFormSuccess(form, `Event show ${editingId ? 'updated' : 'created'} successfully!`);
        cancelEdit('event-show');
        await loadEventShows(eventId);

    } catch (err) {
        showFormError(form, err.message);
    } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = editingId ? 'Update Event Show' : 'Create Event Show';
    }
}

/**
 * Updates the event list display.
 * @param {Array} events - Array of event objects
 */
function updateEventList(events) {
    const listContainer = document.getElementById('event-list');
    if (!listContainer) return;

    if (!events || events.length === 0) {
        listContainer.innerHTML = '<p style="color: var(--text-muted);">No events yet</p>';
        return;
    }

    listContainer.innerHTML = `
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Category</th>
                    <th>City</th>
                    <th>Featured</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                ${events.map(e => `
                    <tr>
                        <td>${escapeHtml(e.title)}</td>
                        <td>${escapeHtml(e.category)}</td>
                        <td>${escapeHtml(e.city || '-')}</td>
                        <td>${e.is_featured ? '⭐' : '-'}</td>
                        <td>
                            <div class="table-actions">
                                <button class="btn btn-ghost btn-xs" onclick="editEvent('${e.id}')">
                                    ${JayShow.icon('wrench', 'inline-icon')}
                                </button>
                                <button class="btn btn-danger btn-xs" onclick="deleteEvent('${e.id}')">
                                    ${JayShow.icon('trash-2', 'inline-icon')}
                                </button>
                            </div>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

/**
 * Updates the event show list display.
 * @param {Array} shows - Array of event show objects
 */
function updateEventShowList(shows) {
    const listContainer = document.getElementById('event-show-list');
    if (!listContainer) return;

    if (!shows || shows.length === 0) {
        listContainer.innerHTML = '<p style="color: var(--text-muted);">No shows for this event</p>';
        return;
    }

    listContainer.innerHTML = `
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Date/Time</th>
                    <th>Venue</th>
                    <th>Price</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                ${shows.map(s => `
                    <tr>
                        <td>${new Date(s.start_time).toLocaleString()}</td>
                        <td>${escapeHtml(s.screens?.theatres?.name || '')} - ${escapeHtml(s.screens?.name || '')}</td>
                        <td>₹${s.price}</td>
                        <td>
                            <div class="table-actions">
                                <button class="btn btn-ghost btn-xs" onclick="editEventShow('${s.id}')">
                                    ${JayShow.icon('wrench', 'inline-icon')}
                                </button>
                                <button class="btn btn-danger btn-xs" onclick="deleteEventShow('${s.id}', '${s.event_id}')">
                                    ${JayShow.icon('trash-2', 'inline-icon')}
                                </button>
                            </div>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

// ============================================
// Form Feedback
// ============================================

/**
 * Shows an error message on a form.
 * 
 * @param {HTMLElement} form - Form element
 * @param {string} message - Error message
 */
function showFormError(form, message) {
    clearFormFeedback(form);
    const feedback = document.createElement('div');
    feedback.className = 'alert alert-error form-feedback';
    feedback.textContent = message;
    form.insertBefore(feedback, form.firstChild);
}

/**
 * Shows a success message on a form.
 * 
 * @param {HTMLElement} form - Form element
 * @param {string} message - Success message
 */
function showFormSuccess(form, message) {
    clearFormFeedback(form);
    const feedback = document.createElement('div');
    feedback.className = 'alert alert-success form-feedback';
    feedback.textContent = message;
    form.insertBefore(feedback, form.firstChild);

    // Auto-clear after 3 seconds
    setTimeout(() => feedback.remove(), 3000);
}

/**
 * Clears form feedback messages.
 * 
 * @param {HTMLElement} form - Form element
 */
function clearFormFeedback(form) {
    const existing = form.querySelector('.form-feedback');
    if (existing) existing.remove();
}

/**
 * Deletes an event
 * @param {string} eventId 
 */
async function deleteEvent(eventId) {
    if (!confirm('Are you sure you want to delete this event? This will also delete all associated shows.')) return;

    try {
        const client = JayShow.getSupabaseClient();
        const { error } = await client
            .from('events')
            .delete()
            .eq('id', eventId);

        if (error) throw error;

        alert('Event deleted successfully');
        await loadEvents();
    } catch (err) {
        alert('Error deleting event: ' + err.message);
    }
}

/**
 * Deletes an event show
 * @param {string} showId 
 * @param {string} eventId 
 */
async function deleteEventShow(showId, eventId) {
    if (!confirm('Are you sure you want to delete this show?')) return;

    try {
        const client = JayShow.getSupabaseClient();
        const { error } = await client
            .from('event_shows')
            .delete()
            .eq('id', showId);

        if (error) throw error;

        alert('Show deleted successfully');
        await loadEventShows(eventId);
    } catch (err) {
        alert('Error deleting show: ' + err.message);
    }
}

// Make globally available
window.deleteEvent = deleteEvent;
window.deleteEventShow = deleteEventShow;

/**
 * Deletes a movie
 * @param {string} id 
 */
async function deleteMovie(id) {
    if (!confirm('Are you sure you want to delete this movie? This will also remove all associated shows.')) return;

    try {
        const client = JayShow.getSupabaseClient();
        const { error } = await client.from('movies').delete().eq('id', id);
        if (error) throw error;
        alert('Movie deleted successfully');
        await loadMovies();
    } catch (err) {
        alert('Error deleting movie: ' + err.message);
    }
}

/**
 * Deletes a theatre
 * @param {string} id 
 */
async function deleteTheatre(id) {
    if (!confirm('Are you sure you want to delete this theatre? This will remove all its screens, seats, and shows.')) return;

    try {
        const client = JayShow.getSupabaseClient();
        const { error } = await client.from('theatres').delete().eq('id', id);
        if (error) throw error;
        alert('Theatre deleted successfully');
        await loadTheatres();
    } catch (err) {
        alert('Error deleting theatre: ' + err.message);
    }
}

/**
 * Deletes a screen
 * @param {string} id 
 */
async function deleteScreen(id) {
    if (!confirm('Are you sure you want to delete this screen? All associated seats and shows will be removed.')) return;

    try {
        const client = JayShow.getSupabaseClient();
        const { error } = await client.from('screens').delete().eq('id', id);
        if (error) throw error;
        alert('Screen deleted successfully');
        await loadScreens();
    } catch (err) {
        alert('Error deleting screen: ' + err.message);
    }
}

window.deleteMovie = deleteMovie;
window.deleteTheatre = deleteTheatre;
window.deleteScreen = deleteScreen;

/**
 * Deletes a movie show
 * @param {string} id 
 * @param {string} movieId 
 */
async function deleteMovieShow(id, movieId) {
    if (!confirm('Are you sure you want to delete this show?')) return;

    try {
        const client = JayShow.getSupabaseClient();
        const { error } = await client.from('shows').delete().eq('id', id);
        if (error) throw error;
        alert('Show deleted successfully');
        await loadMovieShows(movieId);
    } catch (err) {
        alert('Error deleting show: ' + err.message);
    }
}

/**
 * Prepopulates a form for editing
 * @param {string} id 
 * @param {string} type 
 */
async function editEntity(id, type) {
    editingId = id;
    editingType = type;
    const client = JayShow.getSupabaseClient();

    try {
        let form, data, error;
        if (type === 'theatre') {
            form = document.getElementById('theatre-form');
            ({ data, error } = await client.from('theatres').select('*').eq('id', id).single());
            if (data) {
                document.getElementById('theatre-name').value = data.name;
                document.getElementById('theatre-location').value = data.location || '';
                const rpInput = document.getElementById('theatre-razorpay');
                if (rpInput) rpInput.value = data.razorpay_account_id || '';
            }
        } else if (type === 'movie') {
            form = document.getElementById('movie-form');
            ({ data, error } = await client.from('movies').select('*').eq('id', id).single());
            if (data) {
                document.getElementById('movie-title').value = data.title;
                document.getElementById('movie-description').value = data.description || '';
                document.getElementById('movie-poster').value = data.poster_url || '';
                document.getElementById('movie-duration').value = data.duration_minutes || '';
                document.getElementById('movie-genre').value = data.genre || '';
                document.getElementById('movie-rating').value = data.rating || '';
                document.getElementById('movie-release').value = data.release_date || '';
            }
        } else if (type === 'screen') {
            form = document.getElementById('screen-form');
            ({ data, error } = await client.from('screens').select('*').eq('id', id).single());
            if (data) {
                document.getElementById('theatre-select').value = data.theatre_id;
                document.getElementById('screen-name').value = data.name;
            }
        } else if (type === 'movie-show') {
            form = document.getElementById('show-form');
            ({ data, error } = await client.from('shows').select('*').eq('id', id).single());
            if (data) {
                document.getElementById('movie-select').value = data.movie_id;
                document.getElementById('screen-select').value = data.screen_id;
                document.getElementById('show-start').value = data.start_time ? data.start_time.slice(0, 16) : '';
                document.getElementById('show-end').value = data.end_time ? data.end_time.slice(0, 16) : '';
                document.getElementById('show-price').value = data.price;
            }
        } else if (type === 'event') {
            form = document.getElementById('event-form');
            ({ data, error } = await client.from('events').select('*').eq('id', id).single());
            if (data) {
                document.getElementById('event-title').value = data.title;
                document.getElementById('event-description').value = data.description || '';
                document.getElementById('event-category').value = data.category;
                document.getElementById('event-organizer').value = data.organizer || '';
                document.getElementById('event-venue').value = data.venue_name || '';
                document.getElementById('event-city').value = data.city || '';
                document.getElementById('event-poster').value = data.poster_url || '';
                document.getElementById('event-tags').value = (data.tags || []).join(', ');
                document.getElementById('event-featured').checked = data.is_featured || false;
            }
        } else if (type === 'event-show') {
            form = document.getElementById('event-show-form');
            ({ data, error } = await client.from('event_shows').select('*').eq('id', id).single());
            if (data) {
                document.getElementById('event-select').value = data.event_id;
                document.getElementById('event-screen-select').value = data.screen_id;
                document.getElementById('event-show-start').value = data.start_time ? data.start_time.slice(0, 16) : '';
                document.getElementById('event-show-end').value = data.end_time ? data.end_time.slice(0, 16) : '';
                document.getElementById('event-show-price').value = data.price;
            }
        }

        if (error) throw error;

        // UI Updates for edit mode
        const submitBtn = form.querySelector('button[type="submit"]');
        const entityLabel = type.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
        submitBtn.textContent = `Update ${entityLabel}`;

        // Add cancel button if it doesn't exist
        if (!form.querySelector('.btn-cancel-edit')) {
            const cancelBtn = document.createElement('button');
            cancelBtn.type = 'button';
            cancelBtn.className = 'btn btn-ghost btn-cancel-edit';
            cancelBtn.style.marginLeft = '0.5rem';
            cancelBtn.textContent = 'Cancel';
            cancelBtn.onclick = () => cancelEdit(type);
            submitBtn.parentNode.appendChild(cancelBtn);
        }

        form.scrollIntoView({ behavior: 'smooth' });

    } catch (err) {
        alert('Error loading data for edit: ' + err.message);
        cancelEdit(type);
    }
}



window.editTheatre = (id) => editEntity(id, 'theatre');
window.editMovie = (id) => editEntity(id, 'movie');
window.editScreen = (id) => editEntity(id, 'screen');
window.editMovieShow = (id) => editEntity(id, 'movie-show');
window.editEvent = (id) => editEntity(id, 'event');
window.editEventShow = (id) => editEntity(id, 'event-show');
window.cancelEdit = cancelEdit;
window.deleteMovieShow = deleteMovieShow;
window.deleteMovie = deleteMovie;
window.deleteScreen = deleteScreen;
window.deleteTheatre = deleteTheatre;
window.deleteEvent = deleteEvent;
window.deleteEventShow = deleteEventShow;
window.loadMovieShows = loadMovieShows;
window.loadEventShows = loadEventShows;
window.openTab = openTab;




/**
 * Resets edit mode
 * @param {string} type 
 */
function cancelEdit(type) {
    editingId = null;
    editingType = null;
    
    // Map internal types to form IDs
    let formId = type + '-form';
    if (type === 'movie-show' || type === 'show') formId = 'show-form';
    
    const form = document.getElementById(formId);
    if (form) {
        form.reset();
        const submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn) {
            // Restore default labels
            let label = 'Create';
            if (type === 'theatre') label = 'Create Theatre';
            else if (type === 'movie') label = 'Add Movie';
            else if (type === 'screen') label = 'Create Screen & Seats';
            else if (type === 'movie-show' || type === 'show') label = 'Create Show';
            else if (type === 'event') label = 'Add Event';
            else if (type === 'event-show') label = 'Create Event Show';
            
            submitBtn.textContent = label;
        }

        const cancelBtn = form.querySelector('.btn-cancel-edit');
        if (cancelBtn) cancelBtn.remove();
    }
}

// ============================================
// Platform Settings (Admin)
// ============================================

async function openPlatformSettingsModal() {
    const modal = document.getElementById('platform-settings-modal');
    if (modal) modal.classList.remove('hidden');

    const client = JayShow.getSupabaseClient();
    const { data, error } = await client
        .from('platform_settings')
        .select('*')
        .eq('key', 'convenience_fee')
        .single();

    if (data && data.value) {
        document.getElementById('fee-type').value = data.value.type || 'fixed';
        document.getElementById('fee-amount').value = data.value.amount || 0;
    }
    updateFeePreview();
}

function updateFeePreview() {
    const type = document.getElementById('fee-type')?.value;
    const amount = parseFloat(document.getElementById('fee-amount')?.value) || 0;
    const preview = document.getElementById('fee-preview');
    if (!preview) return;
    
    if (type === 'percentage') {
        preview.innerHTML = `💡 <strong>${amount}%</strong> of ticket subtotal will be added as convenience fee. Example: ₹300 ticket → ₹${(300 * amount / 100).toFixed(0)} fee.`;
    } else {
        preview.innerHTML = `💡 <strong>₹${amount}</strong> flat fee per ticket. Example: 3 tickets → ₹${amount * 3} total fee.`;
    }
}

// Wire up live preview
document.addEventListener('DOMContentLoaded', () => {
    const feeType = document.getElementById('fee-type');
    const feeAmount = document.getElementById('fee-amount');
    if (feeType) feeType.addEventListener('change', updateFeePreview);
    if (feeAmount) feeAmount.addEventListener('input', updateFeePreview);
});

function closePlatformSettingsModal() {
    const modal = document.getElementById('platform-settings-modal');
    if (modal) modal.classList.add('hidden');
}

document.addEventListener('DOMContentLoaded', () => {
    const platformForm = document.getElementById('platform-settings-form');
    if (platformForm) {
        platformForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const submitBtn = platformForm.querySelector('button[type="submit"]');
            submitBtn.disabled = true;
            submitBtn.textContent = 'Saving...';

            const type = document.getElementById('fee-type').value;
            const amount = parseFloat(document.getElementById('fee-amount').value);

            const client = JayShow.getSupabaseClient();
            const { error } = await client
                .from('platform_settings')
                .upsert({
                    key: 'convenience_fee',
                    value: { type, amount }
                });

            if (error) {
                alert('Error saving settings: ' + error.message);
            } else {
                alert('Settings saved successfully!');
                closePlatformSettingsModal();
            }

            submitBtn.disabled = false;
            submitBtn.textContent = 'Save Settings';
        });
    }
});
