/**
 * JayShow - Event Detail Page Logic
 * ===================================
 * 
 * Handles the event detail page:
 * - Fetches event details from Supabase
 * - Displays event information
 * - Lists available shows for booking
 */

let currentEvent = null;
let eventShows = [];

document.addEventListener('DOMContentLoaded', async () => {
    await updateNavbar();
    await initEventPage();
});

/**
 * Updates the navbar to show login status
 */
async function updateNavbar() {
    const loginLink = document.getElementById('login-link');
    const logoutBtn = document.getElementById('logout-btn');
    const user = await JayShow.getUser();

    if (user) {
        if (loginLink) loginLink.classList.add('hidden');
        if (logoutBtn) {
            logoutBtn.classList.remove('hidden');
            logoutBtn.addEventListener('click', async () => {
                await JayShow.signOut();
                window.location.reload();
            });
        }

        const emailSpan = document.querySelector('.user-email');
        if (emailSpan) {
            emailSpan.textContent = user.email;
            emailSpan.classList.remove('hidden');
        }
    }
}

/**
 * Initializes the event page
 */
async function initEventPage() {
    const urlParams = new URLSearchParams(window.location.search);
    const eventId = urlParams.get('id');

    if (!eventId) {
        showError('Event ID not provided');
        return;
    }

    try {
        // Fetch event details
        const { data: event, error: eventError } = await JayShow.fetchEvent(eventId);

        if (eventError || !event) {
            showError('Event not found');
            return;
        }

        currentEvent = event;
        renderEventDetails(event);

        // Fetch shows for this event
        const { data: shows, error: showsError } = await JayShow.fetchEventShows(eventId);

        if (showsError) {
            console.error('Error fetching shows:', showsError.message);
        }

        eventShows = shows || [];
        renderShows(eventShows);

        // Show content, hide loading
        document.getElementById('loading-state').classList.add('hidden');
        document.getElementById('event-content').classList.remove('hidden');

    } catch (err) {
        console.error('Error loading event:', err);
        showError('Failed to load event details');
    }
}

/**
 * Shows an error message
 * @param {string} message - Error message to display
 */
function showError(message) {
    document.getElementById('loading-state').classList.add('hidden');
    document.getElementById('error-state').classList.remove('hidden');
    document.getElementById('error-message').textContent = message;
}

/**
 * Renders event details in the hero section
 * @param {Object} event - Event object
 */
function renderEventDetails(event) {
    // Update page title
    document.title = `${event.title} - JayShow`;

    // Hero background
    const heroBg = document.getElementById('hero-bg-image');
    heroBg.src = event.banner_url || event.poster_url || 'assets/images/placeholder-poster.svg';

    // Poster
    const poster = document.getElementById('event-poster');
    poster.src = event.poster_url || 'assets/images/placeholder-poster.svg';
    poster.alt = event.title;
    poster.onerror = () => { poster.src = 'assets/images/placeholder-poster.svg'; };

    // Category badge
    const categoryEl = document.getElementById('event-category');
    categoryEl.innerHTML = `${getCategoryIcon(event.category)} ${event.category}`;


    // Title
    document.getElementById('event-title').textContent = event.title;

    // Meta info
    if (event.organizer) {
        document.getElementById('event-organizer').innerHTML = `${JayShow.icon('mic', 'inline-icon')} ${JayShow.escapeHtml(event.organizer)}`;
    } else {
        document.getElementById('event-organizer').style.display = 'none';
    }

    if (event.venue_name) {
        document.getElementById('event-venue').innerHTML = `${JayShow.icon('map-pin', 'inline-icon')} ${JayShow.escapeHtml(event.venue_name)}`;
    } else {
        document.getElementById('event-venue').style.display = 'none';
    }

    if (event.city) {
        document.getElementById('event-city').innerHTML = `${JayShow.icon('building-2', 'inline-icon')} ${JayShow.escapeHtml(event.city)}`;
    } else {
        document.getElementById('event-city').style.display = 'none';
    }

    // Description
    document.getElementById('event-description').textContent = event.description || '';

    // Tags
    if (event.tags && event.tags.length > 0) {
        const tagsContainer = document.getElementById('event-tags');
        tagsContainer.innerHTML = event.tags.map(tag =>
            `<span class="event-tag">#${JayShow.escapeHtml(tag)}</span>`
        ).join('');
    }
}

/**
 * Renders available shows
 * @param {Array} shows - Array of show objects
 */
function renderShows(shows) {
    const showsGrid = document.getElementById('shows-grid');

    if (!shows || shows.length === 0) {
        showsGrid.innerHTML = `
            <div style="grid-column: 1/-1; text-align: center; padding: var(--space-8);">
                <h3>${JayShow.icon('ticket', 'lucide')} No shows available</h3>
                <p style="color: var(--text-secondary); margin-top: var(--space-2);">
                    Check back later for upcoming shows!
                </p>
            </div>
        `;
        return;
    }

    showsGrid.innerHTML = shows.map(show => createShowCard(show)).join('');
}

/**
 * Creates HTML for a show card
 * @param {Object} show - Show object
 * @returns {string} HTML string
 */
function createShowCard(show) {
    const startTime = new Date(show.start_time);
    const dateStr = startTime.toLocaleDateString('en-IN', {
        weekday: 'short',
        day: 'numeric',
        month: 'short',
        year: 'numeric'
    });
    const timeStr = startTime.toLocaleTimeString('en-IN', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
    });

    const venue = show.screens?.theatres?.name || 'Venue TBA';
    const screen = show.screens?.name || '';
    const price = show.price || 499;

    return `
        <div class="show-card">
            <div class="show-date">${JayShow.escapeHtml(dateStr)}</div>
            <div class="show-time">${JayShow.escapeHtml(timeStr)}</div>
            <div class="show-venue">
                ${JayShow.icon('map-pin', 'inline-icon')} ${JayShow.escapeHtml(venue)}${screen ? ` • ${JayShow.escapeHtml(screen)}` : ''}
            </div>
            <div class="show-footer">
                <span class="show-price">₹${price}+</span>
                <button class="btn btn-primary btn-sm" onclick="bookShow('${show.id}')">
                    Select Seats
                </button>
            </div>
        </div>
    `;
}

/**
 * Navigates to seat selection for an event show
 * @param {string} showId - Event show ID
 */
function bookShow(showId) {
    window.location.href = `./seats.html?event_show=${showId}`;
}

/**
 * Gets the icon for a category
 * @param {string} category - Event category
 * @returns {string} Emoji icon
 */
function getCategoryIcon(category) {
    const icons = {
        'concert': JayShow.icon('music', 'inline-icon'),
        'sports': JayShow.icon('trophy', 'inline-icon'),
        'comedy': JayShow.icon('smile', 'inline-icon'),
        'festival': JayShow.icon('tent', 'inline-icon'),
        'theatre': JayShow.icon('drama', 'inline-icon'),
        'workshop': JayShow.icon('graduation-cap', 'inline-icon')
    };
    return icons[category] || JayShow.icon('target', 'inline-icon');
}