/**
 * Quick my Ticket - Index Page Logic
 * ==========================
 * 
 * Handles the movie grid homepage:
 * - Fetches movies from Supabase
 * - Renders movie poster grid
 * - Manages navbar login status
 */

// Module-level cache for genre filtering
let allMovies = [];

document.addEventListener('DOMContentLoaded', async () => {
    // Initialize Navbar first (non-blocking)
    JayShow.updateNavbar().catch(err => console.error('Navbar update failed:', err));

    try {
        // Fetch movies once for both grid and slider
        const { data: movies, error } = await JayShow.fetchMovies();
        
        if (error) throw error;
        
        // Cache for filtering
        allMovies = movies || [];

        // Run these in parallel
        await Promise.all([
            initHeroSlider(allMovies),
            loadMovies(allMovies)
        ]).catch(err => console.error('Parallel initialization failed:', err));

        // Initialize tabs (needs allMovies populated)
        initCategoryTabs();
    } catch (err) {
        console.error('Initial data load failed:', err);
        const grid = document.getElementById('movie-grid');
        if (grid) {
            grid.innerHTML = `<div class="alert alert-error" style="grid-column: 1/-1;">Failed to load movies. Please check your connection.</div>`;
        }
    }
});


/**
 * Initializes the TMDB Hero Slider with optimized performance
 */
async function initHeroSlider(dbMovies) {
    const sliderContainer = document.getElementById('slider-container');
    const dotsContainer = document.getElementById('slider-dots');
    if (!sliderContainer || !dbMovies || dbMovies.length === 0) return;

    // Use up to 5 movies for the slider
    const sliderMovies = dbMovies.slice(0, 5);

    // Render slides
    sliderContainer.innerHTML = sliderMovies.map((movie, index) => {
        const imageUrl = movie.poster_url || 'assets/images/placeholder-poster.svg';
        const rating = movie.rating ? parseFloat(movie.rating).toFixed(1) : 'N/A';
        
        return `
        <div class="slider-item ${index === 0 ? 'active' : ''}" data-index="${index}">
            <img 
                src="${JayShow.escapeHtml(imageUrl)}" 
                alt="${JayShow.escapeHtml(movie.title)}"
                ${index === 0 ? 'fetchpriority="high"' : 'loading="lazy"'}
                style="object-position: center 20%;"
                onerror="this.src='assets/images/placeholder-poster.svg'"
            >
            <div class="slider-overlay">
                <div class="slider-content">
                    <div class="slider-rating">
                        <span>★</span>
                        <span>${rating}</span>
                    </div>
                    <h2 class="slider-title">${JayShow.escapeHtml(movie.title)}</h2>
                    <p class="slider-overview">${JayShow.escapeHtml(movie.description || '')}</p>
                    <button class="btn btn-primary" onclick="window.location.href='./movie.html?id=${movie.id}'">Book Now</button>
                </div>
            </div>
        </div>
        `;
    }).join('');

    // Render dots
    dotsContainer.innerHTML = sliderMovies.map((_, index) => `
        <div class="dot ${index === 0 ? 'active' : ''}" data-index="${index}"></div>
    `).join('');

    // Slider state
    let currentIndex = 0;
    let autoSlideTimer = null;
    const items = sliderContainer.querySelectorAll('.slider-item');
    const dots = dotsContainer.querySelectorAll('.dot');
    const total = items.length;

    function goToSlide(index) {
        if (index < 0) index = total - 1;
        if (index >= total) index = 0;

        items[currentIndex].classList.remove('active');
        dots[currentIndex].classList.remove('active');

        currentIndex = index;
        sliderContainer.style.transform = `translateX(-${currentIndex * 100}%)`;

        items[currentIndex].classList.add('active');
        dots[currentIndex].classList.add('active');
    }

    // Auto slide with pause on interaction
    function startAutoSlide() {
        stopAutoSlide();
        autoSlideTimer = setInterval(() => {
            goToSlide(currentIndex + 1);
        }, 5000);
    }

    function stopAutoSlide() {
        if (autoSlideTimer) {
            clearInterval(autoSlideTimer);
            autoSlideTimer = null;
        }
    }

    function resetAutoSlide() {
        stopAutoSlide();
        startAutoSlide();
    }

    // Controls — reset auto-slide on manual interaction
    document.getElementById('slider-prev')?.addEventListener('click', () => {
        goToSlide(currentIndex - 1);
        resetAutoSlide();
    });
    document.getElementById('slider-next')?.addEventListener('click', () => {
        goToSlide(currentIndex + 1);
        resetAutoSlide();
    });

    dots.forEach(dot => {
        dot.addEventListener('click', () => {
            const index = parseInt(dot.getAttribute('data-index'));
            goToSlide(index);
            resetAutoSlide();
        });
    });

    // Touch/swipe support for mobile
    let touchStartX = 0;
    let touchEndX = 0;
    const slider = document.getElementById('hero-slider');
    
    if (slider) {
        slider.addEventListener('touchstart', (e) => {
            touchStartX = e.changedTouches[0].screenX;
            stopAutoSlide();
        }, { passive: true });

        slider.addEventListener('touchend', (e) => {
            touchEndX = e.changedTouches[0].screenX;
            const diff = touchStartX - touchEndX;
            if (Math.abs(diff) > 50) {
                if (diff > 0) {
                    goToSlide(currentIndex + 1); // Swipe left → next
                } else {
                    goToSlide(currentIndex - 1); // Swipe right → prev
                }
            }
            resetAutoSlide();
        }, { passive: true });
    }

    // Pause auto-slide when tab is hidden
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
            stopAutoSlide();
        } else {
            startAutoSlide();
        }
    });

    // Start auto-slide
    startAutoSlide();
}

/**
 * Loads and displays movies in the grid.
 */
async function loadMovies(movies) {
    const moviesContainer = document.getElementById('movie-grid');
    if (!moviesContainer) return;

    if (!movies || movies.length === 0) {
        moviesContainer.innerHTML = `
            <div class="text-center" style="grid-column: 1/-1; padding: 2rem;">
                <h3>No movies available</h3>
                <p style="color: var(--text-secondary);">Check back later for new releases!</p>
            </div>
        `;
        return;
    }

    // Debug: Log each movie ID
    movies.forEach(m => JayShow.debugLog(`Movie: ${m.title}, ID: ${m.id}`));

    // Render movie cards
    allMovies = movies;
    moviesContainer.innerHTML = movies.map(movie => createMovieCard(movie)).join('');
}

/**
 * Creates HTML for a movie card.
 * 
 * @param {Object} movie - Movie object from Supabase
 * @returns {string} HTML string for the movie card
 */
function createMovieCard(movie) {
    const posterUrl = movie.poster_url || 'assets/images/placeholder-poster.svg';
    const rating = movie.rating ? parseFloat(movie.rating).toFixed(1) : 'N/A';
    const genre = movie.genre || '';

    // Make sure movie.id exists
    if (!movie.id) {
        console.error('Movie missing ID:', movie);
        return '';
    }

    const movieUrl = `./movie.html?id=${movie.id}`;

    return `
        <div class="movie-card" onclick="window.location.href='${movieUrl}'">
            <a href="${movieUrl}">
                <div class="movie-rating">
                    <span>★</span>
                    <span>${rating}</span>
                </div>
                <img 
                    src="${JayShow.escapeHtml(posterUrl)}" 
                    alt="${JayShow.escapeHtml(movie.title)}"
                    class="movie-poster"
                    loading="lazy"
                    onerror="this.src='assets/images/placeholder-poster.svg'"
                >
                <div class="movie-info">
                    <h3 class="movie-title">${JayShow.escapeHtml(movie.title)}</h3>
                    ${genre ? `<p class="movie-genre">${JayShow.escapeHtml(genre)}</p>` : ''}
                </div>
            </a>
        </div>
    `;
}

/**
 * Initializes category tab filtering.
 * Filters the already-loaded movie grid by genre.
 */
function initCategoryTabs() {
    const tabs = document.querySelectorAll('.category-tab');
    const grid = document.getElementById('movie-grid');
    if (!tabs.length || !grid) return;

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Update active state
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');

            const genre = tab.textContent.trim();
            const filtered = (genre === 'All Movies')
                ? allMovies
                : allMovies.filter(m => 
                    m.genre && m.genre.toLowerCase().includes(genre.toLowerCase())
                  );

            if (filtered.length === 0) {
                grid.innerHTML = `
                    <div class="text-center" style="grid-column: 1/-1; padding: 2rem;">
                        <h3>No ${genre} movies</h3>
                        <p style="color: var(--text-secondary);">Try another category</p>
                    </div>
                `;
            } else {
                grid.innerHTML = filtered.map(movie => createMovieCard(movie)).join('');
            }
        });
    });
}