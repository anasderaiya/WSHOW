/**
 * config.js — Theater-specific configuration
 * Injected at deploy time by deploy-theater.js / deploy-theater.sh.
 * Placeholders (%%VALUE%%) are replaced with real values during the build.
 *
 * For LOCAL DEVELOPMENT: placeholders are left as-is. The validator below
 * detects this and falls back to reading <meta> tags from the HTML, so
 * opening index.html directly in a browser works without running the
 * deploy script.
 */
window.QMT_CONFIG = {
  // Theater identity (set per deployment)
  THEATER_ID:     'dddd58fe-82c1-45fc-aadf-79613cbdb122',        // UUID from theatres table
  THEATER_NAME:   'Demo cinema',      // Display name
  SUPABASE_URL:   'https://cyjzbkdxhlzeqfmamdau.supabase.co',      // Same for all deployments
  SUPABASE_ANON:  'sb_publishable__qLGRXfnfzbVqQZJippZVQ_K8lkNqkR', // Same for all deployments
  RAZORPAY_KEY:   'rzp_test_placeholder',      // Theater's own Razorpay key
  DEPLOYMENT_ENV: 'production',    // 'production' | 'staging'
};

// Runtime validation & local dev fallback
(function validateQMTConfig() {
  var isPlaceholder = function(v) {
    return typeof v === 'string' && v.startsWith('%%') && v.endsWith('%%');
  };

  var uninjected = Object.entries(window.QMT_CONFIG)
    .filter(function(entry) { return isPlaceholder(entry[1]); });

  if (uninjected.length === 0) return; // All injected — production deploy, nothing to do

  // --- Local Development Mode ---
  // If we're on file://, localhost, or 127.0.0.1 — this is a dev environment.
  // Fall back to reading Supabase credentials from <meta> tags (injected by inject_config.js)
  // and leave theater-specific fields as null (= main QuickMyTicket platform mode).
  var loc = window.location;
  var isLocal = loc.protocol === 'file:'
    || loc.hostname === 'localhost'
    || loc.hostname === '127.0.0.1'
    || loc.hostname === '';

  if (isLocal) {
    var metaUrl  = document.querySelector('meta[name="supabase-url"]');
    var metaAnon = document.querySelector('meta[name="supabase-anon-key"]');

    // Local dev = QuickMyTickets aggregator mode (all theaters).
    // To test a specific theater's white-label locally, add ?theater=UUID to the URL.
    // Example: index.html?theater=dddd58fe-82c1-45fc-aadf-79613cbdb122
    // getCurrentTheaterId() in app.js picks up ?theater= and overrides this null.
    window.QMT_CONFIG = {
      THEATER_ID:     null,                                          // null = aggregator mode (show all theaters)
      THEATER_NAME:   'QuickMyTickets (Local Dev)',
      SUPABASE_URL:   metaUrl  ? metaUrl.getAttribute('content')  : 'https://cyjzbkdxhlzeqfmamdau.supabase.co',
      SUPABASE_ANON:  metaAnon ? metaAnon.getAttribute('content') : 'sb_publishable__qLGRXfnfzbVqQZJippZVQ_K8lkNqkR',
      RAZORPAY_KEY:   'rzp_test_placeholder',
      DEPLOYMENT_ENV: 'development',
    };

    console.info('[QMT] Local dev mode — aggregator mode (all theaters). Add ?theater=UUID to test white-label.');
    return;
  }

  // --- Production with uninjected placeholders = real error ---
  var missing = uninjected.map(function(entry) { return entry[0]; }).join(', ');

  document.addEventListener('DOMContentLoaded', function() {
    document.body.style.cssText = 'margin:0;font-family:sans-serif;background:#0d0d0d;color:#fff;';
    document.body.innerHTML =
      '<div style="display:flex;align-items:center;justify-content:center;min-height:100vh;padding:40px;">' +
        '<div style="text-align:center;max-width:480px;">' +
          '<div style="font-size:48px;margin-bottom:16px;">⚙️</div>' +
          '<h2 style="margin:0 0 12px;font-size:22px;">Deployment Configuration Missing</h2>' +
          '<p style="color:rgba(255,255,255,0.6);margin:0 0 24px;line-height:1.6;">' +
            'This theater deployment has not been configured.<br>' +
            'Run the deploy script before publishing.' +
          '</p>' +
          '<code style="background:#1a1a1a;border:1px solid #333;padding:12px 20px;display:block;border-radius:4px;font-size:13px;color:#C9A84C;">' +
            'node deploy-theater.js &lt;theater_id&gt; &lt;name&gt; &lt;subdomain&gt;' +
          '</code>' +
          '<p style="color:rgba(255,255,255,0.3);font-size:12px;margin-top:16px;">' +
            'Missing: ' + missing +
          '</p>' +
        '</div>' +
      '</div>';
  });

  throw new Error('[QMT] Config not injected. Missing: ' + missing);
})();
