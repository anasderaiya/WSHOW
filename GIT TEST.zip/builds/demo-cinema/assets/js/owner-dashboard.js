/**
 * Quick My Ticket - Theater Owner Dashboard
 * ==========================================================================
 * Real-time seat status monitoring for theater owners
 * 
 * REALTIME FEATURES:
 * - Surgical seat updates (individual seat DOM patches)
 * - Debounced stats refresh
 * - Auto-refresh polling fallback (30s)
 * - Connection status indicator (LIVE/RECONNECTING/OFFLINE)
 * - Pulse animations on seat state changes
 * - Live show card count updates
 */

// State
let currentShowId = null;
let currentShowType = 'movie'; // Track if current view is movie or event
let currentLayout = null;
let currentSeats = []; // Cache of current seat states for surgical updates
const statsRefreshInterval = 10000; // 10 seconds fallback polling
let statsIntervalId = null;
let currentUser = null;
let bookingSubscription = null;
let globalSubscription = null;
let ownedTheatres = [];

// Debounce timer for stats refresh
let statsDebounceTimer = null;
const STATS_DEBOUNCE_MS = 100; // Wait 100ms after last event before refreshing stats

// Connection state
let connectionState = 'connected'; // 'connected' | 'reconnecting' | 'disconnected'



document.addEventListener('DOMContentLoaded', async () => {
    await initOwnerDashboard();
});

/**
 * Initialize the owner dashboard
 */
async function initOwnerDashboard() {
    const loadingEl = document.getElementById('loading-state');
    const accessDenied = document.getElementById('access-denied');
    const ownerContent = document.getElementById('owner-content');

    try {
        currentUser = await JayShow.getUser();



        if (!currentUser) {
            // Redirect to owner-specific login page
            window.location.href = 'owner-login.html';
            return;
        }

        // Check if user is theater owner
        const isOwner = await checkIsTheaterOwner(currentUser.id);

        if (!isOwner) {
            loadingEl.classList.add('hidden');
            accessDenied.classList.remove('hidden');
            return;
        }

        // User is authorized - show dashboard
        loadingEl.classList.add('hidden');
        ownerContent.classList.remove('hidden');

        // Initialize date picker with today
        document.getElementById('date-filter').valueAsDate = new Date();

        // Load data
        await Promise.all([
            loadOwnedTheatres(),
            loadDashboardStats(),
        ]);

        // Load shows after theatres are loaded
        await loadShows();

        // Setup event listeners
        setupEventListeners();

        // Subscribe to real-time updates
        subscribeToBookings();

        // Start auto-refresh polling as fallback
        startAutoRefresh();

        // Update user info in navbar
        updateNavbar();

        // Set initial timestamp
        updateLastUpdated();

    } catch (error) {
        console.error('Dashboard init error:', error);
        loadingEl.classList.add('hidden');
        accessDenied.classList.remove('hidden');
    }
}

/**
 * Check if user is a theater owner
 */
async function checkIsTheaterOwner(userId) {
    const client = JayShow.getSupabaseClient();

    // Try using the RPC function
    const { data, error } = await client.rpc('is_theater_owner', { p_user_id: userId });

    if (error) {
        JayShow.debugLog('Checking theater_owners table directly...');
        // Fallback: check table directly
        const { data: owners, error: ownerError } = await client
            .from('theater_owners')
            .select('id')
            .eq('user_id', userId)
            .limit(1);

        return !ownerError && owners && owners.length > 0;
    }

    return data === true;
}

/**
 * Load theatres owned by current user
 */
async function loadOwnedTheatres() {
    const client = JayShow.getSupabaseClient();
    const theatresList = document.getElementById('theatres-list');
    const theatreFilter = document.getElementById('theatre-filter');

    try {
        let theatres;

        // Use RPC function
            const { data, error } = await client.rpc('get_owned_theatres', {
                p_user_id: currentUser.id
            });
            if (error) throw error;
            theatres = data || [];

        ownedTheatres = theatres;

        // Render theatres list
        if (theatres.length === 0) {
            theatresList.innerHTML = '<p class="text-muted">No theatres assigned</p>';
        } else {
            theatresList.innerHTML = theatres.map(t => `
                <div class="theatre-card">
                    <div class="theatre-name">${JayShow.escapeHtml(t.theatre_name)}</div>
                    <div class="theatre-meta">
                        <span>${JayShow.icon('map-pin', 'inline-icon')} ${JayShow.escapeHtml(t.location || 'Unknown')}</span>
                        <span>${JayShow.icon('monitor', 'inline-icon')} ${t.screen_count} screens</span>
                    </div>
                    <span class="theatre-role">${t.role}</span>
                </div>
            `).join('');
        }

        // Populate filter dropdown
        theatreFilter.innerHTML = '<option value="">All My Theatres</option>' +
            theatres.map(t => `<option value="${t.theatre_id}">${JayShow.escapeHtml(t.theatre_name)}</option>`).join('');

    } catch (error) {
        console.error('Error loading theatres:', error);
        theatresList.innerHTML = '<p class="text-muted">Failed to load theatres</p>';
    }
}

/**
 * Load dashboard statistics
 */
async function loadDashboardStats() {
    const client = JayShow.getSupabaseClient();

    try {
        const theatreId = document.getElementById('theatre-filter').value || null;
        // Use RPC function
            const { data, error } = await client.rpc('get_owner_dashboard_stats', {
                p_user_id: currentUser.id,
                p_theatre_id: theatreId
            });

            if (error) throw error;
            const stats = data?.[0] || {};

            animateStatUpdate('stat-theatres', stats.total_theatres || 0);
            animateStatUpdate('stat-screens', stats.total_screens || 0);
            animateStatUpdate('stat-seats', stats.total_seats || 0);
            animateStatUpdate('stat-bookings', stats.today_confirmed || 0);
            animateStatUpdate('stat-revenue', `₹${(stats.today_revenue || 0).toLocaleString()}`);
            animateStatUpdate('stat-locked', stats.currently_locked || 0);

        updateLastUpdated();
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

/**
 * Animate a stat card value update with bounce effect
 */
function animateStatUpdate(elementId, newValue) {
    const el = document.getElementById(elementId);
    if (!el) return;

    const oldValue = el.textContent;
    const newStr = String(newValue);

    if (oldValue !== newStr && oldValue !== '--') {
        // Value changed — animate
        el.textContent = newStr;
        el.classList.remove('updated');
        // Force reflow to restart animation
        void el.offsetWidth;
        el.classList.add('updated');
        setTimeout(() => el.classList.remove('updated'), 500);
    } else {
        el.textContent = newStr;
    }
}

/**
 * Update the last updated timestamp
 */
function updateLastUpdated() {
    const el = document.getElementById('last-updated');
    if (el) {
        el.textContent = `Updated ${new Date().toLocaleTimeString()}`;
    }
}

/**
 * Load shows for selected theatre and date
 */
async function loadShows() {
    const client = JayShow.getSupabaseClient();
    const showsList = document.getElementById('shows-list');
    const showFilter = document.getElementById('show-filter');
    const theatreId = document.getElementById('theatre-filter').value;
    const dateStr = document.getElementById('date-filter').value;

    showsList.innerHTML = '<p class="text-muted">Loading shows...</p>';

    try {
        const { data: shows, error } = await client.rpc('get_owner_shows', {
            p_user_id: currentUser.id,
            p_theatre_id: theatreId || null,
            p_date: dateStr || new Date().toISOString().split('T')[0]
        });
        JayShow.debugLog("RPC GET_OWNER_SHOWS RETURNED:", shows);

        if (error) throw error;

        if (!shows || shows.length === 0) {
            showsList.innerHTML = '<p class="text-muted">No shows found for this date</p>';
            showFilter.innerHTML = '<option value="">No shows available</option>';
            return;
        }

        // Render shows list
        showsList.innerHTML = shows.map(show => {
            const time = new Date(show.start_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            const type = show.type || 'movie';
            const title = show.title || show.movie_title || 'Unknown';
            const typeBadge = type === 'event' ? '<span class="badge badge-event">EVENT</span>' : '<span class="badge badge-movie">MOVIE</span>';
            
            const showId = show.id || show.show_id;
            
            return `
                <div class="show-card" data-show-id="${showId}" data-show-type="${type}" onclick="selectShow('${showId}', '${type}')">
                    <div class="show-info">
                        <div class="show-title">
                            ${typeBadge} 
                            ${JayShow.escapeHtml(title)}
                        </div>
                        <div class="show-meta">
                            <span>${JayShow.icon('clock', 'inline-icon')} ${time}</span>
                            <span>${JayShow.icon('monitor', 'inline-icon')} ${JayShow.escapeHtml(show.screen_name)}</span>
                            <span>${JayShow.icon('building-2', 'inline-icon')} ${JayShow.escapeHtml(show.theatre_name || '')}</span>
                        </div>
                    </div>
                    <div class="show-stats-mini">
                        <span class="show-stat-badge locked" data-show-locked="${showId}">${JayShow.icon('lock', 'inline-icon')} ${show.locked_seats}</span>
                        <span class="show-stat-badge booked" data-show-booked="${showId}">${JayShow.icon('check', 'inline-icon')} ${show.booked_seats}</span>
                        <button class="btn btn-secondary" style="padding:0.25rem 0.75rem;font-size:0.75rem;" onclick="event.stopPropagation(); openOfflineModal('${showId}', '${show.screen_id}', '${type}')">${JayShow.icon('settings', 'inline-icon')} Offline</button>
                        <button class="btn btn-outline" style="padding:0.25rem 0.75rem;font-size:0.75rem;margin-left:0.5rem;" onclick="event.stopPropagation(); openCustomerListModal('${showId}', '${type}')">${JayShow.icon('users', 'inline-icon')} Customers</button>
                    </div>
                </div>
            `;
        }).join('');

        // Populate show filter
        showFilter.innerHTML = '<option value="">Select a Show</option>' +
            shows.map(show => {
                const time = new Date(show.start_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                const sid = show.id || show.show_id;
                const stype = show.type || 'movie';
                const stitle = show.title || show.movie_title || 'Unknown';
                return `<option value="${sid}" data-type="${stype}">${stitle} (${stype}) @ ${time}</option>`;
            }).join('');

    } catch (error) {
        console.error('Error loading shows:', error);
        showsList.innerHTML = '<p class="text-muted">Failed to load shows</p>';
    }
}

/**
 * Select a show and load its seat grid
 */
async function selectShow(showId, showType = 'movie') {
    // Update UI
    document.querySelectorAll('.show-card').forEach(card => {
        card.classList.toggle('active', card.dataset.showId === showId);
    });

    document.getElementById('show-filter').value = showId;
    document.getElementById('seat-grid-section').classList.remove('hidden');
    const viewCustomersBtn = document.getElementById('view-customers-btn');
    if (viewCustomersBtn) viewCustomersBtn.disabled = false;

    currentShowId = showId;
    currentShowType = showType; // Track globally

    // Unsubscribe from previous show
    if (bookingSubscription) {
        bookingSubscription.unsubscribe();
    }

    // Load seat grid
    await loadSeatGrid(showId, showType);

    // Subscribe to real-time updates for this show
    if (showType === 'event') {
        bookingSubscription = JayShow.subscribeEventBookings(showId, handleBookingUpdate);
    } else {
        bookingSubscription = JayShow.subscribeBookings(showId, handleBookingUpdate);
    }
}

// Make selectShow available globally
window.selectShow = selectShow;

/**
 * Load seat grid for a show
 */
async function loadSeatGrid(showId, showType = 'movie') {
    const container = document.getElementById('live-seat-grid');
    const infoBar = document.getElementById('show-info-bar');

    container.innerHTML = '<div class="loading"><div class="spinner"></div></div>';

    try {
        let show;
        let seats;
        let error;

        if (showType === 'event') {
            const res = await JayShow.fetchEventShow(showId);
            show = res.data;
            const seatRes = await JayShow.fetchEventSeatStates(showId);
            seats = seatRes.data;
            error = seatRes.error;
        } else {
            const res = await JayShow.fetchShow(showId);
            show = res.data;
            const seatRes = await JayShow.fetchSeatStates(showId);
            seats = seatRes.data;
            error = seatRes.error;
        }

        if (show) {
            const time = new Date(show.start_time).toLocaleString();
            const title = showType === 'event' ? (show.events?.title || 'Event') : (show.movies?.title || 'Movie');
            const screenName = show.screens?.name || 'Unknown Screen';
            
            infoBar.innerHTML = `
                <div>
                    <span class="show-name">${JayShow.escapeHtml(title)}</span>
                    <span class="show-details"> | ${JayShow.escapeHtml(screenName)} | ${time}</span>
                </div>
            `;
        }

        if (error) throw error;

        // Cache seats for surgical updates
        currentSeats = seats || [];

        // Get layout
        // Always fetch layout for the current screen
        if (show && show.screen_id) {
            const { data: layout } = await JayShow.fetchScreenLayout(show.screen_id);
            if (layout) {
                currentLayout = layout;
            }
        }

        renderSeatGrid(currentSeats);
        updateSeatStats(currentSeats);

    } catch (error) {
        console.error('Error loading seat grid:', error);
        container.innerHTML = `<p class="text-danger">Failed to load seat grid: ${error.message || 'Unknown error'}</p>`;
    }
}

/**
 * Render the seat grid
 */
function renderSeatGrid(seats) {
    const container = document.getElementById('live-seat-grid');

    if (!seats || seats.length === 0) {
        container.innerHTML = '<p class="text-muted">No seats found for this show</p>';
        return;
    }

    if (currentLayout && currentLayout.rows) {
        let html = '<div class="screen-indicator"></div>';

        currentLayout.rows.forEach(row => {
            html += `<div class="seat-row"><span class="row-label">${row.label}</span>`;

            row.seats.forEach(layoutSeat => {
                if (!layoutSeat) {
                    html += '<div class="owner-seat gap"></div>';
                    return;
                }

                // Find database seat
                const seat = seats.find(s => s.row === row.label && parseInt(s.col) === parseInt(layoutSeat.id));

                if (!seat) {
                    html += '<div class="owner-seat gap"></div>';
                    return;
                }

                const stateClass = seat.state === 'offline' ? 'offline' :
                    (seat.state === 'booked' ? 'booked' :
                    (seat.state === 'locked' || seat.state === 'selected') ? 'locked' : 'available');

                // If a seat is available or offline, it can be toggled by the owner.
                const isToggleable = stateClass === 'available' || stateClass === 'offline';
                const cursorStyle = isToggleable ? 'cursor: pointer;' : 'cursor: not-allowed;';
                const onclickAttr = isToggleable ? `onclick="toggleSeatSelection('${seat.id}')"` : '';

                html += `
                    <div class="owner-seat ${stateClass}" 
                         id="owner-seat-${seat.id}"
                         data-seat-id="${seat.id}"
                         data-state="${stateClass}"
                         style="${cursorStyle}"
                         ${onclickAttr}
                         title="${row.label}${seat.col} - ${stateClass.toUpperCase()} - ₹${seat.price || 0}">
                        ${seat.col}
                    </div>
                `;
            });

            html += '</div>';
        });

        container.innerHTML = html;
        return;
    }

    // Fallback logic
    // Group by row
    const rows = {};
    seats.forEach(seat => {
        if (!rows[seat.row]) rows[seat.row] = [];
        rows[seat.row].push(seat);
    });

    let html = '<div class="screen-indicator"></div>';

    // Render rows
    Object.keys(rows).sort().forEach(rowName => {
        html += `<div class="seat-row"><span class="row-label">${rowName}</span>`;

        rows[rowName].sort((a, b) => a.col - b.col).forEach(seat => {
            const stateClass = seat.state === 'booked' ? 'booked' :
                seat.state === 'locked' ? 'locked' :
                    seat.state === 'selected' ? 'locked' : 'available';

            html += `
                <div class="owner-seat ${stateClass}" 
                     data-seat-id="${seat.id}"
                     title="${rowName}${seat.col} - ${stateClass.toUpperCase()} - ₹${seat.price || 0}">
                    ${seat.col}
                </div>
            `;
        });

        html += '</div>';
    });

    container.innerHTML = html;
}

/**
 * Update seat statistics
 */
function updateSeatStats(seats) {
    const available = seats.filter(s => s.state === 'available').length;
    const locked = seats.filter(s => s.state === 'locked' || s.state === 'selected').length;
    const booked = seats.filter(s => s.state === 'booked').length;
    const total = seats.length;
    const occupancy = total > 0 ? Math.round(((booked + locked) / total) * 100) : 0;

    animateStatUpdate('available-count', available);
    animateStatUpdate('locked-count', locked);
    animateStatUpdate('booked-count', booked);
    animateStatUpdate('occupancy-rate', `${occupancy}%`);
}

/**
 * ============================================
 * SURGICAL REAL-TIME UPDATE SYSTEM
 * ============================================
 * Instead of re-fetching the entire seat grid on every booking change,
 * this system patches individual seats in the DOM.
 */

/**
 * Handle real-time booking updates — surgical approach
 */
function handleBookingUpdate(payload) {
    JayShow.debugLog('🔴 Realtime booking update:', payload);

    const booking = payload.new || payload.old;
    if (!booking) return;

    // 1. Surgical seat update in DOM
    surgicalSeatUpdate(booking, payload.eventType);

    // 2. Update show card badges in real-time
    updateShowCardBadges(booking, payload.eventType);

    // 3. Add to activity feed
    addActivityEntry(payload);

    // 4. Debounced stats refresh (avoids hammering RPC on rapid changes)
    debouncedStatsRefresh();
}

/**
 * Surgically update a single seat in the DOM without re-rendering
 */
function surgicalSeatUpdate(booking, eventType) {
    const seatId = booking.seat_id;
    if (!seatId) return;

    const seatEl = document.querySelector(`.owner-seat[data-seat-id="${seatId}"]`);
    if (!seatEl) return;

    // Determine new state
    let newState = 'available';
    if (eventType === 'DELETE' || booking.status === 'cancelled' || booking.status === 'expired') {
        newState = 'available';
    } else if (booking.status === 'confirmed') {
        newState = 'booked';
    } else if (booking.status === 'locked') {
        newState = 'locked';
    }

    // Remove old state classes
    seatEl.classList.remove('available', 'locked', 'booked');

    // Add new state class
    seatEl.classList.add(newState);

    // Add pulse animation
    const pulseClass = `pulse-${newState}`;
    seatEl.classList.remove('pulse-available', 'pulse-locked', 'pulse-booked');
    // Force reflow to restart animation
    void seatEl.offsetWidth;
    seatEl.classList.add(pulseClass);

    // Remove pulse class after animation completes
    setTimeout(() => seatEl.classList.remove(pulseClass), 900);

    // Update the tooltip
    const row = seatEl.closest('.seat-row')?.querySelector('.row-label')?.textContent || '';
    const col = seatEl.textContent.trim();
    const price = booking.price || currentSeats.find(s => s.id === seatId)?.price || 0;
    seatEl.title = `${row}${col} - ${newState.toUpperCase()} - ₹${price}`;

    // Update local seats cache
    const cachedSeat = currentSeats.find(s => s.id === seatId);
    if (cachedSeat) {
        cachedSeat.state = newState;
        cachedSeat.booking = eventType === 'DELETE' ? null : booking;
    }

    // Recalculate stats from cache (instant, no DB call)
    updateSeatStats(currentSeats);
}

/**
 * Update the locked/booked badges on show cards in real-time
 */
function updateShowCardBadges(booking, eventType) {
    const showId = booking.show_id || booking.event_show_id; // Check both
    if (!showId) return;

    const lockedBadge = document.querySelector(`[data-show-locked="${showId}"]`);
    const bookedBadge = document.querySelector(`[data-show-booked="${showId}"]`);

    if (!lockedBadge || !bookedBadge) return;

    // Parse current counts from badge text (format: "icon N")
    let lockedCount = parseInt(lockedBadge.textContent.replace(/\D/g, '')) || 0;
    let bookedCount = parseInt(bookedBadge.textContent.replace(/\D/g, '')) || 0;

    if (eventType === 'INSERT' && booking.status === 'locked') {
        lockedCount++;
    } else if (eventType === 'UPDATE') {
        if (booking.status === 'confirmed') {
            lockedCount = Math.max(0, lockedCount - 1);
            bookedCount++;
        } else if (booking.status === 'cancelled' || booking.status === 'expired') {
            lockedCount = Math.max(0, lockedCount - 1);
        }
    } else if (eventType === 'DELETE') {
        const oldBooking = booking; // payload.old
        if (oldBooking.status === 'locked') lockedCount = Math.max(0, lockedCount - 1);
        if (oldBooking.status === 'confirmed') bookedCount = Math.max(0, bookedCount - 1);
    }

    lockedBadge.innerHTML = `${JayShow.icon('lock', 'inline-icon')} ${lockedCount}`;
    bookedBadge.innerHTML = `${JayShow.icon('check', 'inline-icon')} ${bookedCount}`;
}

/**
 * Debounced stats refresh — waits for rapid events to settle
 */
function debouncedStatsRefresh() {
    if (statsDebounceTimer) {
        clearTimeout(statsDebounceTimer);
    }
    statsDebounceTimer = setTimeout(() => {
        loadDashboardStats();
        statsDebounceTimer = null;
    }, STATS_DEBOUNCE_MS);
}

/**
 * Add entry to activity feed
 */
function addActivityEntry(payload) {
    const feed = document.getElementById('activity-feed');
    const time = new Date().toLocaleTimeString();

    // Remove placeholder if exists
    const placeholder = feed.querySelector('.activity-placeholder');
    if (placeholder) placeholder.remove();

    const message = getActivityMessage(payload);
    let entryClass = '';

    if (payload.eventType === 'INSERT') entryClass = 'lock';
    else if (payload.new?.status === 'confirmed') entryClass = 'confirm';
    else if (payload.new?.status === 'cancelled' || payload.new?.status === 'expired') entryClass = 'cancel';

    const entry = document.createElement('div');
    entry.className = `activity-entry ${entryClass}`;
    entry.innerHTML = `
        <span class="activity-time">${time}</span>
        <span class="activity-action">${message}</span>
    `;

    feed.insertBefore(entry, feed.firstChild);

    // Keep only last 50 entries
    while (feed.children.length > 50) {
        feed.removeChild(feed.lastChild);
    }
}

/**
 * Get human-readable activity message
 */
function getActivityMessage(payload) {
    const seatId = payload.new?.seat_id || payload.old?.seat_id;
    const seatInfo = seatId ? currentSeats.find(s => s.id === seatId) : null;
    const seatLabel = seatInfo ? ` (${seatInfo.row}${seatInfo.col})` : '';

    switch (payload.eventType) {
        case 'INSERT':
            return `${JayShow.icon('lock', 'inline-icon')} Seat locked${seatLabel}`;
        case 'UPDATE':
            if (payload.new?.status === 'confirmed') return `${JayShow.icon('check', 'inline-icon')} Booking confirmed${seatLabel}`;
            if (payload.new?.status === 'cancelled') return `${JayShow.icon('x', 'inline-icon')} Booking cancelled${seatLabel}`;
            return `${JayShow.icon('file-text', 'inline-icon')} Booking updated${seatLabel}`;
        case 'DELETE':
            return `${JayShow.icon('trash-2', 'inline-icon')} Booking removed${seatLabel}`;
        default:
            return `${JayShow.icon('radio', 'inline-icon')} Activity detected`;
    }
}

/**
 * ============================================
 * CONNECTION MANAGEMENT
 * ============================================
 */

/**
 * Subscribe to all booking updates with connection state tracking
 */
function subscribeToBookings() {
    const client = JayShow.getSupabaseClient();

    const channel = client
        .channel('owner-all-bookings')
        .on('postgres_changes', {
            event: '*',
            schema: 'public',
            table: 'bookings'
        }, (payload) => {
            JayShow.debugLog('📡 Global booking event:', payload.eventType, payload.new?.status);

            // Add to activity feed if not the currently-viewed show (that has its own handler)
            if (!currentShowId || payload.new?.show_id !== currentShowId) {
                addActivityEntry(payload);
            }

            // Always refresh stats on any booking change
            debouncedStatsRefresh();
        });

    // Track connection state changes
    channel.on('system', {}, (payload) => {
        JayShow.debugLog('📡 Channel system event:', payload);
    });

    channel.subscribe((status) => {
        JayShow.debugLog('📡 Subscription status:', status);
        updateConnectionState(status);
    });

    globalSubscription = channel;
}

/**
 * Update the LIVE badge based on connection state
 */
function updateConnectionState(status) {
    const badge = document.querySelector('.live-badge');
    if (!badge) return;

    // Remove all state classes
    badge.classList.remove('reconnecting', 'disconnected');

    switch (status) {
        case 'SUBSCRIBED':
            connectionState = 'connected';
            badge.textContent = 'LIVE';
            // Re-add the dot (CSS ::before handles it)
            break;
        case 'CHANNEL_ERROR':
        case 'TIMED_OUT':
            connectionState = 'reconnecting';
            badge.classList.add('reconnecting');
            badge.textContent = 'RECONNECTING';
            // Attempt recovery
            setTimeout(() => {
                if (connectionState === 'reconnecting') {
                    JayShow.debugLog('🔄 Attempting to recover connection...');
                    recoverConnection();
                }
            }, 5000);
            break;
        case 'CLOSED':
            connectionState = 'disconnected';
            badge.classList.add('disconnected');
            badge.textContent = 'OFFLINE';
            // Attempt recovery after delay
            setTimeout(() => {
                if (connectionState === 'disconnected') {
                    recoverConnection();
                }
            }, 10000);
            break;
    }
}

/**
 * Attempt to recover a dropped connection
 */
function recoverConnection() {
    const client = JayShow.getSupabaseClient();

    // Clean up old subscription
    if (globalSubscription) {
        try { client.removeChannel(globalSubscription); } catch (e) { /* ignore */ }
    }

    JayShow.debugLog('🔄 Recovering realtime connection...');

    // Re-subscribe
    subscribeToBookings();

    // Also re-subscribe to current show if one is selected
    if (currentShowId && bookingSubscription) {
        try { bookingSubscription.unsubscribe(); } catch (e) { /* ignore */ }
        bookingSubscription = JayShow.subscribeBookings(currentShowId, handleBookingUpdate);
    }

    // Full refresh to catch any missed events
    loadDashboardStats();
    if (currentShowId) loadSeatGrid(currentShowId);
}

/**
 * ============================================
 * AUTO-REFRESH POLLING (Fallback)
 * ============================================
 * Ensures data stays fresh even if realtime misses events
 */

/**
 * Start the auto-refresh polling interval
 */
function startAutoRefresh() {
    // Clear any existing interval
    if (statsIntervalId) clearInterval(statsIntervalId);

    statsIntervalId = setInterval(async () => {
        JayShow.debugLog('⏰ Auto-refresh polling...');

        // Refresh stats
        await loadDashboardStats();

        // If a show is selected, refresh seat grid silently
        if (currentShowId) {
            try {
                const { data: seats, error } = await JayShow.fetchSeatStates(currentShowId);
                if (!error && seats) {
                    // Compare with cache to find changes
                    const changes = findSeatChanges(currentSeats, seats);
                    if (changes.length > 0) {
                        JayShow.debugLog(`⏰ Polling found ${changes.length} seat changes`);
                        currentSeats = seats;
                        renderSeatGrid(currentSeats);
                        updateSeatStats(currentSeats);
                    }
                }
            } catch (err) {
                console.error('Auto-refresh seat error:', err);
            }
        }
    }, statsRefreshInterval);
}

/**
 * Find differences between cached seats and fresh seats
 */
function findSeatChanges(oldSeats, newSeats) {
    const changes = [];
    const oldMap = {};
    oldSeats.forEach(s => { oldMap[s.id] = s; });

    newSeats.forEach(seat => {
        const old = oldMap[seat.id];
        if (!old || old.state !== seat.state) {
            changes.push({ seatId: seat.id, oldState: old?.state, newState: seat.state });
        }
    });

    return changes;
}

/**
 * ============================================
 * EVENT LISTENERS & UI HELPERS
 * ============================================
 */

/**
 * Setup event listeners
 */
function setupEventListeners() {
    // Theatre filter
    document.getElementById('theatre-filter').addEventListener('change', loadShows);

    // Date filter
    document.getElementById('date-filter').addEventListener('change', loadShows);

    // Show filter dropdown
    document.getElementById('show-filter').addEventListener('change', (e) => {
        if (e.target.value) {
            selectShow(e.target.value);
        }
    });

    // Refresh button
    document.getElementById('refresh-btn').addEventListener('click', async () => {
        const btn = document.getElementById('refresh-btn');
        btn.disabled = true;
        btn.style.opacity = '0.6';
        
        await Promise.all([loadDashboardStats(), loadShows()]);
        if (currentShowId) await loadSeatGrid(currentShowId);
        
        btn.disabled = false;
        btn.style.opacity = '1';
        showToast('Dashboard refreshed');
    });

    // Clear activity
    document.getElementById('clear-activity').addEventListener('click', () => {
        document.getElementById('activity-feed').innerHTML = `
            <div class="activity-placeholder">
                <span class="activity-placeholder-icon">${JayShow.icon('radio', 'lucide lucide-lg')}</span>
                <p>Listening for booking activity...</p>
            </div>
        `;
    });

    // Logout
    document.getElementById('logout-btn').addEventListener('click', async () => {
        await JayShow.signOut();
        window.location.href = 'index.html';
    });

    // Export button (placeholder)
    document.getElementById('export-btn').addEventListener('click', () => {
        showToast('Export feature coming soon!');
    });

    // Notifications button (placeholder)
    document.getElementById('notify-btn').addEventListener('click', () => {
        showToast('Notifications coming soon!');
    });
}

/**
 * Update navbar with user info
 */
function updateNavbar() {
    const emailSpan = document.querySelector('.user-email');
    if (emailSpan && currentUser) {
        emailSpan.textContent = currentUser.email;
        emailSpan.classList.remove('hidden');
    }
}

/**
 * Show toast notification
 */
function showToast(message) {
    const toast = document.getElementById('toast');
    const messageEl = document.getElementById('toast-message');

    messageEl.innerHTML = message;
    toast.classList.remove('hidden');
    toast.classList.add('show');

    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.classList.add('hidden'), 300);
    }, 3000);
}
/**
 * Cleanup on page unload
 */
window.addEventListener('beforeunload', () => {
    // Stop auto-refresh
    if (statsIntervalId) clearInterval(statsIntervalId);
    if (statsDebounceTimer) clearTimeout(statsDebounceTimer);

    // Unsubscribe from realtime
    if (bookingSubscription) bookingSubscription.unsubscribe();
    if (globalSubscription) {
        JayShow.getSupabaseClient()?.removeChannel(globalSubscription);
    }
});

/* ============================================
   White-Label Branding Settings Logic
   ============================================ */
document.addEventListener('DOMContentLoaded', () => {
    const tabDashboardBtn = document.getElementById('tab-dashboard-btn');
    const tabBrandingBtn = document.getElementById('tab-branding-btn');
    const dashboardView = document.getElementById('dashboard-view');
    const brandingView = document.getElementById('branding-view');
    const theatreSelect = document.getElementById('branding-theatre-select');
    const brandingForm = document.getElementById('branding-form');
    
    if(!tabBrandingBtn) return;

    // Tab Switching
    tabDashboardBtn.addEventListener('click', (e) => {
        e.preventDefault();
        tabDashboardBtn.classList.add('active');
        tabBrandingBtn.classList.remove('active');
        dashboardView.classList.remove('hidden');
        brandingView.classList.add('hidden');
    });

    tabBrandingBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        tabBrandingBtn.classList.add('active');
        tabDashboardBtn.classList.remove('active');
        brandingView.classList.remove('hidden');
        dashboardView.classList.add('hidden');
        await loadTheatresForBranding();
    });

    // Inputs
    const inputName = document.getElementById('branding-name');
    const inputTagline = document.getElementById('branding-tagline');
    const inputPrimary = document.getElementById('color-primary');
    const inputAccent = document.getElementById('color-accent');
    const inputBg = document.getElementById('color-bg');
    const inputWhatsapp = document.getElementById('branding-whatsapp');
    const inputEmail = document.getElementById('branding-email');
    const inputPoweredBy = document.getElementById('branding-powered-by');
    const domainDisplay = document.getElementById('branding-domain');
    
    const uploadArea = document.getElementById('logo-upload');
    const inputFile = document.getElementById('logo-file');
    const previewLogo = document.getElementById('logo-preview');
    
    // Preview Elements
    const previewBtn = document.querySelector('.preview-button');
    const previewTitle = document.getElementById('preview-name');
    const previewCard = document.getElementById('branding-preview-card');

    // Sync Live Preview
    [inputPrimary, inputAccent, inputBg, inputName, inputTagline].forEach(el => {
        if(el) el.addEventListener('input', updatePreview);
    });

    // Logo Upload Interaction
    if(uploadArea && inputFile) {
        uploadArea.addEventListener('click', () => inputFile.click());
        inputFile.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                previewLogo.src = URL.createObjectURL(file);
                previewLogo.style.display = 'block';
                updatePreview();
            }
        });
    }

    function updatePreview() {
        const primary = inputPrimary?.value || '#e50914';
        const bg = inputBg?.value || '#141414';
        const name = inputName?.value || 'Theater Name';
        
        if(previewBtn) previewBtn.style.background = primary;
        if(previewCard) previewCard.style.background = bg;
        if(previewTitle) previewTitle.textContent = name;
        
        if(previewLogo && previewLogo.src) {
            previewLogo.style.display = 'block';
        }
    }

    async function loadTheatresForBranding() {
        try {
            const user = await JayShow.getUser();
            if(!user) { console.warn('Branding: No user found'); return; }
            const client = JayShow.getSupabaseClient();
            const { data, error } = await client
                .from('theater_owners')
                .select('theatre_id, theatres(id, name)')
                .eq('user_id', user.id);
            
            if (error) { console.error('Branding: Error loading theatres:', error); return; }
            
            theatreSelect.innerHTML = '<option value="">Select Theatre</option>';
            if(data && data.length > 0) {
                data.forEach(t => {
                    const theatre = t.theatres;
                    if (!theatre) return;
                    const opt = document.createElement('option');
                    opt.value = theatre.id;
                    opt.textContent = theatre.name;
                    theatreSelect.appendChild(opt);
                });
            }
        } catch(err) {
            console.error('Branding: Failed to load theatres:', err);
        }
    }

    theatreSelect.addEventListener('change', async (e) => {
        const theaterId = e.target.value;
        if(!theaterId) return;

        const client = JayShow.getSupabaseClient();
        const { data } = await client.from('theater_branding').select('*').eq('theater_id', theaterId).maybeSingle();
        if (data) {
            if(inputName) inputName.value = data.display_name || '';
            if(inputTagline) inputTagline.value = data.tagline || '';
            if(inputPrimary) inputPrimary.value = data.primary_color || '#e50914';
            if(inputAccent) inputAccent.value = data.accent_color || '#ffffff';
            if(inputBg) inputBg.value = data.background_color || '#141414';
            if(inputWhatsapp) inputWhatsapp.value = data.whatsapp_number || '';
            if(inputEmail) inputEmail.value = data.support_email || '';
            if(inputPoweredBy) inputPoweredBy.checked = data.show_powered_by ?? true;
            
            if(data.logo_url && previewLogo) {
                previewLogo.src = data.logo_url;
                previewLogo.style.display = 'block';
            } else if(previewLogo) {
                previewLogo.style.display = 'none';
                previewLogo.removeAttribute('src');
            }

            if(domainDisplay) {
                const subdomain = data.subdomain || '';
                const domain = data.custom_domain || (subdomain ? `${subdomain}.quickmytickets.com` : 'Not configured');
                domainDisplay.textContent = domain;
            }
            
            updatePreview();
        } else {
            // Defaults
            if(inputName) inputName.value = theatreSelect.options[theatreSelect.selectedIndex].text;
            if(inputTagline) inputTagline.value = '';
            if(inputPrimary) inputPrimary.value = '#e50914';
            if(inputAccent) inputAccent.value = '#ffffff';
            if(inputBg) inputBg.value = '#141414';
            if(inputWhatsapp) inputWhatsapp.value = '';
            if(inputEmail) inputEmail.value = '';
            if(inputPoweredBy) inputPoweredBy.checked = true;
            if(previewLogo) {
                previewLogo.style.display = 'none';
                previewLogo.removeAttribute('src');
            }
            if(domainDisplay) domainDisplay.textContent = 'Not configured';
            updatePreview();
        }
    });

    const previewSiteBtn = document.getElementById('preview-branding');
    if (previewSiteBtn) {
        previewSiteBtn.addEventListener('click', (e) => {
            e.preventDefault();
            const theaterId = theatreSelect.value;
            if(!theaterId) return alert('Please select a theatre to preview');
            
            // Safely construct index.html preview URL using the native URL object (supports clean router URLs)
            try {
                const urlObj = new URL(window.location.href);
                const pathParts = urlObj.pathname.split('/');
                pathParts[pathParts.length - 1] = 'index.html';
                urlObj.pathname = pathParts.join('/');
                urlObj.search = '';
                urlObj.hash = `theater=${theaterId}`;
                const previewUrl = urlObj.toString();
                window.open(previewUrl, '_blank');
            } catch (err) {
                console.error('Failed to construct robust preview URL, falling back:', err);
                const baseUrl = window.location.href.split('?')[0].split('#')[0];
                const previewUrl = baseUrl.replace('owner-dashboard.html', 'index.html') + `#theater=${theaterId}`;
                window.open(previewUrl, '_blank');
            }
        });
    }

    const saveBtn = document.getElementById('save-branding');
    if(saveBtn) {
        saveBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            const theaterId = theatreSelect.value;
            if(!theaterId) return alert('Please select a theatre');

            saveBtn.textContent = 'Saving...';
            saveBtn.disabled = true;

            try {
                let logoUrl = previewLogo.src && !previewLogo.src.startsWith('blob:') ? previewLogo.src : null;

                if (inputFile && inputFile.files[0]) {
                    const file = inputFile.files[0];
                    const fileExt = file.name.split('.').pop();
                    const fileName = `${theaterId}/logo-${Date.now()}.${fileExt}`;
                    
                    const supaClient = JayShow.getSupabaseClient();
                    const { error: uploadError, data } = await supaClient.storage
                        .from('branding')
                        .upload(fileName, file, { upsert: true });
                    
                    if (uploadError) throw uploadError;

                    const { data: { publicUrl } } = supaClient.storage.from('branding').getPublicUrl(fileName);
                    logoUrl = publicUrl;
                }

                const payload = {
                    theater_id: theaterId,
                    display_name: inputName.value.trim(),
                    tagline: inputTagline.value.trim(),
                    primary_color: inputPrimary.value,
                    accent_color: inputAccent.value,
                    background_color: inputBg.value,
                    whatsapp_number: inputWhatsapp.value.trim(),
                    support_email: inputEmail.value.trim(),
                    show_powered_by: inputPoweredBy.checked,
                    active: true
                };

                if(logoUrl) payload.logo_url = logoUrl;

                const brandClient = JayShow.getSupabaseClient();
                const { error } = await brandClient.from('theater_branding').upsert(payload, { onConflict: 'theater_id' });
                if (error) throw error;

                if(window.JayShow.showToast) {
                    window.JayShow.showToast('Branding saved successfully!', 'success');
                } else {
                    alert('Branding saved successfully!');
                }
            } catch(err) {
                console.error('Save branding error:', err);
                if(window.JayShow.showToast) {
                    window.JayShow.showToast('Failed to save branding: ' + err.message, 'error');
                } else {
                    alert('Failed to save branding: ' + err.message);
                }
            } finally {
                saveBtn.textContent = 'Save Branding';
                saveBtn.disabled = false;
            }
        });
    }
});

// Offline Seat Selection Logic
const selectedOfflineSeats = new Set();

window.toggleSeatSelection = function(seatId) {
    const seatEl = document.getElementById('owner-seat-' + seatId);
    if (!seatEl) return;
    
    // Toggle visual selection for toggling offline
    if (selectedOfflineSeats.has(seatId)) {
        selectedOfflineSeats.delete(seatId);
        seatEl.style.outline = 'none';
        seatEl.style.boxShadow = 'none';
    } else {
        selectedOfflineSeats.add(seatId);

        seatEl.style.outline = '2px solid var(--primary)';
        seatEl.style.boxShadow = '0 0 8px var(--primary)';
    }
    
    const btn = document.getElementById('toggle-offline-btn');
    if (btn) btn.disabled = selectedOfflineSeats.size === 0;
};

window.toggleOfflineStatus = async function() {
    if (selectedOfflineSeats.size === 0 || !currentShowId) return;
    
    const btn = document.getElementById('toggle-offline-btn');
    const feedback = document.getElementById('offline-feedback');
    
    btn.disabled = true;
    btn.textContent = 'Updating...';
    
    // Determine target state based on the first selected seat's current state
    const firstSeatId = Array.from(selectedOfflineSeats)[0];
    const firstSeatEl = document.getElementById('owner-seat-' + firstSeatId);
    const isCurrentlyOffline = firstSeatEl && firstSeatEl.dataset.state === 'offline';
    
    // We want to flip it: if it was offline, we make it available (p_offline = false)
    const targetOffline = !isCurrentlyOffline;

    try {
        const client = JayShow.getSupabaseClient();
        const { error } = await client.rpc('toggle_offline_seats', {
            p_show_id: currentShowId,
            p_seat_ids: Array.from(selectedOfflineSeats),
            p_offline: targetOffline
        });
        
        if (error) throw error;
        
        feedback.textContent = 'Seats updated successfully!';
        feedback.style.color = 'green';
        
        // Reset selection
        selectedOfflineSeats.forEach(id => {
            const el = document.getElementById('owner-seat-' + id);
            if(el) {
                el.style.outline = 'none';
                el.style.boxShadow = 'none';
            }
        });
        selectedOfflineSeats.clear();
        btn.disabled = true;
        btn.textContent = 'Toggle Offline Status';
        
        // Reload seat grid to reflect new state
        await loadSeatGrid(currentShowId, currentShowType);
        
    } catch (error) {
        console.error('Error toggling offline status:', error);
        feedback.textContent = 'Error: ' + error.message;
        feedback.style.color = 'red';
        btn.disabled = false;
        btn.textContent = 'Toggle Offline Status';
    }
    
    setTimeout(() => {
        if(feedback.textContent.includes('successfully')) {
            feedback.textContent = '';
        }
    }, 3000);
};

// ============================================
// Modal-Based Offline Seat Management
// ============================================

let offlineModalShowId = null;
let offlineModalScreenId = null;
let offlineModalShowType = 'movie';

async function openOfflineModal(showId, screenId, showType = 'movie') {
    offlineModalShowId = showId;
    offlineModalScreenId = screenId;
    offlineModalShowType = showType || 'movie';
    const modal = document.getElementById('offline-seats-modal');
    if (modal) modal.classList.remove('hidden');
    await renderOfflineGrid();
}
window.openOfflineModal = openOfflineModal;

function closeOfflineModal() {
    const modal = document.getElementById('offline-seats-modal');
    if (modal) modal.classList.add('hidden');
    offlineModalScreenId = null;
    offlineModalShowType = 'movie';
}
window.closeOfflineModal = closeOfflineModal;

async function renderOfflineGrid() {
    const grid = document.getElementById('offline-seat-grid');
    const status = document.getElementById('offline-status');
    grid.innerHTML = '<p style="color:var(--text-muted);">Loading seats...</p>';
    status.textContent = '';

    const client = JayShow.getSupabaseClient();

    // 1. Get screen layout
    const { data: screen, error: screenErr } = await client
        .from('screens')
        .select('seat_layout')
        .eq('id', offlineModalScreenId)
        .single();

    if (screenErr || !screen?.seat_layout?.rows) {
        grid.innerHTML = '<p style="color:var(--danger);">Could not load seat layout</p>';
        return;
    }

    // 2. Get current availability
    const viewName = offlineModalShowType === 'event' ? 'event_seat_availability' : 'seat_availability';
    const filterCol = offlineModalShowType === 'event' ? 'event_show_id' : 'show_id';

    const { data: availability, error: avErr } = await client
        .from(viewName)
        .select('seat_id, availability_status, row, col')
        .eq(filterCol, offlineModalShowId);

    if (avErr) {
        grid.innerHTML = '<p style="color:var(--danger);">Could not load seat status: ' + avErr.message + '</p>';
        return;
    }

    // Build lookup: seat row+col => status
    const statusMap = {};
    const seatIdMap = {};
    (availability || []).forEach(s => {
        const key = s.row + '-' + s.col;
        statusMap[key] = s.availability_status;
        seatIdMap[key] = s.seat_id;
    });

    // 3. Render grid
    const layout = screen.seat_layout;
    grid.innerHTML = '';

    layout.rows.forEach((row) => {
        const rowEl = document.createElement('div');
        rowEl.style.cssText = 'display:flex;align-items:center;gap:4px;';

        const labelEl = document.createElement('span');
        labelEl.style.cssText = 'width:28px;font-weight:700;color:var(--text-muted);font-size:0.8rem;text-align:center;';
        labelEl.textContent = row.label;
        rowEl.appendChild(labelEl);

        (row.seats || []).forEach((seat) => {
            const seatEl = document.createElement('div');
            seatEl.style.cssText = 'width:32px;height:32px;border-radius:4px;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:600;color:white;cursor:pointer;transition:all 0.15s;';

            if (!seat) {
                // Gap
                seatEl.style.background = 'transparent';
                seatEl.style.border = '1px dashed var(--border-color)';
                seatEl.style.cursor = 'default';
                rowEl.appendChild(seatEl);
                return;
            }

            const key = row.label + '-' + seat.id;
            const st = statusMap[key] || 'available';
            const seatUuid = seatIdMap[key];

            seatEl.textContent = seat.id;
            seatEl.dataset.seatKey = key;
            seatEl.dataset.seatUuid = seatUuid || '';
            seatEl.dataset.status = st;

            if (st === 'offline') {
                seatEl.style.background = '#f59e0b';
                seatEl.title = 'Offline (click to release)';
            } else if (st === 'booked' || st === 'locked') {
                seatEl.style.background = '#555';
                seatEl.style.cursor = 'not-allowed';
                seatEl.title = st === 'booked' ? 'Booked online' : 'Currently locked';
            } else {
                // available — color by tier
                if (seat.type === 'vip') seatEl.style.background = 'var(--seat-vip)';
                else if (seat.type === 'premium') seatEl.style.background = 'var(--seat-premium)';
                else seatEl.style.background = 'var(--seat-regular)';
                seatEl.title = 'Available (click to mark offline)';
            }

            if (st !== 'booked' && st !== 'locked') {
                seatEl.onclick = () => toggleOfflineSeat(seatEl, seatUuid, st);
                seatEl.onmouseenter = () => { seatEl.style.transform = 'scale(1.15)'; };
                seatEl.onmouseleave = () => { seatEl.style.transform = 'scale(1)'; };
            }

            rowEl.appendChild(seatEl);
        });

        grid.appendChild(rowEl);
    });

    // Count offline
    const offlineCount = Object.values(statusMap).filter(s => s === 'offline').length;
    status.textContent = offlineCount > 0 ? `${offlineCount} seat(s) reserved for offline selling` : 'No seats reserved for offline';
}

async function toggleOfflineSeat(seatEl, seatUuid, currentStatus) {
    if (!seatUuid) {
        alert('Seat ID not found. Please ensure the seat layout is saved first.');
        return;
    }

    const makeOffline = currentStatus !== 'offline';
    seatEl.style.opacity = '0.5';
    seatEl.style.pointerEvents = 'none';

    const client = JayShow.getSupabaseClient();
    const { error } = await client.rpc('toggle_offline_seats', {
        p_show_id: offlineModalShowId,
        p_seat_ids: [seatUuid],
        p_offline: makeOffline
    });

    if (error) {
        alert('Failed to toggle seat: ' + error.message);
        seatEl.style.opacity = '1';
        seatEl.style.pointerEvents = 'auto';
        return;
    }

    // Re-render the grid to reflect the new state
    await renderOfflineGrid();
}
window.toggleOfflineSeat = toggleOfflineSeat;

// ==========================================
// Customer List Modal Logic
// ==========================================

let currentCustomerData = [];

window.openCustomerListModal = async function(passedShowId, passedShowType) {
    if (passedShowId) {
        currentShowId = passedShowId;
        currentShowType = passedShowType || 'movie';
    }
    if (!currentShowId) return;
    
    const modal = document.getElementById('customer-list-modal');
    const tbody = document.getElementById('customer-list-body');
    const loading = document.getElementById('customer-list-loading');
    const empty = document.getElementById('customer-list-empty');
    
    if (modal) modal.classList.remove('hidden');
    
    tbody.innerHTML = '';
    loading.classList.remove('hidden');
    empty.classList.add('hidden');
    
    try {
        const client = JayShow.getSupabaseClient();
        const user = await JayShow.getUser();
        if (!user) throw new Error('Not logged in');

        const { data, error } = await client.rpc('get_customer_bookings_for_show', {
            p_show_id: currentShowId,
            p_type: currentShowType || 'movie'
        });

        if (error) throw error;

        currentCustomerData = data || [];
        loading.classList.add('hidden');

        if (currentCustomerData.length === 0) {
            empty.classList.remove('hidden');
            return;
        }

        tbody.innerHTML = currentCustomerData.map(booking => {
            const seatLabel = `${booking.seat_row}${booking.seat_col}`;
            const dateStr = new Date(booking.created_at).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' });
            return `
                <tr style="border-bottom: 1px solid rgba(255,255,255,0.05); transition: background 0.2s;">
                    <td style="padding: 1rem; font-weight: 600; color: var(--primary);">${JayShow.escapeHtml(seatLabel)}</td>
                    <td style="padding: 1rem;">${JayShow.escapeHtml(booking.guest_name || 'Anonymous')}</td>
                    <td style="padding: 1rem; color: var(--text-secondary);">${JayShow.escapeHtml(booking.guest_email || 'N/A')}</td>
                    <td style="padding: 1rem; color: var(--text-secondary);">${JayShow.escapeHtml(booking.guest_phone || 'N/A')}</td>
                    <td style="padding: 1rem;">₹${booking.price}</td>
                    <td style="padding: 1rem; color: var(--text-secondary); font-size: 0.8rem;">${dateStr}</td>
                </tr>
            `;
        }).join('');

    } catch (err) {
        console.error('Error fetching customer list:', err);
        loading.classList.add('hidden');
        tbody.innerHTML = `<tr><td colspan="6" style="padding: 2rem; text-align: center; color: var(--danger);">Error loading data: ${err.message}</td></tr>`;
    }
};

window.closeCustomerListModal = function() {
    const modal = document.getElementById('customer-list-modal');
    if (modal) modal.classList.add('hidden');
};

window.downloadCustomerCSV = function() {
    if (!currentCustomerData || currentCustomerData.length === 0) {
        JayShow.showToast('No customer data to download', 'error');
        return;
    }

    const headers = ['Seat', 'Name', 'Email', 'Phone', 'Price', 'Booking Date'];
    const rows = currentCustomerData.map(b => [
        `${b.seat_row}${b.seat_col}`,
        b.guest_name || 'Anonymous',
        b.guest_email || 'N/A',
        b.guest_phone || 'N/A',
        b.price,
        new Date(b.created_at).toLocaleString()
    ]);

    const csvContent = [
        headers.join(','),
        ...rows.map(r => r.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `customers_show_${currentShowId}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
};
