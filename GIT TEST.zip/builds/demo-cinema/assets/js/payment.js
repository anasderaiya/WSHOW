/**
 * Quick My Ticket - Payment Integration
 * =====================================
 * 
 * This module handles payment processing with Razorpay and
 * communication with Supabase Edge Functions for order creation
 * and payment verification.
 * 
 * DEMO MODE:
 * ----------
 * When DEMO_MODE is true, payments are simulated without actual
 * Razorpay integration. This is useful for testing the UI flow.
 * 
 * SECURITY NOTE:
 * --------------
 * The Razorpay KEY SECRET must NEVER be in client-side code!
 * It should only be used in Supabase Edge Functions.
 * 
 * Your Edge Function needs to be created to:
 * 1. Create orders (using secret key)
 * 2. Verify payment signatures (using secret key)
 * 
 * SECURITY BEST PRACTICES:
 * ------------------------
 * 1. Order creation MUST happen on the server (Edge Function)
 * 2. Payment verification MUST happen on the server (Edge Function)
 * 3. Consider implementing a webhook as backup verification
 */

// ============================================
// Configuration
// ============================================

// Set to false when Edge Functions are ready.
// SAFETY: Even if accidentally set to true, it is force-disabled on
// non-localhost origins so a production deploy can never run in demo mode.
const _DEMO_MODE_FLAG = false;
const DEMO_MODE = _DEMO_MODE_FLAG && (['localhost', '127.0.0.1', ''].includes(window.location.hostname));

// Razorpay Key ID — injected at build/deploy time via config.js:
//   window.QMT_CONFIG.RAZORPAY_KEY (set by deploy-theater.sh replacing %%RAZORPAY_KEY%%)
//   Falls back to <meta name="razorpay-key"> then to an obvious placeholder
//   so a missing key is immediately visible rather than silently using a test key.
const RAZORPAY_KEY_ID =
    window.QMT_CONFIG?.RAZORPAY_KEY ||
    document.querySelector('meta[name="razorpay-key"]')?.getAttribute('content') ||
    'rzp_test_placeholder_key_not_configured';

// Edge Function base URL — derived from the Supabase project URL already
// declared in app.js (SUPABASE_URL) or from a <meta> tag. This avoids
// hardcoding the project reference in a second place.
const _SUPABASE_BASE = (
    document.querySelector('meta[name="supabase-url"]')?.getAttribute('content') ||
    window.SUPABASE_URL ||
    '' // will be caught at call time
);
const EDGE_FN_CREATE_ORDER_URL  = `${_SUPABASE_BASE}/functions/v1/create-order`;
const EDGE_FN_VERIFY_PAYMENT_URL = `${_SUPABASE_BASE}/functions/v1/verify-payment`;

// ============================================
// Order Creation
// ============================================

/**
 * Creates a Razorpay order by calling the Edge Function.
 * In demo mode, simulates order creation.
 * 
 * @param {number} amount - Amount in smallest currency unit (paise for INR)
 * @param {string} receipt - Unique receipt ID (e.g., booking reference)
 * @param {string[]} bookingIds - Array of booking IDs to associate with order
 * @returns {Promise<Object>} Razorpay order object or error
 */
async function createOrder(amount, receipt, bookingIds = []) {
    // Demo mode - simulate order creation
    if (DEMO_MODE) {
        return {
            order: {
                id: 'demo_order_' + Date.now(),
                amount: amount,
                currency: 'INR',
                receipt: receipt
            },
            error: null
        };
    }

    try {
        // Get auth token to pass to Edge Function
        const client = window.JayShow?.getSupabaseClient();
        let authToken = '';
        let sessionId = null;

        if (client) {
            const { data: { session } } = await client.auth.getSession();
            authToken = session?.access_token || '';
        }

        // For guest users, use the anon key so the Edge Function accepts the request
        if (!authToken) {
            authToken = window.JayShow?.getAnonKey?.() || '';
            sessionId = window.JayShow?.getGuestSessionId?.() || null;
        }

        const response = await fetch(EDGE_FN_CREATE_ORDER_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({
                amount,
                currency: 'INR',
                receipt,
                booking_ids: bookingIds,
                session_id: sessionId
            })
        });

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.error || `HTTP ${response.status}: Failed to create order`);
        }

        const order = await response.json();

        if (!order.id || !order.amount) {
            throw new Error('Invalid order response from server');
        }

        return { order, error: null };

    } catch (error) {
        console.error('Error creating order:', error.message);
        return { order: null, error };
    }
}

// ============================================
// Payment Verification
// ============================================

/**
 * Verifies payment by calling the Edge Function.
 * In demo mode, simulates verification.
 * 
 * @param {Object} payload - Payment verification payload
 * @returns {Promise<Object>} Verification result or error
 */
async function verifyPayment(payload) {
    // Demo mode - simulate verification and confirm bookings
    if (DEMO_MODE) {
        const bookingIds = payload.booking_ids || [];

        // Update bookings to confirmed status using RPC to ensure tokens are generated
        if (bookingIds.length > 0 && window.JayShow) {
            const client = window.JayShow.getSupabaseClient();
            if (client) {
                // Call the confirm_bookings RPC just like the edge function does
                const { data, error } = await client.rpc('confirm_bookings', {
                    p_booking_ids: bookingIds,
                    p_payment_id: payload.razorpay_payment_id,
                    p_guest_name: payload.guest_name || null,
                    p_guest_email: payload.guest_email || null,
                    p_guest_phone: payload.guest_phone || null
                });
                
                // Also fetch the generated tokens since the edge function does this
                if (!error) {
                    const { data: tokenData } = await client
                        .from('bookings')
                        .select('ticket_token')
                        .in('id', bookingIds)
                        .not('ticket_token', 'is', null);
                        
                    if (tokenData) {
                        return {
                            result: { 
                                verified: true, 
                                message: 'Demo payment successful',
                                tokens: tokenData.map(b => b.ticket_token)
                            },
                            error: null
                        };
                    }
                }
            }
        }

        return {
            result: { verified: true, message: 'Demo payment successful' },
            error: null
        };
    }

    try {
        const client = window.JayShow?.getSupabaseClient();
        let authToken = '';
        let sessionId = null;

        if (client) {
            const { data: { session } } = await client.auth.getSession();
            authToken = session?.access_token || '';
        }

        // For guest users, use the anon key so the Edge Function accepts the request
        if (!authToken) {
            authToken = window.JayShow?.getAnonKey?.() || '';
            sessionId = window.JayShow?.getGuestSessionId?.() || null;
        }

        const response = await fetch(EDGE_FN_VERIFY_PAYMENT_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({
                razorpay_order_id: payload.razorpay_order_id,
                razorpay_payment_id: payload.razorpay_payment_id,
                razorpay_signature: payload.razorpay_signature,
                booking_ids: payload.booking_ids || [],
                session_id: sessionId,
                guest_name: payload.guest_name,
                guest_email: payload.guest_email,
                guest_phone: payload.guest_phone
            })
        });

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.error || `HTTP ${response.status}: Payment verification failed`);
        }

        const result = await response.json();
        return { result, error: null };

    } catch (error) {
        console.error('Error verifying payment:', error.message);
        return { result: null, error };
    }
}

// ============================================
// Razorpay Checkout
// ============================================

/**
 * Launches Razorpay checkout or demo payment modal.
 * 
 * @param {Object} order - Razorpay order object (from createOrder)
 * @param {Object} buyer - Buyer details
 * @param {Object} options - Additional options
 * @returns {Promise<Object>} Payment response or error
 */
function startRazorpay(order, buyer, options = {}) {
    return new Promise((resolve, reject) => {
        // Demo mode - show simulated payment modal
        if (DEMO_MODE) {
            showDemoPaymentModal(order, buyer, options)
                .then(resolve)
                .catch(reject);
            return;
        }

        // Check if Razorpay is loaded
        if (typeof Razorpay === 'undefined') {
            reject(new Error('Razorpay SDK not loaded. Include checkout.razorpay.com/v1/checkout.js'));
            return;
        }

        const rzpOptions = {
            key: RAZORPAY_KEY_ID,
            amount: order.amount,
            currency: order.currency || 'INR',
            name: window.QMT_CONFIG?.THEATER_NAME || document.title || 'Quick my Ticket',
            description: options.description || 'Movie Ticket Booking',
            order_id: order.id,
            prefill: {
                name: buyer.name || '',
                email: buyer.email || '',
                contact: buyer.phone || ''
            },
            theme: {
                color: getComputedStyle(document.documentElement).getPropertyValue('--brand-primary').trim() || '#d4af37'
            },
            modal: {
                ondismiss: function () {
                    reject(new Error('Payment cancelled by user'));
                }
            },
            handler: async function (response) {
                try {
                    const { result, error } = await verifyPayment({
                        razorpay_order_id: response.razorpay_order_id,
                        razorpay_payment_id: response.razorpay_payment_id,
                        razorpay_signature: response.razorpay_signature,
                        booking_ids: options.bookingIds || [],
                        guest_name: buyer.name,
                        guest_email: buyer.email,
                        guest_phone: buyer.phone
                    });

                    if (error) {
                        // SECURITY FIX: reject so the UI shows an error instead of
                        // silently treating an unverified payment as success.
                        reject(error);
                    } else {
                        resolve({
                            success: true,
                            verified: true,
                            payment_id: response.razorpay_payment_id,
                            order_id: response.razorpay_order_id,
                            tokens: result.tokens,
                            result
                        });
                    }
                } catch (err) {
                    // Network / transient error — reject so caller can show
                    // a "verification pending" message and retry.
                    reject(err);
                }
            }
        };

        const razorpay = new Razorpay(rzpOptions);

        razorpay.on('payment.failed', function (response) {
            reject({
                code: response.error.code,
                description: response.error.description,
                source: response.error.source,
                step: response.error.step,
                reason: response.error.reason
            });
        });

        razorpay.open();
    });
}

// ============================================
// Demo Payment Modal
// ============================================

/**
 * Shows a demo payment modal for testing.
 */
function showDemoPaymentModal(order, buyer, options) {
    return new Promise((resolve, reject) => {
        // Remove existing modal if any
        const existingModal = document.getElementById('demo-payment-modal');
        if (existingModal) existingModal.remove();

        const amount = formatAmount(order.amount);

        const modal = document.createElement('div');
        modal.id = 'demo-payment-modal';
        modal.innerHTML = `
            <div class="demo-modal-overlay">
                <div class="demo-modal-content">
                    <div class="demo-modal-header">
                        <h3>${JayShow.icon('credit-card', 'lucide')} Demo Payment</h3>
                        <p style="color: var(--text-muted); font-size: 0.875rem; margin-top: 0.5rem;">
                            This is a simulated payment for demo purposes
                        </p>
                    </div>
                    <div class="demo-modal-body">
                        <div class="demo-payment-amount">${amount}</div>
                        <p style="color: var(--text-secondary); margin-bottom: 1rem;">
                            ${options.description || 'Movie Ticket Booking'}
                        </p>
                        <div style="background: var(--bg-input); padding: 1rem; border-radius: var(--radius-md); margin-bottom: 1rem;">
                            <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                                <span style="color: var(--text-muted);">Card Number</span>
                                <span style="font-family: monospace;">•••• •••• •••• 4242</span>
                            </div>
                            <div style="display: flex; justify-content: space-between;">
                                <span style="color: var(--text-muted);">Email</span>
                                <span>${buyer.email || 'user@example.com'}</span>
                            </div>
                        </div>
                    </div>
                    <div class="demo-modal-actions">
                        <button class="btn btn-secondary" id="demo-cancel-btn">Cancel</button>
                        <button class="btn btn-success" id="demo-pay-btn">
                            Pay ${amount}
                        </button>
                    </div>
                </div>
            </div>
        `;

        // Add styles
        const style = document.createElement('style');
        style.textContent = `
            .demo-modal-overlay {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0, 0, 0, 0.8);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 10000;
                animation: fadeIn 0.3s ease;
            }
            .demo-modal-content {
                background: var(--bg-card);
                border-radius: var(--radius-xl);
                padding: 2rem;
                max-width: 400px;
                width: 90%;
                box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
                animation: slideUp 0.3s ease;
            }
            .demo-modal-header {
                text-align: center;
                margin-bottom: 1.5rem;
            }
            .demo-modal-header h3 {
                margin: 0;
                color: var(--text-primary);
            }
            .demo-payment-amount {
                font-size: 2.5rem;
                font-weight: 700;
                color: var(--accent);
                text-align: center;
                margin-bottom: 0.5rem;
            }
            .demo-modal-body {
                text-align: center;
            }
            .demo-modal-actions {
                display: flex;
                gap: 1rem;
                margin-top: 1.5rem;
            }
            .demo-modal-actions .btn {
                flex: 1;
                padding: 1rem;
            }
            @keyframes slideUp {
                from { transform: translateY(20px); opacity: 0; }
                to { transform: translateY(0); opacity: 1; }
            }
        `;
        modal.appendChild(style);
        document.body.appendChild(modal);

        // Handle cancel
        document.getElementById('demo-cancel-btn').addEventListener('click', () => {
            modal.remove();
            reject(new Error('Payment cancelled by user'));
        });

        // Handle pay
        document.getElementById('demo-pay-btn').addEventListener('click', async () => {
            const payBtn = document.getElementById('demo-pay-btn');
            payBtn.disabled = true;
            payBtn.innerHTML = '<div class="spinner" style="width: 20px; height: 20px;"></div> Processing...';

            // Simulate payment processing delay
            await new Promise(r => setTimeout(r, 1500));

            const paymentId = 'demo_pay_' + Date.now();

            // Verify (confirms bookings in demo mode)
            const { result, error } = await verifyPayment({
                razorpay_order_id: order.id,
                razorpay_payment_id: paymentId,
                razorpay_signature: 'demo_signature',
                booking_ids: options.bookingIds || []
            });

            modal.remove();

            if (error) {
                reject(error);
            } else {
                resolve({
                    success: true,
                    verified: true,
                    payment_id: paymentId,
                    order_id: order.id,
                    tokens: result.tokens
                });
            }
        });

        // Close on overlay click
        modal.querySelector('.demo-modal-overlay').addEventListener('click', (e) => {
            if (e.target === e.currentTarget) {
                modal.remove();
                reject(new Error('Payment cancelled by user'));
            }
        });
    });
}

// ============================================
// Utility Functions
// ============================================

/**
 * Formats amount from paise to rupees with currency symbol.
 * 
 * @param {number} amountInPaise - Amount in paise
 * @returns {string} Formatted amount (e.g., "₹500.00")
 */
function formatAmount(amountInPaise) {
    const rupees = amountInPaise / 100;
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR'
    }).format(rupees);
}

/**
 * Calculates total with tax.
 * 
 * @param {number} subtotal - Subtotal in paise
 * @param {number} taxRate - Tax rate as decimal (e.g., 0.18 for 18%)
 * @returns {Object} Object with subtotal, tax, and total in paise
 */
function calculateTotal(subtotal, seatCount = 1, taxRate = 0.18) {
    // Read the fee from global window variable (loaded during initialization)
    const feeSetting = window.platformConvenienceFee || null;
    let convenienceFee = 0;
    
    if (feeSetting) {
        if (feeSetting.type === 'fixed') {
            convenienceFee = Math.round((feeSetting.amount * 100) * seatCount);
        } else if (feeSetting.type === 'percentage') {
            convenienceFee = Math.round(subtotal * (feeSetting.amount / 100));
        }
    }
    
    // Option B: GST is applied ONLY on the convenience fee, not on the ticket base price
    const tax = Math.round(convenienceFee * taxRate);
    const total = subtotal + convenienceFee + tax;
    
    return { subtotal, convenienceFee, tax, total };
}

/**
 * Generates a unique receipt ID.
 * 
 * @param {string} prefix - Prefix for the receipt ID
 * @returns {string} Unique receipt ID
 */
function generateReceiptId(prefix = 'JS') {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substring(2, 8);
    return `${prefix}-${timestamp}-${random}`.toUpperCase();
}

// ============================================
// Export
// ============================================

window.QMyTicketPayment = window.JayShowPayment = {
    createOrder,
    verifyPayment,
    startRazorpay,
    formatAmount,
    calculateTotal,
    generateReceiptId,

    // Constants
    TAX_RATE: 0.18,
    DEMO_MODE,
    get RAZORPAY_KEY_ID() { return RAZORPAY_KEY_ID; }
};
