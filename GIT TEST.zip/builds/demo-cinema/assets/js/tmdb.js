/**
 * TMDB Helper Module
 * ==================
 * Fetches movie data from The Movie Database API via Supabase Edge Function proxy.
 */

const TMDB_IMAGE_BASE_URL = 'https://image.tmdb.org/t/p/w1280';

const JayShowTMDB = {
    /**
     * Builds the proxied URL for a TMDB endpoint with optional parameters
     */
    getProxyUrl(endpoint, params = {}) {
        const supabaseUrl = window.QMT_CONFIG?.SUPABASE_URL || JayShow.SUPABASE_URL;
        if (!supabaseUrl) return null;
        
        const url = new URL(`${supabaseUrl}/functions/v1/tmdb-proxy`);
        url.searchParams.set('endpoint', endpoint);
        Object.entries(params).forEach(([k, v]) => {
            if (v !== undefined && v !== null) {
                url.searchParams.set(k, v);
            }
        });
        return url.toString();
    },

    /**
     * Helper to get necessary headers for Supabase Edge Functions
     */
    getHeaders() {
        const anonKey = window.QMT_CONFIG?.SUPABASE_ANON || JayShow.SUPABASE_ANON_KEY;
        return {
            'apikey': anonKey,
            'Content-Type': 'application/json'
        };
    },

    /**
     * Fetch trending movies from TMDB via Supabase Edge Function proxy
     */
    async fetchTrendingMovies() {
        const url = this.getProxyUrl('trending');
        if (!url) {
            console.warn('Supabase URL not initialized. Returning fallback data.');
            return this.getFallbackMovies();
        }

        try {
            const response = await fetch(url, { headers: this.getHeaders() });
            if (!response.ok) {
                throw new Error(`Server returned status ${response.status}`);
            }
            
            const data = await response.json();
            if (data.error) {
                console.warn('tmdb-proxy returned error:', data.error);
                return this.getFallbackMovies();
            }

            return data.results.map(movie => ({
                id: movie.id,
                title: movie.title,
                overview: movie.overview,
                poster: movie.poster_path ? `${TMDB_IMAGE_BASE_URL}${movie.poster_path}` : 'assets/images/placeholder-poster.svg',
                backdrop: movie.backdrop_path ? `${TMDB_IMAGE_BASE_URL}${movie.backdrop_path}` : 'https://images.unsplash.com/photo-1440404653325-ab127d49abc1?auto=format&fit=crop&q=80&w=2000',
                rating: movie.vote_average,
                release_date: movie.release_date
            }));
        } catch (error) {
            console.error('Error fetching from TMDB proxy:', error);
            return this.getFallbackMovies();
        }
    },

    /**
     * Search movies on TMDB via Supabase Edge Function proxy
     */
    async searchMovies(query) {
        const url = this.getProxyUrl('search', { query });
        if (!url) return [];

        try {
            const response = await fetch(url, { headers: this.getHeaders() });
            if (!response.ok) throw new Error(`Server returned status ${response.status}`);
            
            const data = await response.json();
            if (data.error) {
                console.warn('searchMovies proxy returned error:', data.error);
                return [];
            }
            return data.results || [];
        } catch (error) {
            console.error('Error searching TMDB via proxy:', error);
            return [];
        }
    },

    /**
     * Fetch movie details from TMDB via Supabase Edge Function proxy
     */
    async fetchMovieDetails(id) {
        const url = this.getProxyUrl('details', { id });
        if (!url) return null;

        try {
            const response = await fetch(url, { headers: this.getHeaders() });
            if (!response.ok) throw new Error(`Server returned status ${response.status}`);
            
            const data = await response.json();
            if (data.error) {
                console.warn('fetchMovieDetails proxy returned error:', data.error);
                return null;
            }
            return data;
        } catch (error) {
            console.error('Error fetching movie details via proxy:', error);
            return null;
        }
    },

    /**
     * Fetch movie credits from TMDB via Supabase Edge Function proxy
     */
    async fetchMovieCredits(id) {
        const url = this.getProxyUrl('credits', { id });
        if (!url) return null;

        try {
            const response = await fetch(url, { headers: this.getHeaders() });
            if (!response.ok) throw new Error(`Server returned status ${response.status}`);
            
            const data = await response.json();
            if (data.error) return null;
            return data;
        } catch (error) {
            console.error('Error fetching movie credits via proxy:', error);
            return null;
        }
    },

    /**
     * Fetch movie videos from TMDB via Supabase Edge Function proxy
     */
    async fetchMovieVideos(id) {
        const url = this.getProxyUrl('videos', { id });
        if (!url) return null;

        try {
            const response = await fetch(url, { headers: this.getHeaders() });
            if (!response.ok) throw new Error(`Server returned status ${response.status}`);
            
            const data = await response.json();
            if (data.error) return null;
            return data;
        } catch (error) {
            console.error('Error fetching movie videos via proxy:', error);
            return null;
        }
    },

    /**
     * Fallback data in case of API issues or missing key
     */
    getFallbackMovies() {
        return [
            {
                id: 1,
                title: "Dune: Part Two",
                overview: "Follow the mythic journey of Paul Atreides as he unites with Chani and the Fremen while on a warpath of revenge against the conspirators who destroyed his family.",
                backdrop: "https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&q=80&w=2000",
                rating: 8.5
            },
            {
                id: 2,
                title: "Oppenheimer",
                overview: "The story of J. Robert Oppenheimer's role in the development of the atomic bomb.",
                backdrop: "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?auto=format&fit=crop&q=80&w=2000",
                rating: 8.9
            }
        ];
    }
};

window.JayShowTMDB = JayShowTMDB;
