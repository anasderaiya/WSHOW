/**
 * JayShow - Events Page Logic
 * ============================
 * 
 * Handles the events listing page:
 * - Fetches events from Supabase
 * - Renders event cards and featured events
 * - Category filtering
 * - Manages navbar login status
 */

let allEvents = [];
let currentCategory = 'all';

document.addEventListener('DOMContentLoaded', async () => {
    await JayShow.updateNavbar();
    await loadEvents();
    setupCategoryTabs();
});


/**
 * Loads events from Supabase
 */
async function loadEvents() {
    const container = document.getElementById('events-grid');
    if (container && !container.querySelector('.spinner, .skeleton')) {
        container.innerHTML = `
            <div class="loading" style="padding: 3rem; 
                 grid-column: 1/-1; text-align: center;">
                <div class="spinner"></div>
            </div>`;
    }

    const eventsGrid = document.getElementById('events-grid');
    const featuredGrid = document.getElementById('featured-grid');

    try {
        const { data: events, error } = await JayShow.fetchEvents();

        if (error) {
            console.error('Error fetching events:', error.message);
            eventsGrid.innerHTML = `
                <div class="alert alert-error" style="grid-column: 1/-1;">
                    Failed to load events. Please try again later.
                </div>
            `;
            return;
        }

        allEvents = events || [];

        if (allEvents.length === 0) {
            eventsGrid.innerHTML = `
                <div class="text-center" style="grid-column: 1/-1; padding: 2rem;">
                    <h3>No events available</h3>
                    <p style="color: var(--text-secondary);">Check back later for upcoming events!</p>
                </div>
            `;
            featuredGrid.innerHTML = '';
            return;
        }

        // Render featured events
        renderFeaturedEvents();

        // Render all events
        renderEvents();
    } catch (err) {
        console.error('Error loading events:', err);
        eventsGrid.innerHTML = `
            <div class="alert alert-error" style="grid-column: 1/-1;">
                An error occurred while loading events.
            </div>
        `;
    }
}

/**
 * Renders featured events in the featured grid
 */
function renderFeaturedEvents() {
    const featuredGrid = document.getElementById('featured-grid');
    const featuredEvents = allEvents.filter(e => e.is_featured).slice(0, 2);

    if (featuredEvents.length === 0) {
        document.getElementById('featured-section').style.display = 'none';
        return;
    }

    featuredGrid.innerHTML = featuredEvents.map((event, index) => `
        <a href="./event.html?id=${event.id}" class="featured-card ${index === 0 ? 'main' : ''}">
            <img src="${escapeHtml(event.poster_url || event.banner_url || 'assets/images/placeholder-poster.svg')}" 
                 alt="${escapeHtml(event.title)}"
                 onerror="this.src='assets/images/placeholder-poster.svg'">
            <div class="featured-overlay">
                <span class="featured-badge">${getCategoryIcon(event.category)} ${event.category}</span>
                <h3 class="featured-title">${escapeHtml(event.title)}</h3>
                <p class="featured-meta">${JayShow.icon('map-pin', 'inline-icon')} ${escapeHtml(event.venue_name || 'TBA')} • ${escapeHtml(event.city || '')}</p>
            </div>
        </a>
    `).join('');
}

/**
 * Renders events in the events grid
 */
function renderEvents() {
    const eventsGrid = document.getElementById('events-grid');

    let filteredEvents = allEvents;
    if (currentCategory !== 'all') {
        filteredEvents = allEvents.filter(e => e.category === currentCategory);
    }

    if (filteredEvents.length === 0) {
        eventsGrid.innerHTML = `
            <div class="text-center" style="grid-column: 1/-1; padding: 2rem;">
                <h3>No ${currentCategory} events</h3>
                <p style="color: var(--text-secondary);">Try a different category or check back later.</p>
            </div>
        `;
        return;
    }

    eventsGrid.innerHTML = filteredEvents.map(event => createEventCard(event)).join('');
}

/**
 * Creates HTML for an event card
 * @param {Object} event - Event object from Supabase
 * @returns {string} HTML string for the event card
 */
function createEventCard(event) {
    const posterUrl = event.poster_url || 'assets/images/placeholder-poster.svg';

    return `
        <div class="event-card" onclick="window.location.href='./event.html?id=${event.id}'">
            <div class="event-poster-wrapper">
                <img src="${escapeHtml(posterUrl)}" 
                     alt="${escapeHtml(event.title)}"
                     class="event-poster"
                     loading="lazy"
                     onerror="this.src='assets/images/placeholder-poster.svg'">
            </div>
            <div class="event-content">
                <span class="event-category-badge">
                    ${getCategoryIcon(event.category)} ${event.category}
                </span>
                <h3 class="event-title">${escapeHtml(event.title)}</h3>
                <div class="event-details-row">
                    <div class="event-detail-item">
                        ${JayShow.icon('map-pin', 'inline-icon')} 
                        <span>${escapeHtml(event.venue_name || 'Venue TBA')}</span>
                    </div>
                    <div class="event-detail-item">
                        ${JayShow.icon('building-2', 'inline-icon')} 
                        <span>${escapeHtml(event.city || 'City TBA')}</span>
                    </div>
                </div>
                <div class="event-footer">
                    <div class="event-price-wrapper">
                        <div class="event-price-label">Starting from</div>
                        <div class="event-price-tag">₹499</div>
                    </div>
                    <button class="btn btn-ghost btn-sm">Book Now</button>
                </div>
            </div>
        </div>
    `;
}

/**
 * Sets up category tab click handlers
 */
function setupCategoryTabs() {
    const tabs = document.querySelectorAll('.category-tab');

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Update active state
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');

            // Filter events
            currentCategory = tab.dataset.category;
            renderEvents();
        });
    });
}

/**
 * Gets the icon for a category
 * @param {string} category - Event category
 * @returns {string} Emoji icon
 */
function getCategoryIcon(category) {
    const icons = {
        'concert': JayShow.icon('music', 'inline-icon'),
        'sports': JayShow.icon('trophy', 'inline-icon'),
        'comedy': JayShow.icon('smile', 'inline-icon'),
        'festival': JayShow.icon('tent', 'inline-icon'),
        'theatre': JayShow.icon('drama', 'inline-icon'),
        'workshop': JayShow.icon('graduation-cap', 'inline-icon')
    };
    return icons[category] || JayShow.icon('target', 'inline-icon');
}