/**
 * Quick My Ticket - Seat Selection Page Logic
 * ============================================
 * 
 * Handles seat selection with:
 * - Real-time seat state updates via Supabase subscription
 * - Multi-seat selection with locking
 * - Price calculation with tax
 * - Payment flow integration
 */


// Safe local fallback or reuse from JayShow
const localEscapeHtml = window.JayShow?.escapeHtml || function(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
};

// Offline detection — warn user if network drops during seat selection
window.addEventListener('offline', () => {
    JayShow.showToast(
        '⚠️ You are offline. Your seat is still reserved but ' +
        'reconnect within your timer to complete payment.', 
        'error', 
        8000
    );
});

window.addEventListener('online', () => {
    JayShow.showToast('✓ Back online. Your session is active.', 'info', 3000);
    // Refresh seat availability to catch any changes while offline
    if (typeof loadSeats === 'function') loadSeats();
});

// State management
let currentShow = null;
let seatStates = [];
let selectedBookings = {}; // { seatId: bookingId }
let realtimeSubscription = null;
let currentScreenLayout = null;

let isProcessingClick = false; // Prevent double-clicks

// Timer, Heartbeat & Polling state
let lockTimerInterval = null;      // Countdown timer interval
let heartbeatInterval = null;      // Heartbeat to extend locks
let pollingInterval = null;        // Polling fallback for realtime
let lockStartTime = null;          // When the first seat was locked
const LOCK_DURATION_MS = 5 * 60 * 1000;    // 5 minutes in milliseconds
const HEARTBEAT_INTERVAL_MS = 2 * 60 * 1000; // Send heartbeat every 2 minutes
const POLLING_INTERVAL_MS = 10 * 1000;      // Poll every 10 seconds

document.addEventListener('DOMContentLoaded', async () => {
    await initSeatsPage();
});

/**
 * Initializes the seat selection page.
 * Users can browse and select seats without logging in.
 * Login is required only when they try to pay.
 */
async function initSeatsPage() {
    try {
        const urlParams = new URLSearchParams(window.location.search);
        let showId = urlParams.get('show');
        window.isEventShow = false;

        if (!showId) {
            showId = urlParams.get('event_show');
            if (showId) {
                window.isEventShow = true;
            } else {
                showError('Show ID not provided. Open this page from a movie or event listing.');
                return;
            }
        }

        // Start the heavy seat state fetch IMMEDIATELY in the background
        const seatFetchPromise = window.isEventShow 
            ? JayShow.fetchEventSeatStates(showId) 
            : JayShow.fetchSeatStates(showId);

        // Start cleanup in the background (DO NOT AWAIT - not needed for UI render)
        JayShow.cleanupExpiredLocks().catch(console.error);

        // Run independent tasks in parallel to dramatically speed up loading
        await Promise.all([
            loadShowDetails(showId),
            JayShow.loadPlatformSettings ? JayShow.loadPlatformSettings() : Promise.resolve(),
            JayShow.getUser().then(() => JayShow.updateNavbar())
        ]);

        // Await the seat fetch that was running in parallel
        await loadSeats(showId, seatFetchPromise);

        // Subscribe to real-time updates
        subscribeToSeatUpdates(showId);

        // Start polling fallback (backup for realtime)
        startPolling(showId);

        // Setup pay button
        setupPayButton();

        // Setup auth modal forms
        setupAuthModal();

        // Handle tab visibility changes (pause/resume heartbeat)
        document.addEventListener('visibilitychange', handleVisibilityChange);

        // Event Delegation for seat clicks (fast)
        const gridContainer = document.getElementById('seat-grid');
        if (gridContainer) {
            gridContainer.addEventListener('click', handleSeatClick);
        }

        // Cleanup on page unload
        window.addEventListener('beforeunload', cleanup);
    } catch (error) {
        console.error('Error initializing seats page:', error);
        showError('Initialization Error: ' + error.message);
    }
}


/**
 * Restores visual seat selections after a grid re-render.
 * Consolidates the duplicated restore logic used by realtime, polling, and visibility handlers.
 *
 * @param {Set|Array} seatIds - Seat IDs to restore as selected
 */
function restoreSelections(seatIds) {
    seatIds.forEach(seatId => {
        const seatEl = document.querySelector(`.seat[data-seat-id="${seatId}"]`);
        if (seatEl && !seatEl.classList.contains('booked')) {
            seatEl.classList.add('selected');
            seatEl.classList.remove('locked');
        }
    });
    updateSummary();
}


/**
 * Loads show details for the header.
 * 
 * @param {string} showId - ID of the show
 */
async function loadShowDetails(showId) {
    const headerContainer = document.getElementById('show-header');

    const { data: show, error } = window.isEventShow
        ? await JayShow.fetchEventShow(showId)
        : await JayShow.fetchShow(showId);

    if (error || !show) {
        showError(error?.message || 'Failed to load show details');
        return;
    }

    currentShow = show;

    // Update page title and header
    const title = window.isEventShow ? show.events?.title : show.movies?.title;
    document.title = `Select Seats - ${title || 'Quick my Ticket'}`;

    if (headerContainer) {
        const startTime = new Date(show.start_time).toLocaleString('en-IN', {
            weekday: 'short',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            hour12: true
        });

        headerContainer.innerHTML = `
            <h2>${localEscapeHtml(title || 'Event')}</h2>
            <p style="color: var(--text-secondary);">
                ${localEscapeHtml(show.screens?.theatres?.name || '')} • 
                ${localEscapeHtml(show.screens?.name || '')} • 
                ${startTime}
            </p>
        `;
    }
}

/**
 * Loads and renders the seat grid.
 * 
 * @param {string} showId - ID of the show
 * @param {Promise} seatFetchPromise - The already-running promise fetching the seats
 */
async function loadSeats(showId, seatFetchPromise) {
    const gridContainer = document.getElementById('seat-grid');
    if (!gridContainer) return;

    try {
        const { data: seats, error } = await seatFetchPromise;

        if (error) {
            gridContainer.innerHTML = `
                <div class="alert alert-error">Failed to load seats. ${error.message}</div>
            `;
            return;
        }

        const screenId = getCurrentScreenId();
        seatStates = dedupeSeatStates(seats || [])
            .filter(seat => !screenId || !seat.screen_id || seat.screen_id === screenId)
            .map(seat => {
                if (seat.state === 'offline') {
                    return { ...seat, state: 'booked' };
                }
                return seat;
            });

        // Recover phantom locks from page reload into selectedBookings mapping
        let earliestLockTime = null;
        seatStates.forEach(s => {
            if (s.state === 'selected' && s.booking?.id) {
                selectedBookings[s.id] = s.booking.id;
                
                if (s.booking.locked_at) {
                    const lockTime = new Date(s.booking.locked_at).getTime();
                    if (!earliestLockTime || lockTime < earliestLockTime) {
                        earliestLockTime = lockTime;
                    }
                }
            }
        });

        if (Object.keys(selectedBookings).length > 0 && !lockTimerInterval && earliestLockTime) {
            lockStartTime = earliestLockTime;
            startLockTimer(true);
        }

        // Fetch screen layout for gaps/aisles.
        const embeddedLayout = currentShow?.screens?.seat_layout;

        if (embeddedLayout) {
            currentScreenLayout = normalizeScreenLayout(embeddedLayout);
            console.info('Seat layout loaded from show.screens.seat_layout', getLayoutDebugInfo(currentScreenLayout));
        } else if (screenId) {
            const { data: layout, error: layoutError, source } = await JayShow.fetchScreenLayout(screenId);
            currentScreenLayout = layoutError ? null : normalizeScreenLayout(layout);
            console.info('Seat layout loaded from', source || 'unknown', getLayoutDebugInfo(currentScreenLayout));
        } else {
            currentScreenLayout = null;
            console.warn('Seat layout unavailable: no screen id found');
        }

        renderSeatGrid();
    } catch (err) {
        console.error('Error loading seats:', err);
        gridContainer.innerHTML = `
            <div class="alert alert-error">Failed to load seats. ${err.message}</div>
        `;
    }
}


function showNoSeatsConfigured() {
    const gridContainer = document.getElementById('seat-grid');
    if (!gridContainer) return;

    const screenName = currentShow?.screens?.name || 'this screen';
    gridContainer.innerHTML = `
        <div class="alert alert-warning" style="width: 100%; text-align: center;">
            No seats are configured for ${localEscapeHtml(screenName)}.
            Please choose another screen or save a layout for this screen in the Seat Layout Editor.
        </div>
    `;
}

function getLayoutDebugInfo(layout) {
    if (!layout?.rows) return { rows: 0, positions: 0, seats: 0, gaps: 0 };

    return layout.rows.reduce((info, row) => {
        info.rows += 1;
        info.positions += row.seats.length;
        row.seats.forEach(seat => {
            if (seat) info.seats += 1;
            else info.gaps += 1;
        });
        return info;
    }, { rows: 0, positions: 0, seats: 0, gaps: 0 });
}

function getCurrentScreenId() {
    return currentShow?.screen_id || currentShow?.screens?.id || seatStates[0]?.screen_id || null;
}

function dedupeSeatStates(seats) {
    const uniqueSeats = new Map();

    seats.forEach(seat => {
        const col = parseInt(seat?.col, 10);
        const row = normalizeRowLabel(seat?.row);
        const key = row && !Number.isNaN(col)
            ? `position:${row}-${col}`
            : `seat:${seat?.id}`;

        if (!key) return;

        const existing = uniqueSeats.get(key);
        if (!existing || getSeatStatePriority(seat.state) > getSeatStatePriority(existing.state)) {
            uniqueSeats.set(key, seat);
        }
    });

    return Array.from(uniqueSeats.values());
}

function getSeatStatePriority(state) {
    if (state === 'selected') return 4;
    if (state === 'booked') return 3;
    if (state === 'offline') return 2;
    if (state === 'locked') return 1;
    return 0;
}

function normalizeScreenLayout(layout) {
    if (!layout || !Array.isArray(layout.rows)) return null;

    return {
        ...layout,
        rows: layout.rows.map((row, rowIndex) => ({
            label: String(row?.label || String.fromCharCode(65 + rowIndex)).toUpperCase(),
            seats: Array.isArray(row?.seats) ? row.seats : []
        }))
    };
}

/**
 * Renders the seat grid grouped by rows.
 */
function renderSeatGrid() {
    const gridContainer = document.getElementById('seat-grid');
    if (!gridContainer) return;

    if (seatStates.length === 0) {
        showNoSeatsConfigured();
        return;
    }

    // If we have a custom layout, use it to render with gaps
    if (currentScreenLayout && currentScreenLayout.rows) {
        const seatStateMap = buildSeatStateMap(seatStates);

        gridContainer.innerHTML = currentScreenLayout.rows.map(row => {
            return `
                <div class="seat-row">
                    <span class="row-label">${localEscapeHtml(row.label)}</span>
                    ${row.seats.map(layoutSeat => {
                if (!layoutSeat) return '<div class="seat-gap" aria-hidden="true"></div>';

                // Find seat state from database
                const seatState = seatStateMap.get(`${normalizeRowLabel(row.label)}-${parseInt(layoutSeat.id, 10)}`);

                return seatState ? createSeatElement(seatState) : '<div class="seat-gap" aria-hidden="true"></div>';
            }).join('')}
                    <span class="row-label">${localEscapeHtml(row.label)}</span>
                </div>
            `;
        }).join('');
    } else {
        // Group seats by row (legacy/fallback)
        const rows = {};
        seatStates.forEach(seat => {
            const rowLabel = seat.row || 'A';
            if (!rows[rowLabel]) {
                rows[rowLabel] = [];
            }
            rows[rowLabel].push(seat);
        });

        // Sort rows alphabetically
        const sortedRows = Object.keys(rows).sort();

        // Render grid
        gridContainer.innerHTML = sortedRows.map(rowLabel => {
            const rowSeats = rows[rowLabel].sort((a, b) => a.col - b.col);
            return `
                <div class="seat-row">
                    <span class="row-label">${rowLabel}</span>
                    ${rowSeats.map(seat => createSeatElement(seat)).join('')}
                    <span class="row-label">${rowLabel}</span>
                </div>
            `;
        }).join('');
    }

    // Click handlers are now attached ONCE via Event Delegation in initSeatsPage
}

/**
 * Creates HTML for a single seat.
 * 
 * @param {Object} seat - Seat object with state
 * @returns {string} HTML string for the seat
 */
function createSeatElement(seat) {
    const tier = seat.tier || 'regular';
    const state = seat.state || 'available';
    const isDisabled = state === 'booked' || state === 'locked' || state === 'offline';
    const seatLabel = `${seat.row}${seat.col}`;

    return `
        <div 
            class="seat ${tier} ${state}"
            data-seat-id="${seat.id}"
            data-tier="${tier}"
            data-price="${seat.price || currentShow?.price || 0}"
            ${isDisabled ? 'disabled' : ''}
            title="${seatLabel} - ${tier.charAt(0).toUpperCase() + tier.slice(1)} (${state})"
        >
            ${seat.col}
        </div>
    `;
}

/**
 * Handles seat click for selection/deselection.
 * 
 * @param {Event} e - Click event
 */
async function handleSeatClick(e) {
    const seatEl = e.target.closest('.seat');
    if (!seatEl || !seatEl.dataset.seatId || seatEl.classList.contains('booked') || seatEl.classList.contains('offline')) {
        return;
    }

    // Allow deselection of user's own locked seats (they have both 'locked' and 'selected' classes)
    const isSelected = seatEl.classList.contains('selected');
    const isLocked = seatEl.classList.contains('locked');

    // Block if seat is locked AND not selected (someone else's lock)
    if (isLocked && !isSelected) {
        return;
    }

    // Prevent double-clicks / rapid clicking
    if (isProcessingClick) {
        return;
    }

    const seatId = seatEl.dataset.seatId;

    if (seatEl.classList.contains('processing')) {
        console.log('Seat is already processing...');
        return;
    }

    if (seatEl.classList.contains('locked') || seatEl.classList.contains('booked')) {
        if (!seatEl.classList.contains('selected')) {
            showToast('This seat is already booked or locked', 'warning');
            return;
        }
    }

    // Per-seat processing lock
    seatEl.classList.add('processing');
    seatEl.style.pointerEvents = 'none';
    
    // OPTIMISTIC UI UPDATE: Give instant visual feedback
    const wasSelected = seatEl.classList.contains('selected');
    if (wasSelected) {
        seatEl.classList.remove('selected');
        seatEl.style.opacity = '0.5';
    } else {
        seatEl.classList.add('selected');
        seatEl.style.opacity = '0.8';
    }

    if (wasSelected) {
        // Seat is locked in DB (by user OR guest session) - unlock it
        try {
            const { error } = await JayShow.unlockBooking(selectedBookings[seatId]);
            if (!error) {
                delete selectedBookings[seatId];
                updateSummary();

                // Stop timer if no more selections
                if (Object.keys(selectedBookings).length === 0) {
                    stopLockTimer();
                }
            } else {
                // Revert optimistic UI on failure
                seatEl.classList.add('selected');
                console.error('Unlock error:', error);
                showToast('Failed to deselect seat: ' + error.message, 'error');
            }
        } catch (err) {
            // Revert optimistic UI on failure
            seatEl.classList.add('selected');
            console.error('Unlock error:', err);
            showToast('Failed to deselect seat', 'error');
        } finally {
            seatEl.classList.remove('processing');
            seatEl.style.pointerEvents = '';
            seatEl.style.opacity = '';
        }
    } else {
        // Selecting a seat
        try {
            const urlParams = new URLSearchParams(window.location.search);
            const showId = urlParams.get('show') || urlParams.get('event_show');

            const { data: booking, error } = window.isEventShow
                ? await JayShow.lockEventSeat(showId, seatId)
                : await JayShow.lockSeat(showId, seatId);

            if (error) {
                // Revert optimistic UI on failure
                seatEl.classList.remove('selected');
                
                if (error.message.includes('already locked') || error.message.includes('already locked or booked')) {
                    seatEl.classList.add('locked');
                    showToast('Seat was just taken by someone else', 'warning');
                } else if (error.message.includes('being processed')) {
                    showToast('Seat is being selected by another user, try again', 'warning');
                } else {
                    showToast(error.message, 'error');
                }
            } else {
                selectedBookings[seatId] = booking.id;
                updateSummary();

                // Start timer on first selection
                if (Object.keys(selectedBookings).length === 1) {
                    startLockTimer();
                }
            }
        } catch (err) {
            // Revert optimistic UI on failure
            seatEl.classList.remove('selected');
            console.error('Lock error:', err);
            showToast('An error occurred', 'error');
        } finally {
            seatEl.classList.remove('processing');
            seatEl.style.pointerEvents = '';
            seatEl.style.opacity = '';
        }
    }
}

function buildSeatStateMap(seats) {
    const seatStateMap = new Map();

    seats.forEach(seat => {
        const col = parseInt(seat?.col, 10);
        if (!seat?.row || Number.isNaN(col)) return;

        const key = `${normalizeRowLabel(seat.row)}-${col}`;
        const existing = seatStateMap.get(key);

        if (!existing || getSeatStatePriority(seat.state) > getSeatStatePriority(existing.state)) {
            seatStateMap.set(key, seat);
        }
    });

    return seatStateMap;
}

function normalizeRowLabel(label) {
    return String(label || '').trim().toUpperCase();
}


/**
 * Subscribes to real-time booking updates.
 * 
 * @param {string} showId - ID of the show
 */
function subscribeToSeatUpdates(showId) {
    console.log('🔔 Setting up realtime subscription for show:', showId);

    const subscribeFunc = window.isEventShow ? JayShow.subscribeEventBookings : JayShow.subscribeBookings;
    realtimeSubscription = subscribeFunc(showId, (payload) => {
        // Fast dynamic DOM updates instead of redrawing the whole grid
        const booking = payload.new || payload.old;
        if (!booking || !booking.seat_id) return;

        // If it's our own selection, ignore it to prevent flashing
        const isOurBooking = Object.values(selectedBookings).includes(booking.id);
        if (isOurBooking && payload.eventType !== 'DELETE') return;

        const seatEl = document.querySelector(`.seat[data-seat-id="${booking.seat_id}"]`);
        if (!seatEl) return;

        if (payload.eventType === 'INSERT' || payload.eventType === 'UPDATE') {
            if (booking.status === 'locked' || booking.status === 'booked') {
                seatEl.classList.remove('selected', 'locked', 'booked');
                seatEl.classList.add(booking.status);
            } else if (booking.status === 'available' || booking.status === 'expired') {
                seatEl.classList.remove('selected', 'locked', 'booked');
            }
        } else if (payload.eventType === 'DELETE') {
            seatEl.classList.remove('selected', 'locked', 'booked');
            
            // If it was our booking that got deleted (e.g. lock expired), remove it from local state
            if (isOurBooking) {
                const seatId = Object.keys(selectedBookings).find(key => selectedBookings[key] === booking.id);
                if (seatId) delete selectedBookings[seatId];
                updateSummary();
            }
        }
    });
}

/**
 * Updates the booking summary (selected seats, prices, totals).
 */
function updateSummary() {
    const selectedSeatsContainer = document.getElementById('selected-seats');
    const subtotalEl = document.getElementById('subtotal');
    const taxEl = document.getElementById('tax');
    const totalEl = document.getElementById('total');
    const payBtn = document.getElementById('pay-btn');

    // Get selected seat IDs from both selectedBookings (logged in users) AND visually selected seats (guests)
    const selectedSeatEls = document.querySelectorAll('.seat.selected');
    // Merge both sources - use Set to avoid duplicates
    const allSelectedIds = [...new Set([...Object.keys(selectedBookings), ...Array.from(selectedSeatEls).map(el => el.dataset.seatId)])];

    // Get selected seat details
    const selectedSeats = seatStates.filter(s => allSelectedIds.includes(s.id));

    // Render selected seat tags
    if (selectedSeatsContainer) {
        if (selectedSeats.length === 0) {
            selectedSeatsContainer.innerHTML = '<span style="color: var(--text-muted);">No seats selected</span>';
        } else {
            selectedSeatsContainer.innerHTML = selectedSeats.map(seat => `
                <span class="selected-seat-tag ${localEscapeHtml(seat.tier || 'regular')}">
                    ${localEscapeHtml(seat.row)}${localEscapeHtml(seat.col.toString())}
                </span>
            `).join('');
        }
    }

    // Calculate prices
    let subtotal = 0;
    selectedSeats.forEach(seat => {
        subtotal += (seat.price || currentShow?.price || 0) * 100; // Convert to paise
    });

    // Debug: log fee state
    console.log('💰 updateSummary:', {
        subtotal,
        seatCount: selectedSeats.length,
        platformConvenienceFee: window.platformConvenienceFee,
        paymentModule: typeof JayShowPayment
    });

    const { convenienceFee, tax, total } = JayShowPayment.calculateTotal(subtotal, selectedSeats.length);

    console.log('💰 calculateTotal result:', { convenienceFee, tax, total });

    // Update display
    if (subtotalEl) subtotalEl.textContent = JayShowPayment.formatAmount(subtotal);
    
    const feeRow = document.getElementById('convenience-fee-row');
    const feeEl = document.getElementById('convenience-fee');
    if (feeRow && feeEl) {
        if (convenienceFee > 0) {
            feeRow.style.display = 'flex';
            feeEl.textContent = JayShowPayment.formatAmount(convenienceFee);
            
            // Dynamically update label with breakdown details to show it's NOT hardcoded
            const feeLabel = feeRow.querySelector('span:first-child');
            if (feeLabel) {
                const feeSetting = window.platformConvenienceFee;
                if (feeSetting) {
                    if (feeSetting.type === 'fixed') {
                        feeLabel.innerHTML = `Convenience Fee <span style="font-size: 0.8rem; color: var(--text-secondary); font-weight: normal; margin-left: 4px;">(₹${feeSetting.amount} × ${selectedSeats.length})</span>`;
                    } else if (feeSetting.type === 'percentage') {
                        feeLabel.innerHTML = `Convenience Fee <span style="font-size: 0.8rem; color: var(--text-secondary); font-weight: normal; margin-left: 4px;">(${feeSetting.amount}%)</span>`;
                    }
                } else {
                    feeLabel.textContent = 'Convenience Fee';
                }
            }
        } else {
            feeRow.style.display = 'none';
        }
    }
    
    if (taxEl) taxEl.textContent = JayShowPayment.formatAmount(tax);
    if (totalEl) totalEl.textContent = JayShowPayment.formatAmount(total);

    // Enable/disable pay button
    if (payBtn) {
        payBtn.disabled = selectedSeats.length === 0;
    }

    // Store total for payment
    window.currentBookingTotal = total;

    // === Sync mobile sticky pay bar ===
    const mobileBar = document.getElementById('mobile-pay-bar');
    const mpbSeats = document.getElementById('mpb-seats');
    const mpbTotal = document.getElementById('mpb-total');
    const mpbPayBtn = document.getElementById('mpb-pay-btn');

    if (mobileBar) {
        if (selectedSeats.length > 0) {
            mobileBar.classList.add('visible');
            if (mpbSeats) {
                const labels = selectedSeats.map(s => `${s.row}${s.col}`).join(', ');
                mpbSeats.textContent = `${selectedSeats.length} seat${selectedSeats.length > 1 ? 's' : ''}: ${labels}`;
            }
            if (mpbTotal) mpbTotal.textContent = JayShowPayment.formatAmount(total);
            if (mpbPayBtn) mpbPayBtn.disabled = false;
        } else {
            mobileBar.classList.remove('visible');
            if (mpbSeats) mpbSeats.textContent = 'No seats selected';
            if (mpbTotal) mpbTotal.textContent = '₹0';
            if (mpbPayBtn) mpbPayBtn.disabled = true;
        }
    }
}

/**
 * Sets up the pay button click handler.
 */
function setupPayButton() {
    const payBtn = document.getElementById('pay-btn');
    if (payBtn) {
        payBtn.addEventListener('click', handlePayment);
    }

    // Mobile sticky pay bar button
    const mpbPayBtn = document.getElementById('mpb-pay-btn');
    if (mpbPayBtn) {
        mpbPayBtn.addEventListener('click', handlePayment);
    }
}

/**
 * Handles the payment flow.
 * Shows auth modal if user is not logged in.
 */
async function handlePayment() {
    const payBtn = document.getElementById('pay-btn');
    const selectedSeatEls = document.querySelectorAll('.seat.selected');

    if (selectedSeatEls.length === 0) {
        showToast('Please select at least one seat', 'warning');
        return;
    }

    // Get user details - show modal if not logged in
    const user = await JayShow.getUser();
    if (!user) {
        showGuestModal();
        return;
    }

    // Proceed with payment
    await processPayment({ email: user.email, name: user.user_metadata?.name || '' });
}

/**
 * Processes the actual payment after user details are collected.
 * @param {Object} buyer - Buyer object with name, email, phone
 */
async function processPayment(buyer) {
    const payBtn = document.getElementById('pay-btn');
    const bookingIds = Object.values(selectedBookings);

    if (bookingIds.length === 0) {
        showToast('Please select seats first', 'warning');
        return;
    }

    // Disable button and show loading
    payBtn.disabled = true;
    payBtn.innerHTML = '<div class="spinner" style="width: 20px; height: 20px;"></div> Processing...';

    try {
        // Generate receipt ID
        const receipt = JayShowPayment.generateReceiptId();
        const amount = window.currentBookingTotal || 0;

        if (amount <= 0) {
            throw new Error('Invalid amount');
        }

        // Create order via Edge Function
        const { order, error: orderError } = await JayShowPayment.createOrder(
            amount,
            receipt,
            bookingIds
        );

        if (orderError) {
            throw orderError;
        }

        const result = await JayShowPayment.startRazorpay(
            order,
            buyer,
            {
                description: `${(window.isEventShow ? currentShow?.events?.title : currentShow?.movies?.title) || 'Ticket'} - ${Object.keys(selectedBookings).length} seats`,
                bookingIds
            }
        );

        if (result.success) {
            // Payment successful - redirect to ticket page
            showToast('Payment successful!', 'success');

            // Store booking IDs for ticket display
            localStorage.setItem('lastBookingIds', JSON.stringify(bookingIds));

            setTimeout(() => {
                const tokens = result.tokens ? result.tokens.join(',') : '';
                window.location.href = `ticket.html?t=${tokens}`;
            }, 1000);
        }

    } catch (err) {
        console.error('Payment error:', err);

        // Distinguish verification-pending (money captured, verification failed)
        // from hard failures (user cancelled, network down, etc.).
        const isVerifyError = err && err.message && err.message.toLowerCase().includes('verification');
        if (isVerifyError) {
            showToast('Payment received but verification is pending. Your tickets will be confirmed shortly.', 'warning');
        } else {
            showToast(err.message || 'Payment failed. Please try again.', 'error');
        }

        // Re-enable button
        payBtn.disabled = false;
        payBtn.textContent = 'Pay Now';
    }
}

/**
 * Shows a toast notification.
 * 
 * @param {string} message - Message to display
 * @param {string} type - Type: success, error, warning
 */
function showToast(message, type = 'info') {
    // Remove existing toast
    const existingToast = document.querySelector('.toast');
    if (existingToast) existingToast.remove();

    const toast = document.createElement('div');
    toast.className = `toast alert alert-${type === 'info' ? 'warning' : type}`;
    toast.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        z-index: 9999;
        animation: fadeIn 0.3s ease;
    `;
    toast.textContent = message;

    document.body.appendChild(toast);

    setTimeout(() => {
        toast.style.animation = 'fadeOut 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

/**
 * Shows an error message on the page.
 * 
 * @param {string} message - Error message
 */
function showError(message) {
    const container = document.querySelector('.seats-container');
    if (container) {
        container.innerHTML = `
            <div class="alert alert-error">
                ${localEscapeHtml(message)}
                <br><br>
                <a href="index.html" class="btn btn-secondary">← Back to Movies</a>
            </div>
        `;
    }
}

/**
 * Cleanup function for page unload.
 * Stops all intervals and cleans up subscriptions.
 */
async function cleanup() {
    // Unsubscribe from realtime
    if (realtimeSubscription) {
        realtimeSubscription.unsubscribe();
    }

    // Stop all intervals
    stopLockTimer();
    stopHeartbeat();
    stopPolling();

    // Note: We intentionally DON'T unlock seats here
    // The server-side cleanup function will handle expired locks
    // This prevents losing selections due to accidental refreshes
}
// Add CSS animation for toasts
// Add CSS animation for toasts
(function() {
    const style = document.createElement('style');
    style.textContent = `
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeOut {
            from { opacity: 1; transform: translateY(0); }
            to { opacity: 0; transform: translateY(20px); }
        }
    `;
    document.head.appendChild(style);
})();

// ============================================
// Guest Modal Functions
// ============================================

/**
 * Shows the guest modal.
 */
function showGuestModal() {
    const modal = document.getElementById('guest-modal');
    if (modal) {
        modal.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
        // Focus first input
        setTimeout(() => {
            const firstInput = modal.querySelector('input');
            if (firstInput) firstInput.focus();
        }, 100);
    }
}

/**
 * Hides the guest modal.
 */
function hideGuestModal() {
    const modal = document.getElementById('guest-modal');
    if (modal) {
        modal.classList.add('hidden');
        document.body.style.overflow = '';
        // Clear any errors
        document.getElementById('guest-error')?.classList.add('hidden');
    }
}

/**
 * Sets up guest modal form handlers.
 */
function setupAuthModal() {
    // Close modal when clicking backdrop
    const backdrop = document.querySelector('.modal-backdrop');
    if (backdrop) {
        backdrop.addEventListener('click', hideGuestModal);
    }

    // Close modal on Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') hideGuestModal();
    });

    // Guest form handler
    const guestForm = document.getElementById('guest-form');
    if (guestForm) {
        guestForm.addEventListener('submit', handleGuestForm);
    }
}

/**
 * Handles guest form submission.
 */
async function handleGuestForm(e) {
    e.preventDefault();

    const name = document.getElementById('guest-name').value;
    const email = document.getElementById('guest-email').value;
    const phone = document.getElementById('guest-phone').value;
    const errorEl = document.getElementById('guest-error');
    const submitBtn = e.target.querySelector('button[type="submit"]');

    // Show loading
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<div class="spinner" style="width: 16px; height: 16px;"></div> Proceeding...';
    errorEl.classList.add('hidden');

    try {
        // Success - close modal
        hideGuestModal();
        showToast('Proceeding to payment...', 'info');

        // Proceed to payment
        await processPayment({ name, email, phone });

    } catch (err) {
        errorEl.textContent = err.message || 'An error occurred';
        errorEl.classList.remove('hidden');
    } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Proceed to Payment';
    }
}

// ============================================
// COUNTDOWN TIMER FUNCTIONS
// ============================================

/**
 * Starts the countdown timer when first seat is locked.
 * Shows remaining time to complete payment.
 */
function startLockTimer(isResume = false) {
    // Don't restart if already running
    if (lockTimerInterval) return;

    if (!isResume) {
        lockStartTime = Date.now();
    }
    JayShow.debugLog('⏱️ Lock timer started');

    // Show timer container
    const timerContainer = document.getElementById('lock-timer-container');
    const timerHint = document.getElementById('timer-hint');
    if (timerContainer) {
        timerContainer.classList.remove('hidden', 'warning', 'expired');
    }
    if (timerHint) {
        timerHint.style.display = 'none';
    }

    // Update timer every second
    updateTimerDisplay();
    lockTimerInterval = setInterval(updateTimerDisplay, 1000);
}

/**
 * Stops the countdown timer.
 */
function stopLockTimer() {
    if (lockTimerInterval) {
        clearInterval(lockTimerInterval);
        lockTimerInterval = null;
    }
    lockStartTime = null;

    // Hide timer container
    const timerContainer = document.getElementById('lock-timer-container');
    const timerHint = document.getElementById('timer-hint');
    if (timerContainer) {
        timerContainer.classList.add('hidden');
        timerContainer.classList.remove('warning', 'expired');
    }
    if (timerHint) {
        timerHint.style.display = '';
    }

    JayShow.debugLog('⏱️ Lock timer stopped');
}

/**
 * Updates the timer display with remaining time.
 */
function updateTimerDisplay() {
    if (!lockStartTime) return;

    const elapsed = Date.now() - lockStartTime;
    const remaining = Math.max(0, LOCK_DURATION_MS - elapsed);
    const minutes = Math.floor(remaining / 60000);
    const seconds = Math.floor((remaining % 60000) / 1000);

    const timerEl = document.getElementById('lock-timer');
    const timerContainer = document.getElementById('lock-timer-container');
    const progressBar = document.getElementById('lock-timer-progress');

    if (timerEl) {
        timerEl.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
    }

    if (progressBar) {
        const percentage = (remaining / LOCK_DURATION_MS) * 100;
        progressBar.style.width = `${percentage}%`;
    }

    // Warning state when less than 1 minute
    if (timerContainer) {
        if (remaining <= 60000 && remaining > 0) {
            timerContainer.classList.add('warning');
            timerContainer.classList.remove('expired');
        } else if (remaining <= 0) {
            timerContainer.classList.add('expired');
            timerContainer.classList.remove('warning');
        } else {
            timerContainer.classList.remove('warning', 'expired');
        }
    }

    // Timer expired - release seats
    if (remaining <= 0) {
        handleLockExpired();
    }
}

/**
 * Handles when the lock timer expires.
 * Releases all selected seats and notifies user.
 */
async function handleLockExpired() {
    stopLockTimer();
    // stopHeartbeat(); // Disabled: locks expire naturally after 5 mins

    showToast('⏰ Time expired! Your seat selection has been released.', 'error');

    // Clear all selections
    const selectedSeatEls = document.querySelectorAll('.seat.selected');
    selectedSeatEls.forEach(el => el.classList.remove('selected'));

    // Clear booking references
    selectedBookings = {};

    // Update summary
    updateSummary();

    // Refresh seats to show current state
    const urlParams = new URLSearchParams(window.location.search);
    const showId = urlParams.get('show') || urlParams.get('event_show');
    if (showId) {
        await loadSeats(showId);
    }
}

// ============================================
// HEARTBEAT FUNCTIONS (Keep Locks Alive)
// ============================================

/**
 * Starts the heartbeat that periodically extends locks.
 */
function startHeartbeat() {
    // Don't start if already running or no bookings
    if (heartbeatInterval) return;

    console.log('💓 Heartbeat started');

    heartbeatInterval = setInterval(async () => {
        const bookingIds = Object.values(selectedBookings);
        if (bookingIds.length === 0) {
            stopHeartbeat();
            return;
        }

        console.log('💓 Sending heartbeat for', bookingIds.length, 'booking(s)');
        const { data, error } = await JayShow.extendLocks(bookingIds);

        if (error) {
            console.warn('💔 Heartbeat failed:', error.message);
            // If heartbeat fails, the locks may have expired
            // The timer will handle the expiration
        } else if (data && data.extended_count > 0) {
            // Reset timer since locks were extended
            lockStartTime = Date.now();
            console.log('💓 Locks extended, timer reset');
        }
    }, HEARTBEAT_INTERVAL_MS);
}

/**
 * Stops the heartbeat.
 */
function stopHeartbeat() {
    if (heartbeatInterval) {
        clearInterval(heartbeatInterval);
        heartbeatInterval = null;
        console.log('💓 Heartbeat stopped');
    }
}

// ============================================
// POLLING FALLBACK FUNCTIONS
// ============================================

/**
 * Starts polling for seat updates as a fallback to realtime.
 * 
 * @param {string} showId - ID of the show
 */
function startPolling(showId) {
    if (pollingInterval) return;

    JayShow.debugLog('🔄 Polling started (every 10 seconds)');

    pollingInterval = setInterval(async () => {
        // Only poll if page is visible
        if (document.hidden) return;

        JayShow.debugLog('🔄 Polling for seat updates...');

        // Preserve current selections before refresh
        const currentSelections = new Set(Object.keys(selectedBookings));

        // Fetch fresh seat states
        const { data: seats, error } = window.isEventShow
            ? await JayShow.fetchEventSeatStates(showId)
            : await JayShow.fetchSeatStates(showId);
        if (error) {
            console.warn('🔄 Polling error:', error.message);
            return;
        }

        // Apply the same dedup + screen filter as loadSeats
        const screenId = getCurrentScreenId();
        seatStates = dedupeSeatStates(seats || [])
            .filter(seat => !screenId || !seat.screen_id || seat.screen_id === screenId);
        renderSeatGrid();

        // Restore user's selections
        restoreSelections(currentSelections);
    }, POLLING_INTERVAL_MS);
}

/**
 * Stops polling.
 */
function stopPolling() {
    if (pollingInterval) {
        clearInterval(pollingInterval);
        pollingInterval = null;
        JayShow.debugLog('🔄 Polling stopped');
    }
}

// ============================================
// VISIBILITY CHANGE HANDLER
// ============================================

/**
 * Handles tab visibility changes.
 * Pauses heartbeat when tab is hidden, resumes when visible.
 */
async function handleVisibilityChange() {
    if (document.hidden) {
        JayShow.debugLog('👁️ Tab hidden - pausing heartbeat');
    } else {
        JayShow.debugLog('👁️ Tab visible - resuming');
        
        // Refresh seats when tab becomes visible and restore selections
        const currentSelections = new Set(Object.keys(selectedBookings));
        const urlParams = new URLSearchParams(window.location.search);
        const showId = urlParams.get('show') || urlParams.get('event_show');
        if (showId) {
            await loadSeats(showId);
            restoreSelections(currentSelections);
        }
    }
}
