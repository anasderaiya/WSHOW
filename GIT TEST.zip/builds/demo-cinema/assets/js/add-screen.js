/**
 * JayShow - Add Screen Page logic
 */

let currentUser = null;
let ownedTheatres = [];

document.addEventListener('DOMContentLoaded', async () => {
    await initAddScreenPage();
});

async function initAddScreenPage() {
    const loadingEl = document.getElementById('loading-state');
    const accessDenied = document.getElementById('access-denied');
    const mainContent = document.getElementById('add-screen-content');

    try {
        currentUser = await JayShow.getUser();

        // Check if user is logged in
        if (!currentUser) {
            // Check for demo mode in app.js or fallback
            // For now redirect or show access denied
            // If we are in demo mode (implicit), we might continue, but let's stick to auth pattern
        }

        const isOwner = await JayShow.isTheaterOwner();
        if (!isOwner) {
            loadingEl.classList.add('hidden');
            accessDenied.classList.remove('hidden');
            return;
        }

        // Access Granted
        loadingEl.classList.add('hidden');
        mainContent.classList.remove('hidden');

        await loadOwnedTheatres();
        await loadOwnerScreens();

        // Event Listeners
        document.getElementById('add-screen-form').addEventListener('submit', handleCreateScreen);

        // Logout
        document.getElementById('logout-btn').addEventListener('click', async () => {
            await JayShow.signOut();
            window.location.href = 'index.html';
        });

        updateNavbar();

    } catch (error) {
        console.error('Init error:', error);
        loadingEl.innerHTML = '<p class="error">Failed to initialize page.</p>';
    }
}

async function loadOwnedTheatres() {
    const client = JayShow.getSupabaseClient();
    const theatreSelect = document.getElementById('theatre-select');

    try {
        const { data: theatres } = await client.rpc('get_owned_theatres', {
            p_user_id: currentUser.id
        });

        if (!theatres) {
            theatreSelect.innerHTML = '<option value="">No theatres found</option>';
            return;
        }

        ownedTheatres = theatres; // These are summaries (id, name, location)

        theatreSelect.innerHTML = '<option value="">Select Theatre</option>' +
            theatres.map(t => `<option value="${t.theatre_id}">${escapeHtml(t.theatre_name)}</option>`).join('');

    } catch (error) {
        console.error('Error loading theatres:', error);
    }
}

async function loadOwnerScreens() {
    const client = JayShow.getSupabaseClient();
    const listContainer = document.getElementById('screens-list');

    try {
        if (!ownedTheatres.length) {
            listContainer.innerHTML = '<p class="text-muted">No theatres found</p>';
            return;
        }

        const theatreIds = ownedTheatres.map(t => t.theatre_id);
        const theatreMap = {};
        ownedTheatres.forEach(t => theatreMap[t.theatre_id] = t.theatre_name);

        const { data: screens, error } = await client
            .from('screens')
            .select('*')
            .in('theatre_id', theatreIds)
            .order('name');

        if (error) throw error;

        if (!screens || screens.length === 0) {
            listContainer.innerHTML = '<p class="text-muted">No screens found. Create one!</p>';
            return;
        }

        listContainer.innerHTML = screens.map(s => {
            // Get seat info from layout metadata if available
            const layout = s.seat_layout;
            const rowCount = layout?.metadata?.rowCount || '?';
            const seatsPerRow = layout?.metadata?.maxSeatsPerRow || '?';
            return `
            <div class="show-card">
                <div class="show-info">
                    <div class="show-title">${escapeHtml(s.name)}</div>
                    <div class="show-meta">
                        <span>${JayShow.icon('building-2', 'inline-icon')} ${escapeHtml(theatreMap[s.theatre_id] || 'Unknown')}</span>
                        <span>${JayShow.icon('armchair', 'inline-icon')} ${rowCount} rows × ${seatsPerRow} seats</span>
                    </div>
                </div>
                 <div class="show-badges">
                    <a href="seat-editor.html?screen=${s.id}" class="btn btn-sm btn-outline">Edit Layout</a>
                </div>
            </div>
        `}).join('');

    } catch (error) {
        console.error('Error loading screens:', error);
        listContainer.innerHTML = '<p class="text-muted">Failed to load screens</p>';
    }
}

async function handleCreateScreen(e) {
    e.preventDefault();

    const theatreId = document.getElementById('theatre-select').value;
    const screenName = document.getElementById('screen-name').value;
    const rows = parseInt(document.getElementById('screen-rows').value);
    const cols = parseInt(document.getElementById('screen-cols').value);
    const regularPrice = parseInt(document.getElementById('regular-price')?.value || 150);
    const premiumPrice = parseInt(document.getElementById('premium-price')?.value || 250);
    const vipPrice = parseInt(document.getElementById('vip-price')?.value || 400);
    const feedback = document.getElementById('form-feedback');

    if (!theatreId || !screenName) {
        showFeedback(feedback, 'Please fill all required fields.', 'error');
        return;
    }

    const submitBtn = e.target.querySelector('button[type="submit"]');
    submitBtn.disabled = true;
    submitBtn.textContent = 'Creating...';

    try {
        const client = JayShow.getSupabaseClient();

        // Generate default seat layout
        const layout = { rows: [], metadata: { rowCount: rows, maxSeatsPerRow: cols } };
        for (let r = 0; r < rows; r++) {
            const row = {
                label: String.fromCharCode(65 + r),
                seats: []
            };

            // Simple tier logic: Front 2 rows Regular, rest Premium, Back 2 VIP
            let type = 'premium';
            let price = premiumPrice;

            if (r < 2) {
                type = 'regular';
                price = regularPrice;
            } else if (r >= rows - 2 && rows > 4) {
                type = 'vip';
                price = vipPrice;
            }

            for (let c = 1; c <= cols; c++) {
                // Create an aisle in the middle if more than 10 columns
                if (cols > 10 && (c === Math.floor(cols / 2) || c === Math.floor(cols / 2) + 1)) {
                    continue;
                }

                row.seats.push({
                    id: c,
                    type: type,
                    price: price
                });
            }
            layout.rows.push(row);
        }

        // 1. Create Screen Entry
        const { data: newScreen, error } = await client
            .from('screens')
            .insert({
                theatre_id: theatreId,
                name: screenName
            })
            .select()
            .single();

        if (error) throw error;

        showFeedback(feedback, 'Screen created! Initializing seats...', 'success');

        // 2. Try to initialize seats
        try {
            const { data: layoutResult, error: layoutError } = await client.rpc('update_screen_layout', {
                p_screen_id: newScreen.id,
                p_seat_layout: layout
            });

            if (layoutError) {
                console.warn('Layout RPC not available or failed:', layoutError);
                showFeedback(feedback, 'Screen created! Configure seats in Seat Editor.', 'success');
            } else {
                showFeedback(feedback, 'Screen and seats created successfully!', 'success');
            }
        } catch (rpcError) {
            console.warn('Layout RPC not available:', rpcError);
            showFeedback(feedback, 'Screen created! Configure seats in Seat Editor.', 'success');
        }

        // Reset form and reload list
        e.target.reset();
        await loadOwnerScreens();

    } catch (error) {
        console.error('Create error:', error);
        showFeedback(feedback, error.message || 'Failed to create screen', 'error');
    } finally {
        btn.disabled = false;
        btn.textContent = 'Create Screen';
    }
}

function generateDefaultLayout(rows, cols) {
    const layout = {
        rows: [],
        metadata: {
            totalSeats: rows * cols,
            rowCount: rows,
            maxSeatsPerRow: cols
        }
    };

    for (let r = 0; r < rows; r++) {
        const rowLabel = String.fromCharCode(65 + r); // A, B, C...

        // Simple tier logic: Front 2 rows Regular, rest Premium, Back 2 VIP
        let type = 'premium';
        let price = 300;

        if (r < 2) {
            type = 'regular';
            price = 200;
        } else if (r >= rows - 2 && rows > 4) {
            type = 'vip';
            price = 500;
        }

        const row = {
            label: rowLabel,
            seats: []
        };

        for (let c = 1; c <= cols; c++) {
            row.seats.push({
                id: c,
                type: type,
                price: price
            });
        }
        layout.rows.push(row);
    }
    return layout;
}

function showFeedback(el, msg, type) {
    el.textContent = msg;
    el.className = `form-feedback ${type}`;
    el.classList.remove('hidden');
    if (type === 'success') setTimeout(() => el.classList.add('hidden'), 3000);
}

function updateNavbar() {
    const emailSpan = document.querySelector('.user-email');
    if (emailSpan && currentUser) {
        emailSpan.textContent = currentUser.email;
        emailSpan.classList.remove('hidden');
    }
}