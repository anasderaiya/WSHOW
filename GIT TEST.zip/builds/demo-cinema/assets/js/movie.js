/**
 * JayShow - Movie Details Page Logic
 * ===================================
 * 
 * Handles the movie detail page:
 * - Reads movie ID from URL
 * - Fetches movie details and show times
 * - Renders show cards with book button
 * - Date filtering for shows
 */

let currentMovie = null;
let allShows = [];

document.addEventListener('DOMContentLoaded', async () => {
    await initMoviePage();
    await JayShow.updateNavbar();
});


/**
 * Initializes the movie detail page.
 */
async function initMoviePage() {
    const urlParams = new URLSearchParams(window.location.search);
    const movieId = urlParams.get('id');

    if (!movieId) {
        showError('Movie ID not provided');
        return;
    }

    // Generate date selector
    generateDateSelector();

    // Load movie details and shows in parallel
    await Promise.all([
        loadMovieDetails(movieId),
        loadShows(movieId)
    ]);
}

/**
 * Generates the date selector for the next 7 days
 */
function generateDateSelector() {
    const container = document.getElementById('date-selector');
    if (!container) return;

    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

    container.innerHTML = '';

    for (let i = 0; i < 7; i++) {
        const date = new Date();
        date.setDate(date.getDate() + i);

        const dayName = i === 0 ? 'Today' : i === 1 ? 'Tomorrow' : days[date.getDay()];
        const localDateStr = getLocalISODate(date);

        const btn = document.createElement('button');
        btn.className = `date-btn ${i === 0 ? 'active' : ''}`;
        btn.dataset.date = localDateStr;
        btn.innerHTML = `
            <span class="day">${dayName}</span>
            <span class="date">${date.getDate()}</span>
            <span class="month">${months[date.getMonth()]}</span>
        `;

        btn.addEventListener('click', () => {
            // Update active state
            container.querySelectorAll('.date-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            // Filter shows
            filterShowsByDate(btn.dataset.date);
        });

        container.appendChild(btn);
    }
}

/**
 * Loads and displays movie details.
 * 
 * @param {string} movieId - ID of the movie
 */
async function loadMovieDetails(movieId) {
    const heroContent = document.querySelector('.movie-hero-content');
    const heroBg = document.getElementById('hero-bg');

    const { data: movie, error } = await JayShow.fetchMovie(movieId);

    if (error || !movie) {
        showError('Failed to load movie details');
        return;
    }

    currentMovie = movie;

    // Update page title
    document.title = `${movie.title} - JayShow`;

    // Update hero background
    if (heroBg && movie.poster_url) {
        heroBg.style.backgroundImage = `url(${movie.poster_url})`;
    }

    // Render movie details
    const posterUrl = movie.poster_url || 'assets/images/placeholder-poster.svg';
    const duration = movie.duration_minutes ? `${movie.duration_minutes} min` : '';
    const rating = movie.rating ? parseFloat(movie.rating).toFixed(1) : '';

    heroContent.innerHTML = `
        <img 
            src="${JayShow.escapeHtml(posterUrl)}" 
            alt="${JayShow.escapeHtml(movie.title)}"
            class="movie-hero-poster"
            onerror="this.src='assets/images/placeholder-poster.svg'"
        >
        <div class="movie-hero-info">
            <h1>${JayShow.escapeHtml(movie.title)}</h1>
            <div class="movie-badges">
                ${rating ? `<span class="movie-badge rating">★ ${rating}</span>` : ''}
                ${movie.genre ? `<span class="movie-badge">${JayShow.icon('drama', 'inline-icon')} ${JayShow.escapeHtml(movie.genre)}</span>` : ''}
                ${duration ? `<span class="movie-badge">${JayShow.icon('clock', 'inline-icon')} ${duration}</span>` : ''}
                ${movie.release_date ? `<span class="movie-badge">${JayShow.icon('calendar', 'inline-icon')} ${formatDate(movie.release_date)}</span>` : ''}
            </div>
            <p class="movie-description">
                ${JayShow.escapeHtml(movie.description || 'No description available.')}
            </p>
        </div>
    `;
}

/**
 * Helper to get YYYY-MM-DD in local time
 */
function getLocalISODate(date) {
    const offset = date.getTimezoneOffset() * 60000;
    const local = new Date(date.getTime() - offset);
    return local.toISOString().split('T')[0];
}

/**
 * Loads shows for the movie.
 * 
 * @param {string} movieId - ID of the movie
 */
async function loadShows(movieId) {
    const loadContainer = document.getElementById('shows-container');
    if (loadContainer && !loadContainer.querySelector('.spinner, .skeleton')) {
        loadContainer.innerHTML = `
            <div class="loading" style="padding: 3rem; 
                 grid-column: 1/-1; text-align: center;">
                <div class="spinner"></div>
            </div>`;
    }

    const container = document.getElementById('show-list');
    if (!container) return;

    const { data: shows, error } = await JayShow.fetchShowsForMovie(movieId);

    if (error) {
        container.innerHTML = `
            <div class="alert alert-error">
                Failed to load show times. ${error.message}
            </div>
        `;
        return;
    }

    allShows = shows || [];

    // Find the first date that has shows, starting from today
    const today = getLocalISODate(new Date());
    let bestDate = today;
    let foundUpcoming = false;

    if (allShows.length > 0) {
        // Group shows by date to check availability
        const showDates = new Set();
        const sortedUniqueDates = [];

        allShows.forEach(show => {
            const dateStr = getLocalISODate(new Date(show.start_time));
            if (!showDates.has(dateStr)) {
                showDates.add(dateStr);
                sortedUniqueDates.push(dateStr);
            }
        });

        // Sort dates (string comparison works for ISO format)
        sortedUniqueDates.sort();

        // 1. Try to find a date in the next 7 days
        for (let i = 0; i < 7; i++) {
            const d = new Date();
            d.setDate(d.getDate() + i);
            const dateStr = getLocalISODate(d);

            if (showDates.has(dateStr)) {
                bestDate = dateStr;
                foundUpcoming = true;
                break;
            }
        }

        // 2. If no shows in next 7 days, but we have shows, pick the first available one relative to today
        if (!foundUpcoming && sortedUniqueDates.length > 0) {
            // Try to find first future date
            const firstFuture = sortedUniqueDates.find(d => d >= today);
            if (firstFuture) {
                bestDate = firstFuture;
            } else {
                // All shows are in the past, pick the last one (most recent past)
                bestDate = sortedUniqueDates[sortedUniqueDates.length - 1];
            }
        }

        ensureDateVisibleInSelector(bestDate);
    }

    // Update the tabs to reflect the selected date
    const dateButtons = document.querySelectorAll('.date-btn');
    dateButtons.forEach(btn => {
        if (btn.dataset.date === bestDate) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });

    filterShowsByDate(bestDate);
}

/**
 * Ensures the selected date is visible in the date selector.
 */
function ensureDateVisibleInSelector(targetDateStr) {
    const selector = document.getElementById('date-selector');
    if (!selector) return;

    const existingBtn = selector.querySelector(`button[data-date="${targetDateStr}"]`);

    // If button exists just return, standard logic handles activation
    if (existingBtn) {
        return;
    }

    // If not found, implies it's outside the standard 7-day range.
    // We add a special button for it.
    const dateBtn = createDateButton(targetDateStr);

    // Determine where to put it
    const today = getLocalISODate(new Date());
    if (targetDateStr < today) {
        // Past date: prepend
        selector.insertBefore(dateBtn, selector.firstChild);
    } else {
        // Future date (beyond 7 days): append
        selector.appendChild(dateBtn);
    }
}

/**
 * Helper to create a date button
 */
function createDateButton(dateStr) {
    const date = new Date(dateStr);
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    const btn = document.createElement('button');
    btn.className = 'date-btn'; // Activation handled by caller
    btn.dataset.date = dateStr;

    const dayName = days[date.getDay()];

    btn.innerHTML = `
        <span class="day">${dayName}</span>
        <span class="date">${date.getDate()}</span>
        <span class="month">${months[date.getMonth()]}</span>
    `;

    btn.addEventListener('click', () => {
        const container = document.getElementById('date-selector');
        container.querySelectorAll('.date-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        filterShowsByDate(dateStr);
    });

    return btn;
}

/**
 * Filters and displays shows for a specific date.
 * 
 * @param {string} dateStr - Date string (YYYY-MM-DD)
 */
function filterShowsByDate(dateStr) {
    const container = document.getElementById('show-list');
    if (!container) return;

    let filteredShows = allShows.filter(show => {
        // Parse show start time (UTC ISO string) to Date object
        const showDateObj = new Date(show.start_time);
        // Get local YYYY-MM-DD
        const showLocalStr = getLocalISODate(showDateObj);
        return showLocalStr === dateStr;
    });

    if (filteredShows.length === 0) {
        if (allShows.length > 0) {
            container.innerHTML = `
                <div class="no-shows">
                    <div class="emoji">${JayShow.icon('calendar', 'lucide lucide-lg')}</div>
                    <h3>No shows on ${formatDate(dateStr)}</h3>
                    <p>Please check other dates.</p>
                </div>
            `;
            return;
        } else {
            container.innerHTML = `
                <div class="no-shows">
                    <div class="emoji">${JayShow.icon('clapperboard', 'lucide lucide-lg')}</div>
                    <h3>No shows available</h3>
                    <p>No shows scheduled for this movie yet.</p>
                </div>
            `;
            return;
        }
    }

    // Sort by time
    filteredShows.sort((a, b) => new Date(a.start_time) - new Date(b.start_time));

    container.innerHTML = filteredShows.map(show => createShowCard(show)).join('');
}

/**
 * Creates HTML for a show card.
 * 
 * @param {Object} show - Show object with nested screen and theatre data
 * @returns {string} HTML string for the show card
 */
function createShowCard(show) {
    const startTime = new Date(show.start_time);

    const hours = startTime.getHours();
    const minutes = startTime.getMinutes().toString().padStart(2, '0');
    const period = hours >= 12 ? 'PM' : 'AM';
    const displayHour = hours % 12 || 12;

    const screenName = show.screens?.name || 'Screen';
    const theatreName = show.screens?.theatres?.name || 'Theatre';
    const location = show.screens?.theatres?.location || '';

    const price = show.price ? `₹${show.price.toFixed(0)}` : 'TBD';

    return `
        <div class="show-card">
            <div class="show-time-badge">
                <span class="time">${displayHour}:${minutes}</span>
                <span class="period">${period}</span>
            </div>
            <div class="show-info">
                <div class="show-venue">${JayShow.escapeHtml(theatreName)} • ${JayShow.escapeHtml(screenName)}</div>
                ${location ? `<div class="show-location">${JayShow.icon('map-pin', 'inline-icon')} ${JayShow.escapeHtml(location)}</div>` : ''}
            </div>
            <div class="show-price">${price}</div>
            <a href="seats.html?show=${show.id}" class="btn btn-primary">
                Select Seats →
            </a>
        </div>
    `;
}

/**
 * Shows an error message on the page.
 * 
 * @param {string} message - Error message to display
 */
function showError(message) {
    const container = document.querySelector('.shows-section');
    if (container) {
        container.innerHTML = `
            <div class="alert alert-error" style="margin: 2rem;">
                ${JayShow.escapeHtml(message)}
                <br><br>
                <a href="index.html" class="btn btn-secondary">← Back to Movies</a>
            </div>
        `;
    }
}

/**
 * Formats a date for display.
 * 
 * @param {string} dateStr - Date string
 * @returns {string} Formatted date
 */
function formatDate(dateStr) {
    return new Date(dateStr).toLocaleDateString('en-IN', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}