/**
 * Quick my Ticket - Add Theatre Page logic
 * Allows existing theater owners to add additional theatres
 */

let currentUser = null;

document.addEventListener('DOMContentLoaded', async () => {
    await initAddTheatrePage();
});

async function initAddTheatrePage() {
    const loadingEl = document.getElementById('loading-state');
    const accessDenied = document.getElementById('access-denied');
    const mainContent = document.getElementById('add-theatre-content');

    try {
        currentUser = await JayShow.getUser();

        if (!currentUser) {
            window.location.href = 'owner-login.html';
            return;
        }

        const isOwner = await JayShow.isTheaterOwner();
        if (!isOwner) {
            loadingEl.classList.add('hidden');
            accessDenied.classList.remove('hidden');
            return;
        }

        // Access Granted
        loadingEl.classList.add('hidden');
        mainContent.classList.remove('hidden');

        await loadMyTheatres();

        // Event Listeners
        document.getElementById('add-theatre-form').addEventListener('submit', handleAddTheatre);

        document.getElementById('logout-btn').addEventListener('click', async () => {
            await JayShow.signOut();
            window.location.href = 'index.html';
        });

        updateNavbar();

    } catch (error) {
        console.error('Init error:', error);
        loadingEl.innerHTML = '<p class="error">Failed to initialize page.</p>';
    }
}

async function loadMyTheatres() {
    const client = JayShow.getSupabaseClient();
    const listContainer = document.getElementById('theatres-list');

    try {
        const { data: theatres, error } = await client.rpc('get_owned_theatres', {
            p_user_id: currentUser.id
        });

        if (error) throw error;

        if (!theatres || theatres.length === 0) {
            listContainer.innerHTML = '<p class="text-muted">No theatres yet. Add your first one!</p>';
            return;
        }

        listContainer.innerHTML = theatres.map(t => `
            <div class="show-card">
                <div class="show-info">
                    <div class="show-title">${escapeHtml(t.theatre_name)}</div>
                    <div class="show-meta">
                        <span>${JayShow.icon('map-pin', 'inline-icon')} ${escapeHtml(t.location || 'No location')}</span>
                        <span>${JayShow.icon('monitor', 'inline-icon')} ${t.screen_count || 0} screens</span>
                        <span>${JayShow.icon('armchair', 'inline-icon')} ${t.total_seats || 0} seats</span>
                    </div>
                </div>
                <div class="show-badges">
                    <span class="show-stat-badge">${escapeHtml(t.role || 'owner')}</span>
                </div>
            </div>
        `).join('');

    } catch (error) {
        console.error('Error loading theatres:', error);
        listContainer.innerHTML = '<p class="text-muted">Failed to load theatres</p>';
    }
}

async function handleAddTheatre(e) {
    e.preventDefault();
    const btn = e.target.querySelector('button[type="submit"]');
    const feedback = document.getElementById('form-feedback');

    const name = document.getElementById('theatre-name').value.trim();
    const location = document.getElementById('theatre-location').value.trim();
    const address = document.getElementById('theatre-address').value.trim();
    const phone = document.getElementById('theatre-phone').value.trim();
    const email = document.getElementById('theatre-email').value.trim();

    if (!name || !location) {
        showFeedback(feedback, 'Please fill in required fields', 'error');
        return;
    }

    btn.disabled = true;
    btn.textContent = 'Adding...';

    try {
        const client = JayShow.getSupabaseClient();

        // Use RPC function to add theatre (handles permissions properly)
        const { data: result, error } = await client.rpc('add_theatre_for_owner', {
            p_name: name,
            p_location: location,
            p_address: address || null,
            p_phone: phone || null,
            p_email: email || null
        });

        if (error) {
            // Check if RPC doesn't exist yet
            if (error.message.includes('function') && error.message.includes('does not exist')) {
                throw new Error('Feature not enabled. Ask admin to run migration 008.');
            }
            throw error;
        }

        if (result && !result.success) {
            throw new Error(result.error || 'Failed to add theatre');
        }

        showFeedback(feedback, 'Theatre added successfully!', 'success');
        e.target.reset();
        await loadMyTheatres();
        showToast('Theatre added successfully!');

    } catch (error) {
        console.error('Add theatre error:', error);
        showFeedback(feedback, error.message || 'Failed to add theatre', 'error');
    } finally {
        btn.disabled = false;
        btn.textContent = 'Add Theatre';
    }
}

function showFeedback(el, msg, type) {
    el.textContent = msg;
    el.className = `form-feedback ${type}`;
    el.classList.remove('hidden');
    if (type === 'success') setTimeout(() => el.classList.add('hidden'), 3000);
}

function showToast(message) {
    const toast = document.getElementById('toast');
    const messageEl = document.getElementById('toast-message');
    messageEl.textContent = message;
    toast.classList.remove('hidden');
    toast.classList.add('show');
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.classList.add('hidden'), 300);
    }, 3000);
}

function updateNavbar() {
    const emailSpan = document.querySelector('.user-email');
    if (emailSpan && currentUser) {
        emailSpan.textContent = currentUser.email;
        emailSpan.classList.remove('hidden');
    }
}