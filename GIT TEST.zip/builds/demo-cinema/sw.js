/**
 * Quick my Ticket - Service Worker
 * =================================
 * 
 * Cache-first strategy for static assets (CSS, JS, fonts, images)
 * Network-first strategy for API calls (Supabase)
 * 
 * This provides:
 * - Offline app shell (pages load without internet)
 * - Faster repeat loads from cache
 * - API calls always try network first
 */

// Bump this version string on every deployment
// to force cache refresh for all users: v1, v2, v3...
const CACHE_NAME = 'qmyticket-v3';

// Static assets to pre-cache on install
const PRECACHE_ASSETS = [
    '/',
    '/index.html',
    '/login.html',
    '/seats.html',
    '/movie.html',
    '/events.html',
    '/event.html',
    '/ticket.html',
    '/profile.html',
    '/assets/css/styles.css',
    '/assets/css/owner-dashboard.css',
    '/assets/js/app.js',
    '/assets/js/index.js',
    '/assets/js/seats.js',
    '/assets/js/payment.js',
    '/assets/js/movie.js',
    '/assets/js/events.js',
    '/assets/js/event.js',
    '/assets/js/profile.js',
    '/assets/js/tmdb.js',
    '/assets/images/logo.png',
    '/assets/images/icon-192.png',
    '/assets/images/icon-512.png',
    '/assets/images/placeholder-poster.svg'
];

// Domains that should always use network-first (API calls)
const NETWORK_FIRST_DOMAINS = [
    'supabase.co',
    'supabase.in',
    'razorpay.com',
    'googleapis.com',
    'gstatic.com',
    'cdn.jsdelivr.net'
];

// ============================================
// Install Event - Pre-cache static assets
// ============================================
self.addEventListener('install', (event) => {
    console.log('[SW] Installing service worker...');
    
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then((cache) => {
                console.log('[SW] Pre-caching static assets');
                // Use addAll with catch to handle missing files gracefully
                return cache.addAll(PRECACHE_ASSETS).catch((err) => {
                    console.warn('[SW] Some assets failed to pre-cache:', err);
                    // Pre-cache what we can, one by one
                    return Promise.allSettled(
                        PRECACHE_ASSETS.map(url => 
                            cache.add(url).catch(() => 
                                console.warn('[SW] Failed to cache:', url)
                            )
                        )
                    );
                });
            })
            .then(() => self.skipWaiting()) // Activate immediately
    );
});

// ============================================
// Activate Event - Clean up old caches
// ============================================
self.addEventListener('activate', (event) => {
    console.log('[SW] Activating service worker...');
    
    event.waitUntil(
        caches.keys()
            .then((cacheNames) => {
                return Promise.all(
                    cacheNames
                        .filter((name) => name !== CACHE_NAME)
                        .map((name) => {
                            console.log('[SW] Deleting old cache:', name);
                            return caches.delete(name);
                        })
                );
            })
            .then(() => self.clients.claim()) // Take control of all pages
    );
});

// ============================================
// Fetch Event - Serve from cache or network
// ============================================
self.addEventListener('fetch', (event) => {
    const { request } = event;
    const url = new URL(request.url);

    // Skip non-GET requests
    if (request.method !== 'GET') return;

    // Skip chrome-extension and other non-http(s) requests
    if (!url.protocol.startsWith('http')) return;

    // Network-first for API calls and external resources
    if (NETWORK_FIRST_DOMAINS.some(domain => url.hostname.includes(domain))) {
        event.respondWith(networkFirst(request));
        return;
    }

    // Cache-first for local static assets
    event.respondWith(cacheFirst(request));
});

// ============================================
// Caching Strategies
// ============================================

/**
 * Cache-first strategy: Try cache, fall back to network.
 * Best for static assets that don't change often.
 */
async function cacheFirst(request) {
    const cached = await caches.match(request);
    if (cached) {
        return cached;
    }

    try {
        const response = await fetch(request);
        // Cache successful responses
        if (response.ok) {
            const cache = await caches.open(CACHE_NAME);
            cache.put(request, response.clone());
        }
        return response;
    } catch (err) {
        // If offline and not in cache, return a fallback
        console.warn('[SW] Fetch failed, no cache available:', request.url);
        
        // For navigation requests, try to serve index.html
        if (request.mode === 'navigate') {
            const cachedIndex = await caches.match('/index.html');
            if (cachedIndex) return cachedIndex;
        }
        
        return new Response('Offline', { status: 503, statusText: 'Service Unavailable' });
    }
}

/**
 * Network-first strategy: Try network, fall back to cache.
 * Best for API calls and dynamic content.
 */
async function networkFirst(request) {
    try {
        const response = await fetch(request);
        // Cache successful responses for offline fallback
        if (response.ok) {
            const cache = await caches.open(CACHE_NAME);
            cache.put(request, response.clone());
        }
        return response;
    } catch (err) {
        // Network failed - try cache
        const cached = await caches.match(request);
        if (cached) {
            console.log('[SW] Serving from cache (offline):', request.url);
            return cached;
        }
        return new Response(JSON.stringify({ error: 'Offline' }), {
            status: 503,
            headers: { 'Content-Type': 'application/json' }
        });
    }
}
