const fs = require('fs');
const path = require('path');

const content = fs.readFileSync(path.join(__dirname, 'public', 'assets', 'js', 'app.js'), 'utf8');
const lines = content.split('\n');

lines.forEach((line, idx) => {
    if (line.includes('fetchMovie') || line.includes('searchMovie')) {
        console.log(`Line ${idx + 1}: ${line.trim()}`);
    }
});
