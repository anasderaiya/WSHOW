const fs = require('fs');

// Append to owner-dashboard.js
const jsContent = `
/* ============================================
   White-Label Branding Settings Logic
   ============================================ */
document.addEventListener('DOMContentLoaded', () => {
    const tabDashboardBtn = document.getElementById('tab-dashboard-btn');
    const tabBrandingBtn = document.getElementById('tab-branding-btn');
    const dashboardView = document.getElementById('dashboard-view');
    const brandingView = document.getElementById('branding-view');
    const theatreSelect = document.getElementById('branding-theatre-select');
    const brandingForm = document.getElementById('branding-form');
    
    if(!tabBrandingBtn) return;

    // Tab Switching
    tabDashboardBtn.addEventListener('click', (e) => {
        e.preventDefault();
        tabDashboardBtn.classList.add('active');
        tabBrandingBtn.classList.remove('active');
        dashboardView.classList.remove('hidden');
        brandingView.classList.add('hidden');
    });

    tabBrandingBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        tabBrandingBtn.classList.add('active');
        tabDashboardBtn.classList.remove('active');
        brandingView.classList.remove('hidden');
        dashboardView.classList.add('hidden');
        await loadTheatresForBranding();
    });

    // Inputs
    const inputName = document.getElementById('brand-display-name');
    const inputPrimary = document.getElementById('brand-primary-color');
    const inputPrimaryHex = document.getElementById('brand-primary-hex');
    const inputBg = document.getElementById('brand-bg-color');
    const inputBgHex = document.getElementById('brand-bg-hex');
    const inputLogo = document.getElementById('brand-logo-upload');
    const previewLogo = document.getElementById('brand-logo-preview');
    
    // Preview Elements
    const previewBtn = document.getElementById('preview-btn');
    const previewTitle = document.getElementById('preview-title');
    const previewCard = previewBtn.parentElement.parentElement;
    const previewHero = previewCard.querySelector('div:nth-child(2) > div');
    const previewLogoPh = document.getElementById('preview-logo-placeholder');

    // Sync Hex <-> Color Picker
    inputPrimary.addEventListener('input', (e) => {
        inputPrimaryHex.value = e.target.value;
        updatePreview();
    });
    inputPrimaryHex.addEventListener('input', (e) => {
        inputPrimary.value = e.target.value;
        updatePreview();
    });
    inputBg.addEventListener('input', (e) => {
        inputBgHex.value = e.target.value;
        updatePreview();
    });
    inputBgHex.addEventListener('input', (e) => {
        inputBg.value = e.target.value;
        updatePreview();
    });
    inputName.addEventListener('input', updatePreview);

    inputLogo.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            previewLogo.src = URL.createObjectURL(file);
            previewLogo.style.display = 'block';
            updatePreview();
        }
    });

    function updatePreview() {
        const primary = inputPrimary.value || '#e50914';
        const bg = inputBg.value || '#141414';
        
        previewBtn.style.background = primary;
        previewHero.style.background = \`linear-gradient(45deg, \${primary}, transparent)\`;
        previewCard.parentElement.style.background = bg;
        previewTitle.textContent = inputName.value || 'My Theatre';
        
        if (previewLogo.src) {
            previewLogoPh.style.backgroundImage = \`url(\${previewLogo.src})\`;
            previewLogoPh.style.backgroundSize = 'contain';
            previewLogoPh.style.backgroundRepeat = 'no-repeat';
            previewLogoPh.style.backgroundPosition = 'center';
            previewLogoPh.style.backgroundColor = 'transparent';
        }
    }

    async function loadTheatresForBranding() {
        const user = await JayShow.getCurrentUser();
        if(!user) return;
        const { data } = await JayShow.supabase.from('theatre_owners').select('theatres(id, name)').eq('user_id', user.id);
        
        theatreSelect.innerHTML = '<option value="">Select Theatre</option>';
        if(data) {
            data.forEach(t => {
                const opt = document.createElement('option');
                opt.value = t.theatres.id;
                opt.textContent = t.theatres.name;
                theatreSelect.appendChild(opt);
            });
        }
    }

    theatreSelect.addEventListener('change', async (e) => {
        const theaterId = e.target.value;
        if(!theaterId) return;

        const { data } = await JayShow.supabase.from('theater_branding').select('*').eq('theater_id', theaterId).single();
        if (data) {
            inputName.value = data.display_name || '';
            inputPrimary.value = data.primary_color || '#e50914';
            inputPrimaryHex.value = data.primary_color || '#e50914';
            inputBg.value = data.background_color || '#141414';
            inputBgHex.value = data.background_color || '#141414';
            if(data.logo_url) {
                previewLogo.src = data.logo_url;
                previewLogo.style.display = 'block';
            }
            updatePreview();
        } else {
            // Defaults
            inputName.value = theatreSelect.options[theatreSelect.selectedIndex].text;
            updatePreview();
        }
    });

    brandingForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const theaterId = theatreSelect.value;
        if(!theaterId) return alert('Please select a theatre');

        const btn = brandingForm.querySelector('button');
        btn.textContent = 'Saving...';
        btn.disabled = true;

        try {
            let logoUrl = previewLogo.src && !previewLogo.src.startsWith('blob:') ? previewLogo.src : null;

            if (inputLogo.files[0]) {
                const file = inputLogo.files[0];
                const fileExt = file.name.split('.').pop();
                const fileName = \`\${theaterId}/logo-\${Date.now()}.\${fileExt}\`;
                
                const { error: uploadError, data } = await JayShow.supabase.storage
                    .from('branding')
                    .upload(fileName, file, { upsert: true });
                
                if (uploadError) throw uploadError;

                const { data: { publicUrl } } = JayShow.supabase.storage.from('branding').getPublicUrl(fileName);
                logoUrl = publicUrl;
            }

            const payload = {
                theater_id: theaterId,
                display_name: inputName.value,
                primary_color: inputPrimary.value,
                background_color: inputBg.value,
                logo_url: logoUrl,
                active: true,
                show_powered_by: true
            };

            const { error } = await JayShow.supabase.from('theater_branding').upsert(payload, { onConflict: 'theater_id' });
            if (error) throw error;

            alert('Branding saved successfully!');
        } catch(err) {
            console.error(err);
            alert('Failed to save branding.');
        } finally {
            btn.textContent = 'Save Branding Settings';
            btn.disabled = false;
        }
    });
});
`;

fs.appendFileSync('public/assets/js/owner-dashboard.js', jsContent);

// Update vercel.json
const vercelPath = 'vercel.json';
let vercel = {};
if (fs.existsSync(vercelPath)) {
    vercel = JSON.parse(fs.readFileSync(vercelPath, 'utf8'));
}
if (!vercel.rewrites) {
    vercel.rewrites = [{ source: "/(.*)", destination: "/index.html" }];
}
fs.writeFileSync(vercelPath, JSON.stringify(vercel, null, 2));

console.log('Scripts updated successfully.');
