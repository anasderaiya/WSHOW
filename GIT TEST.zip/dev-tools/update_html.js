const fs = require('fs');
const path = require('path');

const publicDir = 'c:/Users/Yom Computer/Desktop/Codebase/WHITELABLE-SHOW/public';
const files = fs.readdirSync(publicDir).filter(f => f.endsWith('.html'));

const badgeHtml = `
    <div class="powered-by-badge">
        <span>Powered by</span>
        <a href="https://quickmytickets.com" target="_blank" rel="noopener">
            <img src="/assets/images/qmt-badge.png" alt="Quick My Ticket" height="20">
        </a>
    </div>
`;

const configScriptHtml = `
    <script src="assets/js/config.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
`;

let count = 0;
for (const file of files) {
    const filePath = path.join(publicDir, file);
    let content = fs.readFileSync(filePath, 'utf8');
    
    // Inject badge before </footer>
    if (content.includes('</footer>') && !content.includes('powered-by-badge')) {
        content = content.replace('</footer>', badgeHtml + '</footer>');
    }

    // Inject config.js before supabase-js
    if (content.includes('<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>') && !content.includes('assets/js/config.js')) {
        content = content.replace(
            '<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>', 
            configScriptHtml
        );
    }

    fs.writeFileSync(filePath, content);
    count++;
}
console.log(`Updated ${count} HTML files.`);
