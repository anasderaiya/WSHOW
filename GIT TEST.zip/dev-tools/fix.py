import re

with open('public/admin.html', 'r', encoding='utf-8') as f:
    content = f.read()

split_str1 = '                                <input type="datetime-local" id="show-end" class="form-input">\n                            </div>\n'
split_str2 = '                                <label for="event-category" class="form-label">Category *</label>'

if split_str1 in content and split_str2 in content:
    part1 = content.split(split_str1)[0] + split_str1
    part2 = split_str2 + content.split(split_str2)[1]
    
    middle = """                        </div>
                        <div class="form-group">
                            <label for="show-price" class="form-label">Base Price ₹</label>
                            <input type="number" id="show-price" class="form-input" value="200" min="0">
                        </div>
                        <button type="submit" class="btn btn-primary">Create Show</button>
                    </form>
                    <div id="movie-show-list" style="margin-top: 1rem;">
                        <p style="color: var(--text-muted);">Select a movie to see its shows</p>
                    </div>
                </section>
            </div> <!-- End Admin Card Grid -->
        </div> <!-- End Movies & Theatres Group -->

        <!-- Live Events Management Group -->
        <div id="live-events" class="admin-entity-group">
            <div class="admin-section-header">
                <h2>Event Management</h2>
                <div class="admin-header-actions">
                    <button class="btn btn-primary" onclick="openPlatformSettingsModal()">Platform Settings</button>
                </div>
            </div>

            <!-- Platform Settings Modal -->
            <div id="platform-settings-modal" class="modal hidden" style="position: fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center; display: flex;">
                <div class="modal-content" style="background: white; padding: 2rem; border-radius: 8px; width: 400px; max-width: 90%;">
                    <h3>Platform Settings</h3>
                    <form id="platform-settings-form" class="admin-form" style="margin-top: 1rem;">
                        <div class="form-group">
                            <label for="fee-type" class="form-label">Convenience Fee Type</label>
                            <select id="fee-type" class="form-input" required>
                                <option value="fixed">Fixed Amount (₹)</option>
                                <option value="percentage">Percentage (%)</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="fee-amount" class="form-label">Fee Amount</label>
                            <input type="number" id="fee-amount" class="form-input" min="0" step="0.01" required>
                        </div>
                        <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
                            <button type="submit" class="btn btn-primary" style="flex: 1;">Save Settings</button>
                            <button type="button" class="btn btn-outline" style="flex: 1;" onclick="closePlatformSettingsModal()">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="admin-card-grid">

                <!-- Events Section -->
                <section class="admin-section">
                    <h3>Events</h3>
                    <form id="event-form" class="admin-form">
                        <div class="form-group">
                            <label for="event-title" class="form-label">Event Title *</label>
                            <input type="text" id="event-title" class="form-input" placeholder="Arijit Singh Live" required>
                        </div>
                        <div class="form-group">
                            <label for="event-description" class="form-label">Description</label>
                            <textarea id="event-description" class="form-input" rows="3"
                                placeholder="Event description..."></textarea>
                        </div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                            <div class="form-group">
"""
    with open('public/admin.html', 'w', encoding='utf-8') as f:
        f.write(part1 + middle + part2)
    print('Fixed admin.html successfully')
else:
    print('Split strings not found.')
