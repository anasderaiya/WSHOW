const fs = require('fs');
const path = require('path');

function searchDir(dir) {
    const files = fs.readdirSync(dir);
    for (const file of files) {
        const fullPath = path.join(dir, file);
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) {
            if (file !== 'node_modules' && file !== '.git' && file !== '.agents') {
                searchDir(fullPath);
            }
        } else if (file.endsWith('.html') || file.endsWith('.js')) {
            const content = fs.readFileSync(fullPath, 'utf8');
            if (content.includes('fetchTrendingMovies')) {
                console.log(`Found fetchTrendingMovies in: ${fullPath}`);
            }
        }
    }
}

searchDir(path.join(__dirname, 'public'));
