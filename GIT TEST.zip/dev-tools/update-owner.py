import re

with open('public/owner-dashboard.html', 'r', encoding='utf-8') as f:
    content = f.read()

# Remove the modal
content = re.sub(r'<!-- Manage Offline Seats Modal -->.*?</div>\s*</div>\s*<!-- Scripts -->', '<!-- Scripts -->', content, flags=re.DOTALL)

# Add offline to legend and a button
legend_target = '''<span class="legend-item"><span class="seat-dot booked"></span> Booked</span>
                        </div>
                    </div>'''

legend_replacement = '''<span class="legend-item"><span class="seat-dot booked"></span> Booked</span>
                            <span class="legend-item"><span class="seat-dot offline" style="background: #718096"></span> Offline</span>
                        </div>
                        <div style="margin-top: 1rem; display: flex; align-items: center;">
                            <button id="toggle-offline-btn" class="btn btn-secondary btn-sm" disabled onclick="toggleOfflineStatus()">Toggle Offline Status</button>
                            <span id="offline-feedback" style="margin-left: 1rem; font-size: 0.875rem;"></span>
                        </div>
                    </div>'''

if legend_target in content:
    content = content.replace(legend_target, legend_replacement)
else:
    print("Legend target not found")

with open('public/owner-dashboard.html', 'w', encoding='utf-8') as f:
    f.write(content)
