html_content = """<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="supabase-url" content="https://cyjzbkdxhlzeqfmamdau.supabase.co">
    <meta name="supabase-anon-key" content="sb_publishable__qLGRXfnfzbVqQZJippZVQ_K8lkNqkR">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Screen - Quick my Ticket</title>
    <meta name="description" content="Add a new screen to your theatre">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/owner-dashboard.css">
    <!-- PWA Tags -->
        <link rel="preconnect" href="https://cdn.jsdelivr.net">

    <link rel="manifest" href="manifest.json">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <link rel="apple-touch-icon" href="assets/images/icon-192.png">
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar scrolled">
        <div class="navbar-container">
            <a href="index.html" class="navbar-brand">
                <img src="assets/images/logo.png" alt="Quick my Ticket Logo">
            </a>
            <ul class="navbar-links">
                <li><a href="owner-dashboard.html">← Back to Dashboard</a></li>
            </ul>
            <div class="navbar-user" id="navbar-user">
                <span class="user-email hidden"></span>
                <button class="btn btn-secondary" id="logout-btn">Logout</button>
            </div>
        </div>
    </nav>

    <!-- Loading State -->
    <div id="loading-state" class="owner-loading">
        <div class="spinner"></div>
        <p>Loading...</p>
    </div>

    <!-- Access Denied -->
    <div id="access-denied" class="owner-access-denied hidden">
        <div class="access-denied-content">
            <span class="access-denied-icon"><svg xmlns="http://www.w3.org/2000/svg" width="48" height="48"
                    viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"
                    stroke-linejoin="round">
                    <rect width="18" height="11" x="3" y="11" rx="2" ry="2" />
                    <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                </svg></span>
            <h2>Access Denied</h2>
            <p>You need to be a theater owner to access this page.</p>
            <a href="owner-login.html" class="btn btn-primary">Sign In as Owner</a>
        </div>
    </div>

    <!-- Main Content -->
    <main id="add-screen-content" class="owner-dashboard hidden">
        <header class="owner-header">
            <div class="header-content">
                <h1><svg class="lucide" xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24"
                        fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"
                        stroke-linejoin="round">
                        <rect width="20" height="14" x="2" y="3" rx="2" />
                        <line x1="8" x2="16" y1="21" y2="21" />
                        <line x1="12" x2="12" y1="17" y2="21" />
                    </svg> Add New Screen</h1>
                <p>Create a new screen in your theatre</p>
            </div>
        </header>

        <div class="add-show-grid"> <!-- Using same grid layout as add-show -->
            <!-- Add Screen Form -->
            <section class="filter-section">
                <h3><svg class="inline-icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                        viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"
                        stroke-linejoin="round">
                        <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z" />
                        <path d="M14 2v4a2 2 0 0 0 2 2h4" />
                        <path d="M10 9H8" />
                        <path d="M16 13H8" />
                        <path d="M16 17H8" />
                    </svg> Screen Details</h3>
                <form id="add-screen-form" class="add-show-form">
                    <div class="form-group">
                        <label for="theatre-select">Theatre *</label>
                        <select id="theatre-select" class="form-input" required>
                            <option value="">Select Theatre</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="screen-name">Screen Name *</label>
                        <input type="text" id="screen-name" class="form-input" placeholder="e.g. Screen 1, IMAX Hall"
                            required>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="screen-rows">Rows (Default)</label>
                            <input type="number" id="screen-rows" class="form-input" value="10" min="1" max="30">
                        </div>
                        <div class="form-group">
                            <label for="screen-cols">Seats per Row (Default)</label>
                            <input type="number" id="screen-cols" class="form-input" value="12" min="1" max="40">
                        </div>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 0.5rem; margin-top: 1rem;">
                        <div class="form-group">
                            <label for="regular-price" class="form-label">Regular Price ₹</label>
                            <input type="number" id="regular-price" class="form-input" value="150" min="0">
                        </div>
                        <div class="form-group">
                            <label for="premium-price" class="form-label">Premium Price ₹</label>
                            <input type="number" id="premium-price" class="form-input" value="250" min="0">
                        </div>
                        <div class="form-group">
                            <label for="vip-price" class="form-label">VIP Price ₹</label>
                            <input type="number" id="vip-price" class="form-input" value="400" min="0">
                        </div>
                    </div>

                    <div class="form-group" style="margin-top: 1rem;">
                        <p class="text-sm text-muted" style="margin-top: 0.5rem;">
                            Note: You can customize the exact seat layout later using the <a href="seat-editor.html"
                                style="color: var(--primary);">Seat Editor</a>.
                        </p>
                    </div>

                    <div id="form-feedback" class="form-feedback hidden"></div>

                    <button type="submit" class="btn btn-primary btn-lg" style="width: 100%;">
                        Create Screen
                    </button>
                </form>
            </section>

            <!-- Existing Screens -->
            <section class="shows-section">
                <h3><svg class="inline-icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                        viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"
                        stroke-linejoin="round">
                        <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" />
                        <rect width="8" height="4" x="8" y="2" rx="1" ry="1" />
                    </svg> Your Screens</h3>
                <div id="screens-list" class="shows-list">
                    <p class="text-muted">Loading screens...</p>
                </div>
            </section>
        </div>
    
    <!-- Powered By Badge -->
    <div class="powered-by-badge">
        <span>Powered by</span>
        <a href="https://quickmytickets.com" target="_blank" rel="noopener">
            <img src="/assets/images/qmt-badge.png" alt="Quick My Ticket" height="20">
        </a>
    </div>

</main>

    <!-- Toast Notification -->
    <div id="toast" class="toast hidden">
        <span id="toast-message"></span>
    </div>

    <!-- Scripts -->
    
    <script src="assets/js/config.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>

    <script src="assets/js/app.js" defer></script>
    <script src="assets/js/add-screen.js" defer></script>
</body>

</html>"""

with open("public/add-screen.html", "w", encoding="utf-8") as f:
    f.write(html_content)
