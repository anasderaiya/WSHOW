@echo off
echo ==============================================
echo Automatic Supabase Database Pusher
echo (No login required - direct DB connection)
echo ==============================================
echo.

echo Pushing all migrations to the cloud...
call npx supabase db push --db-url "postgresql://postgres:%%40Deraiya4786@db.cyjzbkdxhlzeqfmamdau.supabase.co:5432/postgres"
if %errorlevel% neq 0 (
    echo.
    echo Push failed. See error above.
    pause
    exit /b %errorlevel%
)
echo.

echo ==============================================
echo ALL DONE! Your database is fully set up.
echo ==============================================
pause
