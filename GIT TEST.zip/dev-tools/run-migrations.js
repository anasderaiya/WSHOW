/**
 * run-migrations.js
 * Runs all SQL migrations against Supabase via their Management API.
 * Usage: node run-migrations.js <supabase-access-token>
 * Get your access token from: https://supabase.com/dashboard/account/tokens
 */

const fs = require('fs');
const path = require('path');
const https = require('https');

const PROJECT_REF = 'cyjzbkdxhlzeqfmamdau';
const ACCESS_TOKEN = process.argv[2];

if (!ACCESS_TOKEN) {
  console.error('\n❌ Usage: node run-migrations.js <your-supabase-access-token>');
  console.error('   Get your token at: https://supabase.com/dashboard/account/tokens\n');
  process.exit(1);
}

const MIGRATIONS_DIR = path.join(__dirname, 'supabase', 'migrations');

function runSQL(sql) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({ query: sql });
    const options = {
      hostname: 'api.supabase.com',
      path: `/v1/projects/${PROJECT_REF}/database/query`,
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${ACCESS_TOKEN}`,
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body),
      },
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          if (res.statusCode >= 200 && res.statusCode < 300) {
            resolve(parsed);
          } else {
            reject(new Error(`HTTP ${res.statusCode}: ${JSON.stringify(parsed)}`));
          }
        } catch (e) {
          reject(new Error(`Parse error: ${data}`));
        }
      });
    });

    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

async function ensureMigrationTable() {
  const sql = `
    CREATE TABLE IF NOT EXISTS supabase_migrations.schema_migrations (
      version text NOT NULL PRIMARY KEY,
      statements text[],
      name text
    );
  `;
  try {
    await runSQL(sql);
  } catch (e) {
    // Table may already exist, that's fine
  }
}

async function getAppliedMigrations() {
  try {
    const result = await runSQL(
      `SELECT version FROM supabase_migrations.schema_migrations ORDER BY version;`
    );
    return new Set((result || []).map(r => r.version));
  } catch (e) {
    return new Set();
  }
}

async function markMigrationApplied(version, name) {
  await runSQL(
    `INSERT INTO supabase_migrations.schema_migrations (version, name) 
     VALUES ('${version}', '${name}') ON CONFLICT (version) DO NOTHING;`
  );
}

async function main() {
  console.log('\n🚀 Supabase Migration Runner');
  console.log('============================\n');

  // Get all migration files sorted
  const files = fs.readdirSync(MIGRATIONS_DIR)
    .filter(f => f.endsWith('.sql'))
    .sort();

  console.log(`Found ${files.length} migration files.\n`);

  // Ensure migration tracking table exists
  await ensureMigrationTable();
  const applied = await getAppliedMigrations();

  let successCount = 0;
  let skipCount = 0;
  let errorCount = 0;

  for (const file of files) {
    const version = file.replace(/\.sql$/, '');
    
    if (applied.has(version)) {
      console.log(`⏭️  Skipping ${file} (already applied)`);
      skipCount++;
      continue;
    }

    const sqlPath = path.join(MIGRATIONS_DIR, file);
    const sql = fs.readFileSync(sqlPath, 'utf8');

    process.stdout.write(`⏳ Applying ${file}...`);
    
    try {
      await runSQL(sql);
      await markMigrationApplied(version, file);
      console.log(' ✅');
      successCount++;
    } catch (err) {
      console.log(' ❌');
      console.error(`   Error: ${err.message}\n`);
      errorCount++;
      // Continue with next migration
    }
  }

  console.log('\n============================');
  console.log(`✅ Applied:  ${successCount}`);
  console.log(`⏭️  Skipped:  ${skipCount}`);
  console.log(`❌ Errors:   ${errorCount}`);
  console.log('============================\n');

  if (errorCount > 0) {
    console.log('⚠️  Some migrations had errors. Check logs above.');
  } else {
    console.log('🎉 All migrations applied successfully!');
  }
}

main().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
