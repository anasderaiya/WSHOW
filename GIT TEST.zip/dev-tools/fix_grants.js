const https = require('https');

const SUPABASE_URL = 'https://cyjzbkdxhlzeqfmamdau.supabase.co';
const ANON_KEY = 'sb_publishable__qLGRXfnfzbVqQZJippZVQ_K8lkNqkR';

// We need the service_role key to run admin SQL. 
// Instead, user will paste this SQL in the editor.

const sql = `
-- Fix all table grants (lost when schema was dropped/recreated)
GRANT USAGE ON SCHEMA public TO anon, authenticated, service_role;
GRANT ALL ON ALL TABLES IN SCHEMA public TO anon, authenticated, service_role;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO anon, authenticated, service_role;
GRANT ALL ON ALL FUNCTIONS IN SCHEMA public TO anon, authenticated, service_role;

-- Set default privileges for future tables
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO anon, authenticated, service_role;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO anon, authenticated, service_role;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon, authenticated, service_role;
`;

console.log('Paste this in SQL Editor and Run:\n');
console.log(sql);
