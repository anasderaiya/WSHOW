/**
 * Comprehensive diagnostic - checks everything that could be broken
 * after DROP SCHEMA public CASCADE on Supabase
 */
const https = require('https');

const HOST = 'cyjzbkdxhlzeqfmamdau.supabase.co';
const KEY = 'sb_publishable__qLGRXfnfzbVqQZJippZVQ_K8lkNqkR';

function apiCall(path, method = 'GET', body = null) {
  return new Promise((resolve) => {
    const headers = {
      'apikey': KEY,
      'Authorization': `Bearer ${KEY}`,
      'Content-Type': 'application/json',
    };
    if (body) headers['Content-Length'] = Buffer.byteLength(body);
    
    const req = https.request({ hostname: HOST, path, method, headers }, res => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => resolve({ status: res.statusCode, body: d }));
    });
    req.on('error', e => resolve({ status: 0, body: e.message }));
    if (body) req.write(body);
    req.end();
  });
}

async function main() {
  console.log('=== SUPABASE DIAGNOSTIC REPORT ===\n');

  // 1. Auth health
  const auth = await apiCall('/auth/v1/health');
  console.log(`1. Auth API Health: ${auth.status === 200 ? '✅ OK' : '❌ FAILED'}`);

  // 2. Signup test
  const signup = await apiCall('/auth/v1/signup', 'POST', 
    JSON.stringify({ email: 'test_diag@test.com', password: 'Test@12345' }));
  console.log(`2. Auth Signup: ${signup.status} - ${signup.body.substring(0, 150)}`);

  // 3. Login test
  const login = await apiCall('/auth/v1/token?grant_type=password', 'POST',
    JSON.stringify({ email: 'admin@quickmyticket.com', password: 'Admin@1234' }));
  console.log(`3. Auth Login: ${login.status} - ${login.body.substring(0, 150)}`);

  // 4. REST API - can we reach tables?
  const tables = await apiCall('/rest/v1/theatres?select=id&limit=1');
  console.log(`4. REST theatres: ${tables.status} - ${tables.body.substring(0, 150)}`);

  // 5. REST API - app_settings
  const settings = await apiCall('/rest/v1/app_settings?select=key&limit=1');
  console.log(`5. REST app_settings: ${settings.status} - ${settings.body.substring(0, 150)}`);

  // 6. Check if RPC functions work
  const rpc = await apiCall('/rest/v1/rpc/get_show_seats_with_status', 'POST',
    JSON.stringify({ p_show_id: '00000000-0000-0000-0000-000000000000' }));
  console.log(`6. RPC functions: ${rpc.status} - ${rpc.body.substring(0, 150)}`);

  console.log('\n=== DIAGNOSIS ===');
  
  const parsed2 = JSON.parse(signup.body);
  const parsed3 = JSON.parse(login.body);
  const parsed4 = JSON.parse(tables.body);

  if (parsed2.error_code === 'unexpected_failure' || parsed3.error_code === 'unexpected_failure') {
    console.log('\n❌ AUTH IS BROKEN: GoTrue cannot query the database.');
    console.log('   Root cause: DROP SCHEMA public CASCADE destroyed internal Supabase config.');
    console.log('   Fix: Reset the project from Supabase Dashboard, or restore schema internals.');
  }

  if (parsed4.code === '42501') {
    console.log('\n❌ TABLE GRANTS MISSING: anon/authenticated roles cannot access tables.');
    console.log('   Fix: GRANT ALL ON ALL TABLES IN SCHEMA public TO anon, authenticated, service_role;');
  }

  if (parsed4.code === '42P01') {
    console.log('\n❌ TABLES MISSING: Tables were not created properly.');
  }

  console.log('\n=== RECOMMENDED ACTION ===');
  console.log('The fastest fix: Reset the Supabase project and re-run the schema.');
  console.log('Dashboard → Project Settings → General → "Pause project", then "Restore"');
  console.log('OR: Dashboard → Project Settings → General → "Reset database"');
}

main();
