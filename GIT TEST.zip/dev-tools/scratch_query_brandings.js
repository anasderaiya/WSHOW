const https = require('https');

const SUPABASE_URL = 'https://cyjzbkdxhlzeqfmamdau.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable__qLGRXfnfzbVqQZJippZVQ_K8lkNqkR';

const url = new URL(`${SUPABASE_URL}/rest/v1/theater_branding`);

const options = {
  hostname: url.hostname,
  path: url.pathname + url.search,
  method: 'GET',
  headers: {
    'Content-Type': 'application/json',
    'apikey': SUPABASE_ANON_KEY,
    'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
  },
};

const req = https.request(options, (res) => {
  let data = '';
  res.on('data', chunk => data += chunk);
  res.on('end', () => {
    try {
      const result = JSON.parse(data);
      console.log('HTTP Status:', res.statusCode);
      console.log('Results Count:', result.length);
      console.log('Result:', JSON.stringify(result, null, 2));
    } catch (e) {
      console.log('Raw data:', data);
    }
  });
});

req.on('error', (e) => console.error('Request failed:', e.message));
req.end();
