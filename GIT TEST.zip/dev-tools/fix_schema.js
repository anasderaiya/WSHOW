const fs = require('fs');
const path = require('path');

// 1. Regenerate from migrations
const migrationsDir = path.join(__dirname, 'supabase', 'migrations');
const files = fs.readdirSync(migrationsDir)
  .filter(f => f.endsWith('.sql'))
  .sort();

let combined = '';
for (const file of files) {
  const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
  combined += `-- ============================================\n`;
  combined += `-- Migration: ${file}\n`;
  combined += `-- ============================================\n\n`;
  combined += sql + '\n\n';
}

// 2. Add inline DROP POLICY before every CREATE POLICY
combined = combined.replace(
  /^([ \t]*)(CREATE POLICY\s+"([^"]+)"\s+ON\s+(\S+?)(?=\s))/gm,
  (match, indent, full, policyName, tableName) => {
    return `${indent}DROP POLICY IF EXISTS "${policyName}" ON ${tableName};\n${indent}${full}`;
  }
);

// 3. Make CREATE TABLE/INDEX idempotent
combined = combined.replace(/CREATE TABLE (?!IF NOT EXISTS)/g, 'CREATE TABLE IF NOT EXISTS ');
combined = combined.replace(/CREATE INDEX (?!IF NOT EXISTS)/g, 'CREATE INDEX IF NOT EXISTS ');
combined = combined.replace(/CREATE UNIQUE INDEX (?!IF NOT EXISTS)/g, 'CREATE UNIQUE INDEX IF NOT EXISTS ');

// 4. Prepend a RESET block that drops all app tables in correct order (reverse dependencies)
const resetBlock = `-- ============================================
-- RESET: Drop all existing app objects for clean re-run
-- ============================================
-- Drop views first
DROP VIEW IF EXISTS seat_availability CASCADE;
DROP VIEW IF EXISTS available_seats CASCADE;

-- Drop all tables in reverse dependency order
DROP TABLE IF EXISTS bookings CASCADE;
DROP TABLE IF EXISTS seats CASCADE;
DROP TABLE IF EXISTS shows CASCADE;
DROP TABLE IF EXISTS screens CASCADE;
DROP TABLE IF EXISTS movies CASCADE;
DROP TABLE IF EXISTS theatres CASCADE;
DROP TABLE IF EXISTS theater_owners CASCADE;
DROP TABLE IF EXISTS owner_registrations CASCADE;
DROP TABLE IF EXISTS events CASCADE;
DROP TABLE IF EXISTS app_settings CASCADE;

-- Drop functions
DROP FUNCTION IF EXISTS lock_seat(UUID, UUID, UUID, TEXT) CASCADE;
DROP FUNCTION IF EXISTS unlock_seat(UUID, UUID, TEXT) CASCADE;
DROP FUNCTION IF EXISTS release_expired_locks(INTEGER) CASCADE;
DROP FUNCTION IF EXISTS release_expired_locks() CASCADE;
DROP FUNCTION IF EXISTS auto_release_expired_locks() CASCADE;
DROP FUNCTION IF EXISTS calculate_booking_total(UUID[], DECIMAL) CASCADE;
DROP FUNCTION IF EXISTS confirm_bookings(UUID[], TEXT) CASCADE;
DROP FUNCTION IF EXISTS get_owned_theatres(UUID) CASCADE;
DROP FUNCTION IF EXISTS get_owner_dashboard_stats(UUID) CASCADE;
DROP FUNCTION IF EXISTS get_owner_revenue_report(UUID, DATE, DATE) CASCADE;
DROP FUNCTION IF EXISTS extend_locks(UUID[], UUID, TEXT) CASCADE;
DROP FUNCTION IF EXISTS approve_owner_registration(UUID, UUID) CASCADE;
DROP FUNCTION IF EXISTS reject_owner_registration(UUID) CASCADE;
DROP FUNCTION IF EXISTS lock_seats_batch(UUID, UUID[], UUID, TEXT) CASCADE;
DROP FUNCTION IF EXISTS unlock_seats_batch(UUID[], UUID, TEXT) CASCADE;
DROP FUNCTION IF EXISTS get_show_seats_with_status(UUID) CASCADE;

-- Drop triggers  
DROP TRIGGER IF EXISTS update_theater_owners_updated_at ON theater_owners;
DROP TRIGGER IF EXISTS update_owner_registrations_updated_at ON owner_registrations;
DROP FUNCTION IF EXISTS update_updated_at_column() CASCADE;

-- ============================================
-- END RESET
-- ============================================

`;

const outFile = path.join(__dirname, 'supabase', 'unified_schema.sql');
fs.writeFileSync(outFile, resetBlock + combined);

// Count policies
const policyCount = (combined.match(/CREATE POLICY/g) || []).length;
const dropCount = (combined.match(/DROP POLICY IF EXISTS/g) || []).length;
console.log(`Done! ${files.length} migrations combined.`);
console.log(`${policyCount} CREATE POLICY statements, ${dropCount} DROP POLICY IF EXISTS statements.`);
console.log(`Reset block prepended to drop all tables/functions first.`);
