import os
import re

migrations_dir = 'supabase/migrations'

def fix_corruption(match):
    policy_name = match.group(1)
    table_name = match.group(2)
    return f'DROP POLICY IF EXISTS {policy_name} ON public.{table_name};\nCREATE POLICY {policy_name}\nON public.{table_name}'

for filename in os.listdir(migrations_dir):
    if not filename.endswith('.sql'): continue
    filepath = os.path.join(migrations_dir, filename)
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    new_content = re.sub(r'DROP POLICY IF EXISTS\s+(\"[^\"]+\")\s+ON\s+public;\nCREATE POLICY\s+\"[^\"]+\"\nON\s+public\n*\.([a-zA-Z0-9_]+)', fix_corruption, content, flags=re.IGNORECASE)
    new_content = re.sub(r'DROP POLICY IF EXISTS\s+(\"[^\"]+\")\s+ON\s+public;\nCREATE POLICY\s+\"[^\"]+\"\nON\s+public\.([a-zA-Z0-9_]+)', fix_corruption, new_content, flags=re.IGNORECASE)
    
    if new_content != content:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print(f'Fixed corruption in {filename}')
