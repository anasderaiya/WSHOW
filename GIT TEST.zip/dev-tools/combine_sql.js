const fs = require('fs');
const path = require('path');

const migrationsDir = path.join(__dirname, 'supabase', 'migrations');
const files = fs.readdirSync(migrationsDir)
                .filter(f => f.endsWith('.sql'))
                .sort();

let combinedSql = '-- ==========================================\n';
combinedSql += '-- Quick My Ticket - Unified Supabase Schema\n';
combinedSql += '-- Generated for fresh deployment\n';
combinedSql += '-- ==========================================\n\n';

for (const file of files) {
    combinedSql += `-- ==========================================\n`;
    combinedSql += `-- Migration: ${file}\n`;
    combinedSql += `-- ==========================================\n\n`;
    combinedSql += fs.readFileSync(path.join(migrationsDir, file), 'utf8');
    combinedSql += `\n\n`;
}

const outputPath = path.join(__dirname, 'supabase', 'unified_schema.sql');
fs.writeFileSync(outputPath, combinedSql);
console.log('Successfully created supabase/unified_schema.sql');
