const fs = require('fs');
const path = require('path');

const jsDir = path.join(__dirname, 'public', 'assets', 'js');
const files = fs.readdirSync(jsDir).filter(f => f.endsWith('.js'));

console.log('Searching for loadBranding in JS files:\n');

for (const file of files) {
  const filePath = path.join(jsDir, file);
  const content = fs.readFileSync(filePath, 'utf8');
  if (content.includes('loadBranding')) {
    const lines = content.split('\n');
    lines.forEach((line, idx) => {
      if (line.includes('loadBranding')) {
        console.log(`🔍 ${file}:${idx + 1}: ${line.trim()}`);
      }
    });
  }
}
