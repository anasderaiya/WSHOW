const fs = require('fs');
const path = require('path');

function searchDir(dir) {
    const files = fs.readdirSync(dir);
    for (const file of files) {
        const fullPath = path.join(dir, file);
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) {
            if (file !== 'node_modules' && file !== '.git' && file !== '.agents') {
                searchDir(fullPath);
            }
        } else {
            const content = fs.readFileSync(fullPath, 'utf8');
            if (content.includes('themoviedb.org') || content.includes('api_key')) {
                console.log(`Found match in: ${fullPath}`);
                // Print lines
                const lines = content.split('\n');
                lines.forEach((line, idx) => {
                    if (line.includes('themoviedb.org') || line.includes('api_key')) {
                        console.log(`  Line ${idx + 1}: ${line.trim()}`);
                    }
                });
            }
        }
    }
}

searchDir(path.join(__dirname, 'public'));
searchDir(path.join(__dirname, 'supabase'));
