const https = require('https');

const SUPABASE_URL = 'https://cyjzbkdxhlzeqfmamdau.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable__qLGRXfnfzbVqQZJippZVQ_K8lkNqkR';

const email = 'admin@quickmyticket.com';
const password = 'Admin@1234';

const body = JSON.stringify({
  email,
  password,
  data: { full_name: 'Super Admin' }
});

const url = new URL(`${SUPABASE_URL}/auth/v1/signup`);

const options = {
  hostname: url.hostname,
  path: url.pathname,
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'apikey': SUPABASE_ANON_KEY,
    'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
    'Content-Length': Buffer.byteLength(body),
  },
};

const req = https.request(options, (res) => {
  let data = '';
  res.on('data', chunk => data += chunk);
  res.on('end', () => {
    const result = JSON.parse(data);
    if (res.statusCode >= 200 && res.statusCode < 300 && result.id) {
      console.log('✅ Account created successfully!');
      console.log(`   User ID: ${result.id}`);
      console.log(`   Email: ${email}`);
      console.log(`   Password: ${password}`);
      console.log('\n   Now run this in Supabase SQL Editor to make admin:');
      console.log(`\n   UPDATE auth.users SET raw_app_meta_data = raw_app_meta_data || '{"is_admin": true}'::jsonb WHERE id = '${result.id}';`);
    } else {
      console.log('❌ Error:', JSON.stringify(result, null, 2));
    }
  });
});

req.on('error', (e) => console.error('Request failed:', e.message));
req.write(body);
req.end();
