const https = require('https');

const SUPABASE_URL = 'https://cyjzbkdxhlzeqfmamdau.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable__qLGRXfnfzbVqQZJippZVQ_K8lkNqkR';

// Let's test the theaterId from check_branding.js
const theaterId = "dddd58fe-82c1-45fc-aadf-79613cbdb122";

const url = new URL(`${SUPABASE_URL}/rest/v1/theater_branding?theater_id=eq.${theaterId}&active=eq.true`);

const options = {
  hostname: url.hostname,
  path: url.pathname + url.search,
  method: 'GET',
  headers: {
    'Content-Type': 'application/json',
    'apikey': SUPABASE_ANON_KEY,
    'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
    'Accept': 'application/vnd.pgrst.object+json' // This is equivalent to .single()
  },
};

const req = https.request(options, (res) => {
  let data = '';
  res.on('data', chunk => data += chunk);
  res.on('end', () => {
    try {
      const result = JSON.parse(data);
      console.log('HTTP Status:', res.statusCode);
      console.log('Result:', JSON.stringify(result, null, 2));
    } catch (e) {
      console.log('Raw data:', data);
    }
  });
});

req.on('error', (e) => console.error('Request failed:', e.message));
req.end();
