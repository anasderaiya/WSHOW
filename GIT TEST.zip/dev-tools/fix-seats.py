import re

with open('public/seats.html', 'r', encoding='utf-8') as f:
    content = f.read()

split_str1 = '        <!-- Booking Summary -->\n        <div class="booking-summary">\n'
split_str2 = '            <button id="pay-btn"'

if split_str1 in content and split_str2 in content:
    part1 = content.split(split_str1)[0] + split_str1
    part2 = split_str2 + content.split(split_str2)[1]
    
    middle = """            <div class="summary-header">Booking Summary</div>

            <div id="selected-seats" class="selected-seats">
                <span style="color: var(--text-muted);">No seats selected</span>
            </div>

            <div class="summary-row">
                <span>Subtotal</span>
                <span id="subtotal">₹0.00</span>
            </div>
            <div class="summary-row" id="convenience-fee-row" style="display: none;">
                <span>Convenience Fee</span>
                <span id="convenience-fee">₹0.00</span>
            </div>
            <div class="summary-row">
                <span>Tax (18% GST)</span>
                <span id="tax">₹0.00</span>
            </div>
            <div class="summary-row total">
                <span>Total</span>
                <span id="total">₹0.00</span>
            </div>

"""
    with open('public/seats.html', 'w', encoding='utf-8') as f:
        f.write(part1 + middle + part2)
    print('Fixed seats.html successfully')
else:
    print('Split strings not found.')
