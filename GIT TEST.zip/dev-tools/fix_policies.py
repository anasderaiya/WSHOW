import os
import re

migrations_dir = 'supabase/migrations'

def make_policy_idempotent(match):
    policy_name = match.group(1)
    table_name = match.group(2)
    
    # Check if there is already a DROP POLICY IF EXISTS before this CREATE POLICY
    # To avoid double drops, we just unconditionally replace it with DROP IF EXISTS ... CREATE
    return f'DROP POLICY IF EXISTS {policy_name} ON {table_name};\nCREATE POLICY {policy_name}\nON {table_name}'

for filename in os.listdir(migrations_dir):
    if not filename.endswith('.sql'): continue
    filepath = os.path.join(migrations_dir, filename)
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    # Find CREATE POLICY "name" ON table
    # But only if it's not already preceded by DROP POLICY IF EXISTS
    # Let's clean up existing drop policies first to avoid duplicates
    content = re.sub(r'DROP POLICY IF EXISTS\s+\"[^\"]+\"\s+ON\s+[a-zA-Z0-9_]+;\n*', '', content, flags=re.IGNORECASE)
    
    # Now replace all CREATE POLICY
    new_content = re.sub(r'CREATE POLICY\s+(\"[^\"]+\")\s*\n*\s*ON\s+([a-zA-Z0-9_]+)', make_policy_idempotent, content, flags=re.IGNORECASE)

    if new_content != content:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print(f"Updated {filename}")
