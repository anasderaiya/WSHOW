// inject_config.js
// Reads from environment variables — never hardcode credentials here
require('dotenv').config();

const fs = require('fs');
const path = require('path');

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY;
const MASTER_RAZORPAY_KEY = process.env.MASTER_RAZORPAY_KEY;

if (!SUPABASE_URL || !SUPABASE_ANON_KEY || !MASTER_RAZORPAY_KEY) {
  console.error('❌ Missing env vars. Copy .env.example to .env and fill in values.');
  process.exit(1);
}

const metaTags = `    <meta name="supabase-url" content="${SUPABASE_URL}">
    <meta name="supabase-anon-key" content="${SUPABASE_ANON_KEY}">`;

const htmlDir = path.join(__dirname, 'public');
const files = fs.readdirSync(htmlDir).filter(f => f.endsWith('.html'));

let updated = 0;
for (const file of files) {
    const filePath = path.join(htmlDir, file);
    let html = fs.readFileSync(filePath, 'utf8');
    
    // Skip if already has supabase-url meta tag
    if (html.includes('supabase-url')) {
        console.log(`⏭️  ${file} - already has meta tags`);
        continue;
    }
    
    // Insert after the first <head> or after charset meta
    if (html.includes('<head>')) {
        html = html.replace('<head>', '<head>\n' + metaTags);
    } else if (html.includes('<HEAD>')) {
        html = html.replace('<HEAD>', '<HEAD>\n' + metaTags);
    }
    
    fs.writeFileSync(filePath, html);
    console.log(`✅ ${file} - meta tags added`);
    updated++;
}

console.log(`\nDone! Updated ${updated}/${files.length} HTML files.`);
