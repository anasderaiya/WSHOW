const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
require('dotenv').config();

// Read credentials from .env — no fallbacks, fail loud if missing
const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY;
const MASTER_RAZORPAY_KEY = process.env.MASTER_RAZORPAY_KEY;

if (!SUPABASE_URL || !SUPABASE_ANON_KEY || !MASTER_RAZORPAY_KEY) {
  console.error('❌ Missing env vars. Copy .env.example to .env and fill in values.');
  process.exit(1);
}

/**
 * Copy directory recursively (cross-platform fallback for older Node versions)
 */
function copyFolderRecursiveSync(source, target) {
  if (!fs.existsSync(target)) {
    fs.mkdirSync(target, { recursive: true });
  }

  if (fs.lstatSync(source).isDirectory()) {
    const files = fs.readdirSync(source);
    files.forEach((file) => {
      const curSource = path.join(source, file);
      const curTarget = path.join(target, file);
      if (fs.lstatSync(curSource).isDirectory()) {
        copyFolderRecursiveSync(curSource, curTarget);
      } else {
        fs.copyFileSync(curSource, curTarget);
      }
    });
  }
}

async function run() {
  // Parse command line arguments
  // Usage: node deploy-theater.js [theater_id] [theater_name] [subdomain]
  const theaterId = process.argv[2] || 'dddd58fe-82c1-45fc-aadf-79613cbdb122';
  const theaterName = process.argv[3] || 'Demo cinema';
  const subdomain = process.argv[4] || 'demo-cinema';

  // Automatically compile the JS bundle first
  const { build } = require('./scripts/build-js.js');
  build();

  console.log('==================================================');
  console.log('🎬  QUICK MY TICKET - THEATER DEPLOYER');
  console.log('==================================================');
  console.log(`Theater ID:   ${theaterId}`);
  console.log(`Theater Name: ${theaterName}`);
  console.log(`Subdomain:    ${subdomain}`);
  console.log('--------------------------------------------------');

  const buildBaseDir = path.join(__dirname, 'builds');
  const buildDir = path.join(buildBaseDir, `qmt-${subdomain}`);

  // 1. Create a clean build directory
  console.log(`🧹 Cleaning old builds at builds/qmt-${subdomain}...`);
  if (fs.existsSync(buildDir)) {
    fs.rmSync(buildDir, { recursive: true, force: true });
  }
  fs.mkdirSync(buildDir, { recursive: true });

  // 2. Copy the public folder contents into the build directory
  console.log('📦 Copying website files to build folder...');
  const publicDir = path.join(__dirname, 'public');
  copyFolderRecursiveSync(publicDir, buildDir);

  // 3. Copy the vercel.json configuration to the build folder
  console.log('⚙️  Copying vercel.json routing configuration...');
  const vercelConfigSrc = path.join(__dirname, 'vercel.json');
  const vercelConfigDest = path.join(buildDir, 'vercel.json');
  if (fs.existsSync(vercelConfigSrc)) {
    fs.copyFileSync(vercelConfigSrc, vercelConfigDest);
  } else {
    console.error('❌ vercel.json not found in project root. Cannot deploy without CSP headers.');
    process.exit(1);
  }

  // 4. Inject actual config values into config.js
  const configJsPath = path.join(buildDir, 'assets', 'js', 'config.js');
  if (fs.existsSync(configJsPath)) {
    console.log('📝 Injecting theater credentials into config.js...');
    let configContent = fs.readFileSync(configJsPath, 'utf8');

    configContent = configContent
      .replace(/%%THEATER_ID%%/g, theaterId)
      .replace(/%%THEATER_NAME%%/g, theaterName)
      .replace(/%%SUPABASE_URL%%/g, SUPABASE_URL)
      .replace(/%%SUPABASE_ANON_KEY%%/g, SUPABASE_ANON_KEY)
      .replace(/%%RAZORPAY_KEY%%/g, MASTER_RAZORPAY_KEY)
      .replace(/%%DEPLOYMENT_ENV%%/g, 'production');

    fs.writeFileSync(configJsPath, configContent, 'utf8');
    console.log('✅ Configuration successfully injected!');
  } else {
    console.error('❌ Error: config.js not found in build assets!');
    process.exit(1);
  }

  // 5. Deploy using Vercel CLI
  console.log('\n🚀 Starting Vercel deployment...');
  console.log('👉 Note: If you are not logged in, Vercel will open a browser window to authenticate.');
  console.log('--------------------------------------------------');

  const vercelArgs = [
    'vercel',
    '--prod',
    '--yes' // Automatic confirmation for new/existing project questions
  ];

  // We use npx to run the locally-cached or newly-downloaded Vercel CLI
  const deployProcess = spawn('npx', vercelArgs, {
    cwd: buildDir,
    shell: true,
    stdio: 'inherit' // Pipe all output/input to parent process to allow interactive logins
  });

  deployProcess.on('close', (code) => {
    console.log('--------------------------------------------------');
    if (code === 0) {
      console.log('🎉 DEPLOYMENT COMPLETED SUCCESSFULLY!');
      console.log(`🔗 Your white-label site for "${theaterName}" is now live!`);
    } else {
      console.error(`❌ Deployment failed with exit code ${code}`);
      console.log('💡 Tip: Try running "npx vercel login" first to authorize the CLI.');
    }
  });
}

run().catch(err => {
  console.error('Fatal error during deployment:', err);
});
