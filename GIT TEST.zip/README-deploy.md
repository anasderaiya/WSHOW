# Deployment Guide

This document explains how to deploy a white-labeled theater frontend to Vercel.

## Prerequisites

1. **Node.js** (v18+)
2. **Vercel CLI** — `npm i -g vercel` and authenticate with `vercel login`
3. **`.env` file** — Copy `.env.example` to `.env` and fill in your values:
   ```
   SUPABASE_URL=https://your-project.supabase.co
   SUPABASE_ANON_KEY=your_anon_key
   MASTER_RAZORPAY_KEY=your_razorpay_key
   ```

## Deployment Pipeline

There are **two scripts** that work together. You only need to run **one command** — the deploy script — which handles everything.

### Quick Deploy (One Command)

**Windows / Cross-platform:**
```bash
node deploy-theater.js <theater_id> <theater_name> <subdomain>
```

**Linux / macOS:**
```bash
./scripts/deploy-theater.sh <theater_id> <theater_name> <subdomain>
```

**Example:**
```bash
node deploy-theater.js dddd58fe-82c1-45fc-aadf-79613cbdb122 "Demo Cinema" demo-cinema
```

### What the Deploy Script Does

```
┌─────────────────────────────────────────────┐
│ 1. Reads credentials from .env              │
│ 2. Copies public/ → builds/qmt-<subdomain>  │
│ 3. Copies vercel.json (CSP headers)         │
│ 4. Injects credentials into config.js       │
│    (replaces %%PLACEHOLDER%% tokens)        │
│ 5. Runs `vercel --prod` from build folder   │
└─────────────────────────────────────────────┘
```

### Script Roles

| Script | Platform | Role |
|--------|----------|------|
| `deploy-theater.js` | Windows / Cross-platform | Full pipeline: copy → inject → deploy |
| `scripts/deploy-theater.sh` | Linux / macOS | Same pipeline using `sed` and shell |
| `inject_config.js` | Any | **Standalone** — injects Supabase meta tags into HTML `<head>` for the main platform (not white-label) |

> **Note:** `inject_config.js` is for the **parent QuickMyTickets platform**, not for white-label deploys. It adds `<meta name="supabase-url">` tags to all HTML files in `public/`. The deploy scripts handle white-label config injection via `config.js` placeholder replacement.

## File Flow

```
public/assets/js/config.js     ← Source template with %%PLACEHOLDERS%%
        │
        ▼  (deploy script copies + replaces)
builds/qmt-<subdomain>/assets/js/config.js  ← Injected with real values
        │
        ▼  (vercel --prod)
https://qmt-<subdomain>.vercel.app           ← Live site
```

## Config Template

`public/assets/js/config.js` contains these placeholders:

| Placeholder | Injected From |
|-------------|---------------|
| `%%THEATER_ID%%` | CLI argument |
| `%%THEATER_NAME%%` | CLI argument |
| `%%SUPABASE_URL%%` | `.env` → `SUPABASE_URL` |
| `%%SUPABASE_ANON_KEY%%` | `.env` → `SUPABASE_ANON_KEY` |
| `%%RAZORPAY_KEY%%` | `.env` → `MASTER_RAZORPAY_KEY` |
| `%%DEPLOYMENT_ENV%%` | Hardcoded to `production` |

If any placeholder is left uninjected, `config.js` has a runtime validator that displays a clear error page instead of a blank screen.

## Database Migrations

Push migrations to the remote Supabase database:

```bash
npx supabase db push
```

This requires the Supabase CLI to be logged in and the project linked:

```bash
npx supabase login
npx supabase link --project-ref cyjzbkdxhlzeqfmamdau
```

## Edge Functions

Deploy the TMDB proxy Edge Function:

```bash
npx supabase functions deploy tmdb-proxy
```

## Troubleshooting

| Symptom | Cause | Fix |
|---------|-------|-----|
| Blank page with "Deployment Configuration Missing" | `config.js` placeholders not injected | Run the deploy script with correct args |
| All pages redirect to index | SPA rewrite in `vercel.json` | Ensure `vercel.json` has no `rewrites` block |
| `❌ Missing env vars` on deploy | `.env` file missing or incomplete | Copy `.env.example` → `.env` and fill values |
| Movie data not loading | TMDB proxy not deployed | Run `npx supabase functions deploy tmdb-proxy` |
