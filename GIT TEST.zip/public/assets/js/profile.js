/**
 * JayShow - Profile Page Logic
 * ============================
 * Handles user profile display and booking history.
 */

document.addEventListener('DOMContentLoaded', async () => {
    // 1. Initial UI update
    await JayShow.updateNavbar();
    
    // 2. Auth check
    const user = await JayShow.getUser();
    if (!user) {
        window.location.href = 'login.html';
        return;
    }

    // 3. Render user info
    renderUserInfo(user);

    // 4. Load booking history
    await loadBookingHistory(user.id);
});

/**
 * Renders user basic information from auth session
 */
function renderUserInfo(user) {
    const emailDisplay = document.getElementById('user-display-email');
    const initialsDisplay = document.getElementById('user-initials');
    const memberSince = document.getElementById('member-since');

    if (emailDisplay) emailDisplay.textContent = user.email;
    if (initialsDisplay) {
        initialsDisplay.textContent = user.email.charAt(0).toUpperCase();
    }
    
    if (memberSince && user.created_at) {
        const date = new Date(user.created_at);
        memberSince.textContent = date.toLocaleDateString('en-US', {
            month: 'long',
            year: 'numeric'
        });
    }
}

/**
 * Loads and renders confirmed bookings for the user
 */
async function loadBookingHistory(userId) {
    const container = document.getElementById('booking-history-list');
    if (container && !container.querySelector('.spinner, .skeleton')) {
        container.innerHTML = `
            <div class="loading" style="padding: 3rem; 
                 grid-column: 1/-1; text-align: center;">
                <div class="spinner"></div>
            </div>`;
    }

    const listContainer = document.getElementById('booking-history-list');
    if (!listContainer) return;

    try {
        const client = JayShow.getSupabaseClient();
        
        const { data: allBookings, error: historyError } = await client
            .from('bookings')
            .select(`
                id,
                status,
                seat_id,
                confirmed_at,
                payment_id,
                ticket_token,
                shows (
                    start_time,
                    movies (title, poster_url),
                    screens (
                        name,
                        theatre_id,
                        theatres (name)
                    )
                ),
                event_shows (
                    start_time,
                    events (title, poster_url),
                    screens (
                        name,
                        theatre_id,
                        theatres (name)
                    )
                ),
                seats (row, col, price)
            `)
            .eq('user_id', userId)
            .eq('status', 'confirmed')
            .order('confirmed_at', { ascending: false });

        if (historyError) throw historyError;

        let combined = allBookings || [];

        // Check white-label theater isolation
        const theaterId = typeof JayShow.getCurrentTheaterId === 'function' ? JayShow.getCurrentTheaterId() : null;
        if (theaterId) {
            combined = combined.filter(booking => {
                const show = booking.event_shows || booking.shows;
                const showTheatreId = show?.screens?.theatre_id;
                return showTheatreId === theaterId;
            });
        }

        if (combined.length === 0) {
            listContainer.innerHTML = `
                <div class="empty-history">
                    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" style="margin-bottom: 1rem;"><rect width="18" height="18" x="3" y="3" rx="2" /><path d="M7 3v18" /><path d="M17 3v18" /><path d="M3 7h4" /><path d="M17 7h4" /><path d="M3 12h18" /><path d="M3 17h4" /><path d="M17 17h4" /></svg>
                    <p>No bookings found yet.</p>
                    <a href="index.html" class="btn btn-primary" style="margin-top: 1.5rem;">Explore Movies</a>
                </div>
            `;
            return;
        }

        // Render each booking
        listContainer.innerHTML = '';
        combined.forEach(booking => {
            const card = createBookingCard(booking);
            listContainer.appendChild(card);
        });

    } catch (err) {
        console.error('Error loading history:', err);
        listContainer.innerHTML = `<div class="alert alert-error">Failed to load booking history. ${err.message || ''}</div>`;
    }
}

/**
 * Creates a DOM element for a booking card
 */
function createBookingCard(booking) {
    const isEvent = !!booking.event_shows;
    const show = isEvent ? booking.event_shows : booking.shows;
    const title = isEvent ? show?.events?.title : show?.movies?.title;
    const theatre = show?.screens?.theatres?.name || 'Local Theatre';
    const venue = show?.screens?.name || 'Main Hall';
    
    const div = document.createElement('div');
    div.className = 'booking-card';
    
    const date = new Date(show?.start_time);
    const formattedDate = date.toLocaleDateString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });

    const price = booking.seats?.price || 0;
    const totalWithTax = (price * 1.18).toFixed(2);

    const posterUrl = isEvent 
        ? show?.events?.poster_url 
        : show?.movies?.poster_url;

    const ticketParam = booking.ticket_token ? `t=${booking.ticket_token}` : `id=${booking.id}`;

    const escapedTitle = JayShow.escapeHtml(title || 'Unknown Title');
    const escapedTheatre = JayShow.escapeHtml(theatre);
    const escapedVenue = JayShow.escapeHtml(venue);
    const escapedRow = JayShow.escapeHtml(booking.seats?.row || '');
    const escapedCol = JayShow.escapeHtml(booking.seats?.col || '');
    const escapedPosterUrl = JayShow.escapeHtml(posterUrl || '');

    div.innerHTML = `
        <div class="booking-poster">
            ${escapedPosterUrl 
            ? `<img src="${escapedPosterUrl}" alt="${escapedTitle}" 
                style="width:100%;height:100%;object-fit:cover;border-radius:8px"
                loading="lazy"
                onerror="this.style.display='none'">`
            : `<div style="width:100%;height:100%;background:var(--gradient-primary);
                border-radius:8px;display:flex;align-items:center;
                justify-content:center;font-size:1.5rem;">🎬</div>`
            }
        </div>
        <div class="booking-info">
            <span class="booking-status">Confirmed</span>
            <h3>${escapedTitle}</h3>
            <div class="booking-meta">
                <span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
                    ${escapedTheatre} • ${escapedVenue}
                </span>
                <span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="18" height="18" x="3" y="4" rx="2" ry="2"/><line x1="16" x2="16" y1="2" y2="6"/><line x1="8" x2="8" y1="2" y2="6"/><line x1="3" x2="21" y1="10" y2="10"/></svg>
                    ${formattedDate}
                </span>
                <span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 20H2M7 20v-5a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v5M9 20v-8a3 3 0 0 1 3-3 3 3 0 0 1 3 3v8"/></svg>
                    Seat: ${escapedRow}${escapedCol}
                </span>
            </div>
        </div>
        <div class="booking-price">
            <span class="price-amount">₹${totalWithTax}</span>
            <a href="ticket.html?${ticketParam}" class="btn btn-primary btn-sm" style="margin-top: 0.5rem; font-size: 0.7rem; padding: 4px 8px;">View Detail</a>
        </div>
    `;
    
    return div;
}
