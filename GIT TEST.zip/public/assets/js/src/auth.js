/**
 * auth.js
 * ============================================
 * Authentication & Session Management
 * ============================================
 */

/**
 * Gets the currently authenticated user.
 * 
 * @returns {Promise<Object|null>} User object or null if not authenticated
 */
async function getUser() {
    const client = getSupabaseClient();
    if (!client) return null;

    const { data: { user }, error } = await client.auth.getUser();
    if (error) {
        if (error.message?.toLowerCase().includes('auth session missing')) {
            return null;
        }
        console.error('Error getting user:', error.message);
        return null;
    }
    return user;
}

/**
 * Signs in a user with email and password.
 * 
 * @param {string} email - User's email address
 * @param {string} password - User's password
 * @returns {Promise<Object>} Object containing user data or error
 */
async function signIn(email, password) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const { data, error } = await client.auth.signInWithPassword({
        email,
        password
    });

    if (error) {
        console.error('Sign in error:', error.message);
        return { data: null, error };
    }

    return { data, error: null };
}

/**
 * Signs up a new user with email and password.
 * 
 * @param {string} email - User's email address
 * @param {string} password - User's password
 * @returns {Promise<Object>} Object containing user data or error
 */
async function signUp(email, password) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const { data, error } = await client.auth.signUp({
        email,
        password
    });

    if (error) {
        console.error('Sign up error:', error.message);
        return { data: null, error };
    }

    return { data, error: null };
}

/**
 * Signs out the current user.
 * 
 * @returns {Promise<Object>} Object containing error if any
 */
async function signOut() {
    const client = getSupabaseClient();
    if (!client) return { error: { message: 'Client not initialized' } };

    const { error } = await client.auth.signOut();

    if (error) {
        console.error('Sign out error:', error.message);
        return { error };
    }

    return { error: null };
}

/**
 * Listens for authentication state changes.
 * 
 * @param {Function} callback - Function to call on auth state change
 * @returns {Object} Subscription object with unsubscribe method
 */
function onAuthStateChange(callback) {
    const client = getSupabaseClient();
    if (!client) return { data: { subscription: { unsubscribe: () => { } } } };

    return client.auth.onAuthStateChange((event, session) => {
        callback(event, session);
    });
}

/**
 * Checks if a user is a theater owner.
 * 
 * @param {string} userId - User ID to check (optional, defaults to current user)
 * @returns {Promise<boolean>} True if user is a theater owner
 */
async function isTheaterOwner(userId = null) {
    const client = getSupabaseClient();
    if (!client) return false;

    if (!userId) {
        const user = await getUser();
        if (!user) return false;
        userId = user.id;
    }

    // Try RPC function first
    const { data, error } = await client.rpc('is_theater_owner', { p_user_id: userId });

    if (!error && data !== null) {
        return data === true;
    }

    // Fallback: check table directly
    const { data: owners, error: ownerError } = await client
        .from('theater_owners')
        .select('id')
        .eq('user_id', userId)
        .limit(1);

    return !ownerError && owners && owners.length > 0;
}

/**
 * Gets the role of the current user (admin, theater owner, or regular user).
 * 
 * @returns {Promise<Object>} Object with is_admin, is_theater_owner, and owned_theatre_count
 */
async function getUserRole() {
    const client = getSupabaseClient();
    if (!client) return { is_admin: false, is_theater_owner: false, owned_theatre_count: 0 };

    const user = await getUser();
    if (!user) return { is_admin: false, is_theater_owner: false, owned_theatre_count: 0 };

    // Check admin status from metadata
    const isAdmin = user.app_metadata?.is_admin === true;

    // Check theater owner status
    const { data: owners } = await client
        .from('theater_owners')
        .select('id')
        .eq('user_id', user.id);

    return {
        is_admin: isAdmin,
        is_theater_owner: owners && owners.length > 0,
        owned_theatre_count: owners?.length || 0
    };
}

/**
 * Fetches theatres owned by a user.
 * 
 * @param {string} userId - User ID (optional, defaults to current user)
 * @returns {Promise<Object>} Object containing theatres array or error
 */
async function fetchOwnedTheatres(userId = null) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    if (!userId) {
        const user = await getUser();
        if (!user) return { data: null, error: { message: 'Not authenticated' } };
        userId = user.id;
    }

    // Try RPC function first
    const { data, error } = await client.rpc('get_owned_theatres', { p_user_id: userId });

    if (!error) {
        return { data, error: null };
    }

    // Fallback: manual query
    const { data: owners, error: ownerError } = await client
        .from('theater_owners')
        .select(`
            role,
            theatres (
                id,
                name,
                location,
                screens (id)
            )
        `)
        .eq('user_id', userId);

    if (ownerError) {
        return { data: null, error: ownerError };
    }

    const theatres = owners?.map(o => ({
        theatre_id: o.theatres.id,
        theatre_name: o.theatres.name,
        location: o.theatres.location,
        role: o.role,
        screen_count: o.theatres.screens?.length || 0
    })) || [];

    return { data: theatres, error: null };
}

/**
 * Updates navbar user details and manages visibility of auth controls dynamically.
 */
async function updateNavbar() {
    const navbarUser = document.getElementById('navbar-user');
    const loginLink = document.getElementById('login-link');
    const logoutBtn = document.getElementById('logout-btn');
    const adminLink = document.getElementById('admin-link');
    const ownerLink = document.getElementById('owner-link');
    const profileLink = document.getElementById('profile-link');

    if (!navbarUser) return;

    const user = await getUser();

    if (user) {
        // User is logged in
        if (loginLink) loginLink.classList.add('hidden');
        if (logoutBtn) logoutBtn.classList.remove('hidden');
        if (profileLink) profileLink.classList.remove('hidden');

        // Show user email
        const emailSpan = navbarUser.querySelector('.user-email');
        if (emailSpan) {
            emailSpan.textContent = user.email;
            emailSpan.classList.remove('hidden');
        }

        // Show admin link if user is admin
        if (adminLink && user.app_metadata?.is_admin === true) {
            adminLink.classList.remove('hidden');
        }

        // Show owner link if user is a theater owner
        if (ownerLink) {
            try {
                const isOwner = await isTheaterOwner();
                if (isOwner) {
                    ownerLink.classList.remove('hidden');
                }
            } catch (error) {
                console.error('Error checking owner status:', error);
            }
        }

        // Attach logout handler
        if (logoutBtn && !logoutBtn.dataset.hasHandler) {
            logoutBtn.addEventListener('click', async () => {
                const { error } = await signOut();
                if (!error) window.location.reload();
            });
            logoutBtn.dataset.hasHandler = 'true';
        }

        // Mobile Profile Link
        const mobileProfileLink = document.getElementById('mobile-profile-link');
        if (mobileProfileLink) {
            mobileProfileLink.href = 'profile.html';
            const label = mobileProfileLink.querySelector('span:not(.nav-icon)') || mobileProfileLink;
            if (label && label.lastChild && label.lastChild.nodeType === Node.TEXT_NODE) {
                label.lastChild.textContent = ' Profile';
            }
        }
    } else {
        // User is not logged in
        if (loginLink) loginLink.classList.remove('hidden');
        if (logoutBtn) logoutBtn.classList.add('hidden');
        if (adminLink) adminLink.classList.add('hidden');
        if (ownerLink) ownerLink.classList.add('hidden');
        if (profileLink) profileLink.classList.add('hidden');

        const emailSpan = navbarUser.querySelector('.user-email');
        if (emailSpan) {
            emailSpan.classList.add('hidden');
            emailSpan.textContent = '';
        }

        // Mobile Profile Link
        const mobileProfileLink = document.getElementById('mobile-profile-link');
        if (mobileProfileLink) {
            mobileProfileLink.href = 'login.html';
            const label = mobileProfileLink.querySelector('span:not(.nav-icon)') || mobileProfileLink;
            if (label && label.lastChild && label.lastChild.nodeType === Node.TEXT_NODE) {
                label.lastChild.textContent = ' Profile';
            }
        }
    }

    // Highlight active mobile nav tab
    if (typeof updateMobileNavActiveState === 'function') {
        updateMobileNavActiveState();
    }
}
