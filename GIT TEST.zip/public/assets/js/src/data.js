/**
 * data.js
 * ============================================
 * Database Queries & Data Fetching Helpers
 * ============================================
 */

/**
 * Fetches the custom seat layout for a screen.
 * 
 * @param {string} screenId - ID of the screen
 * @returns {Promise<Object>} Object containing layout data or error
 */
async function fetchScreenLayout(screenId) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const { data: screen, error: screenError } = await client
        .from('screens')
        .select('seat_layout')
        .eq('id', screenId)
        .single();

    if (!screenError && screen?.seat_layout) {
        return { data: screen.seat_layout, error: null, source: 'screens.seat_layout' };
    }

    const { data, error } = await client.rpc('get_screen_layout', { p_screen_id: screenId });
    if (!error && data) {
        return { data, error: null, source: 'get_screen_layout' };
    }

    return {
        data: generateDefaultScreenLayout(10, 12),
        error: screenError || error || null,
        source: 'generated-default'
    };
}

function generateDefaultScreenLayout(rowCount, seatsPerRow) {
    const rows = [];
    for (let i = 0; i < rowCount; i++) {
        const label = String.fromCharCode(65 + i);
        const seats = [];

        for (let j = 1; j <= seatsPerRow; j++) {
            let type = 'regular';
            let price = 200;

            if (i >= rowCount - 2 && rowCount > 4) {
                type = 'vip';
                price = 500;
            } else if (i >= 2) {
                type = 'premium';
                price = 300;
            }

            seats.push({ id: j, type, price });
        }

        rows.push({ label, seats });
    }

    return {
        rows,
        metadata: {
            totalSeats: rowCount * seatsPerRow,
            rowCount,
            maxSeatsPerRow: seatsPerRow
        }
    };
}

/**
 * Fetches all movies.
 * 
 * @returns {Promise<Object>} Object containing movies array or error
 */
async function fetchMovies() {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const theaterId = typeof JayShow.getCurrentTheaterId === 'function' ? JayShow.getCurrentTheaterId() : null;
    
    if (theaterId) {
        // Query the shows scheduled at this specific theater
        const { data: shows, error: showsError } = await client
            .from('shows')
            .select(`
                movie_id,
                screens!inner (
                    theatre_id
                )
            `)
            .eq('screens.theatre_id', theaterId);

        if (showsError) {
            console.error('Error fetching shows for theater filtering:', showsError.message);
            return { data: null, error: showsError };
        }

        if (!shows || shows.length === 0) {
            return { data: [], error: null };
        }

        // Get unique movie IDs from the shows
        const allowedMovieIds = Array.from(new Set(shows.map(s => s.movie_id).filter(id => !!id)));

        if (allowedMovieIds.length === 0) {
            return { data: [], error: null };
        }

        // Fetch movies that are scheduled at this theater
        const { data, error } = await client
            .from('movies')
            .select('*')
            .in('id', allowedMovieIds)
            .order('created_at', { ascending: false });

        return { data, error };
    } else {
        // No theater ID, return all movies (for Quick My Ticket platform)
        const { data, error } = await client
            .from('movies')
            .select('*')
            .order('created_at', { ascending: false });

        return { data, error };
    }
}

/**
 * Fetches a single movie by ID.
 * 
 * @param {string} movieId - ID of the movie
 * @returns {Promise<Object>} Object containing movie data or error
 */
async function fetchMovie(movieId) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const { data, error } = await client
        .from('movies')
        .select('*')
        .eq('id', movieId)
        .single();

    return { data, error };
}

/**
 * Fetches all events.
 * 
 * @returns {Promise<Object>} Object containing events array or error
 */
async function fetchEvents() {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const theaterId = typeof JayShow.getCurrentTheaterId === 'function' ? JayShow.getCurrentTheaterId() : null;

    if (theaterId) {
        // Fetch only upcoming event shows for this theater
        const { data: eventShows, error: showsError } = await client
            .from('event_shows')
            .select(`
                event_id,
                screens!inner (
                    theatre_id
                )
            `)
            .eq('screens.theatre_id', theaterId);

        if (showsError) {
            console.error('Error fetching event shows for filtering:', showsError.message);
            return { data: null, error: showsError };
        }

        if (!eventShows || eventShows.length === 0) {
            return { data: [], error: null };
        }

        const allowedEventIds = Array.from(new Set(eventShows.map(es => es.event_id).filter(id => !!id)));

        if (allowedEventIds.length === 0) {
            return { data: [], error: null };
        }

        const { data, error } = await client
            .from('events')
            .select('*')
            .eq('status', 'upcoming')
            .in('id', allowedEventIds)
            .order('created_at', { ascending: false });

        return { data, error };
    } else {
        const { data, error } = await client
            .from('events')
            .select('*')
            .eq('status', 'upcoming')
            .order('created_at', { ascending: false });

        return { data, error };
    }
}

/**
 * Fetches a single event by ID.
 * 
 * @param {string} eventId - ID of the event
 * @returns {Promise<Object>} Object containing event data or error
 */
async function fetchEvent(eventId) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const { data, error } = await client
        .from('events')
        .select('*')
        .eq('id', eventId)
        .single();

    return { data, error };
}

/**
 * Fetches shows for an event with screen and venue details.
 * Restricts shows to the current theater on white-label domains.
 * 
 * @param {string} eventId - ID of the event
 * @returns {Promise<Object>} Object containing event shows array or error
 */
async function fetchEventShows(eventId) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const theaterId = typeof JayShow.getCurrentTheaterId === 'function' ? JayShow.getCurrentTheaterId() : null;

    let query;
    if (theaterId) {
        query = client
            .from('event_shows')
            .select(`
                *,
                screens!inner (
                    id,
                    name,
                    seat_layout,
                    theatres (
                        id,
                        name,
                        location
                    )
                )
            `)
            .eq('event_id', eventId)
            .eq('screens.theatre_id', theaterId);
    } else {
        query = client
            .from('event_shows')
            .select(`
                *,
                screens (
                    id,
                    name,
                    seat_layout,
                    theatres (
                        id,
                        name,
                        location
                    )
                )
            `)
            .eq('event_id', eventId);
    }

    const { data, error } = await query.order('start_time', { ascending: true });

    return { data, error };
}

/**
 * Fetches a single event show by ID.
 * Validates theater ownership on white-label domains.
 * 
 * @param {string} eventShowId - ID of the event show
 * @returns {Promise<Object>} Object containing event show data or error
 */
async function fetchEventShow(eventShowId) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const theaterId = typeof JayShow.getCurrentTheaterId === 'function' ? JayShow.getCurrentTheaterId() : null;

    let query;
    if (theaterId) {
        query = client
            .from('event_shows')
            .select(`
                *,
                events (*),
                screens!inner (
                    id,
                    name,
                    seat_layout,
                    theatres!inner (*)
                )
            `)
            .eq('id', eventShowId)
            .eq('screens.theatre_id', theaterId);
    } else {
        query = client
            .from('event_shows')
            .select(`
                *,
                events (*),
                screens (
                    id,
                    name,
                    seat_layout,
                    theatres (*)
                )
            `)
            .eq('id', eventShowId);
    }

    const { data, error } = await query.single();

    if (!error && data && theaterId) {
        const showTheatreId = data.screens?.theatre_id || data.screens?.theatres?.id;
        if (showTheatreId !== theaterId) {
            console.error('🚫 Security Isolation: Event show does not belong to this theater.');
            return { data: null, error: { message: 'Access Denied: This show is not available for this theater.' } };
        }
    }

    return { data, error };
}

/**
 * Fetches shows for a movie with screen and theatre details.
 * Restricts shows to the current theater on white-label domains.
 * 
 * @param {string} movieId - ID of the movie
 * @returns {Promise<Object>} Object containing shows array or error
 */
async function fetchShowsForMovie(movieId) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const theaterId = typeof JayShow.getCurrentTheaterId === 'function' ? JayShow.getCurrentTheaterId() : null;

    let query;
    if (theaterId) {
        query = client
            .from('shows')
            .select(`
                *,
                screens!inner (
                    id,
                    name,
                    seat_layout,
                    theatres (
                        id,
                        name,
                        location
                    )
                )
            `)
            .eq('movie_id', movieId)
            .eq('screens.theatre_id', theaterId);
    } else {
        query = client
            .from('shows')
            .select(`
                *,
                screens (
                    id,
                    name,
                    seat_layout,
                    theatres (
                        id,
                        name,
                        location
                    )
                )
            `)
            .eq('movie_id', movieId);
    }

    const { data, error } = await query.order('start_time', { ascending: true });

    return { data, error };
}

/**
 * Fetches a single show with all related details.
 * Validates theater ownership on white-label domains.
 * 
 * @param {string} showId - ID of the show
 * @returns {Promise<Object>} Object containing show data or error
 */
async function fetchShow(showId) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const theaterId = typeof JayShow.getCurrentTheaterId === 'function' ? JayShow.getCurrentTheaterId() : null;

    let query;
    if (theaterId) {
        query = client
            .from('shows')
            .select(`
                *,
                movies (*),
                screens!inner (
                    id,
                    name,
                    seat_layout,
                    theatres!inner (*)
                )
            `)
            .eq('id', showId)
            .eq('screens.theatre_id', theaterId);
    } else {
        query = client
            .from('shows')
            .select(`
                *,
                movies (*),
                screens (
                    id,
                    name,
                    seat_layout,
                    theatres (*)
                )
            `)
            .eq('id', showId);
    }

    const { data, error } = await query.single();

    if (!error && data && theaterId) {
        const showTheatreId = data.screens?.theatre_id || data.screens?.theatres?.id;
        if (showTheatreId !== theaterId) {
            console.error('🚫 Security Isolation: Show does not belong to this theater.');
            return { data: null, error: { message: 'Access Denied: This show is not available for this theater.' } };
        }
    }

    return { data, error };
}
