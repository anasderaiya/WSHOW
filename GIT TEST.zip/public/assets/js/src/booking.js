/**
 * booking.js
 * ============================================
 * Seat Locking, Heartbeats, Realtime, & Bookings
 * ============================================
 */

/**
 * Gets or creates a guest session ID for unauthenticated users.
 * 
 * @returns {string} Session ID
 */
function getGuestSessionId() {
    let sessionId = null;
    try {
        sessionId = sessionStorage.getItem('qmyticket_guest_session_id');
    } catch (e) {
        console.warn('⚠️ Accessing sessionStorage is blocked or unavailable:', e.message);
    }
    
    if (!sessionId) {
        // Generate a cryptographically secure UUID.
        if (typeof crypto.randomUUID === 'function') {
            sessionId = crypto.randomUUID();
        } else {
            // Fallback: crypto.getRandomValues-based UUID v4
            const bytes = new Uint8Array(16);
            crypto.getRandomValues(bytes);
            bytes[6] = (bytes[6] & 0x0f) | 0x40; // version 4
            bytes[8] = (bytes[8] & 0x3f) | 0x80; // variant 1
            const hex = Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
            sessionId = `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20)}`;
        }
        try {
            sessionStorage.setItem('qmyticket_guest_session_id', sessionId);
        } catch (e) {
            console.warn('⚠️ Could not save guest session ID in sessionStorage:', e.message);
        }
    }
    return sessionId;
}

/**
 * Locks a seat using atomic database function.
 * Uses row-level locking to prevent race conditions.
 * 
 * @param {string} showId - ID of the show
 * @param {string} seatId - ID of the seat to lock
 * @returns {Promise<Object>} Object containing booking data or error
 */
async function lockSeat(showId, seatId) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const user = await getUser();
    const userId = user ? user.id : null;
    const sessionId = user ? null : getGuestSessionId();
    // Use atomic RPC function for race-condition-safe locking
    const { data, error } = await client.rpc('lock_seat', {
        p_show_id: showId,
        p_seat_id: seatId,
        p_user_id: userId,
        p_session_id: sessionId
    });

    if (error) {
        console.error('Error locking seat:', error.message);
        return { data: null, error };
    }

    // RPC returns array with single result
    const result = data?.[0];

    if (!result || !result.success) {
        return {
            data: null,
            error: { message: result?.message || 'Failed to lock seat' }
        };
    }

    return {
        data: { id: result.booking_id, message: result.message },
        error: null
    };
}

/**
 * Unlocks a booking (sets status to 'cancelled').
 * Uses atomic database function to ensure proper authorization.
 * 
 * @param {string} bookingId - ID of the booking to unlock
 * @returns {Promise<Object>} Object containing result or error
 */
async function unlockBooking(bookingId) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const user = await getUser();
    const userId = user ? user.id : null;
    const sessionId = user ? null : getGuestSessionId();
    
    // Use atomic RPC function for safe unlocking
    const { data, error } = await client.rpc('unlock_seat', {
        p_booking_id: bookingId,
        p_user_id: userId,
        p_session_id: sessionId
    });

    if (error) {
        console.error('Error unlocking booking:', error.message);
        return { data: null, error };
    }

    const result = data?.[0];

    if (!result || !result.success) {
        return {
            data: null,
            error: { message: result?.message || 'Failed to unlock seat' }
        };
    }

    return { data: { success: true, message: result.message }, error: null };
}

/**
 * Fetches the current state of all seats for a show.
 * Uses the optimized seat_availability view for better performance.
 * Falls back to manual query if view doesn't exist.
 * 
 * @param {string} showId - ID of the show
 * @returns {Promise<Object>} Object containing seat states or error
 */
async function fetchSeatStates(showId) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    // Get current user to identify their own bookings
    const user = await getUser();

    const { data: showScreen, error: showScreenError } = await client
        .from('shows')
        .select('screen_id')
        .eq('id', showId)
        .single();

    if (showScreenError) {
        console.error('Error fetching show screen:', showScreenError.message);
        return { data: null, error: showScreenError };
    }

    // Try using the optimized view first
    const { data: viewData, error: viewError } = await client
        .from('seat_availability')
        .select('*')
        .eq('show_id', showId)
        .eq('screen_id', showScreen.screen_id)
        .order('row')
        .order('col');

    if (!viewError && viewData) {
        // View exists and worked - map to expected format
        const seatStates = viewData.map(seat => {
            let state = seat.availability_status || 'available';

            // Mark user's own locked seats as 'selected'
            const isUserLocked = user && seat.locked_by === user.id;
            const isGuestLocked = !user && seat.locked_by_session === getGuestSessionId();
            
            if (state === 'locked' && (isUserLocked || isGuestLocked)) {
                state = 'selected';
            }

            return {
                id: seat.seat_id,
                screen_id: seat.screen_id,
                row: seat.row,
                col: seat.col,
                tier: seat.tier,
                price: seat.effective_price,
                state,
                booking: seat.booking_id ? {
                    id: seat.booking_id,
                    user_id: seat.locked_by,
                    locked_at: seat.locked_at
                } : null
            };
        });

        return { data: seatStates, error: null };
    }

    // Fallback to manual query (view might not exist)
    if (typeof debugLog === 'function') {
        debugLog('Falling back to manual seat query (view not available)');
    }

    // Get all seats for this screen
    const { data: seats, error: seatsError } = await client
        .from('seats')
        .select('*')
        .eq('screen_id', showScreen.screen_id)
        .order('row')
        .order('col');

    if (seatsError) {
        console.error('Error fetching seats:', seatsError.message);
        return { data: null, error: seatsError };
    }

    // Get all active bookings for this show
    const { data: bookings, error: bookingsError } = await client
        .from('bookings')
        .select('id, seat_id, status, user_id, locked_at')
        .eq('show_id', showId)
        .in('status', ['locked', 'confirmed', 'offline']);

    if (bookingsError) {
        console.error('Error fetching bookings:', bookingsError.message);
        return { data: null, error: bookingsError };
    }

    // Merge seat data with booking status
    // Filter out expired locks (older than 5 minutes)
    const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();
    const bookingMap = {};
    bookings.forEach(b => {
        // Include confirmed bookings, offline bookings, and non-expired locked bookings
        if (b.status === 'confirmed' ||
            b.status === 'offline' ||
            (b.status === 'locked' && b.locked_at && b.locked_at >= fiveMinutesAgo)) {
            bookingMap[b.seat_id] = b;
        }
    });

    const seatStates = seats.map(seat => {
        const booking = bookingMap[seat.id];
        let state = 'available';

        if (booking) {
            if (booking.status === 'confirmed') {
                state = 'booked';
            } else if (booking.status === 'offline') {
                state = 'offline';
            } else if (booking.status === 'locked') {
                // Check if it's the current user's lock
                state = (user && booking.user_id === user.id) ? 'selected' : 'locked';
            }
        }

        return {
            ...seat,
            state,
            booking: booking || null
        };
    });

    return { data: seatStates, error: null };
}

/**
 * Subscribes to real-time booking updates for a show.
 * Calls the callback whenever a booking is created, updated, or deleted.
 * 
 * @param {string} showId - ID of the show to subscribe to
 * @param {Function} callback - Function to call on booking changes
 * @returns {Object} Subscription object with unsubscribe method
 */
function subscribeBookings(showId, callback) {
    const client = getSupabaseClient();
    if (!client) {
        console.error('Client not initialized for realtime subscription');
        return { unsubscribe: () => { } };
    }

    const channel = client
        .channel(`bookings-${showId}`)
        .on(
            'postgres_changes',
            {
                event: '*',
                schema: 'public',
                table: 'bookings',
                filter: `show_id=eq.${showId}`
            },
            (payload) => {
                callback(payload);
            }
        )
        .subscribe();

    return {
        unsubscribe: () => {
            client.removeChannel(channel);
        }
    };
}

/**
 * Locks a seat for an event show.
 * Uses atomic database function to prevent race conditions.
 * 
 * @param {string} eventShowId - ID of the event show
 * @param {string} seatId - ID of the seat to lock
 * @returns {Promise<Object>} Object containing booking data or error
 */
async function lockEventSeat(eventShowId, seatId) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const user = await getUser();
    const userId = user ? user.id : null;
    const sessionId = user ? null : getGuestSessionId();

    const { data, error } = await client.rpc('lock_event_seat', {
        p_event_show_id: eventShowId,
        p_seat_id: seatId,
        p_user_id: userId,
        p_session_id: sessionId
    });

    if (error) {
        console.error('Error locking event seat:', error.message);
        return { data: null, error };
    }

    const result = data?.[0];

    if (!result || !result.success) {
        return {
            data: null,
            error: { message: result?.message || 'Failed to lock seat' }
        };
    }

    return {
        data: { id: result.booking_id, message: result.message },
        error: null
    };
}

/**
 * Fetches seat states for an event show.
 * 
 * @param {string} eventShowId - ID of the event show
 * @returns {Promise<Object>} Object containing seat states or error
 */
async function fetchEventSeatStates(eventShowId) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const user = await getUser();

    const { data: eventShowScreen, error: eventShowScreenError } = await client
        .from('event_shows')
        .select('screen_id')
        .eq('id', eventShowId)
        .single();

    if (eventShowScreenError) {
        console.error('Error fetching event show screen:', eventShowScreenError.message);
        return { data: null, error: eventShowScreenError };
    }

    const { data: viewData, error: viewError } = await client
        .from('event_seat_availability')
        .select('*')
        .eq('event_show_id', eventShowId)
        .eq('screen_id', eventShowScreen.screen_id)
        .order('row')
        .order('col');

    if (!viewError && viewData) {
        const seatStates = viewData.map(seat => {
            let state = seat.availability_status || 'available';

            const isUserLocked = user && seat.locked_by === user.id;
            const isGuestLocked = !user && seat.locked_by_session === getGuestSessionId();
            
            if (state === 'locked' && (isUserLocked || isGuestLocked)) {
                state = 'selected';
            }

            return {
                id: seat.seat_id,
                screen_id: seat.screen_id,
                row: seat.row,
                col: seat.col,
                tier: seat.tier,
                price: seat.effective_price,
                state,
                booking: seat.booking_id ? {
                    id: seat.booking_id,
                    user_id: seat.locked_by,
                    locked_at: seat.locked_at
                } : null
            };
        });

        return { data: seatStates, error: null };
    }

    return { data: null, error: viewError };
}

/**
 * Subscribes to real-time booking updates for an event show.
 * Calls the callback whenever a booking is created, updated, or deleted.
 * 
 * @param {string} eventShowId - ID of the event show to subscribe to
 * @param {Function} callback - Function to call on booking changes
 * @returns {Object} Subscription object with unsubscribe method
 */
function subscribeEventBookings(eventShowId, callback) {
    const client = getSupabaseClient();
    if (!client) {
        console.error('Client not initialized for realtime subscription');
        return { unsubscribe: () => { } };
    }

    const channel = client
        .channel(`events-bookings-${eventShowId}`)
        .on(
            'postgres_changes',
            {
                event: '*',
                schema: 'public',
                table: 'bookings',
                filter: `event_show_id=eq.${eventShowId}`
            },
            (payload) => {
                callback(payload);
            }
        )
        .subscribe();

    return {
        unsubscribe: () => {
            client.removeChannel(channel);
        }
    };
}

/**
 * Fetches user's bookings.
 * 
 * @param {string} userId - ID of the user (optional, defaults to current user)
 * @returns {Promise<Object>} Object containing bookings array or error
 */
async function fetchUserBookings(userId = null) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    if (!userId) {
        const user = await getUser();
        if (!user) return { data: null, error: { message: 'Not authenticated' } };
        userId = user.id;
    }

    const { data, error } = await client
        .from('bookings')
        .select(`
            *,
            seats (*),
            shows (
                *,
                movies (*),
                screens (
                    *,
                    theatres (*)
                )
            )
        `)
        .eq('user_id', userId)
        .eq('status', 'confirmed')
        .order('created_at', { ascending: false });

    return { data, error };
}

/**
 * Cleans up the current user's expired seat locks.
 * Call this when loading the seat selection page to release any stuck locks.
 * 
 * @param {number} timeoutMinutes - Lock timeout in minutes (default 5)
 * @returns {Promise<Object>} Object containing cleaned_count or error
 */
async function cleanupExpiredLocks(timeoutMinutes = 5) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const { data, error } = await client.rpc('cleanup_my_expired_locks', {
        p_timeout_minutes: timeoutMinutes
    });

    if (error) {
        console.warn('Could not cleanup expired locks:', error.message);
        return { data: null, error };
    }

    const result = data?.[0] || { cleaned_count: 0 };
    if (result.cleaned_count > 0 && typeof debugLog === 'function') {
        debugLog(`Cleaned up ${result.cleaned_count} expired locks`);
    }

    return { data: result, error: null };
}

/**
 * Force releases ALL expired seat locks (emergency use).
 * Use this if seats are stuck and not releasing properly.
 * 
 * @param {number} timeoutMinutes - Lock timeout in minutes (default 5)
 * @returns {Promise<Object>} Object containing released_count and released_ids or error
 */
async function forceReleaseAllLocks(timeoutMinutes = 5) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    const { data, error } = await client.rpc('force_release_all_expired_locks', {
        p_timeout_minutes: timeoutMinutes
    });

    if (error) {
        console.error('Could not force release locks:', error.message);
        return { data: null, error };
    }

    const result = data?.[0] || { released_count: 0, released_ids: [] };
    if (typeof debugLog === 'function') {
        debugLog(`Force released ${result.released_count} locks`);
    }

    return { data: result, error: null };
}

/**
 * Extends the lock duration for active bookings.
 * Called periodically (heartbeat) to keep locks alive while user is on page.
 * 
 * @param {string[]} bookingIds - Array of booking IDs to extend
 * @returns {Promise<Object>} Object containing extended_count or error
 */
async function extendLocks(bookingIds) {
    const client = getSupabaseClient();
    if (!client) return { data: null, error: { message: 'Client not initialized' } };

    if (!bookingIds || bookingIds.length === 0) {
        return { data: { extended_count: 0 }, error: null };
    }

    const user = await getUser();
    const userId = user ? user.id : null;
    const sessionId = user ? null : getGuestSessionId();

    const { data, error } = await client.rpc('extend_locks', {
        p_booking_ids: bookingIds,
        p_user_id: userId,
        p_session_id: sessionId
    });

    if (error) {
        console.warn('Could not extend locks:', error.message);
        return { data: null, error };
    }

    const result = data?.[0] || { extended_count: 0, success: false };
    if (result.extended_count > 0 && typeof debugLog === 'function') {
        debugLog(`♻️ Extended ${result.extended_count} lock(s)`);
    }

    return { data: result, error: null };
}
