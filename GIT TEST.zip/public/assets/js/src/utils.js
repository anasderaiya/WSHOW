/**
 * utils.js
 * ============================================
 * Configuration and Shared Utilities
 * ============================================
 */

const SUPABASE_URL = document.querySelector('meta[name="supabase-url"]')?.getAttribute('content') || 'YOUR_SUPABASE_URL';
const SUPABASE_ANON_KEY = document.querySelector('meta[name="supabase-anon-key"]')?.getAttribute('content') || 'YOUR_SUPABASE_ANON_KEY';

window.JayShow = window.JayShow || {};

/**
 * Resolves and returns the current active theater ID for multi-tenant isolation.
 * Looks in URL search params, URL hash, config settings, and session storage fallback.
 * 
 * @returns {string|null} Resolved theater UUID, or null if on main QuickMyTicket platform
 */
JayShow.getCurrentTheaterId = function() {
    try {
        const urlParams = new URLSearchParams(window.location.search);
        const hashParams = new URLSearchParams(window.location.hash.substring(1));
        let theaterId = urlParams.get('theater') || hashParams.get('theater') || window.QMT_CONFIG?.THEATER_ID;
        
        // Store preview ID in session so navigation keeps the branding
        if (urlParams.get('theater') || hashParams.get('theater')) {
            const val = urlParams.get('theater') || hashParams.get('theater');
            sessionStorage.setItem('preview_theater_id', val);
        } else if (sessionStorage.getItem('preview_theater_id') && (!theaterId || theaterId === '%%THEATER_ID%%')) {
            theaterId = sessionStorage.getItem('preview_theater_id');
        }

        if (theaterId && theaterId !== '%%THEATER_ID%%') {
            return theaterId;
        }
    } catch (e) {
        console.warn('⚠️ Error resolving current theater ID:', e.message);
    }
    return null;
};

let supabaseClient = null;

/**
 * Creates and returns the Supabase client instance.
 * Uses a singleton pattern to avoid multiple client instances.
 * 
 * @returns {Object} Supabase client instance
 */
function getSupabaseClient() {
    if (!supabaseClient) {
        // Check if supabase-js is loaded via CDN
        if (typeof supabase === 'undefined' || typeof supabase.createClient !== 'function') {
            console.error('Supabase JS library not loaded. Make sure to include the CDN script.');
            return null;
        }
        supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    }
    return supabaseClient;
}

/**
 * Escapes HTML entities to prevent XSS in template literals.
 * Centralised here so every page can use JayShow.escapeHtml()
 * instead of duplicating the function.
 *
 * @param {string} text - Text to escape
 * @returns {string} Escaped text
 */
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

/**
 * Sanitizes an HTML string using DOMPurify if loaded, or strips scripts as a fallback.
 * Allows safe rendering of trusted markup with dynamic content.
 *
 * @param {string} html - HTML string to sanitize
 * @returns {string} Sanitized HTML string
 */
function sanitize(html) {
    if (!html) return '';
    if (window.DOMPurify) {
        return window.DOMPurify.sanitize(html);
    }
    // Fallback: DOM-based sanitizer when DOMPurify CDN is slow/down.
    // Parses the HTML in an inert document, strips dangerous elements
    // and attributes (scripts, event handlers, javascript: URIs).
    console.warn('[JayShow] DOMPurify not loaded yet, using fallback DOM sanitizer');
    try {
        const doc = new DOMParser().parseFromString(html, 'text/html');
        // Remove dangerous elements
        const dangerous = doc.querySelectorAll('script, iframe, object, embed, form, link[rel="import"]');
        dangerous.forEach(el => el.remove());
        // Remove dangerous attributes from all elements
        doc.querySelectorAll('*').forEach(el => {
            for (const attr of [...el.attributes]) {
                const name = attr.name.toLowerCase();
                const value = (attr.value || '').toLowerCase().trim();
                if (name.startsWith('on') || value.startsWith('javascript:') || value.startsWith('data:text/html')) {
                    el.removeAttribute(attr.name);
                }
            }
        });
        return doc.body.innerHTML;
    } catch (e) {
        // Last resort: escape everything
        return escapeHtml(html);
    }
}

const DEBUG = false; // set true locally only
function debugLog(...args) { if (DEBUG) console.log(...args); }

function showToast(message, type = 'info', duration = 4000) {
    const existing = document.getElementById('qmt-toast');
    if (existing) existing.remove();
    
    const toast = document.createElement('div');
    toast.id = 'qmt-toast';
    toast.style.cssText = `
        position: fixed;
        bottom: 80px;
        left: 50%;
        transform: translateX(-50%);
        background: ${type === 'error' ? '#ef4444' : 'var(--bg-card)'};
        color: white;
        padding: 12px 24px;
        border-radius: 999px;
        font-size: 0.875rem;
        font-weight: 500;
        z-index: 9999;
        box-shadow: 0 8px 32px rgba(0,0,0,0.4);
        animation: slideUp 0.3s ease;
        max-width: 90vw;
        text-align: center;
    `;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), duration);
}

/**
 * Updates the active class on mobile bottom navigation based on current path
 */
function updateMobileNavActiveState() {
    const mobileNav = document.getElementById('mobile-nav');
    if (!mobileNav) return;

    const links = mobileNav.querySelectorAll('a');
    const currentPath = window.location.pathname;
    const page = currentPath.split('/').pop() || 'index.html';

    links.forEach(link => {
        const href = link.getAttribute('href');
        const isActive = href === page || 
                         (page === 'movie.html' && href === 'index.html') || 
                         (page === 'seats.html' && href === 'index.html') ||
                         (page === 'profile.html' && href === 'profile.html');
        
        if (isActive) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
}
