/**
 * branding.js
 * ============================================
 * White-Label Branding & Theme Loading
 * ============================================
 */

JayShow.loadPlatformSettings = async function() {
    try {
        const client = typeof getSupabaseClient === 'function' ? getSupabaseClient() : null;
        if (!client) {
            console.warn('⚙️ Platform settings: Supabase client is not available yet. Retrying in 100ms...');
            if (!window._loadSettingsRetries) window._loadSettingsRetries = 0;
            if (window._loadSettingsRetries < 50) {
                window._loadSettingsRetries++;
                setTimeout(JayShow.loadPlatformSettings, 100);
            }
            return;
        }
        window._loadSettingsRetries = 0; // Reset retries on success

        const { data, error } = await client
            .from('platform_settings')
            .select('value')
            .eq('key', 'convenience_fee')
            .single();

        if (error) {
            console.warn('⚙️ Platform settings: Error loading convenience fee:', error.message);
            return;
        }

        if (data && data.value) {
            window.platformConvenienceFee = data.value;
            console.log('⚙️ Platform settings: Convenience fee loaded:', data.value.type, data.value.amount);
        } else {
            console.log('⚙️ Platform settings: No convenience fee configured');
        }
    } catch (err) {
        console.error('Error loading platform settings:', err);
    }
};

// Auto-initialize settings on load
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        JayShow.loadPlatformSettings();
    });
} else {
    JayShow.loadPlatformSettings();
}

JayShow.loadBranding = async function() {
    console.log('🎨 loadBranding: Initializing white-label branding check...');
    try {
        const theaterId = JayShow.getCurrentTheaterId();
        console.log('🎨 loadBranding: Final resolved theaterId:', theaterId);

        if (!theaterId) {
            console.log('🎨 loadBranding: No valid theaterId found. Aborting white-label load.');
            return;
        }

        const client = typeof getSupabaseClient === 'function' ? getSupabaseClient() : null;
        if (!client) {
            console.warn('🎨 loadBranding: Supabase client is not available yet. Retrying in 100ms...');
            if (!window._loadBrandingRetries) window._loadBrandingRetries = 0;
            if (window._loadBrandingRetries < 50) {
                window._loadBrandingRetries++;
                setTimeout(JayShow.loadBranding, 100);
            }
            return;
        }
        window._loadBrandingRetries = 0; // Reset retries on success

        console.log('🎨 loadBranding: Querying theater_branding for theater_id:', theaterId);
        const { data: branding, error } = await client
          .from('theater_branding')
          .select('*')
          .eq('theater_id', theaterId)
          .single();

        if (error) {
            console.error('🎨 loadBranding: Database query error:', error);
            return;
        }
        
        if (!branding) {
            console.warn('🎨 loadBranding: No branding configuration returned from DB!');
            return;
        }

        console.log('🎨 loadBranding: Successfully retrieved branding data:', branding);

        // Apply CSS variables to root
        const root = document.documentElement;
        root.style.setProperty('--brand-primary',    branding.primary_color);
        root.style.setProperty('--brand-accent',     branding.accent_color);
        root.style.setProperty('--brand-bg',         branding.background_color);
        root.style.setProperty('--brand-card',       branding.card_color);
        root.style.setProperty('--brand-text',       branding.text_color);

        console.log('🎨 loadBranding: Applied CSS colors to root:', {
            '--brand-primary': branding.primary_color,
            '--brand-accent': branding.accent_color,
            '--brand-bg': branding.background_color,
            '--brand-card': branding.card_color,
            '--brand-text': branding.text_color
        });

        // Apply logo
        const logoEls = document.querySelectorAll('.site-logo, .nav-logo, .navbar-brand img, .brand-logo');
        console.log(`🎨 loadBranding: Found ${logoEls.length} logo elements to update.`);
        if (branding.logo_url) {
          logoEls.forEach((el, idx) => {
            el.src = branding.logo_url;
            el.alt = branding.display_name;
            console.log(`🎨 loadBranding: Updated logo element #${idx}`, el);
          });
        }

        // Apply page title (handle all casing variants)
        if (branding.display_name) {
          const currentTitle = document.title;
          document.title = currentTitle
            .replace(/Quick my Ticket/gi, branding.display_name)
            .replace(/Quick My Ticket/gi, branding.display_name);
          console.log('🎨 loadBranding: Updated document title to:', document.title);

          // Update meta description
          const metaDesc = document.querySelector('meta[name="description"]');
          if (metaDesc) {
            metaDesc.setAttribute('content',
              metaDesc.getAttribute('content')
                .replace(/Quick my Ticket/gi, branding.display_name)
                .replace(/Quick My Ticket/gi, branding.display_name)
            );
          }
        }

        // Apply favicon
        if (branding.favicon_url) {
          let favicon = document.querySelector("link[rel='icon']");
          if (!favicon) {
            favicon = document.createElement('link');
            favicon.rel = 'icon';
            document.head.appendChild(favicon);
          }
          favicon.href = branding.favicon_url;
          console.log('🎨 loadBranding: Applied favicon url:', branding.favicon_url);
        }

        // Show/hide "Powered by" badge
        const poweredBy = document.querySelector('.powered-by-badge');
        if (poweredBy) {
          poweredBy.style.display = branding.show_powered_by ? 'flex' : 'none';
          console.log('🎨 loadBranding: Show powered-by badge:', branding.show_powered_by);
        }

        // ── White-label text replacement across the entire page ──
        if (branding.display_name) {
          const replaceBrand = (text) => text
            .replace(/Quick\s*my\s*Tickets?/gi, branding.display_name)
            .replace(/Quick\s*My\s*Tickets?/gi, branding.display_name);

          // Replace in all footer elements
          document.querySelectorAll('footer, .footer').forEach(footer => {
            footer.querySelectorAll('p, strong, span').forEach(el => {
              el.childNodes.forEach(node => {
                if (node.nodeType === Node.TEXT_NODE) {
                  node.textContent = replaceBrand(node.textContent);
                }
              });
              if (el.tagName === 'P' && (el.innerHTML.includes('©') || el.innerHTML.includes('&copy;'))) {
                el.innerHTML = replaceBrand(el.innerHTML);
              }
            });
          });

          // Replace in FAQ subtitles and other body text
          document.querySelectorAll('.faq-subtitle, .faq p, .section-subtitle').forEach(el => {
            el.childNodes.forEach(node => {
              if (node.nodeType === Node.TEXT_NODE) {
                node.textContent = replaceBrand(node.textContent);
              }
            });
          });

          console.log('🎨 loadBranding: All visible brand text replaced with:', branding.display_name);
        }

        // Store branding globally for use by other modules
        window.QMT_BRANDING = branding;

    } catch (err) {
        console.error('🎨 loadBranding: Exception occurred during execution:', err);
    }
};

// Call immediately on DOM ready or if already ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => JayShow.loadBranding());
} else {
    JayShow.loadBranding();
}

// Add hash change listener to dynamically update branding without full reload
window.addEventListener('hashchange', () => {
    console.log('🎨 loadBranding: Hash changed, re-initializing branding...');
    JayShow.loadBranding();
});

// Dynamic Asset Loading (DOMPurify for XSS)
(function() {
    if (typeof window !== 'undefined' && !window.DOMPurify) {
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/dompurify@3.1.2/dist/purify.min.js';
        script.async = true;
        document.head.appendChild(script);
    }
})();
